﻿using System;
using System.Collections.Generic;
//using System.Diagnostics.Contracts;
using System.IO.Compression;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
namespace TransportMag.Filters
{
    public class UserAuthenticationFilter : AuthorizeAttribute
    {
        // Protected Overrides Function AuthorizeCore(httpContext As HttpContextBase) As Boolean
        Boolean filterdata=false;
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool SessionCheck = true;
            try
            {
                if (Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SecuredSession"]) == false)
                {
                    SessionCheck = false;
                }
            }
            catch (Exception ex)
            {
                SessionCheck = false;
            }

            if (SessionCheck == false)
            {
                return true;
            }


            if (filterdata == true)
            {
                return true;
            }

            if (httpContext.SkipAuthorization == true)
            {
                return true;
            }

            try
            {
                if (HttpContext.Current.Request.Headers["X-Requested-With"].ToString() != "XMLHttpRequest")
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                return true;
            }

            if (httpContext.Session["loginuser"] == null)
            {
                return false;
            }
            if (httpContext.Request.Headers["userName"] == null)
            {
                return false;
            }
            if (httpContext.Session["loginuser"].ToString() != httpContext.Request.Headers["userName"].ToString())
            {
                return false;
            }
            return true;
        }


        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.User.Identity.IsAuthenticated == false)
            {
                try
                {

                    if (filterContext.HttpContext.Request.Headers["X-Requested-With"].ToString() == "XMLHttpRequest")
                    {
                        filterContext.HttpContext.Response.StatusCode = 401;
                        filterContext.HttpContext.Response.SuppressFormsAuthenticationRedirect = true;
                    }
                }
                catch (Exception ex)
                {
                    filterContext.HttpContext.Response.StatusCode = 200;
                    filterContext.HttpContext.Response.SuppressFormsAuthenticationRedirect = true;
                }
            }
            base.HandleUnauthorizedRequest(filterContext);
        }

        public override void OnAuthorization(AuthorizationContext filterContext)
        {
          
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }
            
            try
            {

                bool filterdata = filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true)
                         || filterContext.ActionDescriptor.ControllerDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true);

               // filterdata = filterContext.ActionDescriptor.GetCustomAttributes(typeof(SkipMyGlobalActionFilterAttribute), false).Any();
                if (filterdata == false)
                {
                   
 

                    if (filterContext.HttpContext.Request.HttpMethod != "GET")
                    {
                        var httpContext = filterContext.HttpContext;
                        if (httpContext.Session["loginuser"] == null)
                        {
                            throw new Exception("Session is Expaired");
                        }
                        if (httpContext.Request.Headers["userName"] == null)
                        {
                            throw new Exception("Session is Expaired");
                        }
                        if (httpContext.Session["loginuser"].ToString() != httpContext.Request.Headers["userName"].ToString())
                        {
                            throw new Exception("Session is Expaired");
                        }
                       // var httpContext = filterContext.HttpContext;
                        var cookie = httpContext.Request.Cookies[AntiForgeryConfig.CookieName];
                        AntiForgery.Validate(cookie != null ? cookie.Value : null, httpContext.Request.Headers["__RequestVerificationToken"]);
                    }
                }
            }
            catch (Exception ex)
            {
                filterContext.HttpContext.Response.StatusCode = 400;
                filterContext.HttpContext.Response.SuppressFormsAuthenticationRedirect = true;
            }
            base.OnAuthorization(filterContext);
        }



        private static bool SkipAuthorization(AuthorizationContext filterContext)
        {
          // Contract.Assert(filterContext != null);
        return filterContext.ActionDescriptor.GetCustomAttributes(typeof(AllowAnonymousAttribute), true).Any()
               || filterContext.ActionDescriptor.ControllerDescriptor.GetCustomAttributes(typeof(AllowAnonymousAttribute), true).Any();
        }
        }

    }


