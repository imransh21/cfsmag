﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Controllers
{
    public class TransportController : Controller
    {
        [HttpPost]
        public JsonResult SaveVehicleData(VehicleMaster pVehicleMaster)
        {
            pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            VehicleMaster.SaveVehicleDtls(pVehicleMaster);  
            return Json(pVehicleMaster, JsonRequestBehavior.AllowGet);   
        }

        [HttpPost]
        public JsonResult GetVehicleLookup(VehicleMaster pVehicleMaster)
        {
            pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVehicleMaster = new ArrayList();
           arrVehicleMaster= VehicleMaster.GetVehicleMasterAllLookup(pVehicleMaster);
           return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetVehicleDtlsByID(VehicleMaster pVehicleMaster)
        {
            pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            VehicleMaster.GetVehicleMasterByID(pVehicleMaster);
            return Json(pVehicleMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetVendorLookup(VendorMaster pVendorMaster)
        {
            pVendorMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVehicleMaster = new ArrayList();
            arrVehicleMaster=VendorMaster.GetVendorMasterAllByType(pVendorMaster);
            return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
        }
    }
}
