﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
         [AllowAnonymous]
        
        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [AllowAnonymous]
        public string ValidateUser(UserMaster pUserMaster)
        {
            if (ModelState.IsValid == true)
            {
                pUserMaster = UserMaster.validateUser(pUserMaster);
                if (pUserMaster.ErrorMessage != "")
                    return JsonConvert.SerializeObject(pUserMaster);

                if (pUserMaster.EmployeeName != null)
                {
                   
                    Session.Add("JobId", pUserMaster.JobId);
                    Session.Add("PasswordChangeDate", pUserMaster.PasswordChangeDate);
                    Session.Add("UserStatus", pUserMaster.UserStatus);
                    Session.Add("AdminUserStatus", pUserMaster.AdminUserStatus);
                    Session.Add("loginuser", pUserMaster.UserName);
                    Session.Add("CustomerId", pUserMaster.CustomerId);
                    Session.Add("loginLocation", pUserMaster.LocationId);
                    Session.Add("UserType", pUserMaster.UserType);
                    Session.Add("CustomerRefCode", pUserMaster.CustomerRefCode);
                    // 'Load Menu
                   System.Collections.ArrayList arrMenuList = GeneralFunctions.PrepareMenuItems((int)pUserMaster.JobId);
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    // -------------- Convert ArrayList it Generic List Collection item 
                    // --------------
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    List<JobMenuDetails> menuList = new List<JobMenuDetails>();
                     menuList = arrMenuList.Cast<JobMenuDetails>().ToList();
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    // -------------- Format the Menu and Sub Menu Items in JSON Object
                    // --------------
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    List<JobMenuDetails> arrFromatedFinMenu = new List<JobMenuDetails>();

                    arrFromatedFinMenu = MyFunction.GetToMenu(menuList);
                    pUserMaster.Menu = arrFromatedFinMenu;
                }
                return JsonConvert.SerializeObject(pUserMaster);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pUserMaster.ErrorMessage = message;
                return JsonConvert.SerializeObject(pUserMaster);
            }
        }

        
        [AllowAnonymous]
        [HttpPost]
        public JsonResult GetAllLocations()
        {
            ArrayList arrLocationMaster = new ArrayList();
            arrLocationMaster = LocationMaster.GetLocationMasterAll();
            return Json(arrLocationMaster, JsonRequestBehavior.AllowGet);
        }


        [AllowAnonymous]
        [HttpPost]
        public string Logout(UserMaster pUserMaster)
        {
            UserMaster p = new UserMaster();
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            return "Done";
        }
    }
}
