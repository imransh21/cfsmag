﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TransportMag.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Maintenance()
        {
            return View();
        }

        public ActionResult Transportation()
        {
            return View();
        }

        public ActionResult TyreManagement()
        {
            return View();
        }

        public ActionResult Monitoring()
        {
            return View();
        }

        public ActionResult Reports()
        {
            return View();
        }

        public ActionResult Analysis()
        {
            return View();
        }

        public ActionResult Configration()
        {
            return View();
        }

        public ActionResult Store()
        {
            return View();
        }

        public ActionResult Warehouse()
        {
            return View();
        }

        public ActionResult SupplierPortal()
        {
            return View();
        }
    }
}
