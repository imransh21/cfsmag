﻿using System.Web.Mvc;

namespace TransportMag.Areas.SupplierPortal
{
    public class SupplierPortalAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "SupplierPortal";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "SupplierPortal_default",
                "SupplierPortal/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
