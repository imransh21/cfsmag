﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.SupplierPortal.Controllers
{
    public class POApprovalController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult POApproval()
        {
            return View();
        }

        [HttpPost]
        public JsonResult AcceptPoDetails(PoHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = PoHdr.SavePoApproveDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetPOLookupForPOApproval(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = PoHdr.GetPolookupForPoApproval(pPoHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetPOPendingList(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            pPoHdr.List = PoHdr.GetPOAprovedList(pPoHdr);
            return Json(pPoHdr.List, JsonRequestBehavior.AllowGet);
        }


          [HttpPost]
        public JsonResult GetPOLookPulist(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            pPoHdr.List = PoHdr.GetPOPedinglookUpList(pPoHdr);
            return Json(pPoHdr.List, JsonRequestBehavior.AllowGet);
        }

        
        [HttpPost]
        public JsonResult UpdatePoDtls(PoHdr pPoHdr)
        {
            //pPoHdr. = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pPoHdr = PoHdr.UpdatePOStatus(pPoHdr);
            return Json(pPoHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetPOApprovalListByDepot(PoHdr pPoHdr)
        {
            DataSet ds;
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = PoHdr.GetPOApprovalByDepot(pPoHdr);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        [System.Web.Mvc.AllowAnonymous]
        public FileContentResult FileDownload(int docRefNo)
        {
            try
            {

                string MimeType = string.Empty;
                //IndentQuotationRequest pIndentQuotationRequest = new IndentQuotationRequest();
                //pIndentQuotationRequest.IndentQuotReqRefId = docRefNo;
                FileContentResult filecontent;
                //IndentQuotationRequest.GetIndentQuotationRequestByID(pIndentQuotationRequest);
                PoHdr pPoHdr = new PoHdr();
                pPoHdr.PoId = docRefNo;
                PoHdr.GetPoHdrByID(pPoHdr);

                if (pPoHdr.PoFilePath  != null)
                {
                    string FileName = Path.GetFileName(pPoHdr.PoFilePath);
                    Byte[] file = System.IO.File.ReadAllBytes(pPoHdr.PoFilePath);
                    if (pPoHdr.PoFilePath.ToUpper().Contains(".DOC"))
                    {
                        MimeType = "application/msword";
                    }
                    else
                    {
                        if (pPoHdr.PoFilePath.ToUpper().Contains(".DOCX"))
                        {
                            MimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                        }
                        else
                        {
                            if (pPoHdr.PoFilePath.ToUpper().Contains(".JPEG") || pPoHdr.PoFilePath.ToUpper().Contains(".JPG"))
                            {
                                MimeType = "image/jpeg";
                            }
                            else
                            {
                                if (pPoHdr.PoFilePath.ToUpper().Contains(".PNG"))
                                {
                                    MimeType = "image/png";
                                }
                                else
                                {
                                    if (pPoHdr.PoFilePath.ToUpper().Contains(".PDF"))
                                    {
                                        MimeType = "application/pdf";
                                    }
                                    else
                                    {
                                        if (pPoHdr.PoFilePath.ToUpper().Contains(".XLS"))
                                        {
                                            MimeType = "application/vnd.ms-excel";
                                        }
                                        else
                                        {
                                            if (pPoHdr.PoFilePath.ToUpper().Contains(".XLSX"))
                                            {
                                                MimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                            }
                                            else
                                            {
                                                if (pPoHdr.PoFilePath.ToUpper().Contains(".BMP"))
                                                {
                                                    MimeType = "image/bmp";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (MimeType == string.Empty)
                    {
                        MimeType = "text/plain";
                    }
                    filecontent = new FileContentResult(file, MimeType);
                    filecontent.FileDownloadName = FileName;
                    return filecontent;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult SaveDelvSchedule(List<PoDeliverySchedule> parrPoDeliverySchedule)
        {
            PoDeliverySchedule p=new PoDeliverySchedule();
            p = PoDeliverySchedule.SavePoDeliverySchedul(parrPoDeliverySchedule);
            return Json(p, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        [System.Web.Mvc.AllowAnonymous]
        public FileContentResult InvoiceDownload(int docRefNo)
        {
            try
            {

                string MimeType = string.Empty;
                //IndentQuotationRequest pIndentQuotationRequest = new IndentQuotationRequest();
                //pIndentQuotationRequest.IndentQuotReqRefId = docRefNo;
                FileContentResult filecontent;
                //IndentQuotationRequest.GetIndentQuotationRequestByID(pIndentQuotationRequest);
                PoInvoiceDetail p = new PoInvoiceDetail();
                p.InvoiceSeqId = docRefNo;
                PoInvoiceDetail.GetPoInvoiceDetailByID(p);

                
                if (p.InvoiceFilePath != null)
                {
                    string FileName = Path.GetFileName(p.InvoiceFilePath);
                    Byte[] file = System.IO.File.ReadAllBytes(p.InvoiceFilePath);
                    if (p.InvoiceFilePath.ToUpper().Contains(".DOC"))
                    {
                        MimeType = "application/msword";
                    }
                    else
                    {
                        if (p.InvoiceFilePath.ToUpper().Contains(".DOCX"))
                        {
                            MimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                        }
                        else
                        {
                            if (p.InvoiceFilePath.ToUpper().Contains(".JPEG") || p.InvoiceFilePath.ToUpper().Contains(".JPG"))
                            {
                                MimeType = "image/jpeg";
                            }
                            else
                            {
                                if (p.InvoiceFilePath.ToUpper().Contains(".PNG"))
                                {
                                    MimeType = "image/png";
                                }
                                else
                                {
                                    if (p.InvoiceFilePath.ToUpper().Contains(".PDF"))
                                    {
                                        MimeType = "application/pdf";
                                    }
                                    else
                                    {
                                        if (p.InvoiceFilePath.ToUpper().Contains(".XLS"))
                                        {
                                            MimeType = "application/vnd.ms-excel";
                                        }
                                        else
                                        {
                                            if (p.InvoiceFilePath.ToUpper().Contains(".XLSX"))
                                            {
                                                MimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                            }
                                            else
                                            {
                                                if (p.InvoiceFilePath.ToUpper().Contains(".BMP"))
                                                {
                                                    MimeType = "image/bmp";
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (MimeType == string.Empty)
                    {
                        MimeType = "text/plain";
                    }
                    filecontent = new FileContentResult(file, MimeType);
                    filecontent.FileDownloadName = FileName;
                    return filecontent;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPost]
        public JsonResult SaveInvoiceDetails(PoInvoiceDetail pPoInvoiceDetail)
        {
            if (pPoInvoiceDetail.InvoiceSeqId == 0)
            {
                PoInvoiceDetail.Insert(pPoInvoiceDetail);
            }
            else
            {
                PoInvoiceDetail.Update(pPoInvoiceDetail);
            }

            return Json(pPoInvoiceDetail, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ContentResult fileupload(HttpPostedFileBase file, String newFileName, int InvoiceSeqId)
        {
            try
            {

                var fileName = Path.GetFileName(file.FileName);
                String contentType = file.ContentType;
                String filepath;
                filepath = Path.Combine(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["FileUploadPath"]), newFileName);
                file.SaveAs(filepath);

                PoInvoiceDetail P = new PoInvoiceDetail();
                P.InvoiceSeqId = InvoiceSeqId;
                P.InvoiceFilePath = filepath;
                PoInvoiceDetail.UpdateFilePath(P);
                return new ContentResult() { ContentType = "text/plain", Content = filepath, ContentEncoding = Encoding.UTF8 };
            }
            catch (Exception ex)
            {
                return null;
            }
        }




    }
}
