﻿app.controller("KeyRefrenceCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, KeyRefrenceCtrlAJService) {
 
    $scope.clickSubNode = function (strHeadCode, strGroupCode) {
        debugger;
        $scope.HeadCode = strHeadCode;
        $scope.GroupCode = strGroupCode;
        GetMasterData();
    };

    GetMainNodeList();

    $scope.updFlag = function (row) {
        debugger;


        if (row.Pkey > 0) {
            row.OldSortValue = row.SortKey;
            row.OldCodeValue = row.CodeValue;
            row.Flag = "U";
        }
        else {
            row.Flag = "E";
        }
    }

    $scope.canceledit = function (row) {
        debugger;
        row.SortKey = row.OldSortValue;
          row.CodeValue=row.OldCodeValue;

            row.Flag = "E";
       
    }


    var rows = 10;

    function addRow() {
        debugger;
        if ($scope.KeyReferenceList == undefined) {
            $scope.KeyReferenceList = [];

        }
        if ($scope.KeyReferenceList.length < rows) {
            for (k = $scope.KeyReferenceList.length; k < rows; k++) {

                var newItem = [{ SortKey: 0, CodeValue: "", DefaultYn: "N", Pkey: 0, Flag: 'A' }]

                $scope.KeyReferenceList.push(newItem[0]);

            }
        }

    }

    $scope.AddNewRow = function () {
        debugger;

        var newItem = [{ SortKey: 0, CodeValue: "", DefaultYn: "N", Pkey: 0, Flag: 'A' }]

        $scope.KeyReferenceList.push(newItem[0]);




    }



    function GetMasterData() {
        debugger;
        var KeyReference = {
            HeadCode: $scope.HeadCode,
          GroupCode:  $scope.GroupCode
        };

        var getData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        getData.then(function (pKeyReference) {
            debugger;
            $scope.KeyReferenceList1 = pKeyReference.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.KeyReferenceList = $scope.KeyReferenceList1;
            addRow();
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Tariff Heads information " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;
        var i1 = 0;
        debugger;
        for (i1 = 0; i1 < $scope.KeyReferenceList.length; i1++) {
            debugger;
            if (($scope.KeyReferenceList[i1].CodeValue == undefined || $scope.KeyReferenceList[i1].CodeValue == "") && $scope.KeyReferenceList[i1].Pkey > 0) {

                $scope.setclass = "popupBase alert alertShowMsg";
                $scope.errMsg = "Blank Code Value.";
                $scope.isError = true;
                var id = "txtCodeValue" + "" + i1
                $scope.Var = id;
                return;
            }

            if (($scope.KeyReferenceList[i1].SortKey == undefined || $scope.KeyReferenceList[i1].SortKey == "") && $scope.KeyReferenceList[i1].Pkey > 0) {

                $scope.setclass = "popupBase alert alertShowMsg";
                $scope.errMsg = "Blank Sort Key.";
                $scope.isError = true;
                var id = "txtSortKey" + "" + i1
                $scope.Var = id;
                return;
            }
        }

        //if ($scope.JobName == undefined || $scope.JobName == "") {
        //    $scope.setclass = "popupBase alert alertShowMsg";
        //    $scope.errMsg = "Enter Role Name.";
        //    $scope.isError = true;
        //    return;
        //}
        var i = 0, j = 0;

        for (i = 0; i < $scope.KeyReferenceList.length; i++) {
            for (j = i + 1 ; j < $scope.KeyReferenceList.length; j++) {
                debugger;
                if ($scope.KeyReferenceList[i].CodeValue == ($scope.KeyReferenceList[j].CodeValue)) {
                    // got the duplicate element
                    if ($scope.KeyReferenceList[i].CodeValue != "") {
                        $scope.setclass = "popupBase alert alertShowMsg";
                        $scope.errMsg = "Code Value " + $scope.KeyReferenceList[i].CodeValue + " Is Duplicate.";
                        $scope.isError = true;
                        var id = "txtCodeValue" + "" + j
                        $scope.Var = id;
                        return;
                    }
                }
            }
        }

        if (emptyData == false) {
            debugger;

            //var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);
            var KeyReference = {
                HeadCode: $scope.HeadCode,
                GroupCode:  $scope.GroupCode,
                List: $scope.KeyReferenceList
            };

            var saveData = KeyRefrenceCtrlAJService.saveData(KeyReference);
            saveData.then(function (pVehicleTypeMaster) {

                if (pVehicleTypeMaster.data.ErrorMessage != null && pVehicleTypeMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pVehicleTypeMaster.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.errMsg = "";
                    $scope.isError = false;
                    $scope.setclassSuccessful = "popupBase alert alertShowMsg";
                    $scope.SuccessMsg = "Data Saved Successfully.";
                    //VehicleTypeList();
                    GetMasterData();
                }
            }, function () {
                clearFields();
                //$(JobMasterS).each(function (index, item) {
                //    if (item.Key == 'Message3') {
                //        $scope.setclass = "popupBase alert alertShowMsg";
                //        $scope.errMsg = item.value;
                //    }
                //});

                $scope.isError = true;
                return;
            });
        }
    }

    $scope.closeErrorPopup = function () {
        $scope.setclass = "popupBase alert"
        $scope.errMsg = '';
        $scope.isError = false;
        if ($scope.Var != undefined) {
            setTimeout(function () { $("#" + $scope.Var).focus(); }, 500)
        }
    }

    $scope.ExitDtls = function () {

        getIndexpage();
    }
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Configration";

    }

    $scope.CancelDtls = function () {

        GetMainNodeList();

    }


    function GetMainNodeList() {
        var GetData = KeyRefrenceCtrlAJService.GetMainNodeList();

        GetData.then(function (pCustomers) {
            debugger;
            $scope.MainNodeList1 = pCustomers.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.MainNodeList = $scope.MainNodeList1;
            $scope.clickSubNode($scope.MainNodeList[0].List[0].HeadCode, $scope.MainNodeList[0].GroupCode)
            //GetAllCustomers();

        }, function (reason) {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in getting Customer Configuration " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    
});