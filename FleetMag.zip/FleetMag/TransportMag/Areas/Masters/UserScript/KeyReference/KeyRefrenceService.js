﻿app.service("KeyRefrenceCtrlAJService", function ($http) {

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/KeyRefrence/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.getMasterData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/KeyRefrence/LoadMasterData",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }
  
    this.GetMainNodeList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/KeyRefrence/LoadAllMainNode",
            dataType: "json"
        });
        return response;
    }
});