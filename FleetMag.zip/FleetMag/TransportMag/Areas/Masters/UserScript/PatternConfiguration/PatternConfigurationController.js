﻿app.controller("mvcPatternConfigurationCtrl", function ($scope, $localStorage, $compile, $filter, PatternConfigurationAJService, HomeIndex, KeyRefrenceCtrlAJService, ErrorMsgDisplay) {
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.isShownPattern = true;
    $scope.NoOfAxle = 1
    GetVehicleTypeList();
    GetPositionList();
    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            debugger;
            $scope.VehicleTypeList = Response.data;
            //var defaultval = {
            //    VehicleTypeCode: 0,
            //    VehicleType: 'Select'
            //}
            //  $scope.VehicleType = Response.data;
            //   $scope.ManufacturerList.unshift(defaultval);


        }, function (reason) {
            $scope.errMsg = "Error in getting VesselTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };
    var rows = 1;
    $scope.NoOfAxelCount = 1;
    addRow();




    function GetPositionList() {
        var KeyReference = {
            HeadCode: 'Position',
            GroupCode: 'Tyre'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.PositionList = [];
        GetData.then(function (Response) {
            debugger;
            $scope.PositionList = Response.data;
            //var defaultval = {
            //    VehicleTypeCode: 0,
            //    VehicleType: 'Select'
            //}
            //  $scope.VehicleType = Response.data;
            //   $scope.ManufacturerList.unshift(defaultval);


        }, function (reason) {
            $scope.errMsg = "Error in getting VesselTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function addRow() {

        if ($scope.NoOfAxellist == undefined) {
            $scope.NoOfAxellist = [];

        }
        if ($scope.NoOfAxellist.length < rows) {
            for (k = $scope.NoOfAxellist.length; k < rows; k++) {

                var newItem = [{ NoOfLAxel: 0, NoOfRightTyres: 0 }]

                $scope.NoOfAxellist.push(newItem[0]);

            }
        }

    }


    $scope.SetLeftAxel = function (index, NoOfLAxel) {
        debugger;
        $scope.LeftCurrentIndex = index;
        $scope.NoOfAxellist[$scope.LeftCurrentIndex].NoOfLeftAxel = undefined;
        if ($scope.NoOfAxellist[$scope.LeftCurrentIndex].NoOfLeftAxel == undefined) {
            $scope.NoOfAxellist[$scope.LeftCurrentIndex].NoOfLeftAxel = [];
        }

        // if ($scope.NoOfAxel[$scope.LeftCurrentIndex].NoOfLeftAxel.length < NoOfLAxel) {
        for (k = $scope.NoOfAxellist[$scope.LeftCurrentIndex].NoOfLeftAxel.length; k < NoOfLAxel; k++) {
            var newItem = [{ NoOfLeftAxel: "" }]
            $scope.NoOfAxellist[$scope.LeftCurrentIndex].NoOfLeftAxel.push(newItem[0]);

            //    }
        }

    }



    //$scope.SetRightAxel = function (index, NoOfAxle) {
    //    debugger;
    //    $scope.RightCurrentIndex = index;
    //    $scope.NoOfAxel[$scope.RightCurrentIndex].NoOfRightAxel = undefined;
    //    if ($scope.NoOfAxel[$scope.RightCurrentIndex].NoOfRightAxel == undefined) {
    //        $scope.NoOfAxel[$scope.RightCurrentIndex].NoOfRightAxel = [];
    //    }


    //        for (k = $scope.NoOfAxel[$scope.RightCurrentIndex].NoOfRightAxel.length; k < NoOfRAxel; k++) {
    //            var newItem = [{ NoOfRightAxel: "" }]
    //            $scope.NoOfAxel[$scope.RightCurrentIndex].NoOfRightAxel.push(newItem[0]);


    //    }

    //}

    $scope.AddNewRow = function () {
        debugger;
        var newItem = [{ NoOfLAxel: 0, NoOfRAxel: "", NoOfRightAxel: [], NoOfLeftAxel: [] }]

        $scope.NoOfAxellist.push(newItem[0]);

        $scope.NoOfAxle = $scope.NoOfAxellist.length;


    }




    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;
        var i1 = 0;
        debugger;


        if ($scope.ConfigName == undefined || $scope.ConfigName == "") {


            $scope.errMsg = "Please Enter Pattern Name"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtConfigName").val('');
            setTimeout(function () {
                $("#txtConfigName").focus();
            }, 500);
            return;
        }
        if ($scope.VehicleType == undefined || $scope.VehicleType == "") {


            $scope.errMsg = "Please Select Vehicle Type"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#drpVehicleType").val('');
            setTimeout(function () {
                $("#drpVehicleType").focus();
            }, 500);
            return;
        }


        if (emptyData == false) {
            debugger;

            //var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);
            var VehicleAxleConfigHdr = {
                AxleConfigId:$scope.AxleConfigId,
                ConfigName: $scope.ConfigName,
                VehicleType: $scope.VehicleType,
                NoOfAxle: $scope.NoOfAxle,
                vVehicleAxleConfigDtls: $scope.NoOfAxellist
            };

            var saveData = PatternConfigurationAJService.saveData(VehicleAxleConfigHdr);
            saveData.then(function (pVehicleAxleConfigHdr) {

                if (pVehicleAxleConfigHdr.data.ErrorMessage != null && pVehicleAxleConfigHdr.data.ErrorMessage != "") {
                    $scope.errMsg = pVehicleAxleConfigHdr.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    debugger;
                    $scope.isShown = true;
                    $scope.isShownbtn = true
                    $scope.errMsg = "";
                    $scope.isError = false;
                    //         $scope.AssetIntId = pVehicleAxleConfigHdr.data;
                    //    $scope.SearchAssetCodeDtls();
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    //VehicleTypeList();
                    //GetMasterData();

                }
            }, function () {
                clearFields();
                //$(JobMasterS).each(function (index, item) {
                //    if (item.Key == 'Message3') {
                //        $scope.setclass = "popupBase alert alertShowMsg";
                //        $scope.errMsg = item.value;
                //    }
                //});

                $scope.isError = true;
                return;
            });
        }
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownPattern = true;
    }
    function clearData() {
        $scope.ConfigName = undefined;
        $scope.VehicleType = undefined;
        $scope.NoOfAxellist = undefined;
        addRow();
        $scope.NoOfAxle = 1
    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }


    $scope.AddDtls = function () {
        debugger;
        clearData();
        //$scope.isShownSave = true;
        $scope.isShownbtn = false
        $scope.isShownS = false;
        $scope.isShownPattern = false;
        $scope.isShownE = false;


    }

    $scope.SearchDtls = function () {
        // $scope.isShownE = false;
        clearData();
        $scope.isShownS = true;
        $scope.isShownPattern = false;
        $scope.isShownEdit = true;
        $('#txtConfigName').show();
        $('#txtConfigName').autocomplete({

            source: function (request, response) {
                debugger;
                $scope.AxleConfigId = undefined;
                var getUrl = window.location;
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                $.ajax({
                    url: baseUrl + '/Masters/PatternConfiguration/GetPatternNameAuto',
                    data: "{ 'prefixText': '" + request.term + "'}",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map($.parseJSON(data), function (item, key) {
                            return {
                                label: item.ConfigName,
                                ConfigName: item.ConfigName,
                                AxleConfigId: item.AxleConfigId,
                                VehicleType: item.VehicleType,
                                NoOfAxle: item.NoOfAxle
                            }
                        }))
                    },
                    error: function (response) {

                    },
                    failure: function (response) {

                    }
                });
            },
            select: function (e, i) {
                debugger;
                var $scope = angular.element(document.getElementById('bigformBooking')).scope();
                $scope.AxleConfigId = i.item.AxleConfigId;
                $scope.ConfigName = i.item.ConfigName;
                $scope.NoOfAxle = i.item.NoOfAxle;
                $scope.VehicleType = i.item.VehicleType;
                PatternDetails();
                $scope.isShownPattern = true;
                $scope.$apply();
                //alert($scope.VesselCode);


            },
            minLength: 1
        });

    }



    function PatternDetails() {
        debugger;
        if ($scope.AxleConfigId == undefined || $scope.AxleConfigId == 0) {
            $scope.errMsg = "Invalid asset code.";
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.isShown = true;
            $scope.isShownbtn = true
            $scope.isShownAssetNo = false;
            clearData();
            $scope.isError = true;
            $scope.isShownS = true;
            return;
        }

        var PatternData = {
            AxleConfigId: $scope.AxleConfigId
            //VesselName: $scope.VesselName
        };

        var getData = PatternConfigurationAJService.GetPatternDataById(PatternData);
        getData.then(function (PatternData) {
            $scope.errMsg = "";
            $scope.isError = false;
            debugger;
            if (PatternData.data.ErrorMessage != null) {
                $scope.errMsg = PatternData.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";

                $scope.isError = true;
                return;
            }

            $scope.NoOfAxellist = PatternData.data;


            if ($scope.NoOfAxellist.length > 0) {
                for (k = 0 ; k < $scope.NoOfAxellist.length; k++) {
                    for (i = 0; i < $scope.NoOfAxellist[k].NoOfRightTyres; i++) {

                        if ($scope.NoOfAxellist[k].NoOfLeftAxel == undefined) {
                            $scope.NoOfAxellist[k].NoOfLeftAxel = [];
                        }
                        var newItem = [{ NoOfLeftAxel: "" }]

                        $scope.NoOfAxellist[k].NoOfLeftAxel.push(newItem[0]);
                    }

                }
            }

            $scope.isShownEdit = false;
           $scope.isShown = true;


        }, function () {

            clearData();
            $scope.isError = true;




            return;
        });
    };


    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = true;
        $scope.isShownS = false;
    }
});