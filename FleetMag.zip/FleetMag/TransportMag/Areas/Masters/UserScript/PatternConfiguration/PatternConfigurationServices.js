﻿app.service("PatternConfigurationAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.saveData = function (pKeyReference) {
        debugger;
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/PatternConfiguration/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.GetPatternDataById =function(pVehicleManufacturerDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/PatternConfiguration/GetPatternDataById",
            data: JSON.stringify(pVehicleManufacturerDetails),
            dataType: "json"
        });
        return response;
    }
});