﻿app.service("VendorMasterAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/VendorMaster/saveData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetAllVendor = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/VendorMaster/GetAllVendor",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.getVendorById = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/VendorMaster/GetAllVendorbyId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
});
