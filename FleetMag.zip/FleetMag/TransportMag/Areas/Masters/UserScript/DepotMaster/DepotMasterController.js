﻿app.controller("mvcDepoMasterCtrl", function ($scope, $localStorage, $compile, $filter, DepotAJService, HomeIndex) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.UserLocationsList = [];
    var appendlst = "";
    //GetLOcationLists("");

    GetJobLists();


    //AddNew();
    GetDepotList();


    if ($scope.DepotId != undefined) {
        if ($scope.DepotId.length > 0) {
            $scope.UserId = $scope.DepotId[0].DepotId;
            $scope.commonSource($scope.UserId);
        }
    }

    $("#btnAdd").focus();
   

    function GetJobLists() {
        //  debugger;
        var getData = DepotAJService.GetAllJobs();

        getData.then(function (Response) {
            $scope.JobList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Roles " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetDepotList() {
        debugger;
        var GetData = DepotAJService.GetAllDepot();
        
        GetData.then(function (pDepot) {
            debugger;
            $scope.DepotList = pDepot.data;
            $scope.errMsg = "";
            $scope.isError = false;

            GetAllDepot();

        }, function (reason) {
            $(UserMasterS).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    function GetAllDepot() {
        debugger;
        var uiEle = angular.element(document.querySelector('#LpDepotList'));
        $('#LpDepotList').html('');
        angular.forEach($scope.DepotList, function (value, key) {
            if (!jQuery.isEmptyObject(value.DepotName)) {
                appendlst = appendlst + "<li><a href=\"#\" ng-click=\"commonSource('" + value.DepotId + "')\"><span class=\"fa fa-caret-right tree-icon\"></span>" + value.DepotName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var uList = $compile(appendlst)($scope);
        uiEle.append(uList);
        appendlst = "";
    }

    function showFirst(DepotId) {
        debugger;
        var DepotMaster = {
            DepotId: DepotId
        };
        var getData = DepotAJService.getDepotById(DepotMaster);
        getData.then(function (pDepotMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pDepotMaster.data.ErrorMessage != null) {
                $scope.errMsg = pDepotMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.DepotId = pDepotMaster.data.DepotId;
            $scope.DepotCode = pDepotMaster.data.DepotCode;
            $scope.DepotName = pDepotMaster.data.DepotName;
            $scope.DepotAddress = pDepotMaster.data.DepotAddress;
            $scope.ContactPerson = pDepotMaster.data.ContactPerson;
            $scope.MobileNo = pDepotMaster.data.MobileNo;
            $scope.MailId = pDepotMaster.data.MailId;

            var o = {
                DepotName: pDepotMaster.data.DepotName
            };

            //GetLOcationLists(o);

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.commonSource = function (DepotId) {
        debugger;
        showFirst(DepotId);
    }

    $scope.filter = function () {
        var elem = document.getElementById('LpDepotList');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchDepot) != -1 || $scope.SrchDepot == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }
    // ---------------------
    function isValidEmailAddress(emailAddress) {
        var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
        return pattern.test(emailAddress);
    };
    //--------------------------------------
    $scope.SaveDtls = function () {
        debugger;
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;

        if ($scope.DepotCode == undefined || $scope.DepotCode == "") {
            $scope.errMsg = "Depot Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDepotCode").focus();
            return;
        }       
        if ($scope.DepotAddress == undefined || $scope.DepotAddress == "") {
            $scope.errMsg = "Depot Address is required or Invalid Employee";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDepotAddress").focus();
            return;
        }
        if ($scope.MailId == undefined || $scope.MailId == "") {
            $scope.errMsg = "Mail Id is required or Invalid MailId";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtMailId").focus();
            return;
        }
        if ($scope.MobileNo == undefined || $scope.MobileNo == "") {
            $scope.errMsg = "Mobile No  is required or Invalid Mobile No";
            $scope.isError = true;
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtMobile").focus();
            return;
        }




        //-------- Port Data ---------------

        var myRedObjectsNEW = $filter('filter')($scope.UserLocationsList, { Flag: "N" });
        var myRedObjectsEDIT = $filter('filter')($scope.UserLocationsList, { Flag: "U" });

        if (emptyData == false) {
            var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);

            var arrList = [];
            debugger;
           

            var DepotMaster = {
                DepotId:$scope.DepotId,
                DepotCode:$scope.DepotCode,
                DepotName: $scope.DepotName,
                DepotAddress: $scope.DepotAddress,
                ContactPerson: $scope.ContactPerson,
                MobileNo: $scope.MobileNo,
                MailId: $scope.MailId,
                EmployeeName: $scope.EmployeeName,
                MailId: $scope.MailId

                //UserLocationsList: arrList
            };

            var saveData = DepotAJService.saveUserData(DepotMaster);

            saveData.then(function (pDepotMaster) {
                debugger;
                if (pDepotMaster.data.ErrorMessage != null && pDepotMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pDepotMaster.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.isShownEdit = true;
                    $scope.errMsg = "";
                    $scope.isError = false;
                    //$scope.TerminalList = [];
                    //clearTerminalList();
                    //GetAllServicePorts();
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    debugger;
                    GetDepotList();
                    $scope.DepotId = pDepotMaster.data.DepotId;
                    showFirst($scope.DepotId);
                }
            }, function () {
                clearFields();
                $(UserMasterS).each(function (index, item) {
                    if (item.Key == 'Message3') {
                        $scope.setclass = "popupBase alert alertShowMsg";
                        $scope.errMsg = item.value;
                    }
                });

                $scope.isError = true;
                return;
            });
        }







    }


    function AddNew() {
        $scope.UserLocationsList = [];
        //for (var i = 0; i < 5; i++) {
        //    var pService = {SeqNbr: "", RailIcdId: ""};
        //    $scope.ServicePorts.push(pService);
        //}

        var pDepotMaster = {
            DepotMaster: ''
        };
       // GetLOcationLists(pUserMaster);
    }


    $scope.updFlag = function (row) {

        var strlen = 0;
        // if (row.SeqNbr != undefined && row.RailIcdId != "") {
        var str = $filter('filter')($scope.UserLocationsList, { UtpId: row.UtpId });
        strlen = str.length;
        //  }
        //else {
        //    strlen = 0;
        //}

        if (row.UtpId > 0) {
            row.Flag = "U";
        }
        else {
            row.Flag = "N";
        }
    }



    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();

        AddNew();
        $scope.isShown = false;
        $scope.isShownEdit = false;
    }
    //====================================================End Add Event=====================================================================//

    var watchList = $scope.$watch('DepotList', function () {
        if ($scope.DepotList != undefined) {
            showFirst($scope.DepotList[0].DepotId);
            watchList();
        }
    });
    //====================================================Add Event=====================================================================//
    $scope.CancelDtls = function () {
        debugger;
        clearData();
        AddNew();
        $scope.isShown = true;
        $scope.isShownEdit = true;

        if ($scope.DepotId == undefined || $scope.DepotId == 0 || $scope.DepotId == "") {
            clearData();

            var watchList = $scope.$watch('DepotList', function () {
                showFirst($scope.DepotList[0].DepotId);
                watchList();
            });
        }
    }
    //====================================================End Add Event=====================================================================//
    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = true;

    }
    //====================================================End Edit Event=====================================================================//
    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
    //====================================================End Cancel Event=====================================================================//
    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.DepotCode = undefined;
        $scope.DepotName = undefined;
        $scope.DepotAddress = undefined;
        $scope.ContactPerson = undefined;
        $scope.MobileNo = undefined;
        $scope.MailId = undefined;
        $scope.DepotId = undefined;
       // $scope.JobId = undefined;
      
        $scope.UserLocationsList = [];
    }
    //====================================================End Clear form data=====================================================================//
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    //====================================================Add New Row Event=====================================================================//
    //$scope.AddNewDtls = function () {

    //    var pService = {
    //        //ServiceId: "0", ServiceCode: "", ServiceName: "", Flag: "N", RailOperatorId: "", CtoIcdCode: "", ServiceStatus: "N"
    //        SeqNbr: "", RailIcdId:""
    //    };        
    //    $scope.ServicePorts.push(pService);
    //}
    //====================================================End Add New Row Event=====================================================================//
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
});

