﻿app.service("ItemMasterAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetUsedForList = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/GetUsedList",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }

    this.GetMakeList = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/GetMakeList",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }

    this.GetVendorLists = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/GetVendorList",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }

    this.saveUserData = function (UserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/SaveDetails",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetTreeView = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/GetTreeView",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }

    this.getItemById = function (UserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/LoadItemById",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }


    this.GetUnit = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/LoadAllUnit",
            dataType: "json"
        });
        return response;
    }


    this.GetDepotList = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ItemsMaster/GetDepotList",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }


});