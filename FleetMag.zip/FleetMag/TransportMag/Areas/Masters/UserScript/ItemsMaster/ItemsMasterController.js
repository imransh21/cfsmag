﻿app.controller("ItemCntrl", function ($scope, $localStorage, $compile, $filter, ItemMasterAJService, HomeIndex, ErrorMsgDisplay) {

    $scope.MakeList = [];
    $scope.VendorList = [];
    var rows = 10;
    function addRow() {
        if ($scope.VendorList == undefined || $scope.VendorList == "" || $scope.VendorList == null) {
            $scope.VendorList = [];
        }



        if ($scope.VendorList.length < rows) {
            for (k = $scope.VendorList.length; k < rows; k++) {
                var newItem = [{ VendorName: "", VendorId: 0 }]
                $scope.VendorList.push(newItem[0]);
            }
        }

    }
    addRow();
    function MakeaddRow() {


        if ($scope.MakeList == undefined || $scope.MakeList == "" || $scope.MakeList == null) {
            $scope.MakeList = [];
        }




        if ($scope.MakeList.length < rows) {
            for (k = $scope.MakeList.length; k < rows; k++) {
                var newItem = [{ MakeDesc: "", KeyId: 0 }]

                $scope.MakeList.push(newItem[0]);

            }
        }

    }
    MakeaddRow();
    GetUsedForLists();
    //  GetMakeLists();
    //GetVendorLists();
    GetTreeView();
    GetUnitLists();
    $scope.isShownTypeDrp = true;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.isShownTreeEdit = false;
    $scope.SelectAllData = 'N';

    function GetUsedForLists() {
        //   debugger;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetUsedForList(o);

        getData.then(function (Response) {
            $scope.UsedForList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetDepotLists() {
        //   debugger;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetDepotList(o);

        getData.then(function (Response) {
            $scope.DepotList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetUnitLists() {
        //   debugger;
        var getData = ItemMasterAJService.GetUnit();

        getData.then(function (Response) {
            $scope.UnitList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Roles " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetMakeLists() {
        //   debugger;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetMakeList(o);

        getData.then(function (Response) {
            $scope.MakeList = Response.data;

            MakeaddRow();
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVendorLists() {
        //   debugger;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetVendorLists(o);

        getData.then(function (Response) {
            $scope.VendorList = Response.data;
            addRow();
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    $scope.MinStocLevelCheckMain = function () {


        var Total = 0;
        var TotalMin = $scope.MinStocLevel;
        debugger;
        if ($scope.MinStocLevel == '' || $scope.MinStocLevel == undefined) {
            $scope.errMsg = "Please Enter Minimum stock value."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtMinStocLevelid").val('');
            setTimeout(function () {
                $("#txtMinStocLevelid").focus();
            }, 500);
            return;
        }
        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel);
                }
            }
            if (parseFloat(Total) > parseFloat(TotalMin)) {
                $scope.errMsg = "Total Minimum stock value is greater than  Minimum stock"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtMinStocLevelid").val('');
                setTimeout(function () {
                    $("#txtMinStocLevelid").focus();
                }, 500);
                return;
            }

        }
    }


    $scope.MinStocLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.MinStocLevel;
        debugger;
        if ($scope.MinStocLevel == '' || $scope.MinStocLevel == undefined) {
            $scope.errMsg = "Please Enter Minimum stock value."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtMinStocLevelid").val('');
            setTimeout(function () {
                $("#txtMinStocLevelid").focus();
            }, 500);
            return;
        }
        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel);
                }
            }
            if (parseFloat(Total) > parseFloat(TotalMin)) {
                $scope.errMsg = "Total Minimum stock value is greater than  Minimum stock."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                id = "#txtMinimumStockLevel" + "" + index;
                $(id).val('');
                setTimeout(function () {
                    $(id).focus();
                }, 500);
                return;
            }

        }
    }



    $scope.ReOrderLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.ReOrderLevel;
        debugger;
        if ($scope.ReOrderLevel == '' || $scope.ReOrderLevel == undefined) {
            $scope.errMsg = "Please Enter Re Order stock value."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtReOrderLevelid").val('');
            setTimeout(function () {
                $("#txtReOrderLevelid").focus();
            }, 500);
            return;
        }
        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].ReOrderLevel != '' || $scope.DepotList[i].ReOrderLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].ReOrderLevel);
                }
            }
            if (parseFloat(Total) > parseFloat(TotalMin)) {
                $scope.errMsg = "Total ReOrder Level value is greater than ReOrder Level."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                id = "#txtROLevel" + "" + index;
                $(id).val('');
                setTimeout(function () {
                    $(id).focus();
                }, 500);
                return;
            }

        }
    }

    $scope.DongLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.DangerLevel;
        debugger;
        if ($scope.DangerLevel == '' || $scope.DangerLevel == undefined) {
            $scope.errMsg = "Please Enter Danger stock value."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtDangerLevel").val('');
            setTimeout(function () {
                $("#txtDangerLevel").focus();
            }, 500);
            return;
        }
        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].DangerLevel != '' || $scope.DepotList[i].DangerLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].DangerLevel);
                }
            }
            if (parseFloat(Total) > parseFloat(TotalMin)) {
                $scope.errMsg = "Total Danger Level value is greater than Danger Level."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                id = "#txtDongLevel" + "" + index;
                $(id).val('');
                setTimeout(function () {
                    $(id).focus();
                }, 500);
                return;
            }

        }
    }


    $scope.AddDtls = function () {
        debugger;
        $scope.ItemId = undefined;
        $scope.isShown = false;
        $scope.isShownEdit = true;
        $scope.isShownTypeDrp = false
        $scope.isShownTreeEdit = true;
        GetUsedForLists();
        GetDepotLists();
        addRow();
        MakeaddRow();
        $('#scrolling-listSearch').find('button').attr('disabled', 'disabled');
        //$scope.isShownS = false;
        //$scope.isShownPattern = false;
        //$scope.isShownE = false;


    }


    $scope.SelectAllRows = function () {
        angular.forEach($scope.UsedForList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.KeyStatus = 'Y';
            }
            else {
                if ($scope.SelectAllData == 'Y') {
                    value.KeyStatus = 'N';
                }
            }
        })
    };
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;


        //var myRedObjectsNEW = $filter('filter')($scope.UserLocationsList, { Flag: "N" });
        //var myRedObjectsEDIT = $filter('filter')($scope.UserLocationsList, { Flag: "U" });

        if ($scope.ItemType == undefined || $scope.ItemType == "") {
            $scope.errMsg = "Please Select Item Type."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstGroupItem").val('');
            setTimeout(function () {
                $("#lstGroupItem").focus();
            }, 500);
            return;
        }

        if ($scope.ItemCode == undefined || $scope.ItemCode == "") {
            $scope.errMsg = "Please Enter Item Code."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemCode").val('');
            setTimeout(function () {
                $("#txtItemCode").focus();
            }, 500);
            return;
        }

        if ($scope.ItemName == undefined || $scope.ItemName == "") {
            $scope.errMsg = "Please Enter Item Name."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemName").val('');
            setTimeout(function () {
                $("#txtItemName").focus();
            }, 500);
            return;
        }
        if ($scope.ItemDesc == undefined || $scope.ItemDesc == "") {
            $scope.errMsg = "Please Enter Item Desc."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemDesc").val('');
            setTimeout(function () {
                $("#txtItemDesc").focus();
            }, 500);
            return;
        }





        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.MinStocLevel)) {
                    $scope.errMsg = "Total Minimum stock value is Not Equal to  Minimum stock."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    //id = "#txtMinimumStockLevel" + "" + index;
                    //$(id).val('');
                    //setTimeout(function () {
                    //    $(id).focus();
                    //}, 500);
                    return;
                }
            }
        }



        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].ReOrderLevel != '' || $scope.DepotList[i].ReOrderLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].ReOrderLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.ReOrderLevel)) {
                    $scope.errMsg = "Total ReOrder Level value is Not Equal to ReOrder Level."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    //id = "#txtROLevel" + "" + index;
                    //$(id).val('');
                    //setTimeout(function () {
                    //    $(id).focus();
                    //}, 500);
                    return;
                }
            }

        }

        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].DangerLevel != '' || $scope.DepotList[i].DangerLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].DangerLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.DangerLevel)) {
                    $scope.errMsg = "Total Danger Level value is Not Equal to Danger Level."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    //id = "#txtDongLevel" + "" + index;
                    //$(id).val('');
                    //setTimeout(function () {
                    //    $(id).focus();
                    //}, 500);
                    return;
                }
            }

        }


        VendorListData = $scope.VendorList.filter(function (value) {
            return value.VendorId != undefined && value.VendorId != "";
        });
        debugger;

        if ($scope.ItemType == "I") {


            if ($scope.MinStocLevel == '' || $scope.MinStocLevel == undefined || $scope.MinStocLevel <=0 ) {
                $scope.errMsg = "Please Enter Minimum stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtMinStocLevelid").val('');
                setTimeout(function () {
                    $("#txtMinStocLevelid").focus();
                }, 500);
                return;
            }

            if ($scope.ReOrderLevel == '' || $scope.ReOrderLevel == undefined ||$scope.ReOrderLevel <=0) {
                $scope.errMsg = "Please Enter Re order Level stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtReOrderLevelid").val('');
                setTimeout(function () {
                    $("#txtReOrderLevelid").focus();
                }, 500);
                return;
            }

            if ($scope.DangerLevel == '' || $scope.DangerLevel == undefined || $scope.DangerLevel <=0) {
                $scope.errMsg = "Please Enter Danger stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtDangerLevel").val('');
                setTimeout(function () {
                    $("#txtDangerLevel").focus();
                }, 500);
                return;
            }

            if (VendorListData.length <= 0) {
                debugger;
                $scope.errMsg = "Please Enter atleast one vendor";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }
            debugger;
            makeListData = $scope.MakeList.filter(function (value) {
                return value.KeyId != undefined && value.KeyId != "";
            });

            if (makeListData.length <= 0) {
                debugger;
                $scope.errMsg = "Please Enter atleast one Make";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }

            UsedListData = $scope.UsedForList.filter(function (value) {
                return value.KeyStatus =="Y";
            });
            if (UsedListData.length <= 0) {
                debugger;
                $scope.errMsg = "Please Select atleast one Used For";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }

        }
        if ($scope.VendorList.length != null || $scope.VendorList.length != undefined) {
            for (i = 0; i < $scope.VendorList.length; i++) {
                for (j = i + 1 ; j < $scope.VendorList.length; j++) {
                    if ($scope.VendorList[i].VendorId == ($scope.VendorList[j].VendorId)) {
                        // got the duplicate element
                        if ($scope.VendorList[i].VendorId != "") {
                            $scope.errMsg = "Vendor Name " + $scope.VendorList[i].VendorName + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        }


        if ($scope.MakeList.length != null || $scope.MakeList.length != undefined) {
            for (i = 0; i < $scope.MakeList.length; i++) {
                for (j = i + 1 ; j < $scope.MakeList.length; j++) {
                    if ($scope.MakeList[i].KeyId == ($scope.MakeList[j].KeyId)) {
                        // got the duplicate element
                        if ($scope.MakeList[i].KeyId != "") {
                            $scope.errMsg = "Make Name " + $scope.MakeList[i].MakeDesc + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        }


        if (emptyData == false) {
            //var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);

            var arrList = [];
            debugger;
            //if ($scope.VendorList != undefined && $scope.VendorList.length != 0) {
            //    for (var i = 0; i < $scope.VendorList.length; i++) {
            //        if ($scope.VendorList[i].VendorDesc != '') {

            //            if ($scope.VendorList[i].UtpId != "") {
            //                VendorId = $scope.VendorList[i].VendorId;
            //            }


            //            var pLists = {
            //                UserName: $scope.UserName,
            //                LocationId: $scope.UserLocationsList[i].LocationId,
            //                UtpId: vUtpId,
            //                UserId: 0,
            //                CustomerId: 0,
            //                ParentCustomerId: 0,
            //                CreatedOn: '',
            //                CreatedBy: '',
            //                ModifiedBy: '',
            //                ModifiedOn: '',
            //                ActiveStatus: $scope.UserLocationsList[i].ActiveStatus,
            //                ErrorMessage: ''


            //            }
            //            if ($scope.UserLocationsList[i].ActiveStatus == 'Y') {
            //                arrList.push(pLists);
            //            }
            //        }
            //    }
            //}

            //if (arrList.length <= 0) {
            //    $scope.errMsg = "Please Select atleast one location.";
            //    $scope.isError = true;
            //    $scope.isError = true;
            //    ErrorPopupMsg('ErrorDiv');
            //    //$("#drpJobId").focus();
            //    return;
            //}
            var InventoryItemMaster = {
                ItemId: $scope.ItemId,
                PItemId: $scope.PItemId,
                ItemType: $scope.ItemType,
                ItemName: $scope.ItemName,
                ItemCode: $scope.ItemCode,
                FinLedgerCode: $scope.FinLedgerCode,
                ItemDesc: $scope.ItemDesc,
                MinStocLevel: $scope.MinStocLevel,
                AverageRate: $scope.AverageRate,
                ReOrderLevel: $scope.ReOrderLevel,
                DangerLevel: $scope.DangerLevel,
                CurrStockDetail: $scope.CurrStockDetail,
                UomId: $scope.UomId,
                //CreatedOn: $scope.CreatedOn,


                VendorList: $scope.VendorList,
                DepotList: $scope.DepotList,
                MakeList: $scope.MakeList,
                UsedForList: $scope.UsedForList
            };

            var saveData = ItemMasterAJService.saveUserData(InventoryItemMaster);
            saveData.then(function (pItemMasterAJService) {

                if (pItemMasterAJService.data.ErrorMessage != null && pItemMasterAJService.data.ErrorMessage != "") {
                    //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                    //$scope.setclass = "popupBase alert alertShowMsg";
                    //$scope.isError = true;
                    $scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.isShownEdit = true;

                    $scope.isError = false;
                    $scope.isShownTreeEdit = false;
                    //$scope.TerminalList = [];
                    //clearTerminalList();
                    //GetAllServicePorts();
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    clearData();
                    count = 0;
                    appendlst = "";
                    var uiEle = angular.element(document.querySelector('#trview'));
                    uiEle.html('');
                    $scope.TreeViewList = undefined;
                    GetTreeView();
                    $('#scrolling-listSearch').find('button').removeAttr('disabled', 'disabled');
                    //      GetUserList();
                    //$scope.UserId = pUserMaster.data.UserId;
                    // showFirst($scope.UserId);
                }
            }, function () {
                clearFields();
                $(UserMasterS).each(function (index, item) {
                    if (item.Key == 'Message3') {
                        $scope.setclass = "popupBase alert alertShowMsg";
                        $scope.errMsg = item.value;
                    }
                });

                $scope.isError = true;
                return;
            });
        }

    }


    function GetTreeView() {
        debugger;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetTreeView(o);

        getData.then(function (Response) {

            $scope.TreeViewList = Response.data;
            menuList($scope.TreeViewList.Menu);
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    //function menuList() {
    //    debugger;
    //    //var menu = $sessionStorage.menu;
    //    //var menu = $.grep($scope.TreeViewList, function (item, index) {
    //    //    return item.ItemCode === $sessionStorage.ItemCode;
    //    //});




    //    var menu = $scope.TreeViewList.Menu;
    //    var appendlst = "";
    //    var uiEle = angular.element(document.querySelector('#trview'));
    //    uiEle.html('');
    //    angular.forEach(menu, function (value, key) {
    //        if (!jQuery.isEmptyObject(value)) {
    //            appendlst = appendlst + "<li class=\"nav-item\">" +
    //                                                "<button type=\"button\"  ng-click=\"commonSource('" + value.ItemId + "'," + "'" + value.ItemCode + "'," + value.PItemId + ",'" + value.ItemType + "')\">" +
    //                                                    "<span class='fa fa-file menu-icon'></span>" +
    //                                                    "<label id=\"\" >" + value.ItemCode + " </label>" +
    //                                                    "<span class=\"caret\"></span>" +
    //                                                "</button>" +
    //                                                "<ul>";

    //            angular.forEach(value.SubMenu, function (value, key) {
    //                appendlst = appendlst + "<li class=\"nav-item\"><button type=\"button\" ng-click=\"commonSource('" + value.ItemId + "'," + "'" + value.ItemCode + "'," + value.PItemId + ",'" + value.ItemType + "'" + ")\">" + value.ItemCode + "</button></li>";
    //                $('#' + value.ItemCode).attr('data-title', value.ItemCode);
    //            });
    //            appendlst = appendlst + "</ul></li>";
    //        }
    //    });
    //     //uiEle.remove();
    //    var menulst = $compile(appendlst)($scope);
    //    uiEle.append(menulst);
    //    appendlst = "";
    //    $('.list-item a').click(function () {
    //        $('.list-item').removeClass('active');
    //        $(this).closest('li').toggleClass('active');
    //    });
    //}

    var appendlst = "";
    var count = 0;
    //   menuList($scope.TreeViewList.Menu);
    function menuList(menu) {
        debugger;
        //var menu = $sessionStorage.menu;
        //var menu = $.grep($scope.TreeViewList, function (item, index) {
        //    return item.ItemCode === $sessionStorage.ItemCode;
        //});
        $('#scrolling-listSearch .fa-spinner').css({ 'display': 'block' });


        if (count == 0) {
            appendlst = appendlst + "<ul id='trview' class='treeView groupView' >";
            count = count + 1;
        } else {
            appendlst = appendlst + "<ul class='Lbod'>";

        }


        angular.forEach(menu, function (value, key) {
            if (!jQuery.isEmptyObject(value)) {
                appendlst = appendlst + "<li class=\"nav-item\">" +
                                                    "<button type=\"button\"  ng-click=\"commonSource('" + value.ItemId + "'," + "'" + value.ItemCode + "'," + value.PItemId + ",'" + value.ItemType + "')\">" +
                                                        "<span></span>" + value.ItemName +
                                                       // "<label id=\"\" >" +  + " </label>" +
                                                        //"<span class=\"fa fa-caret-up\"></span>" +
                                                    "</button>"

                if (value.SubMenu.length != 0) {
                    menuList(value.SubMenu);
                }

                appendlst = appendlst + "</li>";


            }

        });
        appendlst = appendlst + "</ul>";
        //uiEle.remove();
        var menulst = $compile(appendlst)($scope);
        var uiEle = angular.element(document.querySelector('#trview'));
        uiEle.html('');
        uiEle.replaceWith(menulst);

        $('#scrolling-listSearch .fa-spinner').css({ 'display': 'none' });
        $('#scrolling-listSearch li button').click(function () {
            $('#scrolling-listSearch li').removeClass('active');
            $(this).closest('li').find('ul').toggleClass('hide');
            $(this).closest('li').addClass('active');
        });
    }


    $scope.commonSource = function (ItemId, ItemCode, PItemId, ItemType) {
        debugger;
        $scope.isShownEdit = false;
        //showFirst(ItemId);
        $scope.ItemId = ItemId;
        $scope.ParentCode = ItemCode;
        $scope.PItemId = ItemId
        $scope.ItemType = ItemType
        $scope.ItemTypeTemp = ItemType
        if ($scope.ItemType == 'G') {
            $('#divGroup').removeClass('hide');
            $('#divItem').addClass('hide');
        }
        else {
            $('#divItem').removeClass('hide');
            $('#divGroup').addClass('hide');
        }
    }


    function showFirst(ItemId) {
        var ItemMaster = {
            ItemId: ItemId
        };

        var getData = ItemMasterAJService.getItemById(ItemMaster);
        getData.then(function (pItemMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pItemMaster.data.ErrorMessage != null) {
                $scope.errMsg = pItemMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }

            $scope.ItemId = pItemMaster.data.ItemId;
            $scope.PItemId = pItemMaster.data.PItemId;
            $scope.ItemType = pItemMaster.data.ItemType;
            $scope.ItemName = pItemMaster.data.ItemName;
            $scope.ParentCode = pItemMaster.data.ParentCode;
            $scope.ItemCode = pItemMaster.data.ItemCode;
            $scope.FinLedgerCode = pItemMaster.data.FinLedgerCode;
            $scope.ItemDesc = pItemMaster.data.ItemDesc;
            $scope.MinStocLevel = pItemMaster.data.MinStocLevel;
            $scope.ReOrderLevel = pItemMaster.data.ReOrderLevel;

            $scope.DangerLevel = pItemMaster.data.DangerLevel;
            $scope.UomId = pItemMaster.data.UomId;
            $scope.AverageRate = pItemMaster.data.AverageRate;

            GetDepotLists();
            GetUsedForLists();
            GetMakeLists();
            GetVendorLists();
            $scope.isShownTreeEdit = true;
            if ($scope.ItemType == 'G') {
                $('#divGroup').removeClass('hide');
                $('#divItem').addClass('hide');
            }
            else {
                $('#divItem').removeClass('hide');
                $('#divGroup').addClass('hide');
            }

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }



    $scope.EditDtls = function () {
        $scope.isShownTypeDrp = true;
        $scope.isShown = false;
        $scope.isShownEdit = true;
        $scope.isShownTreeEdit = true;
        $('#scrolling-listSearch').find('button').attr('disabled', 'disabled');
        showFirst($scope.ItemId);

        //$scope.isShownEdit = true;
        //$scope.isShownS = false;
    }
    $scope.TypeChnage = function (type) {

        if (type == 'G') {

            if ($scope.ItemTypeTemp == "I") {
                $scope.errMsg = "Can Not Add Group Under Item."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstGroupItem").val('');
                setTimeout(function () {
                    $("#lstGroupItem").focus();
                }, 500);
                return;
            }

            $('#divGroup').removeClass('hide');
            $('#divItem').addClass('hide');
        }
        else {
            if ($scope.PItemId == undefined || $scope.PItemId == 0) {
                $scope.errMsg = "Please Select Group"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstGroupItem").val('');
                setTimeout(function () {
                    $("#lstGroupItem").focus();
                }, 500);
                return;
            }
            else {
                $('#divItem').removeClass('hide');
                $('#divGroup').addClass('hide');
            }
        }


    }


    function clearData() {
        debugger;
        $scope.ItemId = undefined;
        $scope.PItemId = undefined;
        $scope.ItemType = undefined;
        $scope.ItemName = undefined;
        $scope.ItemCode = undefined;
        $scope.FinLedgerCode = undefined;
        $scope.ItemDesc = undefined;
        $scope.MinStocLevel = undefined;
        $scope.ReOrderLevel = undefined;
        $scope.ParentCode = undefined;
        $scope.DangerLevel = undefined;
        $scope.UomId = undefined;
        $scope.AverageRate = undefined;
        $scope.VendorList = undefined;
        $scope.DepotList = undefined;
        $scope.ItemTypeTemp = undefined;
        $scope.MakeList = undefined;
        $scope.UsedForList = undefined;
        $scope.SelectAllData = 'N';
    }


    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownTreeEdit = false;
        $scope.isShownTypeDrp = true;
        $('#divGroup').removeClass('hide');
        $('#divItem').addClass('hide');
        $('#scrolling-listSearch').find('button').removeAttr('disabled', 'disabled');
        //$scope.isShownbtn = true
        //$scope.isShownAssetNo = true;

    }

    //app.directive("tree", function (RecursionHelper) {
    //    return {

    //        restrict: "E",
    //        scope: { family: '=' },
    //        template:
    //        '<ul class="listView">' +
    //        //'<li ng-repeat="Main in family.SubMenu"><span class="fa fa-caret-right tree-icon"></span>{{ Main.ItemCode}}' +

    //          '<li ng-repeat="Main in family.SubMenu"><a href=\"#\" ng-click=\"commonSource(Main)\"><span class="fa fa-caret-right tree-icon"></span>{{ Main.ItemCode}} </a>' +
    //          //'<li ng-repeat="Main in family.SubMenu"><span class="fa fa-caret-right tree-icon" ></span>{{ Main.ItemCode}} {{Main.ItemId}} ' +

    //                 '<tree family="Main" ></tree>' +
    //        '</li></ul>',

    //        compile: function (element) {
    //            return RecursionHelper.compile(element, function (scope, iElement, iAttrs, controller, transcludeFn) {

    //                // Define your normal link function here.
    //                // Alternative: instead of passing a function,
    //                // you can also pass an object with 
    //                // a 'pre'- and 'post'-link function.
    //            });
    //        }
    //    };
    //});


    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }



    $scope.AddNewRow = function () {
        debugger;
        if ($scope.VendorList == undefined || $scope.VendorList == "" || $scope.VendorList == null) {
            $scope.VendorList = [];
        }
        var newItem = [{ VendorName: "", VendorId: 0 }]

        $scope.VendorList.push(newItem[0]);




    }

    $scope.AddNewRowMake = function () {
        debugger;
        if ($scope.MakeList == undefined || $scope.MakeList == "" || $scope.MakeList ==null) {
            $scope.MakeList = [];
        }
        var newItem = [{ MakeDesc: "", KeyId: 0 }]

        $scope.MakeList.push(newItem[0]);




    }
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }


    $scope.filter = function () {
        debugger;
        var elem = document.getElementById('trview');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchUser) != -1 || $scope.SrchUser == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }


});