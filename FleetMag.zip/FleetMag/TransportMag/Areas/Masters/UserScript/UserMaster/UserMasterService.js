﻿app.service("UserAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.GetAllLocations = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/LoadAllLocations",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }
    this.saveUserData = function (UserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/SaveDetails",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }
    this.GetAllUsers = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/LoadAllUsers",
            dataType: "json"
        });
        return response;
    }
    this.GetAllJobs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/LoadAllJobs",
            dataType: "json"
        });
        return response;
    }
    this.getUserById = function (UserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/LoadUserById",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }
})