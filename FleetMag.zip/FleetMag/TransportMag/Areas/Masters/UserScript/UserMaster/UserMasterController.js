﻿app.controller("mvcUserCtrl", function ($scope, $localStorage, $compile, $filter, UserAJService, HomeIndex) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.UserLocationsList = [];
    var appendlst = "";
    //GetLOcationLists("");

    GetJobLists();


    //AddNew();
    GetUserList();
    

    if ($scope.UserList != undefined) {
        if ($scope.UserList.length > 0) {
            $scope.UserId = $scope.UserList[0].UserId;
            $scope.commonSource($scope.UserId);
        }
    }

    $("#btnAdd").focus();

    function GetLOcationLists(pUserMaster) {
        //   debugger;
        var getData = UserAJService.GetAllLocations(pUserMaster);

        getData.then(function (Response) {
            $scope.UserLocationsList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    
    


    $('#txtEmployeeName').autocomplete({
        
        source: function (request, response) {
            // alert('hi');
            $scope.EmployeeId = undefined;
            var getUrl = window.location;
            var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
            debugger;
            $.ajax({
             
                url: baseUrl + '/UserMaster/LoadAllEmpByBranchAuto',
                //data: "{ 'BranchId': " + $localStorage.locationId + ",'EmployeeName':'" + request.term + "'}",
                data: "{ 'BranchId': " + 1 + ",'EmployeeName':'" + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map((data), function (item, key) {
                        return {
                            label: item.EmployeeName,
                         
                            EmployeeId: item.EmpId

                        }
                    }))
                },
                error: function (response) {
                    //alert(response.responseText);
                },
                failure: function (response) {
                    //alert(response.responseText);
                }
            });
        },
        select: function (e, i) {

            var $scope = angular.element(document.getElementById('divUser')).scope();
            $scope.EmployeeId = i.item.EmployeeId;
            $scope.EmployeeName = i.item.label;
           

        },
        minLength: 1
    });

    function GetJobLists() {
     //   debugger;
        var getData = UserAJService.GetAllJobs();

        getData.then(function (Response) {
            $scope.JobList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Roles " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetUserList() {
        var GetData = UserAJService.GetAllUsers();

        GetData.then(function (pUsers) {
            debugger;
            $scope.UserList = pUsers.data;
            $scope.errMsg = "";
            $scope.isError = false;

            GetAllUsers();

        }, function (reason) {
            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    function GetAllUsers() {

        var uiEle = angular.element(document.querySelector('#LpUser'));
        $('#LpUser').html('');
        angular.forEach($scope.UserList, function (value, key) {
            if (!jQuery.isEmptyObject(value.UserName)) {
                appendlst = appendlst + "<li><a href=\"#\" ng-click=\"commonSource('" + value.UserId + "')\"><span class=\"fa fa-caret-right tree-icon\"></span>" + value.UserName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var uList = $compile(appendlst)($scope);
        uiEle.append(uList);
        appendlst = "";
    }
    function showFirst(UserId) {
        var UserMaster = {
            UserId: UserId
        };

        var getData = UserAJService.getUserById(UserMaster);
        getData.then(function (pUserMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pUserMaster.data.ErrorMessage != null) {
                $scope.errMsg = pUserMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }

            $scope.UserId = pUserMaster.data.UserId;
            $scope.UserName = pUserMaster.data.UserName;
            $scope.Password = pUserMaster.data.Password;
            $scope.UserType = pUserMaster.data.UserType;
            $scope.EmployeeId = pUserMaster.data.EmployeeId;
            $scope.EmployeeName = pUserMaster.data.EmployeeName;
            $scope.MailId = pUserMaster.data.MailId;
            $scope.CustomerId = pUserMaster.data.CustomerId;
            $scope.CustomerRefCode = pUserMaster.data.CustomerRefCode;

            $scope.MobileNo = pUserMaster.data.MobileNo;

            $scope.UserStatus = pUserMaster.data.UserStatus;
            $scope.JobId = pUserMaster.data.JobId;
            $scope.AdminUserStatus = pUserMaster.data.AdminUserStatus;

            var o = {
                UserName: pUserMaster.data.UserName
            };

            GetLOcationLists(o);

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }
    $scope.commonSource = function (UserId) {
        showFirst(UserId);
    }


    $scope.filter = function () {
        var elem = document.getElementById('LpUser');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchUser) != -1 || $scope.SrchUser == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }
   // ---------------------
    function isValidEmailAddress(emailAddress) {
        var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
        return pattern.test(emailAddress);
    };
    //--------------------------------------
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;

        if ($scope.UserName == undefined || $scope.UserName == "") {
            $scope.errMsg = "User Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtUserName").focus();
            return;}
        else if ($scope.UserName.length<6){
            $scope.errMsg = "User Name should be minimum 6 characters";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtUserName").focus();
            return;
        }
        
        if ($scope.Password == undefined || $scope.Password == "") {
            $scope.errMsg = "Password is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtPassword").focus();
            return;
        }

        else {
            if ($scope.Password.length < 8 || $scope.Password.length > 15)
            {
                $scope.errMsg = "Password Length Should be between 8 to 15 characters";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPassword").focus();
                return;
            }
            if ($scope.Password.indexOf(" ") > 0) {
                $scope.errMsg = "Password cannot have spaces.";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPassword").focus();
                return;
            }

            var allLetters = /^[a-zA-Z]+$/;
            var letter = /[a-zA-Z]/;
            var number = /[0-9]/;
            var specialChar = /(?=.*[!@#$%^&*])/;


            if (!number.test($scope.Password)) {
                $scope.errMsg = "Password should contain at least one numeric.";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPassword").focus();
                return;
            }

            if (!letter.test($scope.Password)) {
                $scope.errMsg = "Password should contain at least one alphabet.";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPassword").focus();
                return;
            }
            if (!specialChar.test($scope.Password)) {
                $scope.errMsg = "Password should contain at least one special character.";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPassword").focus();
                return;
            }
        }
        if ($scope.EmployeeId == undefined || $scope.EmployeeId == "") {
            $scope.errMsg = "Employee is required or Invalid Employee";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtEmployeeName").focus();
            return;
        }
        if ($scope.MailId == undefined || $scope.MailId == "") {
            $scope.errMsg = "Mail Id is required or Invalid MailId";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
             $("#txtMailId").focus();
            return;
        }
        if ($scope.MobileNo == undefined || $scope.MobileNo == "") {
            $scope.errMsg = "Mobile No  is required or Invalid Mobile No";
            $scope.isError = true;
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
             $("#txtMobile").focus();
            return;
        }

        if ($scope.JobId == undefined || $scope.JobId == "") {
            $scope.errMsg = "Role Id Required.";
            $scope.isError = true;
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#drpJobId").focus();
            return;
        }

        //if (!isValidEmailAddress($scope.MailId) && $scope.MailId != '') {
        //    $(UserMasterS).each(function (index, item) {
        //        if (item.Key == 'Message7') {
        //            $scope.setclass = "popupBase alert alertShowMsg";
        //            $scope.errMsg = item.value;
        //            return;
        //        }
        //    });
        //    $scope.isError = true;
        //    return;
        //}
        
        //var arrServicePortList = [];
        //if ($scope.ServicePorts.length != 0) {
        //    for (var i = 0; i < $scope.ServicePorts.length; i++) {
        //        if ($scope.ServicePorts[i].RailIcdId > 0) {
        //            var pLists = {
                        
        //                SeqNbr: $scope.ServicePorts[i].SeqNbr,
        //                RailIcdId: $scope.ServicePorts[i].RailIcdId
        //            }
        //            arrServicePortList.push(pLists);
        //        }
        //    }
        //}



       

        //-------- Port Data ---------------
        
        var myRedObjectsNEW = $filter('filter')($scope.UserLocationsList, { Flag: "N" });
        var myRedObjectsEDIT = $filter('filter')($scope.UserLocationsList, { Flag: "U" });
    
        if (emptyData == false) {
            var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);

            var arrList = [];
            debugger;
            if ($scope.UserLocationsList != undefined && $scope.UserLocationsList.length != 0) {
                for (var i = 0; i < $scope.UserLocationsList.length; i++) {
                    if ($scope.UserLocationsList[i].LocationId != '' ) {
                        var vUtpId=0;
                        if ($scope.UserLocationsList[i].UtpId != "")
                        {
                            vUtpId  = $scope.UserLocationsList[i].UtpId;
                        }
                        

                        var pLists = {
                            UserName: $scope.UserName,
                            LocationId: $scope.UserLocationsList[i].LocationId,
                            UtpId: vUtpId,
                            UserId: 0,
                            CustomerId: 0,
                            ParentCustomerId: 0,
                            CreatedOn: '',
                            CreatedBy: '',
                            ModifiedBy: '',
                            ModifiedOn: '',
                            ActiveStatus: $scope.UserLocationsList[i].ActiveStatus,
                            ErrorMessage: ''

                            
                        }
                        if ($scope.UserLocationsList[i].ActiveStatus == 'Y') {
                            arrList.push(pLists);
                        }
                    }
                }
            }

            if (arrList.length<=0)
            {
                $scope.errMsg = "Please Select atleast one location.";
                $scope.isError = true;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                //$("#drpJobId").focus();
                return;
            }
            var UserMaster = {
                UserId: $scope.UserId,
                UserName: $scope.UserName,
                Password: $scope.Password,
                UserType: $scope.UserType,
                EmployeeId: $scope.EmployeeId,
                EmployeeName: $scope.EmployeeName,
                MailId: $scope.MailId,
                CustomerId: $scope.CustomerId,
                CustomerRefCode: $scope.CustomerRefCode,
                MobileNo: $scope.MobileNo,
                UserStatus: $scope.UserStatus,
               
                //CreatedBy: $scope.CreatedBy,
                //CreatedOn: $scope.CreatedOn,
                JobId: $scope.JobId,
                
                AdminUserStatus: $scope.AdminUserStatus,

                UserLocationsList: arrList
            };

            var saveData = UserAJService.saveUserData(UserMaster);
            saveData.then(function (pUserMaster) {

                if (pUserMaster.data.ErrorMessage != null && pUserMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pUserMaster.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.isShownEdit = true;
                    $scope.errMsg = "";
                    $scope.isError = false;
                    //$scope.TerminalList = [];
                    //clearTerminalList();
                    //GetAllServicePorts();
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                   
                    GetUserList();
                    $scope.UserId = pUserMaster.data.UserId;
                    showFirst($scope.UserId);
                }
            }, function () {
                clearFields();
                $(UserMasterS).each(function (index, item) {
                    if (item.Key == 'Message3') {
                        $scope.setclass = "popupBase alert alertShowMsg";
                        $scope.errMsg = item.value;
                    }
                });

                $scope.isError = true;
                return;
            });
        }

      





    }

   
    function AddNew() {
        $scope.UserLocationsList = [];
        //for (var i = 0; i < 5; i++) {
        //    var pService = {SeqNbr: "", RailIcdId: ""};
        //    $scope.ServicePorts.push(pService);
        //}

        var pUserMaster = {
            UserName: ''
        };
        GetLOcationLists(pUserMaster);
    }

    
    $scope.updFlag = function (row) {

        var strlen = 0;
       // if (row.SeqNbr != undefined && row.RailIcdId != "") {
        var str = $filter('filter')($scope.UserLocationsList, { UtpId: row.UtpId });
            strlen = str.length;
      //  }
        //else {
        //    strlen = 0;
        //}

        if (row.UtpId > 0) {
            row.Flag = "U";
        }
        else {
            row.Flag = "N";
        }
    }


    
    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();

        AddNew();
        $scope.isShown = false;
        $scope.isShownEdit = false;
    }
    //====================================================End Add Event=====================================================================//

    var watchList = $scope.$watch('UserList', function () {
        if ($scope.UserList != undefined) {
            showFirst($scope.UserList[0].UserId);
            watchList();
        }
    });
    //====================================================Add Event=====================================================================//
    $scope.CancelDtls = function () {
        clearData();
        AddNew();
        $scope.isShown = true;
        $scope.isShownEdit = true;

        if ($scope.UserId == undefined || $scope.UserId == 0 || $scope.UserId == "") {
            clearData();

            var watchList = $scope.$watch('UserList', function () {
                showFirst($scope.UserList[0].UserId);
                watchList();
            });
        }
    }
    //====================================================End Add Event=====================================================================//
    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = true;

    }
    //====================================================End Edit Event=====================================================================//
    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
    //====================================================End Cancel Event=====================================================================//
     //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.UserId = undefined;
        $scope.UserName = undefined;
        $scope.Password = undefined;
        $scope.UserType = undefined;
        $scope.EmployeeId = undefined;
        $scope.EmployeeName = undefined;
        $scope.MailId = undefined;
        $scope.CustomerId = undefined;
        $scope.CustomerRefCode = undefined;
        $scope.MobileNo = undefined;
       
        
        $scope.JobId = undefined;
       
        $scope.AdminUserStatus = 'N';

        $scope.ActiveStatus = 'N';
        $scope.UserLocationsList = [];
    }
    //====================================================End Clear form data=====================================================================//
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    //====================================================Add New Row Event=====================================================================//
    //$scope.AddNewDtls = function () {

    //    var pService = {
    //        //ServiceId: "0", ServiceCode: "", ServiceName: "", Flag: "N", RailOperatorId: "", CtoIcdCode: "", ServiceStatus: "N"
    //        SeqNbr: "", RailIcdId:""
    //    };        
    //    $scope.ServicePorts.push(pService);
    //}
    //====================================================End Add New Row Event=====================================================================//
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
});

