﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class RoleDefinitionController : Controller
    {
        //
        // GET: /Masters/RoleDefinition/

        public ActionResult RoleDefinition()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult LoadAllJobs()

        {
            ArrayList arrJobs = JobMaster.GetJobMasterAll();

            var JobList = arrJobs;
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }

        // Loads JobID and JobName
        [HttpPost]
        public JsonResult LoadJobById(JobMaster pJobMaster)
        {
            pJobMaster = JobMaster.GetJobMasterByID(pJobMaster);

            return Json(pJobMaster, JsonRequestBehavior.AllowGet);
        }

        // Loads Empty Menu's
        [HttpPost]
        public JsonResult LoadMenuItems()
        {
            ArrayList arrJobs = ExtendedJobMenuItems.GetMenuDtlsAll();

            var JobList = arrJobs;
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }

        // Loads Menu details with permissions for perticular job id.
        [HttpPost]
        public JsonResult LoadAllJobMenuItems(JobMaster pJobMaster)
        {
            ArrayList arrJobs = ExtendedJobMenuItems.GetJobMenuDtlsAll(pJobMaster);

            var JobList = arrJobs;/*JsonConvert.SerializeObject(arrJobs, Formatting.None);*/
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDetails(ExtendedJobMaster pJobMaster)
        {
            if (ModelState.IsValid == true)
            {
                pJobMaster = ExtendedJobMaster.InsertUpdates(pJobMaster);
                return Json(pJobMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pJobMaster.ErrorMessage = message;
                return Json(pJobMaster, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
