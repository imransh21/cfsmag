﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class TaxGroupsMasterController : Controller
    {

        public ActionResult TaxGroupsMaster()
        {
            return PartialView();
        }

      
        [HttpPost]
        public JsonResult SaveDetails(TaxGroups pTaxGroups)
        {
            if (ModelState.IsValid == true)
            {
                pTaxGroups.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

                pTaxGroups = TaxGroups.InsertUpdateDetails(pTaxGroups);

                if (pTaxGroups.ErrorMessage != "")
                    return Json(pTaxGroups, JsonRequestBehavior.AllowGet);

                return Json(pTaxGroups, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pTaxGroups.ErrorMessage = message;

                return Json(pTaxGroups, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadAllTaxGroups(int LocationId)
        {
            ArrayList arrEmp = TaxGroups.GetTaxGroupsAll(LocationId);

           // var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadTaxGroupsByID(TaxGroups pTaxGroups)
        {
            pTaxGroups = TaxGroups.GetTaxGroupsByID(pTaxGroups);

            return Json(pTaxGroups, JsonRequestBehavior.AllowGet);
        }

    }
}
