﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class PatternConfigurationController : Controller
    {
        //
        // GET: /Masters/RoleDefinition/


     
        public ActionResult PatternConfiguration()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult SaveDetails(VehicleAxleConfigHdr pVehicleAxleConfigHdr)
        {

            pVehicleAxleConfigHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ;// Session["loginuser"].ToString();
            pVehicleAxleConfigHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ; //Session["loginuser"].ToString();
           // pVehicleAxleConfigHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pVehicleAxleConfigHdr = VehicleAxleConfigHdr.InsertUpdateDetails(pVehicleAxleConfigHdr);


            return Json(pVehicleAxleConfigHdr, JsonRequestBehavior.AllowGet);


        }


        [HttpPost]
        public JsonResult GetPatternNameAuto(string prefixText)
        {
            DataSet ds;
            ds = VehicleAxleConfigHdr.GePatternLookup(prefixText);
            var pResultList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(pResultList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetPatternNameAutoVehicleType(string prefixText,long vehicleTypeId)
        {
            DataSet ds=new DataSet();
           ds = VehicleAxleConfigHdr.GePatternLookupVehicleType(prefixText, vehicleTypeId);
            var pResultList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(pResultList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetPatternDataById(VehicleAxleConfigDtls pVehicleAxleConfigDtls)
        {
        ArrayList  arrlist = VehicleAxleConfigDtls.GetVehicleAxleConfigDtlsByID1(pVehicleAxleConfigDtls);


            // pVehicleManufacturerDetails.DeckList = VesselDeckMaster.GetVesselDeckMasterAll(pVehicleManufacturerDetails.VesselCode)

            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }

      

    }
}
