﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class VendorMasterController : Controller
    {


        public ActionResult VendorIndex()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult saveData(VendorMaster pVendorMaster)
        {
            if (ModelState.IsValid == true)
            {
                try
                {
                    pVendorMaster.ErrorMessage = "";
                    pVendorMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                    pVendorMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                    
                }
                catch (Exception ex)
                {
                    pVendorMaster.ErrorMessage = "Session Out, Kindly ReLogin.";
                }

                if (pVendorMaster.ErrorMessage == "")
                {
                    pVendorMaster = VendorMaster.InsertUpdateDetails(pVendorMaster);
                }
                return Json(pVendorMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pVendorMaster.ErrorMessage = message;

                return Json(pVendorMaster, JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult GetAllVendor(VendorMaster pVendorMaster)
        {
            pVendorMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVendorMaster = VendorMaster.GetVendorMasterAll(pVendorMaster);

            //var UserList = JsonConvert.SerializeObject(arrUsers, Formatting.None);
            var VendorList = arrVendorMaster;
            return Json(VendorList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetAllVendorbyId(VendorMaster pVendorMaster)
        {
            pVendorMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pVendorMaster = VendorMaster.GetVendorMasterByID(pVendorMaster);
            return Json(pVendorMaster, JsonRequestBehavior.AllowGet);
        }



        public JsonResult GetAllVendorForReapair(VendorMaster pVendorMaster)
        {
            //pVendorMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVendorMaster = VendorMaster.GetVendorMasterRepaire(pVendorMaster);

            //var UserList = JsonConvert.SerializeObject(arrUsers, Formatting.None);
            var VendorList = arrVendorMaster;
            return Json(VendorList, JsonRequestBehavior.AllowGet);
        }
    }
}
