﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class ServiceScheduleMstController : Controller
    {

        public ActionResult ServiceScheduleMst()
        {
            return PartialView();
        }


        [HttpPost]
        public JsonResult GetALLItemMasterLookup(InventoryItemMaster pInventoryItemMaster)
        {
            ArrayList ItemList = new ArrayList();
            pInventoryItemMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            ItemList = InventoryItemMaster.GetAllItemSLookUpAll(pInventoryItemMaster);
            return Json(ItemList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDetails(ScheduleServiceHdr pScheduleServiceHdr)
        {
            pScheduleServiceHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pScheduleServiceHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            ScheduleServiceHdr.SaveDetails(pScheduleServiceHdr);
            return Json(pScheduleServiceHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetALLServiceSchedulelist(ScheduleServiceHdr pScheduleServiceHdr)
        {  

            ArrayList Servicelist = new ArrayList();
            Servicelist = ScheduleServiceHdr.GetScheduleServiceHdrAll(pScheduleServiceHdr);
            return Json(Servicelist, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteItemBySchdtlID(ScheduleServiceDtls pScheduleServiceHdr)
        {
            //pScheduleServiceHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            //pScheduleServiceHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            ScheduleServiceHdr.DeleteItemBySchDtlID(pScheduleServiceHdr);
            return Json(pScheduleServiceHdr, JsonRequestBehavior.AllowGet);
        }



    }
}
