﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class CustomerMasterController : Controller
    {
        //
        // GET: /Masters/CustomerMaster/

        public ActionResult CustomerMaster()
        {
            return PartialView();
        }
        [HttpPost()]
        public JsonResult LoadAllCustomerTypes()
        {
            ArrayList arrCustomerTypes = CustomerTypeMaster.GetCustomerTypeMasterAll();
           
            // With...
            return Json(arrCustomerTypes, JsonRequestBehavior.AllowGet);
        }



        [HttpPost()]
        public JsonResult GetStateMasterAll(string prefixText)
        {
            ArrayList arrCustomerTypes = StateMaster.GetStateMasterAllAuto(prefixText);
                  
            // With...
            return Json(arrCustomerTypes, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult GetCityMasterAll(string prefixText)
        {
            ArrayList arrCustomerTypes = CityMaster.GetCityMasterAllAuto(prefixText);

            // With...
            return Json(arrCustomerTypes, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult LoadAllCustomers()
        {
            ArrayList arrCustomers = CustomerMastercls.GetCustomerMasterAll();


            // Return Json(CustomerList, JsonRequestBehavior.AllowGet)
            return Json(arrCustomers, JsonRequestBehavior.AllowGet);
        }










        [HttpPost]
        public JsonResult SaveDetails(CustomerMastercls pCustomerMaster)
        {
            if (ModelState.IsValid == true)
            {
                pCustomerMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                pCustomerMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                //if (pCustomerMaster.LocationId == 0)
                //    pCustomerMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);

                pCustomerMaster = CustomerMastercls.InsertUpdateDetails(pCustomerMaster);

                if (pCustomerMaster.ErrorMessage != "")
                    // Return Json(pCustomerMaster, JsonRequestBehavior.AllowGet)
                    return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = pCustomerMaster, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                // Return Json(pCustomerMaster, JsonRequestBehavior.AllowGet)
                return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = pCustomerMaster, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pCustomerMaster.ErrorMessage = message;

                // Return Json(pCustomerMaster, JsonRequestBehavior.AllowGet)
                return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = pCustomerMaster, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
        }



        [HttpPost]
        public JsonResult LoadCustomerById(CustomerMastercls pCustomerMaster)
        {
            pCustomerMaster = CustomerMastercls.GetCustomerMasterByID(pCustomerMaster);

            // Return Json(pCustomerMaster, JsonRequestBehavior.AllowGet)
            return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = pCustomerMaster, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
        }


        [HttpPost]
        public JsonResult GetCustomerTypeLookup(CustomerMastercls pCustomerMastercls)
        {
            pCustomerMastercls.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrCustMaster = new ArrayList();
            arrCustMaster = CustomerMastercls.GetCustomerMasterAllByType(pCustomerMastercls);
            return Json(arrCustMaster, JsonRequestBehavior.AllowGet);
        }
    }
}
