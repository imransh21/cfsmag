﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class ItemsMasterController : Controller
    {
        //
        // GET: /KeyRefrence/

        public ActionResult ItemsMaster()
        {
            return PartialView();
        }
        [HttpPost]
        public JsonResult GetUsedList(InventUsedFor pInventUsedFor)
        {
            InventUsedFor[] arrUserLocations = InventUsedFor.GetusedForAll(pInventUsedFor.ItemId);

            //var UserLocationList = JsonConvert.SerializeObject(arrUserLocations, Formatting.None);
            var UserLocationList = arrUserLocations;
            return Json(UserLocationList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetMakeList(InventItemMake pInventUsedFor)
        {
            InventItemMake[] arrUserLocations = InventItemMake.GetMakeAll(pInventUsedFor.ItemId);

            //var UserLocationList = JsonConvert.SerializeObject(arrUserLocations, Formatting.None);
            var UserLocationList = arrUserLocations;
            return Json(UserLocationList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetVendorList(InventItemVendor pInventUsedFor)
        {
            InventItemVendor[] arrUserLocations = InventItemVendor.GetVendorAllByItemId(pInventUsedFor.ItemId);

            //var UserLocationList = JsonConvert.SerializeObject(arrUserLocations, Formatting.None);
            var UserLocationList = arrUserLocations;
            return Json(UserLocationList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDetails(InventoryItemMaster pInventoryItemMaster)
        {
            if (ModelState.IsValid == true)
            {
                try
                {
                    pInventoryItemMaster.ErrorMessage = "";
                    pInventoryItemMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                    pInventoryItemMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                    pInventoryItemMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                }
                catch (Exception ex)
                {
                    pInventoryItemMaster.ErrorMessage = "Session Out, Kindly ReLogin.";
                }

                // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
                // pUserMaster.LocationId = Session.Item("loginLocation")
                if (pInventoryItemMaster.ErrorMessage == "")
                    pInventoryItemMaster = InventoryItemMaster.InsertUpdateDetails(pInventoryItemMaster);

                return Json(pInventoryItemMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pInventoryItemMaster.ErrorMessage = message;

                return Json(pInventoryItemMaster, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
      
        public string GetTreeView(InventoryItemMaster pUserMaster)
        {
            if (ModelState.IsValid == true)
            {

              
                // 'Load Menu
                System.Collections.ArrayList arrMenuList = InventoryItemMaster.PrepareTreeViewItem(Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]),pUserMaster.ItemName);
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    // -------------- Convert ArrayList it Generic List Collection item 
                    // --------------
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    List<InventoryItemMaster> menuList = new List<InventoryItemMaster>();
                    menuList = arrMenuList.Cast<InventoryItemMaster>().ToList();
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    // -------------- Format the Menu and Sub Menu Items in JSON Object
                    // --------------
                    // ----------------------------------------------------------------------------------------------------------------------------------------------------
                    List<InventoryItemMaster> arrFromatedFinMenu = new List<InventoryItemMaster>();

                    arrFromatedFinMenu = MyFunction.GetToTreeMainMenu(menuList);
                    pUserMaster.Menu = arrFromatedFinMenu;
          
                return JsonConvert.SerializeObject(pUserMaster);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pUserMaster.ErrorMessage = message;
                return JsonConvert.SerializeObject(pUserMaster);
            }
        }


        [HttpPost]
        public JsonResult LoadItemById(InventoryItemMaster pInventoryItemMaster)
        {
            pInventoryItemMaster.LocationId= Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pInventoryItemMaster = InventoryItemMaster.GetInventoryItemMasterByID(pInventoryItemMaster);
            return Json(pInventoryItemMaster, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetMakeLookup(KeyReferenceCls pKeyReferenceCls)
        {
            //ArrayList arrList = new ArrayList();
            //ArrayList arrList1 = new ArrayList();
            //KeyReferenceCls pKeyReferenceCls = new KeyReferenceCls();
            //pKeyReferenceCls.GroupCode = "Part";
            //pKeyReferenceCls.HeadCode = "Make";
 
            // arrList = KeyReferenceCls.GetMaterData(pKeyReferenceCls);

            ArrayList MakeLst = new ArrayList();
            pKeyReferenceCls.HeadCode = "Make";
            pKeyReferenceCls.GroupCode = "Part";
            MakeLst = KeyReferenceCls.GetKeyMasterData(pKeyReferenceCls);
            List<KeyReferenceCls> MakeList = new List<KeyReferenceCls>();
            MakeList = MakeLst.Cast<KeyReferenceCls>().ToList();
            var menuItemlst2 = (from t in MakeList
                                where t.CodeValue.Contains(pKeyReferenceCls.CodeValue)
                                select t).ToList();
            return Json(menuItemlst2, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult LoadAllUnit()
        {
            ArrayList arrJobs = Uom.GetUnitListNew();
            var JobList = arrJobs;
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        public JsonResult GetDepotList(InventDepotBreakup pInventUsedFor)
        {
            InventDepotBreakup[] arrUserLocations = InventDepotBreakup.GetDepotListAll(pInventUsedFor.ItemId);

            //var UserLocationList = JsonConvert.SerializeObject(arrUserLocations, Formatting.None);
            var UserLocationList = arrUserLocations;
            return Json(UserLocationList, JsonRequestBehavior.AllowGet);
        }
    }
}



