using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using TransportMagLib.DataAccessLayer;
using System.Collections;
using System.Data.OleDb;
using System.Data;
namespace TransportMagLib.BusinessObjectLayer.BusinessObjects
{
    // <summary>
    // StateMaster Class 
    // @Project/Product Name:  Bulk Cargo Manangement System 
    // @Version	: Version 1.0
    // @Module/Class Name	: StateMaster
    // @author	: Srinivas Reddy - 2/18/2019 3:19:05 PM
    // </summary>
    // <remarks></remarks>

    public class StateMaster
    {

        private long lngStateId; // To Define Private Variable StateId DataType As Long 
        private string strStateCode; // To Define Private Variable StateCode DataType As String 
        private string strStateName; // To Define Private Variable StateName DataType As String 
        private string strCountry; // To Define Private Variable Country DataType As String 
        private string strCreatedBy; // To Define Private Variable CreatedBy DataType As String 
        private string strCreatedDate; // To Define Private Variable CreatedDate DataType As String 
        private long lngLocationId; // To Define Private Variable LocationId DataType As Long 
        private long lngSgst; // To Define Private Variable Sgst DataType As Long 
        private long lngIgst; // To Define Private Variable Igst DataType As Long 
        private long lngCgst; // To Define Private Variable Cgst DataType As Long 
        private long lngUgst; // To Define Private Variable Ugst DataType As Long 

        private string strErrorMessage; //Error Message  


        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>StateId</value>
        /// <returns> return StateId</returns>
        /// <remarks></remarks>
        public long StateId
        {
            get
            {
                return lngStateId;
            }
            set
            {
                lngStateId = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>StateCode</value>
        /// <returns> return StateCode</returns>
        /// <remarks></remarks>
        public string StateCode
        {
            get
            {
                return strStateCode;
            }
            set
            {
                strStateCode = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>StateName</value>
        /// <returns> return StateName</returns>
        /// <remarks></remarks>
        public string StateName
        {
            get
            {
                return strStateName;
            }
            set
            {
                strStateName = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>Country</value>
        /// <returns> return Country</returns>
        /// <remarks></remarks>
        public string Country
        {
            get
            {
                return strCountry;
            }
            set
            {
                strCountry = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>CreatedBy</value>
        /// <returns> return CreatedBy</returns>
        /// <remarks></remarks>
        public string CreatedBy
        {
            get
            {
                return strCreatedBy;
            }
            set
            {
                strCreatedBy = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>CreatedDate</value>
        /// <returns> return CreatedDate</returns>
        /// <remarks></remarks>
        public string CreatedDate
        {
            get
            {
                return strCreatedDate;
            }
            set
            {
                strCreatedDate = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>LocationId</value>
        /// <returns> return LocationId</returns>
        /// <remarks></remarks>
        public long LocationId
        {
            get
            {
                return lngLocationId;
            }
            set
            {
                lngLocationId = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>Sgst</value>
        /// <returns> return Sgst</returns>
        /// <remarks></remarks>
        public long Sgst
        {
            get
            {
                return lngSgst;
            }
            set
            {
                lngSgst = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>Igst</value>
        /// <returns> return Igst</returns>
        /// <remarks></remarks>
        public long Igst
        {
            get
            {
                return lngIgst;
            }
            set
            {
                lngIgst = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>Cgst</value>
        /// <returns> return Cgst</returns>
        /// <remarks></remarks>
        public long Cgst
        {
            get
            {
                return lngCgst;
            }
            set
            {
                lngCgst = value;
            }
        }
        /// <summary>
        /// StateMaster
        /// </summary>
        /// <value>Ugst</value>
        /// <returns> return Ugst</returns>
        /// <remarks></remarks>
        public long Ugst
        {
            get
            {
                return lngUgst;
            }
            set
            {
                lngUgst = value;
            }
        }


        /// <summary>

        /// </summary>
        /// <value>ErrorMessage</value>
        /// <returns> Return ErrorMessage</returns>
        /// <remarks></remarks>
        public string ErrorMessage
        {
            get
            {
                return strErrorMessage;
            }
            set
            {
                strErrorMessage = value;
            }
        }



        // <summary>
        // Preparing New Empty Constructor
        // </summary>
        // <remarks></remarks>
        public StateMaster()
        {
            lngStateId = 0;
            strStateCode = "";
            strStateName = "";
            strCountry = "";
            strCreatedBy = "";
            strCreatedDate = "";
            lngLocationId = 0;
            lngSgst = 0;
            lngIgst = 0;
            lngCgst = 0;
            lngUgst = 0;

        }

        /// <summary>
        /// Preparing New Constructor Having Parameters
        /// <param name="pStateId"></param>
        /// <param name="pStateCode"></param>
        /// <param name="pStateName"></param>
        /// <param name="pCountry"></param>
        /// <param name="pCreatedBy"></param>
        /// <param name="pCreatedDate"></param>
        /// <param name="pLocationId"></param>
        /// <param name="pSgst"></param>
        /// <param name="pIgst"></param>
        /// <param name="pCgst"></param>
        /// <param name="pUgst"></param>
        /// </summary>

        public StateMaster(long pStateId, string pStateCode, string pStateName, string pCountry, string pCreatedBy, string pCreatedDate, long pLocationId, long pSgst, long pIgst, long pCgst, long pUgst)
        {

            lngStateId = pStateId;
            strStateCode = pStateCode;
            strStateName = pStateName;
            strCountry = pCountry;
            strCreatedBy = pCreatedBy;
            strCreatedDate = pCreatedDate;
            lngLocationId = pLocationId;
            lngSgst = pSgst;
            lngIgst = pIgst;
            lngCgst = pCgst;
            lngUgst = pUgst;

        }
        // <summary>
        // This function Inserts a new record in StateMaster master.
        // </summary>

        public static StateMaster Insert(StateMaster pStateMaster)
        {

            DBAccess db = new DBAccess();//object:db for database connectivity from class:DBAccess
            try
            {
                db.BeginTransaction();
                //Before Assigning class variables object:db for database should get clear to store parameters
                db.ClearParameters();
                //Assigning class variables to parameters of stored procedure

                db.AddParameter("@STATE_ID", pStateMaster.StateId, ParameterDirection.Output);
                db.AddParameter("@STATE_CODE", pStateMaster.StateCode);
                db.AddParameter("@STATE_NAME", pStateMaster.StateName);
                db.AddParameter("@COUNTRY", pStateMaster.Country);
                db.AddParameter("@CREATED_BY", pStateMaster.CreatedBy);
                db.AddParameter("@CREATED_DATE", pStateMaster.CreatedDate);
                db.AddParameter("@LOCATION_ID", pStateMaster.LocationId);
                db.AddParameter("@SGST", pStateMaster.Sgst);
                db.AddParameter("@IGST", pStateMaster.Igst);
                db.AddParameter("@CGST", pStateMaster.Cgst);
                db.AddParameter("@UGST", pStateMaster.Ugst);

                db.AddParameter("@ERRMSG", pStateMaster.ErrorMessage, ParameterDirection.Output);
                //Executing store procedure
                db.ExecuteScalar("PKG_INSERT.STATE_MASTER", CommandType.StoredProcedure);
                //Assigning return value of stored procedure to class object
                if (((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString() != "")
                {
                    pStateMaster.ErrorMessage = ((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString();
                    db.RollbackTransaction();
                } // Rollback the transaction if any 
                else
                {

                    pStateMaster.StateId = Convert.ToInt32(((OleDbParameter)(db.Parameters["@STATE_ID"])).Value);

                    db.CommitTransaction();   //Commits the transaction
                }
            }
            catch (Exception ex)
            {
                pStateMaster.ErrorMessage = ex.Message;
                db.RollbackTransaction();
            } // Rollback the transaction if any 

            db.CloseDB();
            //closing the database connection
            return pStateMaster;
            //Returning object for class defined
        }

        // <summary>
        // This function updates a new record in StateMaster master.
        // </summary>

        public static StateMaster Update(StateMaster pStateMaster)
        {
            DBAccess db = new DBAccess(); //object:db for database connectivity from class:DBAccess
            try
            {
                db.BeginTransaction();
                //Before Assigning class variables object:db for database should get clear to store parameters
                db.ClearParameters();
                //Assigning class variables to parameters of stored procedure
                db.AddParameter("@STATE_ID", pStateMaster.StateId);
                db.AddParameter("@STATE_CODE", pStateMaster.StateCode);
                db.AddParameter("@STATE_NAME", pStateMaster.StateName);
                db.AddParameter("@COUNTRY", pStateMaster.Country);
                db.AddParameter("@CREATED_BY", pStateMaster.CreatedBy);
                db.AddParameter("@CREATED_DATE", pStateMaster.CreatedDate);
                db.AddParameter("@LOCATION_ID", pStateMaster.LocationId);
                db.AddParameter("@SGST", pStateMaster.Sgst);
                db.AddParameter("@IGST", pStateMaster.Igst);
                db.AddParameter("@CGST", pStateMaster.Cgst);
                db.AddParameter("@UGST", pStateMaster.Ugst);

                db.AddParameter("@ERRMSG", pStateMaster.ErrorMessage, ParameterDirection.Output);
                //Executing store procedure
                db.ExecuteScalar("PKG_UPDATE.STATE_MASTER", CommandType.StoredProcedure);
                //Assigning return value of stored procedure to class object

                pStateMaster.ErrorMessage = ((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString();
                if (pStateMaster.ErrorMessage == "")
                {
                    db.CommitTransaction();
                }
                else
                {
                    db.RollbackTransaction();
                }
            }
            //Commits the transaction
            catch (Exception ex)
            {
                pStateMaster.ErrorMessage = ex.Message;
                db.RollbackTransaction(); // Rollback the transaction if any 
            }
            db.CloseDB();
            //closing the database connection
            return pStateMaster;
            //Returning object for class defined
        }

        public static StateMaster GetStateMasterByID(StateMaster pStateMaster)
      {
            DBAccess db=new DBAccess(); //object:db for database connectivity from class:DBAccess
            System.Data.OleDb.OleDbDataReader  dbr;     
           
            try {               
                dbr = db.storedprocedure_ReadDB("PKG_SELECT.STATE_MASTER",""+pStateMaster.StateId );
                //Assigning class variables to parameters of stored procedure
                if (dbr.HasRows) {
                    while (dbr.Read()){
                        
if (dbr["STATE_ID"].ToString()!= "" ){ 
pStateMaster.StateId = Convert.ToInt32(dbr["STATE_ID"]);
}
if (dbr["STATE_CODE"].ToString()!= "" ){ 
pStateMaster.StateCode = dbr["STATE_CODE"].ToString();
}
if (dbr["STATE_NAME"].ToString()!= "" ){ 
pStateMaster.StateName = dbr["STATE_NAME"].ToString();
}
if (dbr["COUNTRY"].ToString()!= "" ){ 
pStateMaster.Country = dbr["COUNTRY"].ToString();
}
if (dbr["CREATED_BY"].ToString()!= "" ){ 
pStateMaster.CreatedBy = dbr["CREATED_BY"].ToString();
}
if (dbr["CREATED_DATE"].ToString()!= "" ){ 
pStateMaster.CreatedDate = dbr["CREATED_DATE"].ToString();
}
if (dbr["LOCATION_ID"].ToString()!= "" ){ 
pStateMaster.LocationId = Convert.ToInt32(dbr["LOCATION_ID"]);
}
if (dbr["SGST"].ToString()!= "" ){ 
pStateMaster.Sgst = Convert.ToInt32(dbr["SGST"]);
}
if (dbr["IGST"].ToString()!= "" ){ 
pStateMaster.Igst = Convert.ToInt32(dbr["IGST"]);
}
if (dbr["CGST"].ToString()!= "" ){ 
pStateMaster.Cgst = Convert.ToInt32(dbr["CGST"]);
}
if (dbr["UGST"].ToString()!= "" ){ 
pStateMaster.Ugst = Convert.ToInt32(dbr["UGST"]);
}

                    }
                 }
                dbr.Close(); }                   
            catch (Exception ex)
            {
                pStateMaster.ErrorMessage = ex.Message;                
            }
            db.CloseDB();
            //closing the database connection
            return pStateMaster; 
            //Returning object for class defined
       }


        public static ArrayList GetStateMasterAll()
        {
            DBAccess db = new DBAccess(); //object:db for database connectivity from class:DBAccess
            System.Data.OleDb.OleDbDataReader dbr;
            ArrayList arrStateMaster = new ArrayList();

            try
            {

                //Assigning class variables to parameters of stored procedure
                dbr = db.storedprocedure_ReadDB("PKG_SELECT.STATE_MASTER_ALL", "");
                if (dbr.HasRows)
                {
                    while (dbr.Read())
                    {
                        StateMaster temp = new StateMaster();

                        if (dbr["STATE_ID"].ToString() != "")
                        {
                            temp.StateId = Convert.ToInt32(dbr["STATE_ID"]);
                        }
                        if (dbr["STATE_CODE"].ToString() != "")
                        {
                            temp.StateCode = dbr["STATE_CODE"].ToString();
                        }
                        if (dbr["STATE_NAME"].ToString() != "")
                        {
                            temp.StateName = dbr["STATE_NAME"].ToString();
                        }
                        if (dbr["COUNTRY"].ToString() != "")
                        {
                            temp.Country = dbr["COUNTRY"].ToString();
                        }
                        if (dbr["CREATED_BY"].ToString() != "")
                        {
                            temp.CreatedBy = dbr["CREATED_BY"].ToString();
                        }
                        if (dbr["CREATED_DATE"].ToString() != "")
                        {
                            temp.CreatedDate = dbr["CREATED_DATE"].ToString();
                        }
                        if (dbr["LOCATION_ID"].ToString() != "")
                        {
                            temp.LocationId = Convert.ToInt32(dbr["LOCATION_ID"]);
                        }
                        if (dbr["SGST"].ToString() != "")
                        {
                            temp.Sgst = Convert.ToInt32(dbr["SGST"]);
                        }
                        if (dbr["IGST"].ToString() != "")
                        {
                            temp.Igst = Convert.ToInt32(dbr["IGST"]);
                        }
                        if (dbr["CGST"].ToString() != "")
                        {
                            temp.Cgst = Convert.ToInt32(dbr["CGST"]);
                        }
                        if (dbr["UGST"].ToString() != "")
                        {
                            temp.Ugst = Convert.ToInt32(dbr["UGST"]);
                        }

                        arrStateMaster.Add(temp);
                    }
                }

                dbr.Close();
            }
            //closing the database connection
            catch (Exception ex)
            {
                arrStateMaster = null;
            }
            db.CloseDB();
            return arrStateMaster;  //Returning object for class defined
        }


        public static StateMaster InsertDB(StateMaster pStateMaster, DBAccess db)
        {
            try
            {
                //Before Assigning class variables object:db for database should get clear to store parameters
                db.ClearParameters();
                //Assigning class variables to parameters of stored procedure

                db.AddParameter("@STATE_ID", pStateMaster.StateId, ParameterDirection.Output);
                db.AddParameter("@STATE_CODE", pStateMaster.StateCode);
                db.AddParameter("@STATE_NAME", pStateMaster.StateName);
                db.AddParameter("@COUNTRY", pStateMaster.Country);
                db.AddParameter("@CREATED_BY", pStateMaster.CreatedBy);
                db.AddParameter("@CREATED_DATE", pStateMaster.CreatedDate);
                db.AddParameter("@LOCATION_ID", pStateMaster.LocationId);
                db.AddParameter("@SGST", pStateMaster.Sgst);
                db.AddParameter("@IGST", pStateMaster.Igst);
                db.AddParameter("@CGST", pStateMaster.Cgst);
                db.AddParameter("@UGST", pStateMaster.Ugst);

                db.AddParameter("@ERRMSG", pStateMaster.ErrorMessage, ParameterDirection.Output);
                //Executing store procedure
                db.ExecuteScalar("PKG_INSERT.STATE_MASTER", CommandType.StoredProcedure);
                //Assigning return value of stored procedure to class object
                if (((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString() != "")
                {
                    pStateMaster.ErrorMessage = ((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString();
                }
                else
                {

                    pStateMaster.StateId = Convert.ToInt32(((OleDbParameter)(db.Parameters["@STATE_ID"])).Value);

                }
            }
            catch (Exception ex)
            {
                pStateMaster.ErrorMessage = ex.Message;
            }
            return pStateMaster;
            //Returning object for class defined
        }

        // <summary>
        // This function updates a new record in StateMaster master.
        // </summary>

        public static StateMaster UpdateDB(StateMaster pStateMaster, DBAccess db)
        {

            try
            {

                //Before Assigning class variables object:db for database should get clear to store parameters
                db.ClearParameters();
                //Assigning class variables to parameters of stored procedure
                db.AddParameter("@STATE_ID", pStateMaster.StateId);
                db.AddParameter("@STATE_CODE", pStateMaster.StateCode);
                db.AddParameter("@STATE_NAME", pStateMaster.StateName);
                db.AddParameter("@COUNTRY", pStateMaster.Country);
                db.AddParameter("@CREATED_BY", pStateMaster.CreatedBy);
                db.AddParameter("@CREATED_DATE", pStateMaster.CreatedDate);
                db.AddParameter("@LOCATION_ID", pStateMaster.LocationId);
                db.AddParameter("@SGST", pStateMaster.Sgst);
                db.AddParameter("@IGST", pStateMaster.Igst);
                db.AddParameter("@CGST", pStateMaster.Cgst);
                db.AddParameter("@UGST", pStateMaster.Ugst);

                db.AddParameter("@ERRMSG", pStateMaster.ErrorMessage, ParameterDirection.Output);
                //Executing store procedure
                db.ExecuteScalar("PKG_UPDATE.STATE_MASTER", CommandType.StoredProcedure);
                //Assigning return value of stored procedure to class object

                pStateMaster.ErrorMessage = ((OleDbParameter)db.Parameters["@ERRMSG"]).Value.ToString();
            }
            catch (Exception ex)
            {
                pStateMaster.ErrorMessage = ex.Message;

            }

            return pStateMaster;
            //Returning object for class defined
        }





        public static ArrayList GetStateMasterAllAuto(string prefixText)
        {
            DBAccess db = new DBAccess();
            // object:db for database connectivity from class:DBAccess
            System.Data.OleDb.OleDbDataReader dbr;
            ArrayList arrStateMaster = new ArrayList();
            try
            {
                // Assigning class variables to parameters of stored procedure
                dbr = db.storedprocedure_ReadDB("PKG_SELECT.SP_SELECT_ALL_AUTO", "'" + prefixText + "'");
                if (dbr.HasRows)
                {
                    while (dbr.Read())
                    {
                        StateMaster temp = new StateMaster();
                        if ((dbr["STATE_ID"].ToString() != ""))
                        {
                            temp.StateId = Convert.ToInt32( dbr["STATE_ID"]);
                        }

                        if ((dbr["STATE_CODE"].ToString() != ""))
                        {
                            temp.StateCode =Convert.ToString( dbr["STATE_CODE"]);
                        }

                        if ((dbr["STATE_NAME"].ToString() != ""))
                        {
                            temp.StateName =Convert.ToString( dbr["STATE_NAME"]);
                        }

                        arrStateMaster.Add(temp);
                    }

                }

                dbr.Close();
                // closing the database connection
            }
            catch (Exception ex)
            {
                arrStateMaster = null;
            }

            db.CloseDB();
            return arrStateMaster;
            // Returning object for class defined
        }


        public static ArrayList GetStateMasterLookUp(StateMaster pStateMaster)
        {
            DBAccess db = new DBAccess(); //object:db for database connectivity from class:DBAccess
            System.Data.OleDb.OleDbDataReader dbr;
            ArrayList arrStateMaster = new ArrayList();

            try
            {
                //Assigning class variables to parameters of stored procedure
                dbr = db.storedprocedure_ReadDB("PKG_SELECT.STATE_MASTER_LOOKUP", "'" + pStateMaster.StateName + "'");
                if (dbr.HasRows)
                {
                    while (dbr.Read())
                    {
                        StateMaster temp = new StateMaster();
                        if ((dbr["STATE_ID"].ToString() != ""))
                        {
                            temp.StateId = Convert.ToInt32(dbr["STATE_ID"]);
                        }

                        if ((dbr["STATE_CODE"].ToString() != ""))
                        {
                            temp.StateCode = Convert.ToString(dbr["STATE_CODE"]);
                        }

                        if ((dbr["STATE_NAME"].ToString() != ""))
                        {
                            temp.StateName = Convert.ToString(dbr["STATE_NAME"]);
                        }

                        arrStateMaster.Add(temp);
                    }

                }

                dbr.Close();
                // closing the database connection
            }
            catch (Exception ex)
            {
                arrStateMaster = null;
            }

            db.CloseDB();
            return arrStateMaster;
        }

    }
}