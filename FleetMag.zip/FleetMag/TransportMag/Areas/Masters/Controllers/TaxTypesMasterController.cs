﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class TaxTypesMasterController : Controller
    {

        public ActionResult TaxTypesMaster()
        {
            return PartialView();
        }

      
        [HttpPost]
        public JsonResult SaveDetails(TaxHeadMaster pTaxHeadMaster)
        {
            if (ModelState.IsValid == true)
            {
                pTaxHeadMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

                pTaxHeadMaster = TaxHeadMaster.InsertUpdateDetails(pTaxHeadMaster);

                if (pTaxHeadMaster.ErrorMessage != "")
                    return Json(pTaxHeadMaster, JsonRequestBehavior.AllowGet);

                return Json(pTaxHeadMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pTaxHeadMaster.ErrorMessage = message;

                return Json(pTaxHeadMaster, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadAllTaxHeads(int LocationId)
        {
            ArrayList arrEmp = TaxHeadMaster.GetTaxHeadMasterAll(LocationId);

           // var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadTaxHeadMasterById(TaxHeadMaster pTaxHeadMaster)
        {
            pTaxHeadMaster = TaxHeadMaster.GetTaxHeadMasterByID(pTaxHeadMaster);

            return Json(pTaxHeadMaster, JsonRequestBehavior.AllowGet);
        }

    }
}
