﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class RouteMasterController : Controller
    {
        //
        // GET: /Masters/DriverMaster/


        public ActionResult RouteMaster()
        {
            return PartialView();
        }

        //public PartialViewResult DriverIndex()
        //{
        //    return PartialView();
        //}

        

        
    }
}
