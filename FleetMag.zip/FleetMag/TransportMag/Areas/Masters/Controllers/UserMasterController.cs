﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class UserMasterController : Controller
    {
        //
        // GET: /UserMaster/

        //public PartialViewResult UserMasterINDEX()
        //{
        //    return PartialView();
        //}

        public ActionResult UserMasterINDEX()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult LoadAllLocations(UserMaster pUserMaster)
        {
            UserLocations[] arrUserLocations = UserLocations.GetUserMasterLocationAll(pUserMaster.UserName == null? "": pUserMaster.UserName);

            //var UserLocationList = JsonConvert.SerializeObject(arrUserLocations, Formatting.None);
            var UserLocationList = arrUserLocations;
            return Json(UserLocationList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadAllJobs()
        {
            ArrayList arrJobs = JobMaster.GetJobMasterAllNew();
            var JobList = arrJobs;
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDetails(UserMaster pUserMaster)
        {
            if (ModelState.IsValid == true)
            {
                try
                {
                    pUserMaster.ErrorMessage = "";
                    pUserMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                }
                catch (Exception ex)
                {
                    pUserMaster.ErrorMessage = "Session Out, Kindly ReLogin.";
                }

                // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
                // pUserMaster.LocationId = Session.Item("loginLocation")
                if (pUserMaster.ErrorMessage == "")
                    pUserMaster = UserMaster.InsertUpdateDetails(pUserMaster);

                return Json(pUserMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pUserMaster.ErrorMessage = message;

                return Json(pUserMaster, JsonRequestBehavior.AllowGet);
            }
        }
        // <HttpPost>
        // Public Function SavePassword(ByVal pPasswordChange As PasswordChange) As JsonResult

        // If ModelState.IsValid = True Then
        // pPasswordChange = PasswordChange.Update(pPasswordChange)
        // Return Json(pPasswordChange, JsonRequestBehavior.AllowGet)
        // Else
        // Dim message = ModelState.Values.SelectMany(Function(v) v.Errors).[Select](Function(e) e.ErrorMessage).First()
        // pPasswordChange.ErrorMessage = message

        // Return Json(pPasswordChange, JsonRequestBehavior.AllowGet)
        // End If
        // End Function
        // <HttpPost>
        public JsonResult LoadAllUsers()
        {
            ArrayList arrUsers = UserMaster.GetUserMasterAllNew();

            //var UserList = JsonConvert.SerializeObject(arrUsers, Formatting.None);
            var UserList = arrUsers;
            return Json(UserList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult LoadUserById(UserMaster pUserMaster)
        {
            pUserMaster = UserMaster.GetUserMasterByIDNew(pUserMaster);
            return Json(pUserMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadAllEmpByBranchAuto(EmployeeMaster pEmployeeMaster)
        {
            ArrayList arrEmp = EmployeeMaster.GetEmployeeMasterByBranchAuto(pEmployeeMaster);

            var EmpList = arrEmp;
            return Json(EmpList, JsonRequestBehavior.AllowGet);
        }




    }
}
