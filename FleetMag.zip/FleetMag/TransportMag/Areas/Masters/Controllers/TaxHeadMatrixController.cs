﻿using Newtonsoft.Json;
using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class TaxHeadMatrixController : Controller
    {

        public ActionResult TaxHeadMatrix()
        {
            return PartialView();
        }


        [HttpPost]
        public JsonResult LoadAlltaxMatrixList(TaxGroupHeadsReferenceGst pTaxGroupHeadsReferenceGst)
        {
            DataSet arrData = TaxGroupHeadsReferenceGst.GetTaxMatrixList(pTaxGroupHeadsReferenceGst);
            if (arrData.Tables.Count > 0)
            {
                var AllDataList = JsonConvert.SerializeObject(arrData.Tables[0], Formatting.None);
                return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = AllDataList, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            else
            {
                DataTable dt = new DataTable();
                var AllDataList = JsonConvert.SerializeObject(dt, Formatting.None);
                return new JsonResult() { MaxJsonLength = Int32.MaxValue, Data = AllDataList, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
        }



    }
}
