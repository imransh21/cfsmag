﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Masters.Controllers
{
    public class DepotMasterController : Controller
    {
        //
        // GET: /Masters/DepoMaster/

        public ActionResult DepotMaster()
        {
            return PartialView();
        }

        [HttpPost ]
        public JsonResult SaveDetails(DepotMastercls pDepotMaster)
        {
            if (ModelState.IsValid == true)
            {
                try
                {
                    pDepotMaster.ErrorMessage = "";
                    pDepotMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                }
                catch (Exception ex)
                {
                    pDepotMaster.ErrorMessage = "Session Out, Kindly ReLogin.";
                }

                // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
                // pUserMaster.LocationId = Session.Item("loginLocation")
               
                if (pDepotMaster.ErrorMessage == "")
                    pDepotMaster = DepotMastercls.InsertUpdateDetails(pDepotMaster);

                return Json(pDepotMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pDepotMaster.ErrorMessage = message;

                return Json(pDepotMaster, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public JsonResult LoadAllJobs()
        {
            ArrayList arrJobs = JobMaster.GetJobMasterAllNew();
            var JobList = arrJobs;
            return Json(JobList, JsonRequestBehavior.AllowGet);
        }


        public JsonResult LoadAllDepots()
        {
            ArrayList arrDepots = DepotMastercls.GetDepotMasterAll();

            //var UserList = JsonConvert.SerializeObject(arrUsers, Formatting.None);
            var DepotList = arrDepots;
            return Json(DepotList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadDepotById(DepotMastercls pDepotMaster)
        {
            pDepotMaster = DepotMastercls.GetDepotMasterByID(pDepotMaster);
            return Json(pDepotMaster, JsonRequestBehavior.AllowGet);
        }

    }
}
