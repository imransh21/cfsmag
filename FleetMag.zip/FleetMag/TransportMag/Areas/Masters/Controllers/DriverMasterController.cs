﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class DriverMasterController : Controller
    {
        //
        // GET: /Masters/DriverMaster/


        public ActionResult DriverIndex()
        {
            return PartialView();
        }

        //public PartialViewResult DriverIndex()
        //{
        //    return PartialView();
        //}

        [HttpPost]
        public JsonResult SaveDetails(DriverMaster pDriverMaster)
        {
            if (ModelState.IsValid == true)
            {
                pDriverMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

                pDriverMaster = DriverMaster.InsertUpdateDetails(pDriverMaster);

                if (pDriverMaster.ErrorMessage != "")
                    return Json(pDriverMaster, JsonRequestBehavior.AllowGet);

                return Json(pDriverMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pDriverMaster.ErrorMessage = message;

                return Json(pDriverMaster, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadAllDrivers(int BranchId)
        {
            ArrayList arrEmp = DriverMaster.GetDriverMasterAll(BranchId);

           // var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadDriverById(DriverMaster pDriverMaster)
        {
            pDriverMaster = DriverMaster.GetDriverMasterByID(pDriverMaster);

            return Json(pDriverMaster, JsonRequestBehavior.AllowGet);
        }

    }
}
