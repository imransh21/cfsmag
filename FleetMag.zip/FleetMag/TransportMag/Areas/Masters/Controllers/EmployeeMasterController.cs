﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class EmployeeMasterController : Controller
    {
        //
        // GET: /Masters/EmployeeMaster/

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public JsonResult LoadAllEmpByBranch(EmployeeMaster pEmployeeMaster)
        {
            string IsAdmin =(Session["AdminUserStatus"].ToString() == "Y" ? "1" : "0");
            ArrayList arrEmp = EmployeeMaster.GetEmployeeMasterByBranch(pEmployeeMaster);

            var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(EmpList, JsonRequestBehavior.AllowGet);
        }

    }
}
