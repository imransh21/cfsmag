﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class TariffHeadMasterController : Controller
    {

        public ActionResult TariffHeadMaster()
        {
            return PartialView();
        }

      
        [HttpPost]
        public JsonResult SaveDetails(BillableItemMaster pBillableItemMaster)
        {
            if (ModelState.IsValid == true)
            {
                pBillableItemMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                pBillableItemMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

                pBillableItemMaster = BillableItemMaster.InsertUpdateDetails(pBillableItemMaster);

                if (pBillableItemMaster.ErrorMessage != "")
                    return Json(pBillableItemMaster, JsonRequestBehavior.AllowGet);

                return Json(pBillableItemMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pBillableItemMaster.ErrorMessage = message;

                return Json(pBillableItemMaster, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult LoadAllTarriffHeads(int LocationId)
        {
            ArrayList arrEmp = BillableItemMaster.GetBillableItemMasterAll(LocationId);

           // var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadBillableItemMasterById(BillableItemMaster pBillableItemMaster)
        {
            pBillableItemMaster = BillableItemMaster.GetBillableItemMasterByID(pBillableItemMaster);

            return Json(pBillableItemMaster, JsonRequestBehavior.AllowGet);
        }

    }
}
