﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class KeyRefrenceController : Controller
    {
        //
        // GET: /KeyRefrence/

        public ActionResult KeyRefrence()
        {
            return PartialView();
        }
        [HttpPost]
        public JsonResult LoadMasterData(KeyReferenceCls pKeyReferenceCls)
        {
            //pKeyReferenceCls = KeyReferenceCls.GetMaterData(pKeyReferenceCls);

            //return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);

            ArrayList arrList = KeyReferenceCls.GetKeyMasterData(pKeyReferenceCls);
           // var iList = JsonConvert.SerializeObject(arrList, Formatting.None);
            return Json(arrList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDetails(KeyReferenceCls pKeyReferenceCls)
        {

            pKeyReferenceCls.CreatedBy = "";// Session["loginuser"].ToString();
            pKeyReferenceCls.ModifiedBy = ""; //Session["loginuser"].ToString();

                pKeyReferenceCls = KeyReferenceCls.InsertUpdates(pKeyReferenceCls);


                return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);
           
             
        }

        [HttpPost]
        public JsonResult LoadAllMainNode(KeyReferenceCls pKeyReferenceCls)
        {
            //pKeyReferenceCls = KeyReferenceCls.GetMaterData(pKeyReferenceCls);

            //return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);

            pKeyReferenceCls.List = KeyReferenceCls.GetKeyReferenceClsForNode();
            // var iList = JsonConvert.SerializeObject(arrList, Formatting.None);
            return Json(pKeyReferenceCls.List, JsonRequestBehavior.AllowGet);
        }


    }
}
