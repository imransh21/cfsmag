﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Masters.Controllers
{
    public class EmployeeMasterNewController : Controller
    {
        //
        // GET: /Masters/EmployeeMaster/

        public ActionResult EmployeeMasterNew()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult LoadAllEmployees(EmployeeMaster pEmployeeMaster)
        {

            ArrayList arrEmp = EmployeeMaster.GetEmployeeMasterOnLoad(pEmployeeMaster);

            //var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
             return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDetails(EmployeeMaster pEmployeeMaster)
        {
            if (ModelState.IsValid == true)
            {
                pEmployeeMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

                pEmployeeMaster = EmployeeMaster.InsertUpdateDetails(pEmployeeMaster);

                if (pEmployeeMaster.ErrorMessage != "")
                    return Json(pEmployeeMaster, JsonRequestBehavior.AllowGet);

                return Json(pEmployeeMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pEmployeeMaster.ErrorMessage = message;

                return Json(pEmployeeMaster, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public JsonResult LoadEmpById(EmployeeMaster pEmployeeMaster)
        {

            pEmployeeMaster = EmployeeMaster.GetEmployeeMasterByID(pEmployeeMaster);

            //var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(pEmployeeMaster, JsonRequestBehavior.AllowGet);
        }
    }
}
