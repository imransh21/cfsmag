﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Monitoring.Controllers
{
    public class VehicleTrackingController : Controller
    {


        public ActionResult VehicleTrackingIndex()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult GetInitPositionMap()
        {
            Decimal Latitude = Convert.ToDecimal(System.Configuration.ConfigurationSettings.AppSettings["InItLat"].ToString());
            Decimal longitude = Convert.ToDecimal(System.Configuration.ConfigurationSettings.AppSettings["InItLng"].ToString());
            return Json(new { lat = Latitude, lng = longitude }, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetVehicleList(VehicleMaster pVehicleMaster)
        {
            DataSet ds; 
           ds= VehicleMaster.GetVehicleMasterPossition(pVehicleMaster);
           return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

    }
}
