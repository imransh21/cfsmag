﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class AMCReportController : Controller
    {

        public ActionResult AMCReport()
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public JsonResult SavaDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            IndentHdr.SaveDetailsAmc(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIndentDetailsSearch(IndentHdr pIndentHdr)
        {
          //  IndentHdr.GetIndentHdrByID(pIndentHdr);
            IndentDtls pIndentDtls = new IndentDtls();
            pIndentDtls.IndentRefId = pIndentHdr.IndentRefId;
            pIndentDtls.IndentDate = pIndentHdr.IndentDate;
            pIndentDtls.ExpairyDate = pIndentHdr.ExpDelvDate; 

            ViewBag.IndentRefid = pIndentHdr.IndentRefId;
            pIndentHdr.IndentDtlsList = IndentDtls.GetIndentDtlsByIndentAllSearch(pIndentDtls);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIndentDetails(IndentHdr pIndentHdr)
        {
            IndentHdr.GetIndentHdrByID(pIndentHdr);
            IndentDtls pIndentDtls = new IndentDtls();
            pIndentDtls.IndentRefId = pIndentHdr.IndentRefId;
            ViewBag.IndentRefid = pIndentHdr.IndentRefId;
            pIndentHdr.IndentDtlsList = IndentDtls.GetIndentDtlsByIndentId(pIndentDtls);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIndentLookup(IndentHdr pIndentHdr)
        {
            ArrayList IndentDtls = new ArrayList();
            pIndentHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            IndentDtls = IndentHdr.GetIndentHdrLookup(pIndentHdr);
            return Json(IndentDtls, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetRequiredStockList(IndentHdr pIndentHdr)
        {
            pIndentHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList Inventory = new ArrayList();
            Inventory = InventoryItemMaster.GetAllIndentStock(pIndentHdr);
            return Json(Inventory, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetDepoListLookup(DepotMastercls pDepotMastercls)
        {
            ArrayList DepoList = new ArrayList();
            DepoList = DepotMastercls.GetDepotMasterLookUp(pDepotMastercls);
            return Json(DepoList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetItemMasterLookup(InventoryItemMaster pInventoryItemMaster)
        {
            ArrayList ItemList = new ArrayList();
            ItemList = InventoryItemMaster.GetAMCAllIndentPartLookUp(pInventoryItemMaster);
            return Json(ItemList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPartMake(InventItemMake pInventItemMake)
        {
            ArrayList MakeLst = new ArrayList();
            MakeLst = InventItemMake.GetMakeForItemData(pInventItemMake);

            List<InventItemMake> MakeList = new List<InventItemMake>();
            MakeList = MakeLst.Cast<InventItemMake>().ToList();
            var menuItemlst2 = (from t in MakeList
                                where t.MakeDesc.ToUpper().Contains(pInventItemMake.MakeDesc.ToUpper())
                                select t).ToList();
            return Json(menuItemlst2, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetUserFor(InventUsedFor pInventUsedFor)
        {
            ArrayList MakeLst = new ArrayList();
            MakeLst = InventUsedFor.GetUsedForItemData(pInventUsedFor);
            List<InventUsedFor> MakeList = new List<InventUsedFor>();
            MakeList = MakeLst.Cast<InventUsedFor>().ToList();
            var menuItemlst2 = (from t in MakeList
                                where t.KeyCode.ToUpper().Contains(pInventUsedFor.KeyCode.ToUpper())
                                select t).ToList();
            return Json(menuItemlst2, JsonRequestBehavior.AllowGet);
        }


        public ActionResult IndentGenarationPrint(IndentHdr pIndentHdr)
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPartMakeWithInstock(InventItemMake pInventItemMake)
        {
            ArrayList MakeLst = new ArrayList();
            MakeLst = InventItemMake.GetMakeForItemDataWithInStock(pInventItemMake);
            List<InventItemMake> MakeList = new List<InventItemMake>();
            MakeList = MakeLst.Cast<InventItemMake>().ToList();
            var menuItemlst2 = (from t in MakeList
                                where t.MakeDesc.ToUpper().Contains(pInventItemMake.MakeDesc.ToUpper())
                                select t).ToList();
            return Json(menuItemlst2, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public JsonResult GetItemMasterLookupWithDepot(InventoryItemMaster pInventoryItemMaster)
        {
            ArrayList ItemList = new ArrayList();
            ItemList = InventoryItemMaster.GetAllIndentPartLookUpWithDepot(pInventoryItemMaster);
            return Json(ItemList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetAMCQlist(IndentDtls pIndentDtls)
        {
            DataSet ds=new DataSet();
            ds = IndentDtls.GetAmcQlistData(pIndentDtls);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

    }
}
