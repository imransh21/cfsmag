﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsReceiptGSecurityController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult GoodsReceiptGSecurity()
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPOLookup(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = GoodsRetuenGateSecurityHdr.GetPolookup(pGoodsRetuenGateSecurityHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult LoadPoDetailsByPoNo(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            ArrayList a = new ArrayList();
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            a = GoodsRetuenGateSecurityHdr.GetPoDetailsByPoNo(pGoodsRetuenGateSecurityHdr.PoNo);
            return Json(a, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsRetuenGateSecurityHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pGoodsRetuenGateSecurityHdr = GoodsRetuenGateSecurityHdr.InsertUpdateDetails(pGoodsRetuenGateSecurityHdr);
            return Json(pGoodsRetuenGateSecurityHdr, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public JsonResult  GetGrrDetailsByGrId(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsRetuenGateSecurityHdr = GoodsRetuenGateSecurityHdr.GetGrrDetails(pGoodsRetuenGateSecurityHdr);
            return Json(pGoodsRetuenGateSecurityHdr, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public JsonResult GetGrrLookup(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = GoodsRetuenGateSecurityHdr.GetGrrlookup(pGoodsRetuenGateSecurityHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GoodsReceiptGSecurityPrint()
        {
            return View();
        }
    }
}
