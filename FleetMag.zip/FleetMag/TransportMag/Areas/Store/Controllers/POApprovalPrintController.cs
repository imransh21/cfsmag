﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
//using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class POApprovalPrintController : Controller
    {
        [HttpPost]
        public JsonResult GetpODetailsBypOId(PoHdr pGoodsRetuenGateSecurityHdr)
        {

            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsRetuenGateSecurityHdr = PoHdr.GetPODetailsPrint(pGoodsRetuenGateSecurityHdr);
            return Json(pGoodsRetuenGateSecurityHdr, JsonRequestBehavior.AllowGet);
        }
     
    }
}
