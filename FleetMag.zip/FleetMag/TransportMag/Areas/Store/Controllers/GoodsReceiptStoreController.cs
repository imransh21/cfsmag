﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsReceiptStoreController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult GoodsReceiptStore()
        {
            return PartialView();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPOLookup(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = GoodsRetuenGateSecurityHdr.GetStorePolookup(pGoodsRetuenGateSecurityHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult LoadPoDetailsByPoNo(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            ArrayList a = new ArrayList();
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            a = GoodsRetuenGateSecurityHdr.GetPoDetailsByStorePoNo(pGoodsRetuenGateSecurityHdr.PoNo);
            return Json(a, JsonRequestBehavior.AllowGet);
        }


        //[HttpPost]
        //public JsonResult GetGrrDetailsByGrId(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        //{
        //    ArrayList a = new ArrayList();
        //    string  grrRefID = Convert.ToString (pGoodsRetuenGateSecurityHdr.GrRefId);
        //    pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
        //    a = GoodsRetuenGateSecurityHdr.GetGrrDetailsStores(grrRefID);
        //    return Json(a, JsonRequestBehavior.AllowGet);
        //}


        [HttpPost]
        [Compress]
        public JsonResult GetGrrDetailsByGrId(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsRetuenGateSecurityHdr = GoodsRetuenGateSecurityHdr.GetGrrDetailsStores(pGoodsRetuenGateSecurityHdr);
            return Json(pGoodsRetuenGateSecurityHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(GoodsInwordStoreHdr pGoodsInwordStoreHdr)
        {
            pGoodsInwordStoreHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsInwordStoreHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pGoodsInwordStoreHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            GoodsInwordStoreHdr.SaveGoodsInwordDetails(pGoodsInwordStoreHdr);
            return Json(pGoodsInwordStoreHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult InwordRefLookup(GoodsInwordStoreHdr pGoodsInwordStoreHdr)
        {
            ArrayList InwordList = new ArrayList();
            InwordList=GoodsInwordStoreHdr.GetGoodsInwordStoreHdrAllLookup(pGoodsInwordStoreHdr);
            return Json(InwordList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetRetrieveData(GoodsInwordStoreHdr pGoodsInwordStoreHdr)
        {
            GoodsInwordStoreHdr.GetGoodsInwordStoreHdrByIDNew(pGoodsInwordStoreHdr);
            return Json(pGoodsInwordStoreHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetGrrLookup(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = GoodsRetuenGateSecurityHdr.GetGrrlookup(pGoodsRetuenGateSecurityHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GoodsIssueJobPrint()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult GetStockListByDepot(GoodsRetuenGateSecurityHdr pGoodsRetuenGateSecurityHdr)
        {
            DataSet ds;
            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = GoodsRetuenGateSecurityHdr.GetGoodReceiptStoreListByDepot(pGoodsRetuenGateSecurityHdr);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }
    }
}
