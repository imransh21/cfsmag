﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsTransforController : Controller
    {
  
        public ActionResult GoodsTransforIndex()
        {
            return View();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetItemNameListLookup(InventoryItemMaster pInventoryItemMaster)
        {
             ArrayList arrInventoryItemMaster = new ArrayList();
             arrInventoryItemMaster = InventoryItemMaster.GetAllIndentPartLookUp(pInventoryItemMaster);
             var Query = from InventoryItemMaster inventoryitemmaster in arrInventoryItemMaster
                         select new { inventoryitemmaster.ItemId, inventoryitemmaster.ItemCode, inventoryitemmaster.ItemName };
             return Json(Query, JsonRequestBehavior.AllowGet);              
        }
        [HttpPost]
        [Compress]
        public JsonResult GetBalQty(GoodsTransferDtls pGoodsTransferDtls)
        {
            GoodsTransferDtls.GetBalQty(pGoodsTransferDtls);
            return Json(pGoodsTransferDtls, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveGoodsTransferDtls(GoodsTransferHdr pGoodsTransferHdr)
        {
            GoodsTransferHdr.SaveTransation(pGoodsTransferHdr);
            return Json(pGoodsTransferHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetTransferLookup(GoodsTransferHdr pGoodsTransferHdr)
        {
            ArrayList arrTransforList = new ArrayList();
            arrTransforList=GoodsTransferHdr.GetGoodsTransferHdrLOOKUP(pGoodsTransferHdr);
            var Query = from GoodsTransferHdr vgoodstransferhdr in arrTransforList
                        select new { vgoodstransferhdr.TransferId, vgoodstransferhdr.TransferRefNo};
            return Json(Query, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult RetrieveData(GoodsTransferHdr pGoodsTransferHdr)
        {            
            GoodsTransferHdr.GetGoodsTransferHdrByID (pGoodsTransferHdr);
            GoodsTransferDtls p=new GoodsTransferDtls();
            p.TransferId= pGoodsTransferHdr.TransferId ;
            p.LocationId = pGoodsTransferHdr.LocationId;
            pGoodsTransferHdr.arrGoodsTransferDtls = GoodsTransferDtls.GetGoodsTransferDtlsbyTransferId(p);
            return Json(pGoodsTransferHdr, JsonRequestBehavior.AllowGet);
        }
    }
}
