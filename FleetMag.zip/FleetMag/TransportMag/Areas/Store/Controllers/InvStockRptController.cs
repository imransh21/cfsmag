﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class InvStockRptController : Controller
    {
        //
        // GET: /Store/IndentFinalApproval/

        public ActionResult InvStockRpt()
        {
            return PartialView();
        }


        [HttpPost]
        [Compress]
        public JsonResult GetInventoryItemListLookup(string prefixText)
        {
            DataSet ds;
 
            WorkInstructions pWorkInstructions = new WorkInstructions();
            pWorkInstructions.JobNo = prefixText;
            pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = WorkInstructions.GetInventotyItemNameLookup(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        
        [HttpPost]
        [Compress]

   

        public JsonResult LoadAllIndentPendingForFinalApp(IndentHdr pIndentHdr)
        {
            //pKeyReferenceCls = KeyReferenceCls.GetMaterData(pKeyReferenceCls);
            pIndentHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);

            pIndentHdr.List = IndentHdr.GetAllInvStockRpt(pIndentHdr);
            // var iList = JsonConvert.SerializeObject(arrList, Formatting.None);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SubmitDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = IndentHdr.submitFinalApproveDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pIndentHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = IndentHdr.SaveFinalApproveDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult FinalPendingIndentLookUpData(IndentHdr pIndentHdr)
        {
            pIndentHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pIndentHdr.List = IndentHdr.GetAllIndenFinallookup(pIndentHdr);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }
    }
}
