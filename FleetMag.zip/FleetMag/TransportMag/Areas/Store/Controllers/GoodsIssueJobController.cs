﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsIssueJobController : Controller
    {
        //
        // GET: /Store/GoogsIssueJob/

        public ActionResult GoodsIssue()
        {
            return PartialView();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockReqData(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            ds=WorkInstructions.GetStockReqDataList(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockReqJobListLookup(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            ds = WorkInstructions.GetStockReqJOBLookup(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockJobVehicleDetails(WorkInstructions pWorkInstructions)
        {            
             WorkInstructions.GetWorkInstructionsByJobDetails(pWorkInstructions);
             return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveMaterialIssue(WorkInstructions pWorkInstructions)
        {
            WorkInstructions.updateMaterialIssue(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GoodsIssueJobPrint()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult GetAllGoodIssueJobDtls(WorkInstructions pWorkInstructions)
        {
            WorkInstructions.GetAllWorkInstructionDtlByWISidAndDepot(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockReqDataPrint(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            ds = WorkInstructions.GetStockReqDataList(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockListByDepot(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = WorkInstructions.GetStockListByDepot(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

    }
}
