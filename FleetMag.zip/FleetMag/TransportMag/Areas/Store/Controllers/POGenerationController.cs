﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class POGenerationController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult POGeneration()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult LoadAllDetailsByVendorId(IndentDtls pIndentDtls)
        {
            ArrayList a = new ArrayList();
            pIndentDtls.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            a = IndentDtls.GetIndentDtlsByVendorId(pIndentDtls);
            return Json(a, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pPoHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pPoHdr = PoHdr.InsertUpdateDetails(pPoHdr);
            return Json(pPoHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetpODetailsBypOId(PoHdr pGoodsRetuenGateSecurityHdr)
        {

            pGoodsRetuenGateSecurityHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pGoodsRetuenGateSecurityHdr = PoHdr.GetPODetails(pGoodsRetuenGateSecurityHdr);
            return Json(pGoodsRetuenGateSecurityHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPOLookupForPOGen(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = PoHdr.GetPolookupForPoGen(pPoHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult removePaymentTerms(PoPaymentTerms pPoPaymentTerms)
        {
            PoPaymentTerms.RemovePayterm(pPoPaymentTerms);
            return Json(pPoPaymentTerms, JsonRequestBehavior.AllowGet);
        }
    }
}
