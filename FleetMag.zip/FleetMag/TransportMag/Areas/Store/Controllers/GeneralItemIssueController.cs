﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GeneralItemIssueController : Controller
    {
        //
        // GET: /Store/GeneralItemIssue/

        public ActionResult GeneralItemIssueVw()
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetItemMasterLookup(InventoryItemMaster pInventoryItemMaster)
        {
            ArrayList ItemList = new ArrayList();
            ItemList = InventoryItemMaster.GetAllIndentPartLookUpWithDepot(pInventoryItemMaster);
            return Json(ItemList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetPartMake(InventItemMake pInventItemMake)
        {
            ArrayList MakeLst = new ArrayList();

            MakeLst = InventItemMake.GetMakeForItemDataByDepoId(pInventItemMake);

            List<InventItemMake> MakeList = new List<InventItemMake>();
            MakeList = MakeLst.Cast<InventItemMake>().ToList();
            var menuItemlst2 = (from t in MakeList
                                where t.MakeDesc.ToUpper().Contains(pInventItemMake.MakeDesc.ToUpper())
                                select t).ToList();
            return Json(menuItemlst2, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SavaDetails(GeneralItemIssue pGeneralItemIssue)
        {
            GeneralItemIssue.InsertDetails(pGeneralItemIssue);
            return Json(pGeneralItemIssue, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetRequestData(GeneralItemRequest pGeneralItemRequest)
        {
            GeneralItemIssue.GetGeneralItemRequestByID(pGeneralItemRequest);
            return Json(pGeneralItemRequest, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetRequestNoLookup(GeneralItemRequest pGeneralItemRequest)
        {
            ArrayList arrlist = new ArrayList();
            arrlist = GeneralItemRequest.GetGeneralItemRequestLookup(pGeneralItemRequest);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIssueNoLookup(GeneralItemIssue pGeneralItemIssue)
        {
            ArrayList arrlist = new ArrayList();
            arrlist = GeneralItemIssue.GetGeneralItemIssueLookup(pGeneralItemIssue);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIssueData(GeneralItemIssue pGeneralItemIssue)
        {
            GeneralItemIssue.GetGeneralItemIssueByIssueRefId(pGeneralItemIssue);
            return Json(pGeneralItemIssue, JsonRequestBehavior.AllowGet);
        }

    }
}
