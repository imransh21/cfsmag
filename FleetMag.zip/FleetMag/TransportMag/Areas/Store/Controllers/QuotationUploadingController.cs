﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using Newtonsoft.Json;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using System.Collections;
using System.Text;
using TransportMag.Filters;

namespace TransportMag.Areas.Store.Controllers
{
    public class QuotationUploadingController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult QuotationUploading()
        {
            return PartialView();
        }

        [HttpPost]
        [Compress]
        public JsonResult ItemNameLookup(InventoryItemMaster pInventoryItemMaster)
        {
            DataSet ds;
            try
            {
                ds = InventoryItemMaster.QuotItemLookup(pInventoryItemMaster);
                return Json(JsonConvert.SerializeObject(ds), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        [Compress]
        public JsonResult IndentLookup(IndentHdr PIndentHdr)
        {
            DataSet ds;
            try
            {
                ds = IndentHdr.QuotIndentLookup(PIndentHdr);
                return Json(JsonConvert.SerializeObject(ds), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [Compress]
        public JsonResult GetIndentReqDetails(IndentQuotationRequest pIndentQuotationRequest)
        {
            DataSet ds;
            try
            {
                ds = IndentQuotationRequest.GetIndentProcessData(pIndentQuotationRequest);
                return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpPost]
        [Compress]
        public JsonResult GetPaymentTerms()
        {
            KeyReferenceCls pKeyReferenceCls = new KeyReferenceCls();
            pKeyReferenceCls.HeadCode = "Terms";
            pKeyReferenceCls.GroupCode = "Payment";
            ArrayList arrlist = new ArrayList();
            arrlist = KeyReferenceCls.GetKeyMasterData(pKeyReferenceCls);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveQuotationUpLoading(List<IndentQuotationRequest> pIndentQuotationRequest)
        {

            string Status = "";
            var photo = HttpContext.Request.Files.Count;
            try
            {
                Status = IndentQuotationRequest.SaveQuotationReq(pIndentQuotationRequest);
                if (Status == "")
                {
                    return Json(new { ErrorMessage = "" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { ErrorMessage = Status }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new { ErrorMessage = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
   public ContentResult fileupload(HttpPostedFileBase file, String newFileName)       
        {
            try
            {

                IndentQuotationRequest pIndentQuotationRequest = new IndentQuotationRequest();
               var fileName = Path.GetFileName(file.FileName);
                String contentType = file.ContentType;
                String filepath;              
                filepath = Path.Combine(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["FileUploadPath"]), newFileName);
                file.SaveAs(filepath);
                return new ContentResult() { ContentType = "text/plain", Content = filepath, ContentEncoding = Encoding.UTF8 };
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        
        [HttpGet]
        [System.Web.Mvc.AllowAnonymous]
        public FileContentResult FileDownload(int docRefNo)
        {
            try
            {
          
            string MimeType=string.Empty;
            IndentQuotationRequest pIndentQuotationRequest = new IndentQuotationRequest();
            pIndentQuotationRequest.IndentQuotReqRefId = docRefNo;
            FileContentResult filecontent;
            IndentQuotationRequest.GetIndentQuotationRequestByID(pIndentQuotationRequest);
            if (pIndentQuotationRequest.QuotFilePath != null)
            {
                string FileName = Path.GetFileName(pIndentQuotationRequest.QuotFilePath);
                Byte[] file = System.IO.File.ReadAllBytes(pIndentQuotationRequest.QuotFilePath);
                if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".DOC"))
                {
                    MimeType = "application/msword";
                }
                else
                {
                    if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".DOCX"))
                    {
                        MimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                    }
                    else
                    {
                        if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".JPEG") || pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".JPG"))
                        {
                            MimeType = "image/jpeg";
                        }
                        else
                        {
                            if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".PNG"))
                            {
                                MimeType = "image/png";
                            }
                            else
                            {
                                if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".PDF"))
                                {
                                    MimeType = "application/pdf";
                                }
                                else
                                {
                                    if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".XLS"))
                                    {
                                        MimeType = "application/vnd.ms-excel";
                                    }
                                    else
                                    {
                                        if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".XLSX"))
                                        {
                                            MimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                                        }
                                        else
                                        {
                                            if (pIndentQuotationRequest.QuotFilePath.ToUpper().Contains(".BMP"))
                                            {
                                                MimeType = "image/bmp";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (MimeType == string.Empty)
                {
                    MimeType = "text/plain";
                }
                filecontent = new FileContentResult(file, MimeType);
                filecontent.FileDownloadName = FileName;
                return filecontent;
            }
            else
            {
                return null;
            }
            }
            catch (Exception ex)
            {
                return null;
            }
        }     

    }
}
