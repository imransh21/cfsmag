﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.DataAccessLayer;

namespace TransportMag.Areas.Store.Controllers
{
    public class QuotationMappingController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult QuotationMapping()
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public ActionResult GetQuotationMapping(IndentDtls pIndentDtls)
        {
            ArrayList arrIndentDtls = new ArrayList();
            arrIndentDtls = IndentDtls.GetIndentDtlsQuotationMap(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public ActionResult GetQuotationVendorDtls(IndentDtls pIndentDtls)
        {
            ArrayList arrIndentDtls = new ArrayList();
            arrIndentDtls = IndentDtls.GetIndentDtlsQuotationVendorDtls(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        //public ActionResult SaveData(List<IndentQuotationRequest> pIndentQuotationRequest)
        //{
        //    string ErrorMsg = "";

        //    if (pIndentQuotationRequest != null) {
        //        foreach (IndentQuotationRequest item in pIndentQuotationRequest)
        //        {

        //            item.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
        //            if (item.IndentQuotReqRefId == 0)
        //            {
                //   IndentQuotationRequest.Insert(item);
            
        //            }


        //            if (item.FinalQuotation == "Y" && item.QuotAmount != 0)
        //            {
        //                IndentQuotationRequest.UpdateFinalQuotaion(item);
        //            }

        //            if (item.ErrorMessage != "")
        //            {
        //                ErrorMsg = item.ErrorMessage;
        //                break;
        //            }
        //        }
        //    }

        //    return Json(new { ErrorMessage = ErrorMsg }, JsonRequestBehavior.AllowGet);
        //}




        [HttpPost]
        [Compress]
        public ActionResult SaveData(List<IndentQuotationRequest> pIndentQuotationRequest)
        {
            string ErrorMsg = "";

            if (pIndentQuotationRequest != null)
            {
                DBAccess db = new DBAccess();
                try
                {
                    db.BeginTransaction();

                    foreach (IndentQuotationRequest item in pIndentQuotationRequest)
                    {
                        IndentQuotationRequest IndentQuotationRequestAp = new IndentQuotationRequest();
                        item.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                        item.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                        if (item.IndentQuotReqRefId <= 0)
                        {
                            IndentQuotationRequestAp = IndentQuotationRequest.InsertDB(item,db);
                        }
                        else
                        {
                            IndentQuotationRequestAp = IndentQuotationRequest.UpdateDB(item,db);
                        }
                        if (IndentQuotationRequestAp.ErrorMessage!="")
                        {
                            throw new Exception(IndentQuotationRequestAp.ErrorMessage);
                        }
                        if (item.FinalQuotation == "Y" && item.QuotAmount != 0)
                        {
                            IndentQuotationRequestAp=IndentQuotationRequest.UpdateFinalQuotaion(item,db);
                        }

                        //if (item.ErrorMessage != "")
                        //{
                        //    ErrorMsg = item.ErrorMessage;
                        //    break;
                        //}
                    }
                    db.CommitTransaction();
                }

                catch (Exception ex)
                {
                  //  pIndentQuotationRequest.ErrorMessage = ex.Message;
                    try
                    {
                        db.RollbackTransaction();
                    }
                    catch (Exception ex1)
                    {
                    }
                }

                db.CloseDB();
            
        }
            return Json(new { ErrorMessage = ErrorMsg }, JsonRequestBehavior.AllowGet);
        }

        //[HttpPost]
        //public ActionResult UpdateQuotData(IndentQuotationRequest pIndentQuotationRequest)
        //{
        //    if (pIndentQuotationRequest.FinalQuotation == "Y" && pIndentQuotationRequest.QuotAmount > 0)
        //    {
        //        pIndentQuotationRequest = IndentQuotationRequest.UpdateFinalQuotaion(pIndentQuotationRequest);
        //    }
        //    return Json(pIndentQuotationRequest, JsonRequestBehavior.AllowGet);

        //}



        [HttpPost]
        [Compress]
        public ActionResult GetQuotationDtlLookupData(IndentDtls pIndentDtls)
        {
            ArrayList arrIndentDtls = new ArrayList();
            arrIndentDtls = IndentDtls.GetIndentDtlsQuotationLookupData(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public ActionResult GetQuotationDtlItemData(IndentDtls pIndentDtls)
        {
            ArrayList arrIndentDtls = new ArrayList();
            arrIndentDtls = IndentDtls.GetIndentDtlsQuotFilterItemName(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public ActionResult GetAllQuotationDtlFilter(IndentDtls pIndentDtls)
        {
            ArrayList arrIndentDtls = new ArrayList();
            arrIndentDtls = IndentDtls.GetIndentDtlsQuotFilterAllData(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }

    }
}
