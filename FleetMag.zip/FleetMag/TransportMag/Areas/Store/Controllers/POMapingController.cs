﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Store.Controllers
{
    public class POMappingController : Controller
    {

        public ActionResult POMapping()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult LoadAllIndentPendingForHodApp(IndentHdr pIndentHdr)
        {
            //pKeyReferenceCls = KeyReferenceCls.GetMaterData(pKeyReferenceCls);
            int loginLocation = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);

            pIndentHdr.List = IndentHdr.GetAllIndentForHODApproved(loginLocation);
            // var iList = JsonConvert.SerializeObject(arrList, Formatting.None);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult GetAllVendorDtls(VendorMaster pVendorMaster)
        {
            pVendorMaster.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVendorMaster = VendorMaster.GetVendorMasterAll(pVendorMaster);
            return Json(arrVendorMaster, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(PoMappingDetails pPoMappingDetails)
        {
            pPoMappingDetails.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pPoMappingDetails = PoMappingDetails.InsertUpdateDetails(pPoMappingDetails);
            return Json(pPoMappingDetails, JsonRequestBehavior.AllowGet);
        }

    }
}
