﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Store.Controllers
{
    public class IndentGenarationPrintController : Controller
    {

        [HttpPost]
        [Compress]
        public JsonResult GetIndentPrintDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.LocationId =  Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            IndentHdr.GetIndentHdrByID(pIndentHdr);
            IndentDtls pIndentDtls = new IndentDtls();
            pIndentDtls.IndentRefId = pIndentHdr.IndentRefId;
            ViewBag.IndentRefid = pIndentHdr.IndentRefId;
            pIndentHdr.IndentDtlsList = IndentDtls.GetIndentDtlsByIndentId(pIndentDtls);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }
    }
}
