﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsReturnJobController : Controller
    {
        //
        // GET: /Store/GoodsReturnJob/

        public ActionResult GoodsReturn()
        {
            return PartialView();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockReqData(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            ds = WorkInstructions.GetStockReqDataListReturn(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockReqJobListLookup(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            ds = WorkInstructions.GetStockReqJOBLookup(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetStockJobVehicleDetails(WorkInstructions pWorkInstructions)
        {
            WorkInstructions.GetWorkInstructionsByJobDetails(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveMaterialIssue(WorkInstructions pWorkInstructions)
        {
            WorkInstructions.updateMaterialReturn(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }


        public ActionResult GoodsReturnJobPrint()
        {
            return View();
        }

        [HttpPost]
        [Compress]
        public JsonResult GetAllGoodRetunQlist(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = WorkInstructions.GetGoodRetunQlistAll(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult GetStockListByDepot(WorkInstructions pWorkInstructions)
        {
            DataSet ds;
            pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = WorkInstructions.GetGoodRetunQlistAll(pWorkInstructions);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }
    }
}
