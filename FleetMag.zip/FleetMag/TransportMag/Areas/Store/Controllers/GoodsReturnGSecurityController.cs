﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using System.Collections;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using System.Data;
using System.Linq;
using Newtonsoft.Json;
namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsReturnGSecurityController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult GoodsReturnGSecurity()
        {
            return View();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetPoDetailsLookup(PoHdr pPoHdr)
        {
            ArrayList pArrList = new ArrayList();
            pArrList = PoHdr.GetPolookupForPoGen(pPoHdr);
            return Json(pArrList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult GetGoodsPendingList(PoHdr pPoHdr)
        {

            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            pPoHdr.List = PoHdr.GetGoodsReturnPedingList(pPoHdr);
            return Json(pPoHdr.List, JsonRequestBehavior.AllowGet);
        }

        [Compress]
        [HttpPost]
        public JsonResult GetGoodsReturnGateSecurityDtls(PoHdr ppohdr)
        {
            DataSet ds = new DataSet();
            ds = PoHdr.GetGoodsReturnGateSecurityDtls(ppohdr);
            return Json(JsonConvert.SerializeObject(ds, Formatting.Indented), JsonRequestBehavior.AllowGet);
        
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveReturnGoodsGateSecurity(GoodsReturnStoreHdr pGoodsReturnStoreHdr)
        {
            foreach (GoodsReturnStoreHdr p in pGoodsReturnStoreHdr.GoodReturnGateSecurityList)
            {
                p.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                p.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                
            GoodsReturnStoreHdr.InsertDBDataGateSecurity(p);
            }
            return Json(pGoodsReturnStoreHdr, JsonRequestBehavior.AllowGet);
        }

    }
}
