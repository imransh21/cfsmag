﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class GoodsReturnStoreController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult GoodsReturnStore()
        {
            return View();
        }


        [Compress]
        [HttpPost]
        public JsonResult GetPoDetailsLookup(PoHdr pPoHdr)
        {
            ArrayList pArrList = new ArrayList();
            pArrList=PoHdr.GetPoGoodsReturnLookup(pPoHdr);
            return Json(pArrList, JsonRequestBehavior.AllowGet);
        }

        [Compress]
        [HttpPost]
        public JsonResult GetGoodsReturnPodetails(PoHdr ppohdr)
        {
            DataSet ds = new DataSet();
            ds = PoHdr.GetGoodsReturnPoDtls(ppohdr);
            return Json(JsonConvert.SerializeObject(ds, Formatting.Indented), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveReturnGoodsStore(GoodsReturnStoreHdr pGoodsReturnStoreHdr)
        {
            GoodsReturnStoreHdr.InsertDBData(pGoodsReturnStoreHdr);
            return Json(pGoodsReturnStoreHdr, JsonRequestBehavior.AllowGet);
        }
    }
}
