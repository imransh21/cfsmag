﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.DataAccessLayer;

namespace TransportMag.Areas.Store.Controllers
{
    public class IndentgenrationApprovalController : Controller
    {

        public ActionResult IndentgenrationApproval()
        {
            return View();
        }


        [HttpPost]
        public JsonResult GetAllDetails( string fromDate, string Todate, int LocationId)
        {
            DBAccess db = new DBAccess(); // object:db for database connectivity from class:DBAccess
            DataSet ds = new DataSet();
            try
            {
                ds = db.storedprocedure_ReadDT("PKG_SELECT.INDENT_GENERATION_APP_REPORT", "'" + fromDate + "','" + Todate + "'");
            }
            catch (Exception ex)
            {
               
            }
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }
    }
}
