﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class POApprovalController : Controller
    {
        //
        // GET: /Store/IndentGenaration/

        public ActionResult POApproval()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult AcceptPoDetails(PoHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = PoHdr.SavePoApproveDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult GetPOLookupForPOApproval(PoHdr pPoHdr)
        {
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = PoHdr.GetPolookupForPoApproval(pPoHdr);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public JsonResult GetPOPendingList(PoHdr pPoHdr)
        {

            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            pPoHdr.List = PoHdr.GetPOPedingforAprovalList(pPoHdr);
            return Json(pPoHdr.List, JsonRequestBehavior.AllowGet);
        }


          [HttpPost]
          [Compress]
        public JsonResult GetPOLookPulist(PoHdr pPoHdr)
        {

             pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            pPoHdr.List = PoHdr.GetPOPedinglookUpList(pPoHdr);
            return Json(pPoHdr.List, JsonRequestBehavior.AllowGet);
        }

        
        [HttpPost]
        [Compress]
        public JsonResult UpdatePoDtls(PoHdr pPoHdr)
        {
            //pPoHdr. = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pPoHdr = PoHdr.UpdatePOStatus(pPoHdr);
            foreach (PoHdr pPoHdr1 in pPoHdr.List)
            {
                if (pPoHdr != null)
                {
                    GetPrint(pPoHdr1);
                }
            }
            return Json(pPoHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult GetPOApprovalListByDepot(PoHdr pPoHdr)
        {
            DataSet ds;
            pPoHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ds = PoHdr.GetPOApprovalByDepot(pPoHdr);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

        
        public void  GetPrint(PoHdr pPoHdr)
        {

            try
            {   
                string str = "--disable-smart-shrinking --page-size A4 --margin-top 0 --margin-bottom 0 --margin-left 0 --margin-right 0  --header-font-name Verdana";
                string url = System.Configuration.ConfigurationSettings.AppSettings["PrintPdfUrl"]+pPoHdr.PoId;
                string filepath = System.Configuration.ConfigurationSettings.AppSettings["PDFGenPath"];
                string filename = Regex.Replace(pPoHdr.PoNo, @"[^0-9a-zA-Z]+", "_")+ ".pdf";//"1.pdf";
                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo(System.Configuration.ConfigurationSettings.AppSettings["wkhtmltopdf"]);


                psi.UseShellExecute = false;
                psi.Arguments = str + " " + url + " " + filepath + filename;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardInput = true;
                psi.RedirectStandardError = true;
                psi.WorkingDirectory = System.Configuration.ConfigurationSettings.AppSettings["PDFGenPath"]; 
                System.Diagnostics.Process proc = System.Diagnostics.Process.Start(psi);
                //System.IO.StreamReader strm = System.IO.File.OpenText(strFilePath);
                //System.IO.StreamReader sOut = proc.StandardOutput;
                System.IO.StreamWriter sIn = proc.StandardInput;
                //  while (strm.Peek() != -1)
                //  {
                //      sIn.WriteLine(strm.ReadLine());
                //  }
                //  strm.Close();
                //string stEchoFmt = "# {0} run successfully. Exiting";


                //sIn.WriteLine(String.Format(stEchoFmt, strFilePath));
                sIn.WriteLine("EXIT");


                // Close the process
                proc.Close();


                // Read the sOut to a string.
                // string results = sOut.ReadToEnd().Trim();



                // Close the io Streams;
                sIn.Close();
                //    sOut.Close();



                // Write out the results.
                //string fmtStdOut = "<font face=courier size=0>{0}</font>";
                //this.Response.Write(String.Format(fmtStdOut,results.Replace(System.Environment.NewLine, "<br>")));
                pPoHdr.PoFilePath = filepath + filename;
                PoHdr.UpdatePOFilePath(pPoHdr);
            }
            catch (Exception ex)
            {
                pPoHdr.ErrorMessage = ex.Message; 
            }            
        }

        [HttpGet] 
        public ActionResult POApprovalPrint()
        {
            return View();
        }


        [HttpPost]
        [Compress]
        public JsonResult GetItemHistory(IndentDtls pIndentDtls)
        {
            List<IndentDtls> arrIndentDtls = new List<IndentDtls>();
            arrIndentDtls = IndentDtls.GetIndentDtlsBybyPartNo(pIndentDtls);
            return Json(arrIndentDtls, JsonRequestBehavior.AllowGet);
        }
    }
}
