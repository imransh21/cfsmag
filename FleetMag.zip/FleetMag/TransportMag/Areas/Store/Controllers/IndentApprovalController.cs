﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Store.Controllers
{
    public class IndentApprovalController : Controller
    {
        public ActionResult IndentApproval()
        {
            return PartialView();
        }


        [HttpPost]
        [Compress]
        public JsonResult LoadAllIndentPendingForHodApp(IndentHdr pIndentHdr)
        {
            //pKeyReferenceCls = KeyReferenceCls.GetMaterData(pKeyReferenceCls);
            int loginLocation = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //return Json(pKeyReferenceCls, JsonRequestBehavior.AllowGet);

            pIndentHdr.List = IndentHdr.GetAllIndentForHODApp(loginLocation);
            // var iList = JsonConvert.SerializeObject(arrList, Formatting.None);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult SaveDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = IndentHdr.InsertUpdateStatusDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [Compress]
        public JsonResult SubmitDetails(IndentHdr pIndentHdr)
        {
            pIndentHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pIndentHdr = IndentHdr.InsertUpdateHODDetails(pIndentHdr);
            return Json(pIndentHdr, JsonRequestBehavior.AllowGet);
        }



        [HttpPost]
        [Compress]
        public JsonResult PendingIndentLookUpData(IndentHdr pIndentHdr)
        {
            pIndentHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pIndentHdr.List = IndentHdr.GetAllIndenHODlookup(pIndentHdr);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [Compress]
        public JsonResult DepotLookUpData(DepotMastercls pDepotMastercls)
        {
            //pDepotMastercls. = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrDepotMasterlist = new ArrayList();
            arrDepotMasterlist = DepotMastercls.GetDepotMasterLookUp(pDepotMastercls);
            return Json(arrDepotMasterlist, JsonRequestBehavior.AllowGet);

        }


        [HttpPost]
        [Compress]
        public JsonResult IndentFilterData(IndentHdr pIndentHdr)
        {

            pIndentHdr.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pIndentHdr.List = IndentHdr.GetAllIndentFilterData(pIndentHdr);
            return Json(pIndentHdr.List, JsonRequestBehavior.AllowGet);
        }

    }
}
