﻿app.controller("QuotationReqCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, QuotationReqAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = true;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    SerachIndentDetails();

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownIndent = true;
        
    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownIndent = false;
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
          }

    $scope.SaveDtls = function () {
        var ObjectData=[]
        angular.forEach($scope.IndentListDtls, function (value, key) {           
          var objDatavalue=  value.IndentQuotationRequest.filter(function (value) {
                return value.MailQuotation == 'Y';
          });
       
          angular.forEach(objDatavalue, function (value1, key1) {              
              var inputParam = {
                  IndentRefId: value.IndentRefId,
                  ItemId: value.PartId,
                  VendorId: value1.VendorId,
                  MailQuotation:value1.MailQuotation
             }
             ObjectData.push(inputParam);
          });
        });
        var getData = QuotationReqAJService.SaveQuotationReqDtls(ObjectData);
        getData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                SerachIndentDetails();
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
           
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });

    }
    
    $scope.DisplayData = function () {
        SerachIndentDetails();
    }

    function SerachIndentDetails() {
        var getData = QuotationReqAJService.GetQuotationData();
        getData.then(function (Response) {
            $scope.IndentListDtls = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });

    }

    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = true;
        $scope.SelectAllData = 'N';
        SerachIndentDetails();
    }

    function ClearData() {
        $scope.IndentRefId = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentDate = undefined;
        $scope.NatureOfIndent = undefined;
        $scope.DepotCode = undefined;
        $scope.ExpDelvDate = undefined;
    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;               
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
    }

 
    $scope.GetVendorDetails = function (rowData, Index) {     
        $scope.RowIndex = Index;
    }



    
});