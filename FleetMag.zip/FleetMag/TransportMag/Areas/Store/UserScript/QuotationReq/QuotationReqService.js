﻿app.service("QuotationReqAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetQuotationData = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationMapping/GetQuotationMapping",            
            dataType: "json"
        });
        return response;
    }

    this.GetQuotationVendorData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationMapping/GetQuotationVendorDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.SaveQuotationReqDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationMapping/SaveData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


});