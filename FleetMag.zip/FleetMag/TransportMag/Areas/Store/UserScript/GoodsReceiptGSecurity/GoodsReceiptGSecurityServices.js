﻿app.service("GoodsReceiptGSecurityAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptGSecurity/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetPoData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptGSecurity/LoadPoDetailsByPoNo",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.getItemById = function (UserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptGSecurity/GetGrrDetailsByGrId",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }
});