﻿app.controller("CntrlGoodsReceiptStore", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsReceiptStoreAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isInWrdTrans = true;

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }


    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = true;     
    }

    function ClearData() {
        $scope.IndentRefId = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentDate = undefined;
        $scope.NatureOfIndent = undefined;
        $scope.DepotCode = undefined;
        $scope.ExpDelvDate = undefined;
        $scope.IndentDetailsList = [];
        DefaultRownGrd();
    }

    $scope.AddDtls = function () {
        // ClearData();
        $scope.isInWrdTrans = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
    }

});