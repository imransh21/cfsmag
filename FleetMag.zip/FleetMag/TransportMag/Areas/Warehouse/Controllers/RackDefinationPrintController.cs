﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Warehouse.Controllers
{
    public class RackDefinationPrintController : Controller
    {

        [HttpPost]
        public JsonResult GetBlockMasterRackDetails(BlockMaster pBlockMaster)
        {
            //pBlockMaster.BlockId = pBlockMaster.BlockId;
            pBlockMaster.blocklist = BlockMaster.GetBlockMasterRackDetails(pBlockMaster);
            return Json(pBlockMaster, JsonRequestBehavior.AllowGet);
        }

   
    }
}
