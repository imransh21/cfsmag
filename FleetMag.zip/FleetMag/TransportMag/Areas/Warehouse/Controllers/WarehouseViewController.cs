﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Warehouse.Controllers
{
    public class WarehouseViewController : Controller
    {
        //
        // GET: /Warehouse/WarehouseView/

        public ActionResult WarehouseView()
        {
            return PartialView();
        }
        [HttpPost()]
        public string LineLookup(CustomerMastercls pCustomerMaster)
        {
            try
            {
                DataSet dt = new DataSet();
                dt = CustomerMastercls.GetLineMasterFilter(pCustomerMaster);
                string json = JsonConvert.SerializeObject(dt.Tables[0], Formatting.Indented);
                dt.Dispose();
                return json;
            }
            catch (Exception ex)
            {
                return null;
            }

        }


        [HttpPost()]
        public JsonResult GetReportFilterData(RepReportParam pRepReportParam)
        {
            ArrayList arrRepReport;
            arrRepReport = RepReportParam.GetRepParamByCode(pRepReportParam);
            object RepReport = JsonConvert.SerializeObject(arrRepReport, Formatting.None);
            return Json(RepReport, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult GetWarehouseBlockList()
        {
            ArrayList arrBlockList;
            arrBlockList = BlockMaster.GetBlockMasterWarehouseViewAll();
            object BlockList = JsonConvert.SerializeObject(arrBlockList, Formatting.None);
            return Json(BlockList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost()]
        public JsonResult GetWarehouseViewDetails(BlockMaster pBlockMaster)
        {
            // Dim arrYardList As ArrayList
            // arrYardList = YardBlockLaneColumnSts.GetWarehouseBlockLaneColumnStsByTrmlBlockId(pBlockMaster)
            // Dim YardList = JsonConvert.SerializeObject(arrYardList, Formatting.None)
            // Return Json(YardList, JsonRequestBehavior.AllowGet)
            DataSet ds = new DataSet();
            ds = YardBlockLaneColumnSts.GetWarehouseBlockLaneColumnStsByTrmlBlockIdDT(pBlockMaster);
            object YardList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(YardList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
      public  JsonResult GetYardViewDetailsLaneVW(BlockMaster pBlockMaster)
        {
            // Dim arrYardList As ArrayList
            // arrYardList = YardBlockLaneColumnSts.GetYardBlockLaneColumnStsByTrmlLaneView(pBlockMaster)
            // Dim YardList = JsonConvert.SerializeObject(arrYardList, Formatting.None)
            // Return Json(YardList, JsonRequestBehavior.AllowGet)
            DataSet ds = new DataSet();
            ds = YardBlockLaneColumnSts.GetYardBlockLaneColumnStsByTrmlLaneViewDT(pBlockMaster);
            object YardList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(YardList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetYardViewDetailsColWise(BlockMaster pBlockMaster)
        {
            DataSet ds = new DataSet();
            ds = YardBlockLaneColumnSts.GetYardBlockLaneColumnStsWHByColWiseDT(pBlockMaster);
            var YardList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(YardList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetWHCargoDetails(int YardId)
        {
            DataSet ds = new DataSet();
            ds = YardBlockLaneColumnSts.GetWhCargoDetails(YardId);
            var YardList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(YardList, JsonRequestBehavior.AllowGet);
        }


    }
}
