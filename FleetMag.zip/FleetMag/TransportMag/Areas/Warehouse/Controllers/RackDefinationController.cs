﻿using Newtonsoft.Json;
using System;
using System.Net;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;



namespace TransportMag.Areas.Warehouse.Controllers
{
    public class RackDefinationController : Controller
    {
        //
        // GET: /Warehouse/RackDefination/

        public ActionResult RackDefination()
        {
            return View();
        }
        public ActionResult RackDefinationPrint(IndentHdr pIndentHdr)
        {
            //IndentDtls pIndentDtls = new IndentDtls();
            //pIndentDtls.IndentRefId = pIndentHdr.IndentRefId;
            //pIndentHdr.IndentDtlsList = IndentDtls.GetIndentDtlsByIndentId(pIndentDtls);
            // pIndentHdr.IndentRefId = ViewBag.IndentRefid;
            return View();
        }


        [HttpPost]
        public string LoadAllTerminalYards()
        {
            List<DepotMastercls> TerminalList = new List<DepotMastercls>();
            TerminalList = null;
            ArrayList arrYardBlocks = BlockMaster.GetBlockMasterRackAll();

            List<BlockMaster> YardBlockList = new List<BlockMaster>();
            YardBlockList = arrYardBlocks.Cast<BlockMaster>().ToList();

            List<DepotMastercls> arrFromatedFinYardBlockList = new List<DepotMastercls>();
            arrFromatedFinYardBlockList = GetMainList(TerminalList, YardBlockList);
            return JsonConvert.SerializeObject(arrFromatedFinYardBlockList);
        }

        public static List<DepotMastercls> GetMainList(List<DepotMastercls> TerminalList, List<BlockMaster> YardBlockList)
        {
            List<DepotMastercls> TerminalsAll = new List<DepotMastercls>();
            List<BlockMaster> temp = new List<BlockMaster>();
            temp = (from t in YardBlockList
                    select t).ToList();
            DepotMastercls k = new DepotMastercls();
            k.YardBlocks = temp;
            TerminalsAll.Add(k);
            // Next

            return TerminalsAll;
        }

        [HttpPost]
        public JsonResult SaveDetails(BlockMaster pExtendedBlockMaster)
        {
            pExtendedBlockMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pExtendedBlockMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);

            pExtendedBlockMaster.BlockType = "R";

            pExtendedBlockMaster = ExtendedBlockMaster.InsertUpdateRackDetails(pExtendedBlockMaster);

            if (pExtendedBlockMaster.ErrorMessage != "")
                return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);

            // 'Dim jsonData = JsonConvert.SerializeObject(arrContList, Formatting.None)
            return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadYardBlockRackById(BlockMaster pExtendedBlockMaster)
        {
            pExtendedBlockMaster = ExtendedBlockMaster.GetAllRackBlockMasterByID(pExtendedBlockMaster);

            return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
        }

        public string GetTreeView(ExtendedBlockMaster pUserMaster)
        {
            if (ModelState.IsValid == true)
            {


                // 'Load Menu
                System.Collections.ArrayList arrMenuList = ExtendedBlockMaster.PrepareTreeViewItem(Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]));
                // ----------------------------------------------------------------------------------------------------------------------------------------------------
                // -------------- Convert ArrayList it Generic List Collection item 
                // --------------
                // ----------------------------------------------------------------------------------------------------------------------------------------------------
                List<ExtendedBlockMaster> menuList = new List<ExtendedBlockMaster>();
                menuList = arrMenuList.Cast<ExtendedBlockMaster>().ToList();
                // ----------------------------------------------------------------------------------------------------------------------------------------------------
                // -------------- Format the Menu and Sub Menu Items in JSON Object
                // --------------
                // ----------------------------------------------------------------------------------------------------------------------------------------------------
                List<ExtendedBlockMaster> arrFromatedFinMenu = new List<ExtendedBlockMaster>();

                arrFromatedFinMenu = MyFunction.GetToTreeMainMenu(menuList);
                pUserMaster.Menu = arrFromatedFinMenu;

                return JsonConvert.SerializeObject(pUserMaster);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pUserMaster.ErrorMessage = message;
                return JsonConvert.SerializeObject(pUserMaster);
            }
        }


    }
}
