﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TransportMag.Areas.Warehouse.Controllers
{
    public class WHBookingController : Controller
    {
        //
        // GET: /Warehouse/WHBooking/

        public ActionResult WhBooking()
        {
            return View();
        }

    }
}
