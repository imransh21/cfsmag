﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Warehouse.Controllers
{
    public class WarehouseCreationController : Controller
    {


        public ActionResult WarehouseCreation()
        {
            return View();
        }

        [HttpPost()]
        public JsonResult GetWarehouseBlockList()
        {
            ArrayList arrBlockList;
            arrBlockList = BlockMaster.GetBlockMasterWarehouseViewAll();
            object BlockList = JsonConvert.SerializeObject(arrBlockList, Formatting.None);
            return Json(arrBlockList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost()]
        public JsonResult GetRakeListByWhId(BlockMaster p)
        {
            List<BlockMaster>  arrBlockList;
            arrBlockList = BlockMaster.GetRackDetailsForWareHouse(p);
            object BlockList = JsonConvert.SerializeObject(arrBlockList, Formatting.None);
            return Json(arrBlockList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost()]
        public JsonResult CreateBlock(BlockMaster pBlockMaster)
        {
            pBlockMaster = BlockMaster.CreateBlock(pBlockMaster);
            object objBlockMaster = JsonConvert.SerializeObject(pBlockMaster, Formatting.None);
            return Json(objBlockMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult GetWhDetails(BlockMaster p)
        {
            List<BlockMaster> arrBlockList;
            arrBlockList = BlockMaster.GetDetailsForWareHouse(p);
            object BlockList = JsonConvert.SerializeObject(arrBlockList, Formatting.None);
            return Json(arrBlockList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult RemoveBlock(BlockMaster pBlockMaster)
        {
            pBlockMaster = BlockMaster.DeleteBlock(pBlockMaster);
            object objBlockMaster = JsonConvert.SerializeObject(pBlockMaster, Formatting.None);
            return Json(objBlockMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult UpdateBlock(BlockMaster pBlockMaster)
        {
            pBlockMaster = BlockMaster.UpdateBlock(pBlockMaster);
            object objBlockMaster = JsonConvert.SerializeObject(pBlockMaster, Formatting.None);
            return Json(objBlockMaster, JsonRequestBehavior.AllowGet);
        }
    }
}
