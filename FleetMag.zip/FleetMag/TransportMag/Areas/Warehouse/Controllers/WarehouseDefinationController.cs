﻿using Newtonsoft.Json;
using System;
using System.Net;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;

namespace TransportMag.Areas.Warehouse
{
    public class WarehouseDefinationController : Controller
    {
        //
        // GET: /Warehouse/ProjectedWHPlanning/

        public ActionResult WarehouseDefination()
        {
            return PartialView();
        }

        [HttpPost]
        public string LoadAllTerminalYards()
        {
            List<DepotMastercls> TerminalList = new List<DepotMastercls>();
            TerminalList = null;
            ArrayList arrYardBlocks = BlockMaster.GetBlockMasterWhAll();

            List<BlockMaster> YardBlockList = new List<BlockMaster>();
            YardBlockList = arrYardBlocks.Cast<BlockMaster>().ToList();

            List<DepotMastercls> arrFromatedFinYardBlockList = new List<DepotMastercls>();
            arrFromatedFinYardBlockList = GetMainList(TerminalList, YardBlockList);
            return JsonConvert.SerializeObject(arrFromatedFinYardBlockList);
        }

        public static List<DepotMastercls> GetMainList(List<DepotMastercls> TerminalList, List<BlockMaster> YardBlockList)
        {
            List<DepotMastercls> TerminalsAll = new List<DepotMastercls>();
            List<BlockMaster> temp = new List<BlockMaster>();
            temp = (from t in YardBlockList
                    select t).ToList();
            DepotMastercls k = new DepotMastercls();
            k.YardBlocks = temp;
            TerminalsAll.Add(k);
            // Next

            return TerminalsAll;
        }

        [HttpPost]
        public JsonResult SaveDetails(BlockMaster pExtendedBlockMaster)
        {
            pExtendedBlockMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pExtendedBlockMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pExtendedBlockMaster.ParentBlockId = 0;
            pExtendedBlockMaster.BlockType = "W";
            if (pExtendedBlockMaster.RackBinType == null) {
                pExtendedBlockMaster.RackBinType = "N";
            }

            pExtendedBlockMaster = ExtendedBlockMaster.InsertUpdateWHDetails(pExtendedBlockMaster);

            if (pExtendedBlockMaster.ErrorMessage != "")
                return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);

            // 'Dim jsonData = JsonConvert.SerializeObject(arrContList, Formatting.None)
            return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadYardBlockWHById(BlockMaster pExtendedBlockMaster)
        {
            pExtendedBlockMaster = ExtendedBlockMaster.GetAllBlockMasterByID(pExtendedBlockMaster);

            return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
        }

        
         [HttpPost]
            public JsonResult LoadYardBlockById(BlockMaster pExtendedBlockMaster)
            {
                pExtendedBlockMaster = ExtendedBlockMaster.GetAllBlockMasterByID(pExtendedBlockMaster);

                return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
            }



            
           [HttpPost]
            public JsonResult UpdYardActiveStatus(YardBlockLaneColumnSts pYardBlockLaneColumnSts)
            {
                if (ModelState.IsValid == true)
                {
                    // 'Updation to db is pending. discussion required
                    // 'pYardBlockLaneColumnSts = ExtendedYardBlockLaneColumnSts.UpdateStatus(pYardBlockLaneColumnSts)

                    if (pYardBlockLaneColumnSts.ErrorMessage != "")
                        return Json(pYardBlockLaneColumnSts, JsonRequestBehavior.AllowGet);

                    // 'Dim jsonData = JsonConvert.SerializeObject(arrContList, Formatting.None)
                    return Json(pYardBlockLaneColumnSts, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                    pYardBlockLaneColumnSts.ErrorMessage = message;

                    return Json(pYardBlockLaneColumnSts, JsonRequestBehavior.AllowGet);
                }
            }


       //[HttpPost]
       //public JsonResult GetCommodityDtls(string Commodity)
       //{
       //    DataSet arrcmdtlist = new DataSet();
       //    arrcmdtlist = BlockMaster.getCommodityDtls(Commodity);
       //    var pResultList = JsonConvert.SerializeObject(arrcmdtlist.Tables(0), Formatting.None);
       //    return Json(pResultList, JsonRequestBehavior.AllowGet);
       //}

           [HttpPost]
           public JsonResult GetStateListLookup(StateMaster pStateMaster)
           {
               ArrayList StateList = new ArrayList();
               StateList = StateMaster.GetStateMasterLookUp(pStateMaster);
               return Json(StateList, JsonRequestBehavior.AllowGet);
           }


    }
}
