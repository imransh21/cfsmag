﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Warehouse
{
    public class ProjectedWHPlanningController : Controller
    {
        //
        // GET: /Warehouse/ProjectedWHPlanning/

        public ActionResult ProjectedWHPlanning()
        {
            return PartialView(); 
        }
        [HttpPost]
        public JsonResult GetAllBlock()
        {
            ArrayList arrBlockList = BlockMaster.GetBlockMasterWhAll();
            //var BlockList = JsonConvert.SerializeObject(arrBlockList, Formatting.None);
            return Json(arrBlockList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost()]
        public JsonResult LoadStackDetailsById(YardBlockLaneColumnSts pYardBlockLaneColumnSts)
        {
            List<YardBlockLaneColumnSts> pYardBlockLaneColumnSts1;
            pYardBlockLaneColumnSts1 = YardBlockLaneColumnSts.GetWHStackDetails(pYardBlockLaneColumnSts);
            return Json(pYardBlockLaneColumnSts1, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadYardBlockById(BlockMaster pExtendedBlockMaster)
        {
            pExtendedBlockMaster = BlockMaster.GetAllBlockMasterByID(pExtendedBlockMaster);

            return Json(pExtendedBlockMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadLaneDtlsById(BlockColumnMaster pExtendedBlockMaster)
        {
            DataSet pResult = new DataSet();
            pResult = BlockColumnMaster.GetLaneWHWiseDetails(pExtendedBlockMaster);
           var pResultList = JsonConvert.SerializeObject(pResult.Tables[0], Formatting.None);
           return Json(pResultList, JsonRequestBehavior.AllowGet);
        }

    }
}
