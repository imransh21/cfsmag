﻿app.controller("VehicleMasterCtrl", function ($scope, $sessionStorage, $filter, ErrorMsgDisplay, HomeIndex, VehicleAJService, KeyRefrenceCtrlAJService) {

    $scope.isShown = true;
    $scope.isShownLease = true;
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShownVehicle = true;
    $scope.isShownEquipment = true;
    $scope.isShownBank = true;
    $scope.isShownunderAmc = true;
    $scope.isShownPermissibleSize = true;

    GetManufacturerList();
    GetEquipmentTypeList();
    GetVehicleTypeList();
    GetVehicleSizeList();
    GetVehicleLeaseFrom();
    GetVehicleBrokerFrom();

    $scope.GetLeaseSelect = function () {
        if ($scope.OwnLease == 'L') {
            $scope.isShownLease = false;
        }
        else {
            $scope.isShownLease = true;

        }
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownVehicle = false;
        $scope.isShown = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        if ($("#txtVehicleNo").hasClass('ui-autocomplete-input')) {
            $("#txtVehicleNo").autocomplete("destroy");
            $("#txtVehicleNo").removeData('autocomplete');
        }
    }

    $scope.CancelDtls = function () {
        $scope.isShown = true;
        $scope.isShownLease = true;
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShownVehicle = true;
        $scope.isShownEquipment = true;
        $scope.isShownBank = true;
        $scope.isShownunderAmc = true;
        ClearData();
    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage("/Home/Transportation");
    }
    $scope.SearchDtls = function () {

        ClearData();
        $scope.isShown = true;
        $scope.isShownVehicle = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false
        $scope.isShownSave = false;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        setTimeout(function () {
            document.getElementById("txtVehicleNo").focus();
        }, 1000);


        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtVehicleNo").autocomplete({

            source: function (request, response) {
                var InputParam = {
                    VehicleNo: $("#txtVehicleNo").val()
                }
                $.ajax({
                    url: baseUrl + '/Transport/VehicleMaster/GetVehicleLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.VehicleNo,
                                VehicleId: item.VehicleId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.VehicleNo = i.item.label;
                    $scope.VehicleId = i.item.VehicleId;
                    $scope.SearchVehicle();
                    $scope.isShownVehicle = true;
                });
            },
            minLength: 1
        });

    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownVehicle = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        var currentSelected = $filter('filter')($scope.VehicleTypeList, { Pkey: $scope.TruckType1 })[0]
        if (currentSelected.CodeValue == 'Equipment') {
            $scope.isShownEquipment = false;
        }
        else {
            $scope.EquipmentType = undefined;
            $scope.isShownEquipment = true;
        }

        if ($scope.OwnLease == 'L') {
            $scope.isShownLease = false;
        }
        else {
            $scope.isShownLease = true;
        }

        if ($scope.HypothecatedBankFlg == 'Y') {
            $scope.isShownBank = false;
        }
        else {
            $scope.isShownBank = true;
            $scope.BankName = undefined;
            $scope.Branch = undefined;
            $scope.LoanAmount = undefined;
            $scope.EmiDate = undefined;
            $scope.EmiTillDate = undefined;
            $scope.EmiAmount = undefined;
        }

        if ($scope.UnderAmc == 'Y') {
            $scope.isShownunderAmc = false;
        }
        else {
            $scope.isShownunderAmc = true;
            $scope.AmcExpiryDate = undefined;
        }
    }

    function ClearData() {
        $scope.VehicleId = undefined;
        $scope.LocationId = undefined;
        $scope.VehicleNo = undefined;
        $scope.ChassisNo = undefined;
        $scope.EngineNo = undefined;
        $scope.TruckType1 = undefined;
        $scope.EquipmentType = undefined;
        $scope.PermissibleSizes = undefined;
        $scope.TrailerCapacity = undefined;
        $scope.SpecialGearNo1 = undefined;
        $scope.SpecialGearNo2 = undefined;
        $scope.TareWt = undefined;
        $scope.TrailerLength = undefined;
        $scope.TrailerWidth = undefined;
        $scope.TrailerHeight = undefined;
        $scope.VehicleManufacturerId = undefined;
        $scope.ModelName = undefined;
        $scope.YearOfManufacturer = undefined;
        $scope.ContManufacturerId = undefined;
        $scope.OwnLease = undefined;
        $scope.AssetNo = undefined;
        $scope.LeaseFromTransporter = undefined;
        $scope.LeaseFromBroker = undefined;
        $scope.LeaseTillDate = undefined;
        $scope.PermitsAllowed = undefined;
        $scope.PermitExpiryDate = undefined;
        $scope.InsuranceBy = undefined;
        $scope.InsuranceNo = undefined;
        $scope.InsuranceExpiryDate = undefined;
        $scope.UnderAmc = undefined;
        $scope.AmcExpiryDate = undefined;
        $scope.LatestMeterReading = undefined;
        $scope.MeterReadingAsOn = undefined;
        $scope.NextMaintenanceSchType = undefined;
        $scope.NextMaintenanceDate = undefined;
        $scope.CurrentStatusTrailer = undefined;
        $scope.CurrentLocationTrailer = undefined;
        $scope.CurrentBooking = undefined;
        $scope.NoOfContainersHandled = undefined;
        $scope.CalcMeterReadingTransaction = undefined;
        $scope.TruckStatus = undefined;
        $scope.ModelId = undefined;
        $scope.UseFor = undefined;
        $scope.TruckGruop = undefined;
        $scope.VehicleSizeId = undefined;
        $scope.OpeningBalance = undefined;
        $scope.PoNo = undefined;
        $scope.PurchaseDate = undefined;
        $scope.VendorId = undefined;
        $scope.PurchaseValue = undefined;
        $scope.ContactName = undefined;
        $scope.PhoneNo = undefined;
        $scope.WarrantyExpDate = undefined;
        $scope.MilesKms = undefined;
        $scope.PurchaseMilage = undefined;
        $scope.HypothecatedBankFlg = undefined;
        $scope.BankName = undefined;
        $scope.Branch = undefined;
        $scope.LoanAmount = undefined;
        $scope.EmiDate = undefined;
        $scope.EmiTillDate = undefined;
        $scope.EmiAmount = undefined;
        $scope.VendorName = undefined;
    }

    $scope.SaveDtls = function () {
        debugger;
        if ($scope.VehicleNo == undefined || $scope.VehicleNo == null || $scope.VehicleNo == '') {
            $scope.errMsg = "Please Enter Vehicle No"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtVehicleNo").val('');
            setTimeout(function () {
                $("#txtVehicleNo").focus();
            }, 500);
            return;
        }

        if ($scope.ChassisNo == undefined || $scope.ChassisNo == null || $scope.ChassisNo == '') {
            $scope.errMsg = "Please Enter Chassis No"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtChassisNo").val('');
            setTimeout(function () {
                $("#txtChassisNo").focus();
            }, 500);
            return;
        }

        if ($scope.OwnLease == undefined || $scope.OwnLease == null || $scope.OwnLease == '') {
            $scope.errMsg = "Please Select Own / Lease"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstOwnLease").val('');
            setTimeout(function () {
                $("#lstOwnLease").focus();
            }, 500);
            return;
        }

        if ($scope.AssetNo == undefined || $scope.AssetNo == null || $scope.AssetNo == '') {
            $scope.errMsg = "Please Enter Asset No"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtAssetNo").val('');
            setTimeout(function () {
                $("#txtAssetNo").focus();
            }, 500);
            return;
        }

        if ($scope.EngineNo == undefined || $scope.EngineNo == null || $scope.EngineNo == '') {
            $scope.errMsg = "Please Enter Engine No"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtEngineNo").val('');
            setTimeout(function () {
                $("#txtEngineNo").focus();
            }, 500);
            return;
        }

        if ($scope.TruckType1 == undefined || $scope.TruckType1 == null || $scope.TruckType1 == '') {
            $scope.errMsg = "Please Enter Vehicle Type"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstTruckType").val('');
            setTimeout(function () {
                $("#lstTruckType").focus();
            }, 500);
            return;
        }
        if ($scope.isShownEquipment == false) {
            if ($scope.EquipmentType == undefined || $scope.EquipmentType == null || $scope.EquipmentType == '') {
                $scope.errMsg = "Please Enter Equipment Type"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstEquipmentType").val('');
                setTimeout(function () {
                    $("#lstEquipmentType").focus();
                }, 500);
                return;
            }
        }
        if ($scope.isShownPermissibleSize == false) {
            if ($scope.PermissibleSizes == undefined || $scope.PermissibleSizes == null || $scope.PermissibleSizes == '') {
                $scope.errMsg = "Please Enter Permissible Sizes"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstPermissibleSizes").val('');
                setTimeout(function () {
                    $("#lstPermissibleSizes").focus();
                }, 500);
                return;
            }
        }

        if ($scope.TrailerCapacity == undefined || $scope.TrailerCapacity == null || $scope.TrailerCapacity == '' || $scope.TrailerCapacity<=0) {
            $scope.errMsg = "Please Enter Trailor Capacity"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtTrailerCapacity").val('');
            setTimeout(function () {
                $("#txtTrailerCapacity").focus();
            }, 500);
            return;
        }

        if ($scope.TrailerLength == undefined || $scope.TrailerLength == null || $scope.TrailerLength == '' ||$scope.TrailerLength <=0) {
            $scope.errMsg = "Please Enter Trailor Length"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtLength").val('');
            setTimeout(function () {
                $("#txtLength").focus();
            }, 500);
            return;
        }

        if ($scope.TareWt == undefined || $scope.TareWt == null || $scope.TareWt == '' ||$scope.TareWt <=0) {
            $scope.errMsg = "Please Enter Tare Wt"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtTareWt").val('');
            setTimeout(function () {
                $("#txtTareWt").focus();
            }, 500);
            return;
        }


        //if ($scope.VehicleSizeId == undefined || $scope.VehicleSizeId == null || $scope.VehicleSizeId == '') {
        //    $scope.errMsg = "Please Enter Vehicle Size"
        //    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //    $("#lstVehicleSize").val('');
        //    setTimeout(function () {
        //        $("#lstVehicleSize").focus();
        //    }, 500);
        //    return;
        //}

        if ($scope.VehicleManufacturerId == undefined || $scope.VehicleManufacturerId == null || $scope.VehicleManufacturerId == '') {
            $scope.errMsg = "Please Enter Manufacturer"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstManufacturer").val('');
            setTimeout(function () {
                $("#lstManufacturer").focus();
            }, 500);
            return;
        }

        if ($scope.YearOfManufacturer == undefined || $scope.YearOfManufacturer == null || $scope.YearOfManufacturer == '') {
            $scope.errMsg = "Please Enter Manufacture Date"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtManufacturerDate").val('');
            setTimeout(function () {
                $("#txtManufacturerDate").focus();
            }, 500);
            return;
        }


        if ($scope.UnderAmc == undefined || $scope.UnderAmc == null || $scope.UnderAmc == '') {
            $scope.errMsg = "Please Select Under Amc"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstUnderAmc").val('');
            setTimeout(function () {
                $("#lstUnderAmc").focus();
            }, 500);
            return;
        }

        if ($scope.NextMaintenanceSchType == undefined || $scope.NextMaintenanceSchType == null || $scope.NextMaintenanceSchType == '') {
            $scope.errMsg = "Please Enter Next Maintenance Schedule Type"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtNextMaintenanceSchType").val('');
            setTimeout(function () {
                $("#txtNextMaintenanceSchType").focus();
            }, 500);
            return;
        }

        if ($scope.NextMaintenanceDate == undefined || $scope.NextMaintenanceDate == null || $scope.NextMaintenanceDate == '') {
            $scope.errMsg = "Please Enter Next Maintenance Date"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtNextMaintenanceDate").val('');
            setTimeout(function () {
                $("#txtNextMaintenanceDate").focus();
            }, 500);
            return;
        }


        if ($scope.LatestMeterReading == undefined || $scope.LatestMeterReading == null || $scope.LatestMeterReading == '' ||$scope.LatestMeterReading <=0) {
            $scope.errMsg = "Please Enter Latest Meter Reading"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtLatestMeterReading").val('');
            setTimeout(function () {
                $("#txtLatestMeterReading").focus();
            }, 500);
            return;
        }

        if ($scope.MeterReadingAsOn == undefined || $scope.MeterReadingAsOn == null || $scope.MeterReadingAsOn == '') {
            $scope.errMsg = "Please Enter Meter Reading As On"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtMeterReadingAsOn").val('');
            setTimeout(function () {
                $("#txtMeterReadingAsOn").focus();
            }, 500);
            return;
        }

        if ($scope.OpeningBalance == undefined || $scope.OpeningBalance == null || $scope.OpeningBalance == '' ||$scope.OpeningBalance <=0) {
            $scope.errMsg = "Please Enter Opening Balance"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtOpeningBalance").val('');
            setTimeout(function () {
                $("#txtOpeningBalance").focus();
            }, 500);
            return;
        }

        if ($scope.CurrentStatusTrailer == undefined || $scope.CurrentStatusTrailer == null || $scope.CurrentStatusTrailer == '') {
            $scope.errMsg = "Please Select Current Status Trailor"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#CurrentStatusTrailer").val('');
            setTimeout(function () {
                $("#CurrentStatusTrailer").focus();
            }, 500);
            return;
        }

        if (($scope.WarrantyExpDate == undefined || $scope.WarrantyExpDate == "") && ($scope.MilesKms == undefined || $scope.MilesKms == "" || $scope.MilesKms <= "0")) {
            $scope.errMsg = "Please Enter Warranty Expiry Date Or Miles/kms."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        debugger;

        if ($scope.PhoneNo == undefined || $scope.PhoneNo == "" || $scope.PhoneNo.length<10) {
            $scope.errMsg = "Please Enter 10 Digit Phone No."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        //if ($scope.PhoneNo.Length != 10) {
        //     debugger;
        //    $scope.errMsg = "Phone No should be 10 digit."
        //    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //    return;
        //}

     

        


        if ($scope.HypothecatedBankFlg == 'Y') {
            debugger;
            if ($scope.BankName == undefined || $scope.BankName == null || $scope.BankName == "") {
                $scope.errMsg = "Please enter Bank Name."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtBankName").focus()
                return;
            } else if ($scope.Branch == undefined || $scope.Branch == null || $scope.Branch == "") {
                $scope.errMsg = "Please enter Branch Name."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtBranchName").focus()
                return;
            } else if ($scope.LoanAmount == undefined || $scope.LoanAmount == null || $scope.LoanAmount == "" ||$scope.LoanAmount <=0) {
                $scope.errMsg = "Please enter Loan Amount."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtLoanAmount").focus()
                return;
            } else if ($scope.EmiDate == undefined || $scope.EmiDate == null || $scope.EmiDate == "") {
                $scope.errMsg = "Please enter EMI Date."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtEMIDate").focus()
                return;
            } else if ($scope.EmiTillDate == undefined || $scope.EmiTillDate == null || $scope.EmiTillDate == "") {
                $scope.errMsg = "Please enter EMI Till Date."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtEMITill").focus()
                return;
            } else if ($scope.EmiAmount == undefined || $scope.EmiAmount == null || $scope.EmiAmount == "" || $scope.EmiAmount <= 0) {
                $scope.errMsg = "Please enter EMI Amount."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtEMIAmount").focus()
                return;
            } else if (parseFloat($scope.LoanAmount) < parseFloat($scope.EmiAmount)) {
                $scope.errMsg = "Please enter Loan Amount Greater Than EMI Amoun."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtLoanAmount").focus()
                return;
            }

        }

        if ($scope.UnderAmc == "Y") {
            if ($scope.AmcExpiryDate == undefined || $scope.AmcExpiryDate == null || $scope.AmcExpiryDate == "") {
                $scope.errMsg = "Please Amc Expiry Date."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtAMCExpiryDate").focus()
                return;
            }
        }

        if ($scope.UnderAmc == "Y") {
            if ($scope.AmcExpiryDate == undefined || $scope.AmcExpiryDate == null || $scope.AmcExpiryDate == "") {
                $scope.errMsg = "Please enter Amc Expiry Date."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtAMCExpiryDate").focus()
                return;
            }
        }
        if ($scope.VehicleManufacturerId != "0" || $scope.VehicleManufacturerId != "?") {
            if ($scope.ModelName == undefined || $scope.ModelName == null || $scope.ModelName == "") {
                $scope.errMsg = "Please enter Model Name."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtModelName").focus()
                return;
            } else if ($scope.YearOfManufacturer == undefined || $scope.YearOfManufacturer == null || $scope.YearOfManufacturer == '') {
                $scope.errMsg = "Please Enter Manufacture Date"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtManufacturerDate").val('');
                setTimeout(function () {
                    $("#txtManufacturerDate").focus();
                }, 500);
                return;
            }
        }
        


        if ($scope.OwnLease == "L") {
            if ($scope.LeaseFromBroker == undefined || $scope.LeaseFromBroker == "0" || $scope.LeaseFromBroker == "?") {
                $scope.errMsg = "Please enter Lease From Broker."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstLeaseFromBroker").focus()
                return;
            } else if ($scope.LeaseTillDate == undefined || $scope.LeaseTillDate == null || $scope.LeaseTillDate == "") {
                $scope.errMsg = "Please Enter Lease Till Date"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#LeaseTillDate").val('');
                setTimeout(function () {
                    $("#LeaseTillDate").focus();
                }, 500);
                return;
            } else if ($scope.LeaseFromTransporter == undefined || $scope.LeaseFromTransporter == "0" || $scope.LeaseFromTransporter == "") {
                $scope.errMsg = "Please Enter Lease From Transporter"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstLeaseFrom").val('');
                setTimeout(function () {
                    $("#lstLeaseFrom").focus();
                }, 500);
                return;
            }
        }

        if ($scope.WarrantyExpDate != undefined && $scope.LeaseTillDate != undefined && $scope.LeaseTillDate!="" && $scope.WarrantyExpDate !="" ) {
            var d2 = $scope.WarrantyExpDate.split(" ");

            var todate = d2[0].split("/");

            var ttime = d2[1].split(":");

            var to = new Date(todate[2], parseInt(todate[1]) - 1, todate[0]);

            var d1 = $scope.LeaseTillDate.split(" ");

            var fmdate = d1[0].split("/");

            var ftime = d1[1].split(":");

            var from = new Date(fmdate[2], parseInt(fmdate[1]) - 1, fmdate[0]);  // -1 because months are from 0 to 11

            if (from > to) {

                $scope.errMsg = "Lease Till date can not be Greater than Warranty Expiry Date !"

                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#LeaseTillDate").val('');
                setTimeout(function () {
                    $("#LeaseTillDate").focus();
                }, 500);

                return;
            }
        }

        if ($scope.PurchaseDate != undefined && $scope.EmiDate != undefined && $scope.PurchaseDate != "" && $scope.EmiDate != "") {
            var d2 = $scope.PurchaseDate.split(" ");

            var todate = d2[0].split("/");

            var ttime = d2[1].split(":");

            var PurchaseDate = new Date(todate[2], parseInt(todate[1]) - 1, todate[0], ttime[0], ttime[1]);

            var d1 = $scope.EmiDate.split(" ");

            var fmdate = d1[0].split("/");

            var ftime = d1[1].split(":");

            var EmiDate = new Date(fmdate[2], parseInt(fmdate[1]) - 1, fmdate[0], ftime[0], ftime[1]);  // -1 because months are from 0 to 11

            if (EmiDate < PurchaseDate) {

                $scope.errMsg = " Emi date can not be less than Purchase Date !"

                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtEMIDate").val('');
                setTimeout(function () {
                    $("#txtEMIDate").focus();
                }, 500);

                return;
            }

        }


        //var CurDate = new Date();
        //if (to < CurDate) {
        //    $scope.setclass = "popupBase alert alertShowMsg";
        //    $scope.errMsg = "To date can not be less than System Date"
        //    $scope.isError = true;
        //    row.FromDate = undefined;
        //    $scope.Var = 'txtEffectToDate';
        //    return;
        //}
        

        var InputParam = {
            VehicleId: $scope.VehicleId,
            LocationId: $scope.LocationId,
            VehicleNo: $scope.VehicleNo,
            ChassisNo: $scope.ChassisNo,
            EngineNo: $scope.EngineNo,
            TruckType: $scope.TruckType1,
            EquipmentType: $scope.EquipmentType,
            PermissibleSizes: $scope.PermissibleSizes,
            TrailerCapacity: $scope.TrailerCapacity,
            SpecialGearNo1: $scope.SpecialGearNo1,
            SpecialGearNo2: $scope.SpecialGearNo2,
            TareWt: $scope.TareWt,
            TrailerLength: $scope.TrailerLength,
            TrailerWidth: $scope.TrailerWidth,
            TrailerHeight: $scope.TrailerHeight,
            VehicleManufacturerId: $scope.VehicleManufacturerId,
            ModelName: $scope.ModelName,
            YearOfManufacturer: $scope.YearOfManufacturer,
            ContManufacturerId: $scope.ContManufacturerId,
            OwnLease: $scope.OwnLease,
            AssetNo: $scope.AssetNo,
            LeaseFromTransporter: $scope.LeaseFromTransporter,
            LeaseFromBroker: $scope.LeaseFromBroker,
            LeaseTillDate: $scope.LeaseTillDate,
            PermitsAllowed: $scope.PermitsAllowed,
            PermitExpiryDate: $scope.PermitExpiryDate,
            InsuranceBy: $scope.InsuranceBy,
            InsuranceNo: $scope.InsuranceNo,
            InsuranceExpiryDate: $scope.InsuranceExpiryDate,
            UnderAmc: $scope.UnderAmc,
            AmcExpiryDate: $scope.AmcExpiryDate,
            LatestMeterReading: $scope.LatestMeterReading,
            MeterReadingAsOn: $scope.MeterReadingAsOn,
            NextMaintenanceSchType: $scope.NextMaintenanceSchType,
            NextMaintenanceDate: $scope.NextMaintenanceDate,
            CurrentStatusTrailer: $scope.CurrentStatusTrailer,
            CurrentLocationTrailer: $scope.CurrentLocationTrailer,
            CurrentBooking: $scope.CurrentBooking,
            NoOfContainersHandled: $scope.NoOfContainersHandled,
            CalcMeterReadingTransaction: $scope.CalcMeterReadingTransaction,
            TruckStatus: $scope.TruckStatus,
            ModelId: $scope.ModelId,
            UseFor: $scope.UseFor,
            TruckGruop: $scope.TruckGruop,
            VehicleSizeId: $scope.VehicleSizeId,
            OpeningBalance: $scope.OpeningBalance,
            PoNo: $scope.PoNo,
            PurchaseDate: $scope.PurchaseDate,
            VendorId: $scope.VendorId,
            PurchaseValue: $scope.PurchaseValue,
            ContactName: $scope.ContactName,
            PhoneNo: $scope.PhoneNo,
            WarrantyExpDate: $scope.WarrantyExpDate,
            MilesKms: $scope.MilesKms,
            PurchaseMilage: $scope.PurchaseMilage,
            HypothecatedBankFlg: $scope.HypothecatedBankFlg,
            BankName: $scope.BankName,
            Branch: $scope.Branch,
            LoanAmount: $scope.LoanAmount,
            EmiDate: $scope.EmiDate,
            EmiTillDate: $scope.EmiTillDate,
            EmiAmount: $scope.EmiAmount
        }

        var SaveData = VehicleAJService.SaveDetails(InputParam);
        SaveData.then(function (result) {

            if (result.data.ErrorMessage == "") {
               
                //ClearData();
                $scope.VehicleId = result.data.VehicleId;
                $scope.isShown = true;
                $scope.isShownLease = true;
                $scope.isShownAdd = true;
                $scope.isShownEdit = false;
                $scope.isShownSave = false;
                $scope.isShownSearch = true;
                $scope.isShownExit = true;
                $scope.isShownClear = false;
                $scope.isShownVehicle = true;
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.SearchVehicle();
            }
            else {
                $scope.errMsg = result.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });


    }

    function SearchVehicleById() {
        debugger;
        var InputParam = {
            VehicleId: $scope.VehicleId,
            LocationId: $scope.LocationId
        }
        var VehicleData = VehicleAJService.GetVehicleDtlsById(InputParam);
        VehicleData.then(function (result) {
            ClearData();
            $scope.VehicleId = result.data.VehicleId;
            $scope.LocationId = result.data.LocationId;
            $scope.VehicleNo = result.data.VehicleNo;
            $scope.ChassisNo = result.data.ChassisNo;
            $scope.EngineNo = result.data.EngineNo;
            $scope.PermissibleSizes = result.data.PermissibleSizes;
            $scope.TrailerCapacity = result.data.TrailerCapacity;
            $scope.SpecialGearNo1 = result.data.SpecialGearNo1;
            $scope.SpecialGearNo2 = result.data.SpecialGearNo2;
            $scope.TareWt = result.data.TareWt;
            $scope.TrailerLength = result.data.TrailerLength;
            $scope.TrailerWidth = result.data.TrailerWidth;
            $scope.TrailerHeight = result.data.TrailerHeight;
            $scope.VehicleManufacturerId = result.data.VehicleManufacturerId;
            $scope.ModelName = result.data.ModelName;
            $scope.YearOfManufacturer = result.data.YearOfManufacturer;
            $scope.ContManufacturerId = result.data.ContManufacturerId;
            $scope.OwnLease = result.data.OwnLease;

            $scope.AssetNo = result.data.AssetNo;
            $scope.LeaseFromTransporter = result.data.LeaseFromTransporter;
            $scope.LeaseFromBroker = result.data.LeaseFromBroker;
            $scope.LeaseTillDate = result.data.LeaseTillDate;
            $scope.PermitsAllowed = result.data.PermitsAllowed;
            $scope.PermitExpiryDate = result.data.PermitExpiryDate;
            $scope.InsuranceBy = result.data.InsuranceBy;
            $scope.InsuranceNo = result.data.InsuranceNo;
            $scope.InsuranceExpiryDate = result.data.InsuranceExpiryDate;
            $scope.UnderAmc = result.data.UnderAmc;
            $scope.AmcExpiryDate = result.data.AmcExpiryDate;
            $scope.LatestMeterReading = result.data.LatestMeterReading;
            $scope.MeterReadingAsOn = result.data.MeterReadingAsOn;
            $scope.NextMaintenanceSchType = result.data.NextMaintenanceSchType;
            $scope.NextMaintenanceDate = result.data.NextMaintenanceDate;
            $scope.CurrentStatusTrailer = result.data.CurrentStatusTrailer;
            $scope.CurrentLocationTrailer = result.data.CurrentLocationTrailer;
            $scope.CurrentBooking = result.data.CurrentBooking;
            $scope.NoOfContainersHandled = result.data.NoOfContainersHandled;
            $scope.CalcMeterReadingTransaction = result.data.CalcMeterReadingTransaction;
            $scope.TruckStatus = result.data.TruckStatus;
            $scope.ModelId = result.data.ModelId;
            $scope.UseFor = result.data.UseFor;
            $scope.TruckGruop = result.data.TruckGruop;
            $scope.VehicleSizeId = result.data.VehicleSizeId;
            $scope.OpeningBalance = result.data.OpeningBalance;
            $scope.TruckType1 = result.data.TruckType;

            $scope.EquipmentType = result.data.EquipmentType;
            $scope.PoNo = result.data.PoNo;
            $scope.PurchaseDate = result.data.PurchaseDate;
            $scope.VendorId = result.data.VendorId;
            $scope.PurchaseValue = result.data.PurchaseValue;
            $scope.ContactName = result.data.ContactName;
            $scope.PhoneNo = result.data.PhoneNo;
            $scope.WarrantyExpDate = result.data.WarrantyExpDate;
            $scope.MilesKms = result.data.MilesKms;
            $scope.PurchaseMilage = result.data.PurchaseMilage;
            $scope.HypothecatedBankFlg = result.data.HypothecatedBankFlg;
            $scope.BankName = result.data.BankName;
            $scope.Branch = result.data.Branch;
            $scope.LoanAmount = result.data.LoanAmount;
            $scope.EmiDate = result.data.EmiDate;
            $scope.EmiTillDate = result.data.EmiTillDate;
            $scope.EmiAmount = result.data.EmiAmount;
            $scope.VendorName = result.data.VendorName;
        });
    }

    $scope.SearchVehicle = function () {
        SearchVehicleById();
    }


    function GetManufacturerList() {
        var KeyReference = {
            HeadCode: 'Manufacturer',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.ManufacturerList = [];
        GetData.then(function (Response) {
            var TempManufacturerList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempManufacturerList.unshift(defaltvalue);            
            $scope.ManufacturerList = TempManufacturerList;
            $scope.VehicleManufacturerId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Vehicle Manufacturer " + reason.data;
            $scope.isError = true;
            return;
        });
    };




    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            var TempVehicleTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVehicleTypeList.unshift(defaltvalue);
            $scope.VehicleTypeList = TempVehicleTypeList;
            $scope.TruckType1 = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVehicleSizeList() {
        var KeyReference = {
            HeadCode: 'Size',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleSizeList = [];
        GetData.then(function (Response) {
            $scope.VehicleSizeList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVehicleLeaseFrom() {
        var InputParam = {
            VendorName: "",
            VehicleLeaseStatus: 'L'
        }

        var GetData = VehicleAJService.GetVendorDtls(InputParam);
        $scope.VehicleLeaseList = [];
        GetData.then(function (Response) {
            var TempVehicleList = Response.data;
             var defaltvalue = {
                VendorId: "",
                VendorName: "Select"
             }
            TempVehicleList.unshift(defaltvalue);
            $scope.VehicleLeaseList = TempVehicleList;
            $scope.LeaseFromTransporter = "";

        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVehicleBrokerFrom() {
        var InputParam = {
            VendorName: "",
            VehicleLeaseStatus: 'B'
        }

        var GetData = VehicleAJService.GetVendorDtls(InputParam);
        $scope.VehicleBrokarList = [];
        GetData.then(function (Response) {
            var TempVehicleBrokar = Response.data;
            var defaltvalue = {
                VendorId: "",
                VendorName: "Select"
            }            
            TempVehicleBrokar.unshift(defaltvalue);
            $scope.VehicleBrokarList = TempVehicleBrokar;
            $scope.LeaseFromBroker = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetEquipmentTypeList() {
        var KeyReference = {
            HeadCode: 'EquipmentType',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.EquipmentTypeList = [];
        GetData.then(function (Response) {
            var TempEquipmentLst = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempEquipmentLst.unshift(defaltvalue);
            $scope.EquipmentTypeList = TempEquipmentLst;
            $scope.EquipmentType = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    $scope.TruckTypeChange = function (TruckTypeId) {
        var currentSelected = $filter('filter')($scope.VehicleTypeList, { Pkey: TruckTypeId })[0]
        if (currentSelected.CodeValue == 'Equipment') {
            $scope.isShownEquipment = false;
        }
        else {
            $scope.EquipmentType = undefined;
            $scope.isShownEquipment = true;
        }
        if (currentSelected.CodeValue == 'Trailer') {
            $scope.isShownPermissibleSize = false;
        }
        else {

            $scope.PermissibleSizes = undefined;
            $scope.isShownPermissibleSize = true;
        }
    }

    $scope.HypothClick = function () {
        if ($scope.HypothecatedBankFlg == 'Y') {
            $scope.isShownBank = false;
        }
        else {
            $scope.isShownBank = true;
            $scope.BankName = undefined;
            $scope.Branch = undefined;
            $scope.LoanAmount = undefined;
            $scope.EmiDate = undefined;
            $scope.EmiTillDate = undefined;
            $scope.EmiAmount = undefined;
        }
    }

    $scope.UnderAmcChange = function () {
        if ($scope.UnderAmc == 'Y') {
            $scope.isShownunderAmc = false;
        }
        else {
            $scope.isShownunderAmc = true;
            $scope.AmcExpiryDate = undefined;
        }
    }

    $scope.checkEMIDateValidate = function () {
        debugger;
        if ($scope.EmiDate > $scope.EmiTillDate) {
            $scope.errMsg = "EMI DATE  should be back date than  EMI TILL date ";           
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
    }



    $scope.checkPurchaseDateValidate = function () {
        debugger;
        if ($scope.PurchaseDate > $scope.EmiDate) {
            $scope.errMsg = "Purchase Date should be back date than  EMI date ";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
    }


    //$scope.mobileValidatation = function (PhoneNo) {
    //    debugger;
    //    if ($scope.PhoneNo.minLength != 10) {
    //        $scope.errMsg = "Phone No should 10 digit. ";
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }
    //}

});

