﻿app.service("VehicleAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.SaveDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/SaveVehicleData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetVehicleDtlsById = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleDtlsByID",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVendorDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVendorLookup",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

});