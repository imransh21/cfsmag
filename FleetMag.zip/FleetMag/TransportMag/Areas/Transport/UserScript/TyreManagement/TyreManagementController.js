﻿app.controller("TyreManagementCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, TyreManagementCtrlAJService, KeyRefrenceCtrlAJService, HomeIndex, ErrorMsgDisplay) {
    $scope.isShownAssetNo = true;
    $scope.isShownbtn = true
    $scope.isShown = true
    $scope.isShownE=false
    $scope.AssetSoldFlg = 'N';
    $scope.AssetClosedFlg = 'N';
    $scope.AssetScrapFlg = 'N';
    $scope.AccetDiscardedFlg = 'N';
    GetManufacturerList();
    GetSizeList();
    GetTyreTypeList();
    function GetManufacturerList() {
        var KeyReference = {
            HeadCode: 'Manufacturer',
            GroupCode: 'Tyre'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.ManufacturerList = [];
        GetData.then(function (Response) {
            debugger;
            $scope.ManufacturerList = Response.data;
            //var defaultval = {
            //    VehicleTypeCode: 0,
            //    VehicleType: 'Select'
            //}
            $scope.ManufacturerList = Response.data;
            //   $scope.ManufacturerList.unshift(defaultval);


        }, function (reason) {
            $scope.errMsg = "Error in getting VesselTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetSizeList() {
        var KeyReference = {
            HeadCode: 'Size',
            GroupCode: 'Tyre'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.SizeList = [];
        GetData.then(function (Response) {
            $scope.SizeList = Response.data;
            //var defaultval = {
            //    VehicleTypeCode: 0,
            //    VehicleType: 'Select'
            //}
            $scope.SizeList = Response.data;
            //   $scope.SizeList.unshift(defaultval);


        }, function (reason) {
            $scope.errMsg = "Error in getting VesselTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetTyreTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Tyre'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.TyreTypeList = [];
        GetData.then(function (Response) {
            $scope.TyreTypeList = Response.data;
            //var defaultval = {
            //    VehicleTypeCode: 0,
            //    VehicleType: 'Select'
            //}
            $scope.TyreTypeList = Response.data;
            //   $scope.SizeList.unshift(defaultval);


        }, function (reason) {
            $scope.errMsg = "Error in getting VesselTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };




    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;
        var i1 = 0;
        debugger;
        //for (i1 = 0; i1 < $scope.KeyReferenceList.length; i1++) {
        //    debugger;
        //    if (($scope.KeyReferenceList[i1].CodeValue == undefined || $scope.KeyReferenceList[i1].CodeValue == "") && $scope.KeyReferenceList[i1].Pkey > 0) {

        //        $scope.setclass = "popupBase alert alertShowMsg";
        //        $scope.errMsg = "Blank Code Value.";
        //        $scope.isError = true;
        //        var id = "txtCodeValue" + "" + i1
        //        $scope.Var = id;
        //        return;
        //    }

        //    if (($scope.KeyReferenceList[i1].SortKey == undefined || $scope.KeyReferenceList[i1].SortKey == "") && $scope.KeyReferenceList[i1].Pkey > 0) {

        //        $scope.setclass = "popupBase alert alertShowMsg";
        //        $scope.errMsg = "Blank Sort Key.";
        //        $scope.isError = true;
        //        var id = "txtSortKey" + "" + i1
        //        $scope.Var = id;
        //        return;
        //    }
        //}

        if ($scope.AssetNo == undefined || $scope.AssetNo == "") {
            //$scope.setclass = "popupBase alert alertShowMsg";
            //$scope.errMsg = "Enter Asset No.";
            //$scope.isError = true;
            //var id = "txtAssetNo"
            //        $scope.Var = id;
                 

                    $scope.errMsg = "Enter Asset No."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    $("#txtAssetNo").val('');
                    setTimeout(function () {
                        $("#txtAssetNo").focus();
                    }, 500);
                    return;

            return;
        }
        
        if ($scope.VendorId == undefined || $scope.VendorId == "") {
      

            $scope.errMsg = "Select Vendor."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtVendor").val('');
            setTimeout(function () {
                $("#txtVendor").focus();
            }, 500);
            return;

            
        }

        if ($scope.AssetClosedFlg == 'Y' && $scope.AssetScrapFlg == 'N' && $scope.AssetSoldFlg == 'N' && $scope.AccetDiscardedFlg == 'N') {
         

    
           
            $scope.errMsg = "please Specify reason for closing.."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            //$("#txtVendor").val('');
            //setTimeout(function () {
            //    $("#txtVendor").focus();
            //}, 500);
            return;

        
        }


        if (emptyData == false) {
            debugger;

            //var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);
            var TyreConfigration = {
                AssetIntId: $scope.AssetIntId,
                AssetNo: $scope.AssetNo,
                PoNo: $scope.PoNo,
                PurchaseDate: $scope.PurchaseDate,
                VendorId: $scope.VendorId,
                PurchaseValue: $scope.PurchaseValue,
                ContactName: $scope.ContactName,
                WarrantyExpiryDate: $scope.WarrantyExpiryDate,
                MilesKms: $scope.MilesKms,
                PurchaseMileage: $scope.PurchaseMileage,
                DotBatchId: $scope.DotBatchId,
                TyreType: $scope.TyreType,
                ManufacturerId: $scope.ManufacturerId,
                Size: $scope.Size,
                RimDiameter: $scope.RimDiameter,
                LoadIndex: $scope.LoadIndex,
                TyreConstruction: $scope.TyreConstruction,
                TreadPurchase: $scope.TreadPurchase,
                PressurePurchase: $scope.PressurePurchase,
                AssetClosedFlg: $scope.AssetClosedFlg,
                AssetScrapValue: $scope.AssetScrapValue,
                AssetSoldFlg: $scope.AssetSoldFlg,
                AssetSoldValue: $scope.AssetSoldValue,
                AccetDiscardedFlg: $scope.AccetDiscardedFlg,
                PhoneNo: $scope.PhoneNo,
                WarnTreadValue: $scope.WarnTreadValue,
                ReplaceTreadValue: $scope.ReplaceTreadValue,
                AssetScrapFlg: $scope.AssetScrapFlg
            };

            var saveData = TyreManagementCtrlAJService.saveData(TyreConfigration);
            saveData.then(function (pTyreManagement) {
                debugger;
                if (pTyreManagement.data.ErrorMessage != null && pTyreManagement.data.ErrorMessage != "") {
                    $scope.errMsg = pTyreManagement.data.ErrorMessage;
                 

                 //   $scope.errMsg = "Select Vendor."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                   
                   
                    return;
                }
                else {
                    debugger;
                    $scope.isShown = true;
                    $scope.isShownbtn = true
                    $scope.errMsg = "";
                    $scope.isError = false;
                    $scope.AssetIntId = pTyreManagement.data.AssetIntId;
                    $scope.SearchAssetCodeDtls();
                    $scope.setclassSuccessful = "popupBase alert alertShowMsg";
                    $scope.SuccessMsg = "Data Saved Successfully.";
                    //VehicleTypeList();
                    //GetMasterData();
                  
                }
            }, function () {
                clearFields();
                //$(JobMasterS).each(function (index, item) {
                //    if (item.Key == 'Message3') {
                //        $scope.setclass = "popupBase alert alertShowMsg";
                //        $scope.errMsg = item.value;
                //    }
                //});

                $scope.isError = true;
                return;
            });
        }
    }


    $scope.SearchAssetCodeDtls = function () {
        debugger;
        
        //alert($scope.VesselCode);
        var TyreConfigration = {
            AssetIntId: $scope.AssetIntId
            //VesselName: $scope.VesselName
        };
        if ($scope.AssetIntId == undefined || $scope.AssetIntId == 0) {
            $scope.errMsg = "Invalid asset code.";
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.isShown = true;
            $scope.isShownbtn = true
            $scope.isShownAssetNo = false;
            clearData();
            $scope.isError = true;
            $scope.isShownS = true;
            return;
        }
        var getData = TyreManagementCtrlAJService.GetTyreConfigrationById(TyreConfigration);
        getData.then(function (TyreConfigration) {
            $scope.errMsg = "";
            $scope.isError = false;
            debugger;
            if (TyreConfigration.data.ErrorMessage != null) {
                $scope.errMsg = TyreConfigration.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";

                $scope.isError = true;
                return;
            }
            $scope.isShownAssetNo = true;
            $scope.isShownE = true;
            $scope.AssetNo = TyreConfigration.data.AssetNo;

            $scope.VendorName = TyreConfigration.data.VendorName;
            $scope.PoNo = TyreConfigration.data.PoNo;
            $scope.PurchaseDate = TyreConfigration.data.PurchaseDate,
           $scope.VendorId = TyreConfigration.data.VendorId;
            $scope.PurchaseValue = TyreConfigration.data.PurchaseValue;
            $scope.ContactName = TyreConfigration.data.ContactName;
            $scope.WarrantyExpiryDate = TyreConfigration.data.WarrantyExpiryDate;
            $scope.MilesKms = TyreConfigration.data.MilesKms;
            $scope.PurchaseMileage = TyreConfigration.data.PurchaseMileage;
            $scope.DotBatchId = TyreConfigration.data.DotBatchId;
            $scope.TyreType = TyreConfigration.data.TyreType
            $scope.ManufacturerId = TyreConfigration.data.ManufacturerId;
            $scope.Size = TyreConfigration.data.Size;
            $scope.RimDiameter = TyreConfigration.data.RimDiameter;
            $scope.LoadIndex = TyreConfigration.data.LoadIndex;
            $scope.TyreConstruction = TyreConfigration.data.TyreConstruction;
            $scope.TreadPurchase = TyreConfigration.data.TreadPurchase;
            $scope.PressurePurchase = TyreConfigration.data.PressurePurchase;
            $scope.AssetClosedFlg = TyreConfigration.data.AssetClosedFlg;
            $scope.AssetScrapValue = TyreConfigration.data.AssetScrapValue;
            $scope.AssetSoldFlg = TyreConfigration.data.AssetSoldFlg;
            $scope.AssetSoldValue = TyreConfigration.data.AssetSoldValue;
            $scope.AccetDiscardedFlg = TyreConfigration.data.AccetDiscardedFlg;
            $scope.PhoneNo = TyreConfigration.data.PhoneNo;
            $scope.WarnTreadValue = TyreConfigration.data.WarnTreadValue;
            $scope.ReplaceTreadValue = TyreConfigration.data.ReplaceTreadValue;
            $scope.AssetScrapFlg = TyreConfigration.data.AssetScrapFlg;

           
          
            // $scope.HoldList = pVehicleManufacturerDetailsData.ColorList;
           // addRow();

            $scope.isShownS = false;
         
        }, function () {
          
            clearData();
            $scope.isError = true;




            return;
        });
    }



    $scope.AddDtls = function () {
        debugger;
        clearData();
        $scope.isShown = false;
        $scope.isShownbtn = false
        $scope.isShownS = false;
        $scope.isShownAssetNo = false;
        $scope.isShownE = false;


    }
    function clearData() {
        $scope.VendorName = undefined;
        $scope.AssetIntId = undefined;
        $scope.AssetNo = undefined;
        $scope.PoNo = undefined;
        $scope.PurchaseDate = undefined,
       $scope.VendorId = undefined;
        $scope.PurchaseValue= undefined;
        $scope.ContactName = undefined;
        $scope.WarrantyExpiryDate = undefined;
        $scope.MilesKms = undefined;
        $scope.PurchaseMileage = undefined;
        $scope.DotBatchId = undefined;
        $scope.TyreType = undefined;
        $scope.ManufacturerId = undefined;
        $scope.Size = undefined;
        $scope.RimDiameter = undefined;
        $scope.LoadIndex = undefined;
        $scope.TyreConstruction = undefined;
        $scope.TreadPurchase = undefined;
        $scope.PressurePurchase = undefined;
        $scope.AssetClosedFlg = 'N';
        $scope.AssetScrapValue = undefined;
        $scope.AssetSoldFlg = 'N';
        $scope.AssetSoldValue = undefined;
        $scope.AccetDiscardedFlg = 'N';
        $scope.PhoneNo = undefined;
        $scope.WarnTreadValue = undefined;
        $scope.ReplaceTreadValue = undefined;
        $scope.AssetScrapFlg = 'N';

        $scope.isShownE = false;
        $scope.isShownS = false;
    }

    $scope.SearchDtls = function () {
        $scope.isShownE = false;
        clearData();
        $scope.isShownS = true;
        $scope.isShownAssetNo = false;
        $('#txtAssetNo').show();
        $('#txtAssetNo').autocomplete({
         
            source: function (request, response) {
                debugger;
                $scope.AssetIntId = undefined;
                var getUrl = window.location;
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                $.ajax({
                    url: baseUrl + '/Transport/TyreManagement/GetAssetNoAuto',
                    data: "{ 'prefixText': '" + request.term + "'}",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map($.parseJSON(data), function (item, key) {
                            return {
                                label: item.AssetNo,
                                AssetNo: item.AssetNo,
                                AssetIntId: item.AssetIntId
                            }
                        }))
                    },
                    error: function (response) {

                    },
                    failure: function (response) {

                    }
                });
            },
            select: function (e, i) {

                var $scope = angular.element(document.getElementById('bigformBooking')).scope();
                $scope.AssetIntId = i.item.AssetIntId;
            },
            minLength: 1
        });
     
    }


    $scope.EditDtls = function () {
        debugger;

        if ($scope.isShownE == false)
            
        {
            alert("please Search data");
            return;
        }

         if ($scope.AssetScrapFlg == 'Y')
            {
                $scope.isShown = true;
            }
            else if ($scope.AssetSoldFlg == 'Y') {
                $scope.isShown = true;
            }
            else if ($scope.AccetDiscardedFlg == 'Y') {
                $scope.isShown = true;
            }
            else if ($scope.AssetClosedFlg == 'Y') {
                $scope.isShown = true;
            }
            else
                {
                $scope.isShown = false;
            }

        if ($scope.AssetIntId != undefined) {
          
            $scope.isShownbtn = false
            $scope.isShownAssetNo = true;
           $scope.isShownE = false;


        }
        else {

          
            $scope.isShownbtn = true
            $scope.isShownAssetNo = true;
           


        }


    }


    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownbtn = true
        $scope.isShownAssetNo = true;
       
    }
    $scope.closeErrorPopup = function () {
        $scope.setclass = "popupBase alert"
        $scope.errMsg = '';
        $scope.isError = false;
        if ($scope.Var != undefined) {
            setTimeout(function () { $("#" + $scope.Var).focus(); }, 500)
        }
    }


    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Transportation');
    }
});