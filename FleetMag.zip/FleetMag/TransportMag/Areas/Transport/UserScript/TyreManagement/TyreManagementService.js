﻿app.service("TyreManagementCtrlAJService", function ($http) {


    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/TyreManagement/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }
    this.GetTyreConfigrationById = function (pVehicleManufacturerDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/TyreManagement/GetTyreConfigrationById",
            data: JSON.stringify(pVehicleManufacturerDetails),
            dataType: "json"
        });
        return response;
    }

    

});