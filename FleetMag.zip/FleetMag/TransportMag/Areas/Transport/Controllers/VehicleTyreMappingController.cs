﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.BusinessObjectLayer.BusinessLogics;

namespace TransportMag.Areas.Transport.Controllers
{
    public class VehicleTyreMappingController : Controller
    {
        //
        // GET: /Transport/VehicleTyreMapping/

        public ActionResult Index()
        {
            return View();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetVehicleTyreMappingByVehicleID(ExtendedVehicleTyreMapping pExtendedVehicleTyreMapping)
        {
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVehicleTyreMapping = new ArrayList();
            arrVehicleTyreMapping = ExtendedVehicleTyreMapping.GetVehicleTyreMappingByVehicleId(pExtendedVehicleTyreMapping);
            return Json(arrVehicleTyreMapping, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetAssetList(TyreConfigration pTyreConfigration)
        {
            ArrayList TyreAssetList = new ArrayList();
            TyreAssetList = ExtendedVehicleTyreMapping.GetTyreAssetLookUp(pTyreConfigration);
            return Json(TyreAssetList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDetails(VehicleTyreMapping pVehicleTyreMapping)
        {

            pVehicleTyreMapping.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ;// Session["loginuser"].ToString();
            pVehicleTyreMapping.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ; //Session["loginuser"].ToString();
            //pVehicleTyreMapping = VehicleTyreMapping.InsertUpdates(pVehicleTyreMapping);
            pVehicleTyreMapping = VehicleTyreMapping.Update(pVehicleTyreMapping);
            return Json(pVehicleTyreMapping, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveNewPattern(VehicleTyreMapping pVehicleMaster)
        {
            pVehicleMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pVehicleMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            VehicleTyreMapping.SaveNewPattern(pVehicleMaster);
            return Json(pVehicleMaster, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SwapAssets(List<VehicleTyreMapping> pVehicleTyreMapping)
        {

            pVehicleTyreMapping[0].ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ;// Session["loginuser"].ToString();
            pVehicleTyreMapping[1].ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ;// Session["loginuser"].ToString();

            long TempAssetId;
            string TempAssetNo;

            TempAssetId = pVehicleTyreMapping[0].AssetIntId;
            TempAssetNo = pVehicleTyreMapping[0].AssetNo;

            pVehicleTyreMapping[0].AssetIntId = pVehicleTyreMapping[1].AssetIntId;
            pVehicleTyreMapping[0].AssetNo = pVehicleTyreMapping[1].AssetNo;

            pVehicleTyreMapping[1].AssetIntId = TempAssetId;
            pVehicleTyreMapping[1].AssetNo = TempAssetNo;


            pVehicleTyreMapping = VehicleTyreMapping.SwapAsset(pVehicleTyreMapping);


            return Json(pVehicleTyreMapping, JsonRequestBehavior.AllowGet);


        }


        [HttpPost]
        public JsonResult DeleteTyreMapping(VehicleTyreMapping pVehicleTyreMapping)
        {           
            pVehicleTyreMapping.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ; //Session["loginuser"].ToString();
            pVehicleTyreMapping = VehicleTyreMapping.Delete(pVehicleTyreMapping);
            return Json(pVehicleTyreMapping, JsonRequestBehavior.AllowGet);


        }

    }
}
