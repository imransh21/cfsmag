﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.DataAccessLayer;
using TransportMag.Filters;

namespace TransportMag.Areas.Transport.Controllers
{
    public class EquipmentTransferController : Controller
    {


        public ActionResult EquipmentTransfer()
        {
            return PartialView();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetVehicleList(VehicleMaster pVehicleMaster)
        {
            pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVehicleMaster = new ArrayList();
            arrVehicleMaster = VehicleMaster.GetVehicleMasterEquip(pVehicleMaster);
            //var query = from VehicleMaster vehicleMaster in arrVehicleMaster
            //  select new { vehicleMaster.VehicleId, vehicleMaster.VehicleNo, vehicleMaster.EquipmentType };
            return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
        }

         [Compress]
        [HttpPost]
        public JsonResult GetEquimentList(VehicleMaster pVehicleMaster)
        {
            pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrVehicleMaster = new ArrayList();
            arrVehicleMaster = VehicleMaster.GetEquipType(pVehicleMaster);
            var query = from VehicleMaster vehicleMaster in arrVehicleMaster
                        select new { vehicleMaster.EquipmentType, vehicleMaster.LocationId};
           
            return Json(query, JsonRequestBehavior.AllowGet);
        }

       
        [HttpPost]
        public JsonResult SaveEqipTransferDtls(EquipmentTransfer1 pEquipmentTransfer1)
        {
          
            EquipmentTransfer1.GetSave(pEquipmentTransfer1);
            return Json(pEquipmentTransfer1, JsonRequestBehavior.AllowGet);
        }

         [Compress]
        [HttpPost]
        public JsonResult RetrieveData(EquipmentTransfer1 pGoodsTransferHdr)
        {
            EquipmentTransfer1.GetEquipmentTransferByID(pGoodsTransferHdr);

            return Json(pGoodsTransferHdr, JsonRequestBehavior.AllowGet);
        }

        [Compress]
        [HttpPost]
        public JsonResult GetTransferLookup(EquipmentTransfer1 pGoodsTransferHdr)
        {
            ArrayList arrTransforList = new ArrayList();
            arrTransforList = EquipmentTransfer1.GetEquipmentTransferHdrLOOKUP(pGoodsTransferHdr);
            var Query = from EquipmentTransfer1 vequiptransferhdr in arrTransforList
                        select new { vequiptransferhdr.JobId, vequiptransferhdr.JobNo };
            return Json(Query, JsonRequestBehavior.AllowGet);
        }
       
    }
}
