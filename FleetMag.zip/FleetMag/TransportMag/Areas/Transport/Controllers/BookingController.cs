﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class BookingController : Controller
    {


        public ActionResult BookingIndex()
        {
            return PartialView();
        }

        [HttpPost()]
        public JsonResult GetCityMasterAll(string prefixText)
        {
            ArrayList arrCustomerTypes = CityMaster.GetCityMasterAllAutoNew(prefixText);

            // With...
            return Json(arrCustomerTypes, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetContTypeListLookup(ContTypeMaster pContTypeMaster)
        {
            ArrayList DepoList = new ArrayList();
            DepoList = ContTypeMaster.GetContTypeMasterLookUp(pContTypeMaster);
            return Json(DepoList, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetCommodityListLookup(CommodityMaster pCommodityMaster)
        {
            ArrayList DepoList = new ArrayList();
            DepoList = CommodityMaster.GetCommodityMasterLookUp(pCommodityMaster);
            return Json(DepoList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetCargoPkgListLookup(CargoPackageTypes pCommodityMaster)
        {
            ArrayList DepoList = new ArrayList();
            DepoList = CargoPackageTypes.GetCargoPkgTypeMasterLookUp(pCommodityMaster);
            return Json(DepoList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetContainerDetails(BookingContainerDtl pBookingContainerDtl)
        {
            ArrayList arrCrewDetailsList = new ArrayList();
            arrCrewDetailsList = BookingContainerDtl.GetContainerListDtls(pBookingContainerDtl);
            return Json(arrCrewDetailsList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetCargoDetails(BookingCargoDtl pBookingContainerDtl)
        {
            ArrayList arrCrewDetailsList = new ArrayList();
            arrCrewDetailsList = BookingCargoDtl.GetCargoListDtls(pBookingContainerDtl);
            return Json(arrCrewDetailsList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetAccountManagerLookup(EmployeeMaster p)
        {
            //p.BranchId=  Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrEmployeeMasterList = new ArrayList();
            arrEmployeeMasterList = EmployeeMaster.GetEmployeeMasterForAccountManager(p);
            return Json(arrEmployeeMasterList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SavaDetails(BookingHeader pBookingHeader)
        {
            pBookingHeader.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            BookingHeader.SaveDetails(pBookingHeader);
            return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetBookingNoLookup(BookingHeader pBookingHeader)
        {
            pBookingHeader.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrPoList = new ArrayList();
            arrPoList = BookingHeader.GetBookinglookup(pBookingHeader);
            return Json(arrPoList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetBookingDtlsByID(BookingHeader pBookingHeader)
        {
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
          pBookingHeader=  BookingHeader.GetBookingHeaderByID(pBookingHeader);
          return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetInsuredDetails(BookingInsuredDtl pBookingInsuredDtl)
        {
            ArrayList arrCrewDetailsList = new ArrayList();
            arrCrewDetailsList = BookingInsuredDtl.GetInsuredListDtls(pBookingInsuredDtl);
            return Json(arrCrewDetailsList, JsonRequestBehavior.AllowGet);
        }



        [HttpPost()]
        public JsonResult GetEmployeeMasterAuto(string prefixText)
        {
            ArrayList arrCustomerTypes = EmployeeMaster.GetEmployeeMasterAuto(prefixText);

            // With...
            return Json(arrCustomerTypes, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetCargoBookingDtlsByID(BookingHeader pBookingHeader)
        {
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            pBookingHeader = BookingHeader.GetCargoBookingHeaderByID(pBookingHeader);
            return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SavaCargoDetails(BookingJob pBookingJob)
        {
            pBookingJob.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            BookingJob.Insert(pBookingJob);
            return Json(pBookingJob, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetContainerBookingDtlsByID(BookingHeader pBookingHeader)
        {
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            pBookingHeader = BookingHeader.GetContainerBookingHeaderByID(pBookingHeader);
            return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetWareHouseContainerBookingDtlsByID(BookingHeader pBookingHeader)
        {
            pBookingHeader.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            pBookingHeader = BookingHeader.GetWareHouseContainerBookingHeaderByID(pBookingHeader);
            return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SavaWHJobDetails(BookingJobWarehouse pBookingJob)
        {
            pBookingJob.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            BookingJobWarehouse.Insert(pBookingJob);
            return Json(pBookingJob, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetWareHouseCargoBookingDtlsByID(BookingHeader pBookingHeader)
        {
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            pBookingHeader = BookingHeader.GetCargoWareHouseBookingHeaderByID(pBookingHeader);
            return Json(pBookingHeader, JsonRequestBehavior.AllowGet);
        }
    }
}
