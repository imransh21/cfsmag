﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class JOBExecutionController : Controller
    {


        public ActionResult JOBExecutionIndex()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult GetBookingJobLookup(BookingJob pBookingJob)
        {
            DataSet ds;
            ds = BookingJob.GetBookingJobLookup(pBookingJob);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetBookingJobSearchLookup(BookingJob pBookingJob)
        {
            DataSet ds;
            ds = BookingJob.GetBookingJobSearchLookup(pBookingJob);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SavaDetails(BookingJob pBookingJob)
        {
            BookingJob.SaveJobTruckDetails(pBookingJob);
            return Json(pBookingJob, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetTruckData(BookingJobTruckDtl pBookingJobTruckDtl)
        {
            ArrayList BookingJobTruckDtlList = new ArrayList();
            BookingJobTruckDtlList = BookingJobTruckDtl.GetBookingJobTruckDtlAll(pBookingJobTruckDtl);
            return Json(BookingJobTruckDtlList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveJobExecuteAccept(BookingJob pBookingJob)
        {
            pBookingJob.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            BookingJob.UpdateJobDetails(pBookingJob);
            return Json(pBookingJob, JsonRequestBehavior.AllowGet);
        }


    }
}
