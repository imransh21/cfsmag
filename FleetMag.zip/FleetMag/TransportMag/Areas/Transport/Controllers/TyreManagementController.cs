﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
namespace TransportMag.Areas.Transport.Controllers
{
    public class TyreManagementController : Controller
    {
        //
        // GET: /TyreManagement/

        public ActionResult TyreManagement()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult SaveDetails(TyreConfigration pTyreConfigration)
        {

            pTyreConfigration.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ;// Session["loginuser"].ToString();
            pTyreConfigration.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]); ; //Session["loginuser"].ToString();
            pTyreConfigration.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pTyreConfigration = TyreConfigration.InsertUpdates(pTyreConfigration);


            return Json(pTyreConfigration, JsonRequestBehavior.AllowGet);


        }

        [HttpPost]
        public JsonResult GetAssetNoAuto(string prefixText)
        {
            DataSet ds;
            ds = TyreConfigration.GetAssetNoLookup(prefixText);
            var pResultList = JsonConvert.SerializeObject(ds.Tables[0], Formatting.None);
            return Json(pResultList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetTyreConfigrationById(TyreConfigration pTyreConfigration)
        {
            pTyreConfigration = TyreConfigration.GetTyreConfigrationByID(pTyreConfigration);

          
            // pVehicleManufacturerDetails.DeckList = VesselDeckMaster.GetVesselDeckMasterAll(pVehicleManufacturerDetails.VesselCode)

            return Json(pTyreConfigration, JsonRequestBehavior.AllowGet);
        }


    }
}
