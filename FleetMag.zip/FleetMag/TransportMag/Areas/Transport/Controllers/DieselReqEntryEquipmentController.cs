﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class DieselReqEntryEquipmentController : Controller
    {


        public ActionResult DieselReqEntryEquipment()
        {
            return PartialView();
        }

    }
}
