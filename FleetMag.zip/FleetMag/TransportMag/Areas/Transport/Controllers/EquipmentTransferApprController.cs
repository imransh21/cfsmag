﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMag.Filters;
namespace TransportMag.Areas.Transport.Controllers
{
    public class EquipmentTransferApprController : Controller
    {


        public ActionResult EquipmentTransferAppr()
        {
            return PartialView();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetPendingList(EquipmentTransfer1 pEquipmentTransfer)
        {
            ArrayList arrPoList = new ArrayList();
            pEquipmentTransfer.arrEquipmentTransferDtls = EquipmentTransfer1.GetEquipmentTransferList(pEquipmentTransfer);
            return Json(pEquipmentTransfer.arrEquipmentTransferDtls, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDetails(EquipmentTransfer1 pEquipmentTransfer)
        {
           
            // 'pUserMaster.ModifiedBy = Session.Item("loginuser")
            // pUserMaster.LocationId = Session.Item("loginLocation")
            pEquipmentTransfer = EquipmentTransfer1.GetSaveApprove(pEquipmentTransfer);
            return Json(pEquipmentTransfer, JsonRequestBehavior.AllowGet);
        }
    }
}
