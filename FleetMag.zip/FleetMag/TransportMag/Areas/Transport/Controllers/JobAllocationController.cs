﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class JobAllocationController : Controller
    {


        public ActionResult JobAllocation()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult GetJobAllocationList(WorkInstructionsTransport pWorkInstructions)
        {
            List<WorkInstructionsTransport> arrJobPendencyList = new List<WorkInstructionsTransport>();
            pWorkInstructions.List = WorkInstructionsTransport.GetAllJob(pWorkInstructions);
            return Json(pWorkInstructions.List, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveWorkinstructionAccept(WorkInstructionsTransport pWorkInstructions)
        {
            WorkInstructionsTransport.UpdateWorkInstructionAccept(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult UpdateVehicledtls(WorkInstructionsTransport pWorkInstructions)
        {
            pWorkInstructions.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            WorkInstructionsTransport.updateVehicleDetailsUpdate(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetCrewDetails(WorkInstructionsTransport pWorkInstructions)
        {
            ArrayList arrCrewDetailsList = new ArrayList();
            arrCrewDetailsList = WorkInstructionsTransport.GetCrewAllocationDtls(pWorkInstructions);
            return Json(arrCrewDetailsList, JsonRequestBehavior.AllowGet);
        }

    }
}
