﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class VehicleMasterController : Controller
    {


        public ActionResult VehicleMasterIndex()
        {
            return PartialView();
        }

            [HttpPost]
            public JsonResult SaveVehicleData(VehicleMaster pVehicleMaster)
            {
            pVehicleMaster.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pVehicleMaster.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                VehicleMaster.SaveVehicleDtls(pVehicleMaster);
                return Json(pVehicleMaster, JsonRequestBehavior.AllowGet);
            }


            [Compress]
            [HttpPost]
            public JsonResult GetVehicleLookup(VehicleMaster pVehicleMaster)
            {
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ArrayList arrVehicleMaster = new ArrayList();
                arrVehicleMaster = VehicleMaster.GetVehicleMasterAllLookup(pVehicleMaster);
                var query = from VehicleMaster vehicleMaster in arrVehicleMaster
                            select new { vehicleMaster.VehicleId, vehicleMaster.VehicleNo, vehicleMaster.TyrePatternId };
                return Json(query, JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVehicleDepotWiseLookup(VehicleMaster pVehicleMaster)
            {
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ArrayList arrVehicleMaster = new ArrayList();
                arrVehicleMaster = VehicleMaster.GetVehicleMasterDepotWiseLookup(pVehicleMaster);
                return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
            }

            [Compress]
            [HttpPost]
            public JsonResult GetVehicleDepotWiseSearchInspeLookup(VehicleMaster pVehicleMaster)
            {
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ArrayList arrVehicleMaster = new ArrayList();
                arrVehicleMaster = VehicleMaster.GetVehicleMasterWeeklySearchListByDepot(pVehicleMaster);
                return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
            }

            [Compress]
            [HttpPost]
            public JsonResult GetVehicleDtlsByID(VehicleMaster pVehicleMaster)
            {
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                VehicleMaster.GetVehicleMasterByID(pVehicleMaster);
                return Json(pVehicleMaster, JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVendorLookup(VendorMaster pVendorMaster)
            {
                //pVendorMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ArrayList arrVehicleMaster = new ArrayList();
                arrVehicleMaster = VendorMaster.GetVendorMasterAllByType(pVendorMaster);
                return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVehicleMasterWeeklyListByDepot(VehicleMaster pVehicleMaster)
            {
                DataSet ds;
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ds = VehicleMaster.GetVehicleMasterWeeklyListByDepot(pVehicleMaster);
                return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVehicleMasterDailyListByDepot(VehicleMaster pVehicleMaster)
            {
                DataSet ds;
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ds = VehicleMaster.GetVehicleMasterDailyListByDepot(pVehicleMaster);
                return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVehicleMasterMonthlyListByDepot(VehicleMaster pVehicleMaster)
            {
                DataSet ds;
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ds = VehicleMaster.GetVehicleMasterMonthlyListByDepot(pVehicleMaster);
                return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
            }
            [Compress]
            [HttpPost]
            public JsonResult GetVehicleMaintReportListByDepot(VehicleMaster pVehicleMaster)
            {
                DataSet ds;
                //pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
                ds = VehicleMaster.GetVehicleMaintReportListByDepot(pVehicleMaster);
                return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
            }


        
    
    }
}
