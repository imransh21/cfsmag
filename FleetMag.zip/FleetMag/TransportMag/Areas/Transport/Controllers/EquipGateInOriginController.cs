﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMag.Filters;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Transport.Controllers
{
    public class EquipGateInOriginController : Controller
    {
        
        public ActionResult EquipGateInOrigin()
        {
            return PartialView();
        }

        [Compress]
        [HttpPost]
        public JsonResult GetOriginEqpPendingList(EquipmentTransfer1 pEquipmentTransfer1)
        {
            List<EquipmentTransfer1> arrList = new List<EquipmentTransfer1>();
            arrList = EquipmentTransfer1.GetOriginEquipmentPendingList(pEquipmentTransfer1);
            return Json(arrList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult SaveDetails(EquipmentTransfer1 pEquipmentTransfer)
        {

            pEquipmentTransfer = EquipmentTransfer1.SaveGateInOriginPendency(pEquipmentTransfer);
            return Json(pEquipmentTransfer, JsonRequestBehavior.AllowGet);
        }

        [Compress]
        [HttpPost]
        public JsonResult GetTransferLookup(EquipmentTransfer1 pGoodsTransferHdr)
        {
            ArrayList arrTransforList = new ArrayList();
            arrTransforList = EquipmentTransfer1.GetEquipmentTransferHdrOrigingateinLOOKUP(pGoodsTransferHdr);
            var Query = from EquipmentTransfer1 vequiptransferhdr in arrTransforList
                        select new { vequiptransferhdr.JobId, vequiptransferhdr.JobNo };
            return Json(Query, JsonRequestBehavior.AllowGet);
        }

    }
}
