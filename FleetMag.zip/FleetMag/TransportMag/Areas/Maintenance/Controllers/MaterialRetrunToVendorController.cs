﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class MaterialRetrunToVendorController : Controller
    {


        public ActionResult MaterialRetrunToVendor()
        {
            return PartialView();
        }

      
        [HttpPost]
        public JsonResult GetVehicleMaintReportDepot( string fromDate, string Todate,int DepotId, int LocationId)
        {
            DataSet ds=new DataSet();
            //ds = GoodsReturnStoreHdr.GetVehicleMaintReportByDeport(Todate, fromDate, DepotId, LocationId);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }

    }
}
