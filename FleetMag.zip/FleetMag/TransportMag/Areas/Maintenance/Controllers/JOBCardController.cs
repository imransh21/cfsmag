﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class JOBCardController : Controller
    {
        public ActionResult JOBCard()
        {
            return PartialView();
        }

       

        [HttpPost]
        public JsonResult GetJobAllocationList(WorkInstructions pWorkInstructions)
        {
            List<WorkInstructions> arrJobPendencyList = new List<WorkInstructions>();
            pWorkInstructions.List = WorkInstructions.GetAllJob(pWorkInstructions);
            return Json(pWorkInstructions.List, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveWorkinstructionAccept(WorkInstructions pWorkInstructions)
        {
            WorkInstructions.UpdateWorkInstructionAccept(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetCrewDetails(WorkInstructions pWorkInstructions)
        {
            ArrayList arrCrewDetailsList = new ArrayList();
            arrCrewDetailsList = WorkInstructions.GetCrewAllocationDtls(pWorkInstructions);
            return Json(arrCrewDetailsList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetCrewAllocation(WorkInstructions pWorkInstructions)
        {
            ArrayList arrJobPendencyList = new ArrayList();
            pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            arrJobPendencyList = WorkInstructions.CrewAllocation(pWorkInstructions);
            return Json(arrJobPendencyList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult getworkinstruction(WorkInstructions pWI1)
        { 
            pWI1 = WorkInstructions.GetWorkInstructionsByID(pWI1);
            return Json(pWI1, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult getCrewAllocationSub(CrewMemberMaster pCrewMemberMaster)
        {
            ArrayList arrJobPendencyList = new ArrayList();
            arrJobPendencyList = CrewDetails.GetCrewDetailsSub(pCrewMemberMaster);          
            return Json(arrJobPendencyList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetEmployeeListLookup(EmployeeMaster p)
        {
          //p.BranchId=  Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrEmployeeMasterList = new ArrayList();
            arrEmployeeMasterList = EmployeeMaster.GetEmployeeMasterByBranch(p);
            return Json(arrEmployeeMasterList, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult UpdateCrewDetails(WorkInstructions pWorkInstructions)
        {
            CrewDetails.UpdateCrewdetailsData(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public string DeleteCrewbyEmpID(CrewDetails pCrewDetails)
        {
            string result = CrewDetails.DeleteCrewData(pCrewDetails);
            return result;
        }



        [HttpPost]
        public JsonResult LoadMaterialDetailsByScheduleId(MeterialDetails pMeterialDetails)
        {
            ArrayList a = new ArrayList();

            a = MeterialDetails.GetMaterialDetailsByScheduledId(pMeterialDetails);
            return Json(a, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateMaterialDetails(WorkInstructions pWorkInstructions)
        {
            MeterialDetails.UpdateMaterialdetailsData(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteMaterialRequest(MeterialDetails pWisMaterialDetails)
        {
            pWisMaterialDetails = MeterialDetails.DeleteMaterialRequest(pWisMaterialDetails);
            return Json(pWisMaterialDetails, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult LoadMaterialDetailsByJobId(MeterialDetails pMeterialDetails)
        {
            ArrayList a = new ArrayList();
            a = MeterialDetails.GetMaterialDetailsByJobId(pMeterialDetails);
            return Json(a, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateMaterialReturn(WorkInstructions pWorkInstructions)
        {
            MeterialDetails.UpdateMaterialdetailsReturnData(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateScrapReturn(WorkInstructions pWorkInstructions)
        {
            List<MeterialDetails> ListData = new List<MeterialDetails>();
            ListData=MeterialDetails.UpdateScrapReturnReturnData(pWorkInstructions);
            pWorkInstructions.MaterialDetails = ListData;
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateVehicledtls(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId=Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            WorkInstructions.updateVehicleDetailsUpdate(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult UpdateCloseWorkinst(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            WorkInstructions.updateCloseWorkInst(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetServiceListLookup(ScheduleServiceHdr p)
        {
            //p.BranchId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrServiceList = new ArrayList();
            arrServiceList = ScheduleServiceHdr.GetScheduleServiceHdrAllForJob(p);
            return Json(arrServiceList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SavaJobDetails(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            WorkInstructions.InsertJobByInspection(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }
       
        [HttpPost]
        public JsonResult UpdateOutSideRepairdtls(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            WorkInstructions.updateOutSideRepairDetailsUpdate(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetScrapDetails(MeterialDetails PMeterialDetails)
        {
            List<MeterialDetails> lst = new List<MeterialDetails>();
            lst= MeterialDetails.GetMeterialDetailsScrapDtlsByID(PMeterialDetails);
            return Json(lst, JsonRequestBehavior.AllowGet);
        }

    }
}