﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class DailyChecksController : Controller
    {


        public ActionResult DailyChecks()
        {
            return PartialView();
        }

        public JsonResult LoadAllChecks()
        {
            ArrayList arrChecks = VehicleChecks.GetVehicleChecksMasterData("Vehicle", "Checks");

            //var UserList = JsonConvert.SerializeObject(arrUsers, Formatting.None);
            var ChecksList = arrChecks;
            return Json(ChecksList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult SaveDetails(List<VehicleChecks> pVehicleChecks)
        {
            if (pVehicleChecks.Count > 0)
            {

                foreach (VehicleChecks item in pVehicleChecks)
                {
                    if (item.CheckTypeLst != null)
                    {
                        foreach (VehicleChecks pCheckTypeLst in item.CheckTypeLst)
                        {
                            pCheckTypeLst.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pCheckTypeLst.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pCheckTypeLst.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                            VehicleChecks.InsertCheckType(pCheckTypeLst);
                            item.ErrorMessage = pCheckTypeLst.ErrorMessage;
                        }
                    }

                    if (item.EquipmentTypeList != null)
                    {
                        foreach (VehicleChecks pEquipmentType in item.EquipmentTypeList)
                        {
                            pEquipmentType.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pEquipmentType.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pEquipmentType.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                            VehicleChecks.InsertEquipmentType(pEquipmentType);
                            item.ErrorMessage = pEquipmentType.ErrorMessage;
                        }
                    }

                    if (item.VehicleTypeList != null)
                    {
                        foreach (VehicleChecks pVehicleType in item.VehicleTypeList)
                        {
                            pVehicleType.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pVehicleType.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
                            pVehicleType.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
                            VehicleChecks.InsertVehicleType(pVehicleType);
                            item.ErrorMessage = pVehicleType.ErrorMessage;
                        }
                    }

                }
            }


            return Json(pVehicleChecks, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetAllCheckConfingData()
        {

            List<VehicleChecks> PVehicleChecks = new List<VehicleChecks>();

            int LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            PVehicleChecks = VehicleChecks.GetCheckConfigData("Vehicle", "Checks", LocationID);

            //foreach (VehicleChecks pPVehicleChecks in PVehicleChecks)
            //{
            //    VehicleChecks objVehicleChecks = new VehicleChecks();
            //    objVehicleChecks.CheckValueRefId = pPVehicleChecks.CheckValueRefId;
            //    objVehicleChecks.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //    objVehicleChecks.CheckTypeLst = VehicleChecks.GetCheckTypeConfigData(objVehicleChecks);


            //    VehicleChecks objVehicleType = new VehicleChecks();
            //    objVehicleType.CheckValueRefId = pPVehicleChecks.CheckValueRefId;
            //    objVehicleType.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //    objVehicleType.VehicleTypeList = VehicleChecks.GetVehicleTypeConfigData(objVehicleType);


            //    VehicleChecks objEquipmentType = new VehicleChecks();
            //    objEquipmentType.CheckValueRefId = pPVehicleChecks.CheckValueRefId;
            //    objEquipmentType.LocationID = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            //    objEquipmentType.EquipmentTypeList = VehicleChecks.GetEquipmentTypeConfigData(objEquipmentType);
            //}

            var ChecksList = PVehicleChecks;
            return Json(ChecksList, JsonRequestBehavior.AllowGet);
        }


    }
}
