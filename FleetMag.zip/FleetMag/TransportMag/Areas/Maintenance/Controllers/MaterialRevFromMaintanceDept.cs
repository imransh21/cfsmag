﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;
using TransportMagLib.DataAccessLayer;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class MaterialRetrunFromMaintanceController : Controller
    {

        public ActionResult MaterialRetrunFromMaintance()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult GetAllDetails(int DepotId, string fromDate, string Todate, int LocationId)
        {
            DataSet ds;
            ds = GoodsReturnStoreHdr.GetAllMaterialsDeatils(DepotId, fromDate, Todate, LocationId);
            return Json(JsonConvert.SerializeObject(ds, Formatting.None), JsonRequestBehavior.AllowGet);
        }
    }
}
