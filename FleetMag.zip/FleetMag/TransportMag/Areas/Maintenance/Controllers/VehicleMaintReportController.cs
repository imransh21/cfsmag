﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class VehicleMaintReportController : Controller
    {


        public ActionResult VehicleMaintReport()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult SavaJobDetails(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt32(System.Web.HttpContext.Current.Session["loginLocation"]);
            pWorkInstructions.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            WorkInstructions.InsertJobByReport(pWorkInstructions);
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }


    }
}
