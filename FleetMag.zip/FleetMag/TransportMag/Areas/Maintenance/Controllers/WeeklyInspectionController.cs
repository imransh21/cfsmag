﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class WeeklyInspectionController : Controller
    {

        public ActionResult WeeklyInspection()
        {
            return PartialView();
        }
        public ActionResult DailyInspection()
        {
            return PartialView();
        }
        public ActionResult MonthlyInspection()
        {
            return PartialView();
        }


        [HttpPost]
        public JsonResult GetDailyWeeklyCheck()
        {
            KeyReferenceCls pKeyReferenceCls = new KeyReferenceCls();
            pKeyReferenceCls.HeadCode = "Checks Type";
            pKeyReferenceCls.GroupCode = "Vehicle";
            ArrayList arrlist = new ArrayList();
            arrlist = KeyReferenceCls.GetKeyMasterData(pKeyReferenceCls);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetAllDailyWeelyListById(VehicleChecks pVehicleChecks)
        {
            ArrayList arrlist = new ArrayList();
            arrlist = VehicleChecks.GetVehicleChecksAll(pVehicleChecks);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
           
        }

        [HttpPost]
        public JsonResult GetAllDailyWeelyListByVehicle(VehicleChecks pVehicleChecks)
        {
            ArrayList arrlist = new ArrayList();
            arrlist = VehicleChecks.GetVehicleChecksByVehicle(pVehicleChecks);
            return Json(arrlist, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public JsonResult SavaDetails(VehicleInspectionHdr pVehicleInspectionHdr)
        {
            pVehicleInspectionHdr.CreatedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pVehicleInspectionHdr.ModifiedBy = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            //pVehicleInspectionHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            VehicleInspectionHdr.SaveDetails(pVehicleInspectionHdr);
            return Json(pVehicleInspectionHdr, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetVehicleInspectionLookup(VehicleInspectionHdr pVehicleInspectionHdr)
        {
            //pVehicleInspectionHdr.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrlist = new ArrayList();
            arrlist = VehicleInspectionHdr.GetVehicleInspectionHdrLookup(pVehicleInspectionHdr);
            return Json(arrlist, JsonRequestBehavior.AllowGet);
        }


         [HttpPost]
        public JsonResult GetRetrieveData(VehicleInspectionHdr pVehicleInspectionHdr)
        {
            VehicleInspectionHdr.GetVehicleInspectionHdrByID(pVehicleInspectionHdr);
            return Json(pVehicleInspectionHdr, JsonRequestBehavior.AllowGet);
        }

    }
}
