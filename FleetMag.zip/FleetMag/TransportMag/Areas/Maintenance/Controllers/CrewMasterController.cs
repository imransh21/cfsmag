﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class CrewMasterController : Controller
    {
        
        public ActionResult Index()
        {
            return View();
        }

        public PartialViewResult CrewIndex()
        {
            return PartialView();
        }

        public JsonResult LoadAllSupervisers(EmployeeMaster pSupervisers)
        {
            ArrayList arrSupervisers = EmployeeMaster.GetEmployeeMasterByDesg(pSupervisers);

         //   var SupervisersList = JsonConvert.SerializeObject(arrSupervisers, Formatting.None);
            return Json(arrSupervisers, JsonRequestBehavior.AllowGet);
        }

        public JsonResult LoadAllLocatioNs()
        {
            ArrayList arrTerminals = LocationMaster.GetLocationMasterAll();

            var BranchList = JsonConvert.SerializeObject(arrTerminals, Formatting.None);
            return Json(BranchList, JsonRequestBehavior.AllowGet);
        }


        public JsonResult SaveDetails(CrewMaster pCrewMaster)
        {
            if (ModelState.IsValid == true)
            {
                pCrewMaster = CrewMaster.InsertUpdateDetails(pCrewMaster);

                if (pCrewMaster.ErrorMessage != "")
                    return Json(pCrewMaster, JsonRequestBehavior.AllowGet);
                return Json(pCrewMaster, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var message = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).First();
                pCrewMaster.ErrorMessage = message;
                return Json(pCrewMaster, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult LoadAllCrews(int BranchId)
        {
            ArrayList arrEmp = CrewMaster.GetCrewMasterAll(BranchId);
                                          
          //  var EmpList = JsonConvert.SerializeObject(arrEmp, Formatting.None);
            return Json(arrEmp, JsonRequestBehavior.AllowGet);
        }


        public JsonResult LoadCrewById(CrewMaster pCrewMaster)
        {
            ArrayList arrCrew = CrewMaster.GetCrewMasterByID(pCrewMaster);
            //pCrewMaster.CrewMemberMasterList = CrewMemberMaster.GetCrewMemberMasterAll(pCrewMaster);
           // var CrewList = JsonConvert.SerializeObject(arrCrew, Formatting.None);
            return Json(arrCrew, JsonRequestBehavior.AllowGet);
        }

        //public JsonResult LoadAllWarehousesBlock(BlockMaster pBlockMaster)
        //{
        //    ArrayList arrWarehouse = BlockMaster.GetBlockMasterAllByLocation(pBlockMaster.LocationId);

        //    var WarehouseList = JsonConvert.SerializeObject(arrWarehouse, Formatting.None);
        //    return Json(WarehouseList, JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public JsonResult LoadAllDesignations(EmployeeMaster pEmployeeMaster)
        {
            ArrayList arrWarehouse = EmployeeMaster.GetAllDesignationByLocation(pEmployeeMaster);

          //  var WarehouseList = JsonConvert.SerializeObject(arrWarehouse, Formatting.None);
            return Json(arrWarehouse, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult LoadAllEmpCodes(EmployeeMaster pEmployeeMaster)
        {
            ArrayList arrWarehouse = EmployeeMaster.GetAllEmpCodeByDes(pEmployeeMaster);

           var WarehouseList = JsonConvert.SerializeObject(arrWarehouse, Formatting.None);
           return Json(WarehouseList, JsonRequestBehavior.AllowGet);
        }

    }
}