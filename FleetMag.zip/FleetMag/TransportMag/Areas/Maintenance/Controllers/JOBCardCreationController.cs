﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TransportMagLib.BusinessObjectLayer.BusinessObjects;

namespace TransportMag.Areas.Maintenance.Controllers
{
    public class JOBCardCreationController : Controller
    {
        //
        // GET: /Maintenance/JOBCardCreation/

        public ActionResult JOBCardCreation()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult SaveDetails(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            pWorkInstructions.CreatedBy  = Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            pWorkInstructions.ModifiedBy =  Convert.ToString(System.Web.HttpContext.Current.Session["loginuser"]);
            if (pWorkInstructions.WisId == 0)
            {              
                WorkInstructions.InsertWorkInstruction(pWorkInstructions);
            }
            else
            {
                WorkInstructions.UpdateInstruction(pWorkInstructions);
            }
            
            return Json(pWorkInstructions, JsonRequestBehavior.AllowGet);
        }



        //[HttpPost]
        //public JsonResult GetVehicleLookup(VehicleMaster pVehicleMaster)
        //{
        //    pVehicleMaster.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
        //    ArrayList arrVehicleMaster = new ArrayList();
        //    arrVehicleMaster = VehicleMaster.GetVehicleMasterAllNew(pVehicleMaster);
        //    return Json(arrVehicleMaster, JsonRequestBehavior.AllowGet);
        //}

        [HttpPost]
        public JsonResult GetAllworkinstruction(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arpWorkInstructions = new ArrayList();
            arpWorkInstructions = WorkInstructions.GetWorkInstructionByWisID(pWorkInstructions);
            return Json(arpWorkInstructions, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult GetAllworkinstructionlookup(WorkInstructions pWorkInstructions)
        {
            //pWorkInstructions.LocationId = Convert.ToInt64(System.Web.HttpContext.Current.Session["loginLocation"]);
            ArrayList arrWorkinstruction = new ArrayList();
            arrWorkinstruction = WorkInstructions.GetWorkInstructionByWisLookup(pWorkInstructions);
            return Json(arrWorkinstruction, JsonRequestBehavior.AllowGet);
        }
    }
}
