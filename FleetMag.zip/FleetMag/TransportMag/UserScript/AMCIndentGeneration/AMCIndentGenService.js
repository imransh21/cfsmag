﻿app.service("AMCIndentGenAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/SavaDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetIndentData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/GetIndentDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
    this.GetReqStockList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/GetRequiredStockList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }



    this.GetIndentPrint = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/IndentGenarationPrint",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetAMCDetailsQlist = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/AMCIndentGenaration/GetAMCQlist",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
   

});