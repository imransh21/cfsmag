﻿var app = angular.module("LoginApp", ['ngStorage', 'ui.router', 'ui.multiselect']);

//app.config(function ($httpProvider) {
//    $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
//});

app.factory('http-auth-interceptor', function ($q) {

    return {

        'responseError': function (response) {
            // NOTE: detect error because of unauthenticated user
            if (response.status == "401") {
                var getUrl = window.location;
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                //alert("Session Expired. Logging out....");
                window.location.href = baseUrl;
                return response;
            } else {
                var deferred = $.Deferred();
                 deferred.resolve();                
            }
        }
    };
});


app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    $httpProvider.defaults.headers.common['userName'] = $.parseJSON(sessionStorage.getItem('ngStorage-loginUser'));
    $httpProvider.defaults.headers.common['__RequestVerificationToken'] =angular.element('input[name="__RequestVerificationToken"]').attr('value');
    $httpProvider.interceptors.push('http-auth-interceptor');
}]);

//app.run(function ($http) {
//    $http.defaults.headers.common['__RequestVerificationToken'] =
//        angular.element('input[name="__RequestVerificationToken"]').attr('value');
//});

app.config(function ($stateProvider) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    var VehicleMaster = {
        name: 'dviVehicleMaster',
        url: '/dviVehicleMaster',
        templateUrl: baseUrl + '/Transport/VehicleMaster/VehicleMasterIndex'
    }
    $stateProvider.state(VehicleMaster);


    var RoleDefinition = {
        name: 'divRoleDefinition',
        url: '/divRoleDefinition',
        templateUrl: baseUrl + '/Masters/RoleDefinition/RoleDefinition'
    }
    $stateProvider.state(RoleDefinition);

    var UserMaster = {
        name: 'divUserMaster',
        url: '/divUserMaster',
        templateUrl: baseUrl + '/Masters/UserMaster/UserMasterINDEX'
    }
    $stateProvider.state(UserMaster);

    var KeyRefrence = {
        name: 'divKeyReference',
        url: '/divKeyReference',
        templateUrl: baseUrl + '/Masters/KeyRefrence/KeyRefrence'
    }
    $stateProvider.state(KeyRefrence);

    var TyreManagement = {
        name: 'divTyreManagement',
        url: '/divTyreManagement',
        templateUrl: baseUrl + '/Transport/TyreManagement/TyreManagement'
    }
    $stateProvider.state(TyreManagement);

    var TyrePatternConfig = {
        name: 'divTyrePatternConfig',
        url: '/divTyrePatternConfig',
        templateUrl: baseUrl + '/Masters/PatternConfiguration/PatternConfiguration'
    }
    $stateProvider.state(TyrePatternConfig);



    var JobAllocation = {
        name: 'divJobAlloc',
        url: '/divJobAlloc',
        templateUrl: baseUrl + '/Transport/JobAllocation/JobAllocation'
    }
    $stateProvider.state(JobAllocation);

    var DieselAdjustment = {
        name: 'divDieselAdjustment',
        url: '/divDieselAdjustment',
        templateUrl: baseUrl + '/Transport/DieselAdjustment/DieselAdjustment'
    }
    $stateProvider.state(DieselAdjustment);

    var DieselReqEntryEquipment = {
        name: 'divDieselReqEntryEquip',
        url: '/divDieselReqEntryEquip',
        templateUrl: baseUrl + '/Transport/DieselReqEntryEquipment/DieselReqEntryEquipment'
    }
    $stateProvider.state(DieselReqEntryEquipment);

    var DieselIssueEntryEquipment = {
        name: 'divDieselIssueEntryEquip',
        url: '/divDieselIssueEntryEquip',
        templateUrl: baseUrl + '/Transport/DieselIssueEntryEquipment/DieselIssueEntryEquipment'
    }
    $stateProvider.state(DieselIssueEntryEquipment);

    var DieselAdjustmentFinance = {
        name: 'divDieselAdjustFinance',
        url: '/divDieselAdjustFinance',
        templateUrl: baseUrl + '/Transport/DieselAdjustmentFinance/DieselAdjustmentFinance'
    }
    $stateProvider.state(DieselAdjustmentFinance);


    var IndentGen = {
        name: 'divIndentGen',
        url: '/divIndentGen',
        templateUrl: baseUrl + '/Store/IndentGenaration/IndentGen'
    }
    $stateProvider.state(IndentGen);

    var ItemsMaster = {
        name: 'divItemsMaster',
        url: '/divItemsMaster',
        templateUrl: baseUrl + '/Masters/ItemsMaster/ItemsMaster'
    }
    $stateProvider.state(ItemsMaster);

    var IndentApproval = {
        name: 'divIndentAppv',
        url: '/divIndentAppv',
        templateUrl: baseUrl + '/Store/IndentApproval/IndentApproval'
    }
    $stateProvider.state(IndentApproval);


    var IndentFinalApproval = {
        name: 'divIndentFinalApproval',
        url: '/divIndentFinalApproval',
        templateUrl: baseUrl + '/Store/IndentFinalApproval/IndentFinalApproval'
    }
    $stateProvider.state(IndentFinalApproval);


    var QuotationRequests = {
        name: 'divQuotReq',
        url: '/divQuotReq',
        templateUrl: baseUrl + '/Store/QuotationRequests/QuotationRequests'
    }
    $stateProvider.state(QuotationRequests);


    var DepotMaster = {
        name: 'divDepotMaster',
        url: '/divDepotMaster',
        templateUrl: baseUrl + '/Masters/DepotMaster/DepotMaster'
    }
    $stateProvider.state(DepotMaster);

    var QuotationUploading = {
        name: 'divQuotUpdt',
        url: '/divQuotUpdt',
        templateUrl: baseUrl + '/Store/QuotationUploading/QuotationUploading'
    }
    $stateProvider.state(QuotationUploading);

    var QuotationMapping = {
        name: 'divQuotMap',
        url: '/divQuotMap',
        templateUrl: baseUrl + '/Store/QuotationMapping/QuotationMapping'
    }
    $stateProvider.state(QuotationMapping);


    var PoMap11 = {
        name: 'divPOMapping',
        url: '/divPOMapping',
        templateUrl: baseUrl + '/Store/POMapping/POMapping'
    }
    $stateProvider.state(PoMap11);

    var POGeneration = {
        name: 'divPoGenr',
        url: '/divPoGenr',
        templateUrl: baseUrl + '/Store/POGeneration/POGeneration'
    }
    $stateProvider.state(POGeneration);

    var POApproval = {
        name: 'divPopprval',
        url: '/divPopprval',
        templateUrl: baseUrl + '/Store/POApproval/POApproval'
    }
    $stateProvider.state(POApproval);

    var VendorMaster = {
        name: 'divVendorMaster',
        url: '/divVendorMaster',
        templateUrl: baseUrl + '/Masters/VendorMaster/VendorIndex'
    }
    $stateProvider.state(VendorMaster);
   
    var GoodsReturnGSecurity = {
        name: 'divGoodReturnSecurity',
        url: '/divGoodReturnSecurity',
        templateUrl: baseUrl + '/Store/GoodsReturnGSecurity/GoodsReturnGSecurity'
    }
    $stateProvider.state(GoodsReturnGSecurity);

    var GoodsReceiptGSecurity = {
        name: 'divGoodGateSecurity',
        url: '/divGoodGateSecurity',
        templateUrl: baseUrl + '/Store/GoodsReceiptGSecurity/GoodsReceiptGSecurity'
    }
    $stateProvider.state(GoodsReceiptGSecurity);

    var GoodsReceiptStore = {
        name: 'divGoodStore',
        url: '/divGoodStore',
        templateUrl: baseUrl + '/Store/GoodsReceiptStore/GoodsReceiptStore'
    }
    $stateProvider.state(GoodsReceiptStore);

    var GoodsReturnStore = {
        name: 'divGoodReturnStore',
        url: '/divGoodReturnStore',
        templateUrl: baseUrl + '/Store/GoodsReturnStore/GoodsReturnStore'
    }
    $stateProvider.state(GoodsReturnStore);

    var IndentGenPrint = {
        name: 'divIndentGenPrint',
        url: '/divIndentGenPrint',
        templateUrl: baseUrl + '/Store/IndentGenaration/IndentGenarationPrint'
    }
    $stateProvider.state(IndentGenPrint);


    var GoodsReceiptGSecurity = {
        name: 'divGoodGateSecurityPrint',
        url: '/divGoodGateSecurityPrint',
        templateUrl: baseUrl + '/Store/GoodsReceiptGSecurity/GoodsReceiptGSecurityPrint'
    }
    $stateProvider.state(GoodsReceiptGSecurity);

    var GoodsReceiptStorePrint = {
        name: 'divGoodStorePrint',
        url: '/divGoodStorePrint',
        templateUrl: baseUrl + '/Store/GoodsReceiptStore/GoodsReceiptStorePrint'
    }
    $stateProvider.state(GoodsReceiptStorePrint);


    var ServiceScheduleMst = {
        name: 'divServcScdle',
        url: '/divServcScdle',
        templateUrl: baseUrl + '/Masters/ServiceScheduleMst/ServiceScheduleMst'
    }
    $stateProvider.state(ServiceScheduleMst);

    var DailyChecks = {
        name: 'divDailyCheck',
        url: '/divDailyCheck',
        templateUrl: baseUrl + '/Maintenance/DailyChecks/DailyChecks'
    }
    $stateProvider.state(DailyChecks);

    var WeeklyInspection = {
        name: 'divWeeklyInspection',
        url: '/divWeeklyInspection',
        templateUrl: baseUrl + '/Maintenance/WeeklyInspection/WeeklyInspection'
    }
    $stateProvider.state(WeeklyInspection);

    var DailyInspection = {
        name: 'divDailyInspection',
        url: '/divDailyInspection',
        templateUrl: baseUrl + '/Maintenance/WeeklyInspection/DailyInspection'
    }
    $stateProvider.state(DailyInspection);

    var MonthlyInspection = {
        name: 'divMonthlyInspection',
        url: '/divMonthlyInspection',
        templateUrl: baseUrl + '/Maintenance/WeeklyInspection/MonthlyInspection'
    }
    $stateProvider.state(MonthlyInspection);

    var VehicleMaintReport = {
        name: 'divVehicleMaintReport',
        url: '/divVehicleMaintReport',
        templateUrl: baseUrl + '/Maintenance/VehicleMaintReport/VehicleMaintReport'
    }
    $stateProvider.state(VehicleMaintReport);

    var JOBCard = {
        name: 'divJobCard',
        url: '/divJobCard',
        templateUrl: baseUrl + '/Maintenance/JOBCard/JOBCard'
    }
    $stateProvider.state(JOBCard);

    var CrewMaster = {
        name: 'divCrewMaster',
        url: '/divCrewMaster',
        templateUrl: baseUrl + '/Maintenance/CrewMaster/CrewIndex'
    }
    $stateProvider.state(CrewMaster);


    var DriverMaster = {
        name: 'divDriverMaster',
        url: '/divDriverMaster',
        templateUrl: baseUrl + '/Masters/DriverMaster/DriverIndex'
    }

    $stateProvider.state(DriverMaster);

    var GoodsIssue = {
        name: 'divGoodIssue',
        url: '/divGoodIssue',
        templateUrl: baseUrl + '/Store/GoodsIssueJob/GoodsIssue'
    }
    $stateProvider.state(GoodsIssue);

    var GoodsReturnJob = {
        name: 'divGoodReturnJob',
        url: '/divGoodReturnJob',
        templateUrl: baseUrl + '/Store/GoodsReturnJob/GoodsReturn'
    }
    $stateProvider.state(GoodsReturnJob);


    var GoodsIssueJobPrint = {
        name: 'divGoodIssueJobPrintPrint',
        url: '/divGoodIssueJobPrintPrint',
        templateUrl: baseUrl + '/Store/GoodsIssueJob/GoodsIssueJobPrint'
    }
    $stateProvider.state(GoodsIssueJobPrint);


    var GoodsReturnJobPrint = {
        name: 'divGoodReturnJobPrint',
        url: '/divGoodReturnJobPrint',
        templateUrl: baseUrl + '/Store/GoodsReturnJob/GoodsReturnJobPrint'
    }
    $stateProvider.state(GoodsReturnJobPrint);

    var RouteMaster = {
        name: 'divRouteMaster',
        url: '/divRouteMaster',
        templateUrl: baseUrl + '/Masters/RouteMaster/RouteMaster'
    }
    $stateProvider.state(RouteMaster);

    var Booking = {
        name: 'divBooking',
        url: '/divBooking',
        templateUrl: baseUrl + '/Transport/Booking/BookingIndex'
    }
    $stateProvider.state(Booking);

    var TripChart = {
        name: 'divTripChart',
        url: '/divTripChart',
        templateUrl: baseUrl + '/Transport/TripChart/TripChartIndex'
    }
    $stateProvider.state(TripChart);



    var JOBCardCreation = {
        name: 'divJobCardCreation',
        url: '/divJobCardCreation',
        templateUrl: baseUrl + '/Maintenance/JOBCardCreation/JOBCardCreation'
    }
    $stateProvider.state(JOBCardCreation);

    var VehicleTracking = {
        name: 'divVehicleTracking',
        url: '/divVehicleTracking',
        templateUrl: baseUrl + '/Monitoring/VehicleTracking/VehicleTrackingIndex'
    }
    $stateProvider.state(VehicleTracking);

    var JOBExecution = {
        name: 'divJOBExcute',
        url: '/divJOBExcute',
        templateUrl: baseUrl + '/Transport/JOBExecution/JOBExecutionIndex'
    }
    $stateProvider.state(JOBExecution);


    var CustomerMaster = {
        name: 'divCustomerMaster',
        url: '/divCustomerMaster',
        templateUrl: baseUrl + '/Masters/CustomerMaster/CustomerMaster'
    }
    $stateProvider.state(CustomerMaster);
    
    var geofencing = {
        name: 'divVehicleGeofencing',
        url: '/divVehicleGeofencing',
        templateUrl: baseUrl + '/Monitoring/Geofencing/Geofencing'
    }
    $stateProvider.state(geofencing);

    var ProjectedWHPlanning = {
        name: 'divProjectedWHPlanning',
        url: '/divProjectedWHPlanning',
        templateUrl: baseUrl + '/Warehouse/ProjectedWHPlanning/ProjectedWHPlanning'
    }
    $stateProvider.state(ProjectedWHPlanning);


    var WhDefination = {
        name: 'divWhDefnMstr',
        url: '/divWhDefnMstr',
        templateUrl: baseUrl + '/Warehouse/WarehouseDefination/WarehouseDefination'
    }
    $stateProvider.state(WhDefination);

    var WhView = {
        name: 'divWarehouseView',
        url: '/divWarehouseView',
        templateUrl: baseUrl + '/Warehouse/WarehouseView/WarehouseView'
    }
    $stateProvider.state(WhView);

    var TariffHeadMaster = {
        name: 'divTariffHeadMaster',
        url: '/divTariffHeadMaster',
        templateUrl: baseUrl + '/Masters/TariffHeadMaster/TariffHeadMaster'
    }
    $stateProvider.state(TariffHeadMaster);

    var TaxHeadMaster = {
        name: 'divTaxHeadMaster',
        url: '/divTaxHeadMaster',
        templateUrl: baseUrl + '/Masters/TaxTypesMaster/TaxTypesMaster'
    }
    $stateProvider.state(TaxHeadMaster);

    var TariffRates = {
        name: 'divTariffRates',
        url: '/divTariffRates',
        templateUrl: baseUrl + '/Masters/TariffRates/TariffRatesIndex'
    }
    $stateProvider.state(TariffRates);

    var TaxGroupsMaster = {
        name: 'divTaxGroupsMaster',
        url: '/divTaxGroupsMaster',
        templateUrl: baseUrl + '/Masters/TaxGroupsMaster/TaxGroupsMaster'
    }
    $stateProvider.state(TaxGroupsMaster);

    var TaxHeadMatrix = {
        name: 'divTaxHeadMatrix',
        url: '/divTaxHeadMatrix',
        templateUrl: baseUrl + '/Masters/TaxHeadMatrix/TaxHeadMatrix'
    }
    $stateProvider.state(TaxHeadMatrix);
    

    
    var WhBookng = {
        name: 'divWhBooking',
        url: '/divWhBooking',
        templateUrl: baseUrl + '/Warehouse/WHBooking/WHBooking'
    }
    $stateProvider.state(WhBookng);

    var GoodsTransfor = {
        name: 'divGoodsTransfor',
        url: '/divGoodsTransfor',
        templateUrl: baseUrl + '/Store/GoodsTransfor/GoodsTransforIndex'
    }
    $stateProvider.state(GoodsTransfor);


    var Enquiry = {
        name: 'divEnquiry',
        url: '/divEnquiry',
        templateUrl: baseUrl + '/SupplierPortal/QuotationUploading/QuotationUploading'
    }
    $stateProvider.state(Enquiry);
    var PoList = {
        name: 'divPoList',
        url: '/divPoList',
        templateUrl: baseUrl + '/SupplierPortal/POApproval/POApproval'
    }
    $stateProvider.state(PoList);

    var POPayment = {
        name: 'divPaymentEntry',
        url: '/divPaymentEntry',
        templateUrl: baseUrl + '/Store/POPayment/POPayment'
    }
    $stateProvider.state(POPayment);

    var EquipmentTransfer = {
        name: 'divEquipTransfer',
        url: '/divEquipTransfer',
        templateUrl: baseUrl + '/Transport/EquipmentTransfer/EquipmentTransfer'
    }
    $stateProvider.state(EquipmentTransfer);

    var EquipmentTransferAppr = {
        name: 'divEquipTransAppr',
        url: '/divEquipTransAppr',
        templateUrl: baseUrl + '/Transport/EquipmentTransferAppr/EquipmentTransferAppr'
    }
    $stateProvider.state(EquipmentTransferAppr);

    var EquipGateOutPendency = {
        name: 'divEquipGateOutPen',
        url: '/divEquipGateOutPen',
        templateUrl: baseUrl + '/Transport/EquipGateOutPendency/EquipGateOutPendency'
    }
    $stateProvider.state(EquipGateOutPendency);

    var EquipGateInDistPendency = {
        name: 'divGateInToDestPen',
        url: '/divGateInToDestPen',
        templateUrl: baseUrl + '/Transport/EquipGateInDistPendency/EquipGateInDistPendency'
    }
    $stateProvider.state(EquipGateInDistPendency);

    var JobCompletionStatus = {
        name: 'divJobCompletionStatus',
        url: '/divJobCompletionStatus',
        templateUrl: baseUrl + '/Transport/JobCompletionStatus/JobCompletionStatus'
    }
    $stateProvider.state(JobCompletionStatus);

    var EquipGateOutFromDist = {
        name: 'divEquipGateOutFromDest',
        url: '/divEquipGateOutFromDest',
        templateUrl: baseUrl + '/Transport/EquipGateOutFromDist/EquipGateOutFromDist'
    }
    $stateProvider.state(EquipGateOutFromDist);

    var EquipGateInOrigin = {
        name: 'divEquipGateInOrigin',
        url: '/divEquipGateInOrigin',
        templateUrl: baseUrl + '/Transport/EquipGateInOrigin/EquipGateInOrigin'
    }
    $stateProvider.state(EquipGateInOrigin);

    var HomeIndex = {
        name: 'divHomeIndex',
        url: '/divHomeIndex',
        templateUrl: baseUrl + '/Home/Index'
    }
    $stateProvider.state(HomeIndex);

    var RackDefination = {
        name: 'divWhRackDefnMstr',
        url: '/divWhRackDefnMstr',
        templateUrl: baseUrl + '/Warehouse/RackDefination/RackDefination'
    }
    $stateProvider.state(RackDefination);

    var WarehouseCreation = {
        name: 'divWhCreation',
        url: '/divWhCreation',
        templateUrl: baseUrl + '/Warehouse/WarehouseCreation/WarehouseCreation'
    }
    $stateProvider.state(WarehouseCreation);

    var WarehouseView = {
        name: 'divWhView',
        url: '/divWhView',
        templateUrl: baseUrl + '/Warehouse/RackBinView/RackBinView'
    }
    $stateProvider.state(WarehouseView);

    var GeneralItemReq = {
        name: 'divGenItemsRq',
        url: '/divGenItemsRq',
        templateUrl: baseUrl + '/Store/GeneralItemReq/GenItemsReqVw'
    }
    $stateProvider.state(GeneralItemReq);

    var GeneralItemIssue = {
        name: 'divMaterialIssues',
        url: '/divMaterialIssues',
        templateUrl: baseUrl + '/Store/GeneralItemIssue/GeneralItemIssueVw'
    }
    $stateProvider.state(GeneralItemIssue);

    var AMCDtls = {
        name: 'divAmcDtls',
        url: '/divAmcDtls',
        templateUrl: baseUrl + '/Store/AMCIndentGenaration/AMCIndentGen'
    }
    $stateProvider.state(AMCDtls);
 
    var EmployeeMaster = {
        name: 'divEmployeeMaster',
        url: '/divEmployeeMaster',
        templateUrl: baseUrl + '/Masters/EmployeeMasterNew/EmployeeMasterNew'
    }
    $stateProvider.state(EmployeeMaster);


    var AMCReport = {
        name: 'divAmcReport',
        url: '/divAmcReport',
        templateUrl: baseUrl + '/Store/AMCReport/AMCReport'
    }
    $stateProvider.state(AMCReport);

    var IndentGenrationApprovalReport = {
        name: 'divIndentGenrationApprovalReport',
        url: '/divIndentGenrationApprovalReport',
        templateUrl: baseUrl + '/Store/IndentgenrationApproval/IndentgenrationApproval'
    }
    $stateProvider.state(IndentGenrationApprovalReport);

    var MaterialRetrunToVendor = {
        name: 'divMaterialReturnToVendorReport',
        url: '/divMaterialReturnToVendorReport',        
        templateUrl: baseUrl + '/Maintenance/MaterialRetrunToVendor/MaterialRetrunToVendor'
    }
    $stateProvider.state(MaterialRetrunToVendor);



    var MaterialsRecReport = {
        name: 'divMaterialRevForMaintaiceDeptDtls',
        url: '/divMaterialRevForMaintaiceDeptDtls',
        templateUrl: baseUrl + '/Maintenance/MaterialRetrunFromMaintance/MaterialRetrunFromMaintance'
    }
    $stateProvider.state(MaterialsRecReport);

    var ScrapMaterialReport = {
        name: 'divScapMaterialsReport',
        url: '/divScapMaterialsReport',
        templateUrl: baseUrl + '/Maintenance/ScrapMateriallReport/ScrapMateriallReport'
    }
    $stateProvider.state(ScrapMaterialReport);

    var InvStockRpt = {
        name: 'divInvStockRpt',
        url: '/divInvStockRpt',
        templateUrl: baseUrl + '/Store/InvStockRpt/InvStockRpt'
    }
    $stateProvider.state(InvStockRpt);

});



//====================================Set Error Message===================//
function setErrorMsg(ScrName, MsgID)
{
    ScrName.each(function (index, item) {
        if (item.Key == 'Message1') {
            // $scope.class = "popupBase alert alertShowMsg";
            var RetVal = '';
            RetVal = item.value;
          return RetVal;
        }
    });
}

app.service("ErrorMsgDisplay", function () {
    this.ErrorMsg = function (ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
});

app.service("HomeIndex", function () {
    this.getIndexPage=function(path){
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl +path; 
    };
});


app.directive('numericval', function () {
    return {
        require: 'ngModel',
        restrict: 'A',       
        link: function (scope, element, attr, ctrl) {
            function numericValidate(inputValue){
                if (inputValue == undefined) return '';
                var transformedInput = inputValue.replace(/[^0-9]/g, '');
                if (transformedInput !== inputValue) {
                    ctrl.$setViewValue(transformedInput);
                    ctrl.$render();
                }            
                return transformedInput;   
            }
            ctrl.$parsers.push(numericValidate);
        }
    }
});

app.directive('floatvalues', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function numericValidate(inputValue) {
                if (inputValue == undefined) return '';
                var transformedInput = inputValue.replace(/[\d+(\.\d{1,2})?]/g, '');
                if (transformedInput !== inputValue) {
                    ctrl.$setViewValue(transformedInput);
                    ctrl.$render();
                }
                return transformedInput;
            }
            ctrl.$parsers.push(numericValidate);
        }
    }
});

app.directive('ngOnFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit(attr.broadcastEventName ? attr.broadcastEventName : 'ngRepeatFinished');
                });
            }
        }
    };
});

//Added on 02-11-2017 for fiel upload
app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

app.directive('fileOnChange', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var onChangeHandler = scope.$eval(attrs.fileOnChange);
            element.bind('change', onChangeHandler);
        }
    };
});

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function (file, uploadUrl) {
        var fd = new FormData();
        fd.append('file', file);
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            //headers: { 'Content-Type': undefined }
        })
        //.success(function () {
        //})
        //.error(function () {
        //});
    }
}]);


app.directive('ngConfirmClick', [
        function () {
            return {
                link: function (scope, element, attr) {
                    
                    var msg = attr.ngConfirmClick || "Are you sure?";
                    var wareHouse = attr.ngWareHouse;                   
                    var clickAction = attr.confirmedClick;
                    element.bind('click', function (event) {
                        if (wareHouse==undefined){
                            if (window.confirm(msg)) {
                                scope.$eval(clickAction)
                            }
                            else
                                return true;
                        }
                    });
                }
            };
        }]);

//app.directive("tree", function(RecursionHelper) {
//    return {

//        restrict: "E",
//        scope: { family: '=', commonSource :"&"},
//        template: 
//        '<ul class="listView">' +
//        //'<li ng-repeat="Main in family.SubMenu"><span class="fa fa-caret-right tree-icon"></span>{{ Main.ItemCode}}' +

//          '<li ng-repeat="Main in family.SubMenu"><a href=\"#\" ng-click=\"commonSource(Main)\"><span class="fa fa-caret-right tree-icon"></span>{{ Main.ItemCode}} </a>' +
//          //'<li ng-repeat="Main in family.SubMenu"><span class="fa fa-caret-right tree-icon" ></span>{{ Main.ItemCode}} {{Main.ItemId}} ' +
      
//                 '<tree family="Main" ></tree>' +
//        '</li></ul>',
       
//        compile: function(element) {
//            return RecursionHelper.compile(element, function (scope, iElement, iAttrs, controller, transcludeFn) {

//                // Define your normal link function here.
//                // Alternative: instead of passing a function,
//                // you can also pass an object with 
//                // a 'pre'- and 'post'-link function.
//            });
//        }
//    };
//});

