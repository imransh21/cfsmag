﻿app.controller("QuotationReqCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, QuotationReqAJService, IndentGenAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = true;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    var countFinal = 0;
    var ObjectData = []
    // SerachIndentDetails();
    DepoLookupList();
    $scope.ExitDtls = function () {
        getIndexpage();
    }
    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownIndent = true;

    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownIndent = false;

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    }


    $scope.SelectAllApproveRows = function (SelectAllData) {
        
        angular.forEach($scope.IndentListDtls[$scope.RowIndex].IndentQuotationRequestP, function (value, key) {
            if (SelectAllData == "Y")
            {
                if(value.IndentQuotReqRefId <= 0)
                {
                    value.MailQuotation = "Y";
                }
            }
            else {
                if(value.IndentQuotReqRefId <= 0)
                {
                    value.MailQuotation = "N";
                }
            }
        })
    };


    $scope.SelectAllmailApproveRows = function (SelectMailData) {
        
        angular.forEach($scope.IndentListDtls[$scope.RowIndex].IndentQuotationRequestP, function (value, key) {
            if (SelectMailData == "Y") {
                if (value.IndentQuotReqRefId <= 0) {
                    value.QtyMailQuote = "Y";
                }
            }
            else {
                if (value.IndentQuotReqRefId <= 0) {
                    value.QtyMailQuote = "N";
                }
            }
        })
    };

    $scope.SaveDtls = function () {
        
        ObjectData = [];
        var objDatavalue = $scope.IndentListDtls[$scope.RowIndex].IndentQuotationRequestP.filter(function (value) {
            return value.MailQuotation == 'Y';
        })
        


        if (objDatavalue.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Vendor.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }



        $scope.IndentListDtls[$scope.RowIndex].IndentQuotationRequestP;
        angular.forEach(objDatavalue, function (value1, key1) {
            var inputParam = {
                IndentQuotReqRefId: value1.IndentQuotReqRefId,
                IndentRefId: value1.IndentRefId,
                ItemId: value1.PartId,
                VendorId: value1.VendorId,
                MailQuotation: value1.MailQuotation,
                FinalQuotation: value1.FinalQuotation,
                QuotAmount: value1.QuotAmount,
                QtyMailQuote: value1.QtyMailQuote
            }
            if (value1.FinalQuotation == "Y") {
                countFinal = countFinal + 1
            }

            ObjectData.push(inputParam);
        });



        $sessionStorage.ObjectData = ObjectData;
        //FinalQuot();

        var getData = QuotationReqAJService.SaveQuotationReqDtls(ObjectData);
        getData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                //SerachIndentDetails();
                GetAllIndentFilterData();
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }

        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    //$scope.SaveDtls = function () {
    //    
    //    angular.forEach($scope.IndentListDtls, function (value, key) {           
    //      var objDatavalue=  value.IndentQuotationRequestP.filter(function (value) {
    //            return value.MailQuotation == 'Y';
    //      });

    //      angular.forEach(objDatavalue, function (value1, key1) {              
    //          var inputParam = {
    //              IndentQuotReqRefId:value1.IndentQuotReqRefId,
    //              IndentRefId: value.IndentRefId,
    //              ItemId: value.PartId,
    //              VendorId: value1.VendorId,
    //              MailQuotation: value1.MailQuotation,
    //              FinalQuotation: value1.FinalQuotation,
    //              QuotAmount: value1.QuotAmount
    //          }
    //          if (value1.FinalQuotation == "Y") {
    //              countFinal = countFinal + 1
    //          }

    //         ObjectData.push(inputParam);
    //      });
    //    });


    //    $sessionStorage.ObjectData = ObjectData;
    //    //FinalQuot();

    //    var getData = QuotationReqAJService.SaveQuotationReqDtls(ObjectData);
    //    getData.then(function (Response) {
    //        if (Response.data.ErrorMessage == "") {
    //            $scope.errMsg = 'Data Saved'
    //            ErrorMsgDisplay.ErrorMsg('ErrorDivG');
    //            SerachIndentDetails();
    //        }
    //        else {
    //            $scope.errMsg = Response.data.ErrorMessage;
    //            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        }

    //    }, function (reason) {
    //        $scope.errMsg = "Error in getting locations " + reason.data;
    //        $scope.isError = true;
    //        return;
    //    });
    //}

    function FinalQuot() {
        //FINAL QUOTATION UPDATE
        if (countFinal > 0) {
            
            var getData = QuotationReqAJService.UpdateFinalQuotationReqDtls(ObjectData);
            getData.then(function (Response) {
                if (Response.data.ErrorMessage == "") {
                    $scope.errMsg = 'Data Saved'
                    ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                    SerachIndentDetails();
                }
                else {
                    $scope.errMsg = Response.data.ErrorMessage;
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                }

            }, function (reason) {
                $scope.errMsg = "Error in getting locations " + reason.data;
                $scope.isError = true;
                return;
            });
        }

    }


    $scope.DisplayData = function () {
        SerachIndentDetails();
    }

    function SerachIndentDetails() {
        
        var getData = QuotationReqAJService.GetQuotationData();
        getData.then(function (Response) {
            $scope.IndentListDtls = Response.data;           

        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });

    }




    $scope.FinalQoutCheck = function (position, IndentQuotationRequest) {
        
        angular.forEach(IndentQuotationRequest, function (value, index) {
            if (position != index)
                value.FinalQuotation = false;
        });
    }




    $scope.CancelDtls = function () {
        GetAllIndentFilterData();
        //ClearData();
        //$scope.isShownAdd = true;
        //$scope.isShownEdit = false;
        //$scope.isShownSave = false;
        //$scope.isShownSearch = true;
        //$scope.isShownExit = true;
        //$scope.isShownClear = false;
        //$scope.isShown = true;
        //$scope.isShownDispaly = false;
        //$scope.isShownIndent = true;
        //$scope.SelectAllData = 'N';
        //SerachIndentDetails();
    }

    function ClearData() {
        $scope.IndentRefId = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentDate = undefined;
        $scope.NatureOfIndent = undefined;
        $scope.DepotCode = undefined;
        $scope.ExpDelvDate = undefined;
    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
    }


    $scope.GetVendorDetails = function (rowData, Index) {
        $scope.RowIndex = Index;
    }



    $scope.FilterData = function () {
        
        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        GetAllIndentFilterData();
    }

    function GetAllIndentFilterData() {
        
        var InputParam = {
            DeportId: $scope.DepotId,
            IndentRefId: $scope.IndentRefId,
            PartId: $scope.PartId,
            fromDate: $scope.fromDate,
            toDate: $scope.toDate,
        }
        var GetData = QuotationReqAJService.GetIndentFilterData(InputParam);
        GetData.then(function (Response) {
            
            $scope.IndentListDtls = Response.data;
            CountNoOfVendorAndReceive();
        });
      

    }

    $scope.ClearFilterData = function () {
        
        $scope.IndentRefId = undefined;
        $scope.DepotId = undefined;
        $scope.toDate = undefined;
        $scope.fromDate = undefined;
        $scope.PartName = undefined
        $scope.PartId = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentListDtls = undefined;
        //     GetAllIndentDetails();
    }
    $scope.ViewFile = function (row) {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        var link = document.createElement('a');
        // link.href = baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId;
        //window.location = link.href;
        var wo = window.open(baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId, 'Snopzer', 'left=20,top=20,width=500,height=500,directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,title=AttachedFile');
        wo.document.title = "My File"
    }



    function CountNoOfVendorAndReceive() {
        
        //var countFinal1 = 0;
        ObjectData = [];
        var objDatavalue = $scope.IndentListDtls;
        angular.forEach($scope.IndentListDtls, function (value1) {
            var countRequest1 = 0;
            var countReceived1 = 0;
            angular.forEach(value1.IndentQuotationRequestP, function (value) {
                
                if (value.MailQuotation == "Y" && value1.IndentRefId == value.IndentRefId) {
                    countRequest1 = countRequest1 + 1
                }
                if (value.QuotAmount > 0 && value1.IndentRefId == value.IndentRefId) {
                    countReceived1 = countReceived1 + 1
                }
                value1.NoOfRequest = countRequest1
                value1.NoOfRecieved = countReceived1
            });
            
        }); 
    }

});