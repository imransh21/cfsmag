﻿app.service("EquipmentTransferApprovalAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetVehicleList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/GetVehicleList",
            dataType: "json"
        });
        return response;
    }

    this.GetEquipTypeList = function (InputData) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/GetEquimentList",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

    this.GetPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransferAppr/GetPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    } 
  
    this.SaveTransferDtls = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransferAppr/SaveDetails",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }


});