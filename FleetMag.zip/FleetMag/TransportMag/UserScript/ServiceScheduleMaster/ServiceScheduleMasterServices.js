﻿app.service("ServiceSecheduleAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];



    this.saveData = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/ServiceScheduleMst/SaveDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

       
    this.GetServSchedulelist = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/ServiceScheduleMst/GetALLServiceSchedulelist",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.DeleteItemBySchdtlID = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/ServiceScheduleMst/DeleteItemBySchdtlID",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
})