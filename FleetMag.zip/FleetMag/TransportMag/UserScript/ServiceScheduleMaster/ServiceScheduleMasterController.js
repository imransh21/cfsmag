﻿app.controller("ServiceSecheduleCntrl", function ($scope, $localStorage, $compile, $filter, ServiceSecheduleAJService, HomeIndex, KeyRefrenceCtrlAJService, $state, ErrorMsgDisplay) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.isShownExit = true;
    $scope.isShownAdd = true;
    $scope.isShownSave = false;
    $scope.isShownSchName = true;
    $scope.isShownClear = false;
    $scope.isAddRowShown = false;
    $scope.isAddRowDelete = false;
    
    

    $scope.ItemDtlsList = [];
    //DefaultRownGrd();
    var appendlst = "";
    GetVehicleTypeList();
    GetEquipmentTypeList();
    GetServicingSchedulelist();
    



    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            var TempVehicleTypeList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //TempVehicleTypeList.unshift(defaltvalue);
            $scope.VehicleTypeList = TempVehicleTypeList;
            $scope.TruckType = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetEquipmentTypeList() {
        var KeyReference = {
            HeadCode: 'EquipmentType',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.EquipmentTypeList = [];
        GetData.then(function (Response) {
            var TempEquipmentLst = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
           // TempEquipmentLst.unshift(defaltvalue);
            $scope.EquipmentTypeList = TempEquipmentLst;
            $scope.EquipmentType = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    $scope.AddDtls = function () {
        
        clearData();

        //  AddNew();
        $scope.isShown = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownSchName = false;
        $scope.isShownExit = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isAddRowShown = true;
        $scope.isAddRowDelete = false;
        
        
       // DefaultRownGrd();
    }


    function GridAutoComplete() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        $(".txtItemName").autocomplete({
            source: function (request, response) {
                
                var InputParam = {
                    //DepotName: request.term
                    ItemName: request.term
                }
                $.ajax({
                    url: baseUrl + '/Masters/ServiceScheduleMst/GetALLItemMasterLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.ItemName,
                                ItemId: item.ItemId,
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    $scope.ItemDtlsList[Indexval].ItemId = i.item.ItemId;
                    $scope.ItemDtlsList[Indexval].ItemName = i.item.ItemName;
                });
            },
            minLength: 3
        });
    }


    $scope.InitAutoComplete = function () {
        GridAutoComplete();
    }


    function DefaultRownGrd() {
        
        for (i = 0; i <= 4; i++) {
            var InputParam = {
                ItemName: "",
                ItemId: "",
                Qty: ""
            }
            $scope.ItemDtlsList.push(InputParam);
        }
    }


    $scope.addNewItem = function () {
        
        var InputParam = {
            ItemName: "",
            ItemId: "",
            Qty: ""
        }
        $scope.ItemDtlsList.push(InputParam);
    }




    $scope.SaveDtls = function () {
        var ErrorFound = false;
        if ($scope.ScheduleName == undefined || $scope.ScheduleName == null || $scope.ScheduleName == '') {
            $scope.errMsg = "Please Enter Schedule Name"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtScheduleName").val('');
            setTimeout(function () {
                $("#txtScheduleName").focus();
            }, 500);
            return;
        }





        if ($scope.TruckType == undefined || $scope.TruckType == null || $scope.TruckType == '') {
            $scope.errMsg = "Please select Vehicle Type"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstTruckType").val('');
            setTimeout(function () {
                $("#lstTruckType").focus();
            }, 500);
            return;
        }


        if ($scope.TruckType == "22" && ($scope.EquipmentType == undefined || $scope.EquipmentType == null || $scope.EquipmentType == '')) {
            $scope.errMsg = "Please select Equipment Type"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstEquipmentType").val('');
            setTimeout(function () {
                $("#lstEquipmentType").focus();
            }, 500);
            return;
        }


        if (($scope.RunningHrsFrom == undefined || $scope.RunningHrsFrom == "0" || $scope.RunningHrsFrom == '') && ($scope.RunningKmFrom == undefined || $scope.RunningKmFrom == "0" || $scope.RunningKmFrom == '') && ($scope.PeriodFrom == undefined || $scope.PeriodFrom == "0" || $scope.PeriodFrom == '')) {
            $scope.errMsg = "Please Enter Atleast one from RunningHrsFrom , RunningKmFrom and  PeriodFrom "
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }



        if ($scope.RunningHrsFrom != undefined && $scope.RunningKmFrom == undefined && $scope.PeriodFrom == undefined) {

            if ($scope.RunningHrsFrom == undefined || $scope.RunningHrsFrom == null || $scope.RunningHrsFrom == '' || $scope.RunningHrsFrom == "0" ) {
                
                $scope.errMsg = "Please Enter RunningHrs From"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtRunningHrsFrom").val('');
                setTimeout(function () {
                    $("#txtRunningHrsFrom").focus();
                }, 500);
                return;
            }

            if (($scope.RunningHrsTo == undefined || $scope.RunningHrsTo == null || $scope.RunningHrsTo == '' || $scope.RunningHrsTo == "0") && ($scope.RunningHrsFrom != undefined || $scope.RunningHrsFrom != '' || $scope.RunningHrsFrom != "0")) {
                $scope.errMsg = "Please Enter RunningHrs To"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtRunningHrsTo").val('');
                setTimeout(function () {
                    $("#txtRunningHrsTo").focus();
                }, 500);
                return;
            }

        }




        if ($scope.RunningHrsFrom == undefined && $scope.RunningKmFrom != undefined && $scope.PeriodFrom == undefined) {

            if ($scope.RunningKmFrom == undefined || $scope.RunningKmFrom == null || $scope.RunningKmFrom == '' || $scope.RunningKmFrom == "0") {
                
                $scope.errMsg = "Please Enter RunningKm From"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtRunningKmFrom").val('');
                setTimeout(function () {
                    $("#txtRunningKmFrom").focus();
                }, 500);
                return;
            }

            if (($scope.RunningKmTo == undefined || $scope.RunningKmTo == null || $scope.RunningKmTo == '' || $scope.RunningKmTo == "0") && ($scope.RunningKmFrom != undefined || $scope.RunningKmFrom != '')) {
                $scope.errMsg = "Please Enter Running Km To"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtRunningKmTo").val('');
                setTimeout(function () {
                    $("#txtRunningKmTo").focus();
                }, 500);
                return;
            }

        }


        if (($scope.RunningHrsFrom == undefined || $scope.RunningHrsFrom == "" || $scope.RunningHrsFrom == "0") && ($scope.RunningKmFrom == undefined || $scope.RunningKmFrom == "" || $scope.RunningKmFrom == "0") && ($scope.PeriodFrom != undefined || $scope.PeriodFrom != "" || $scope.PeriodFrom != "0")) {

            if ($scope.PeriodFrom == undefined || $scope.PeriodFrom == null || $scope.PeriodFrom == '' || $scope.PeriodFrom == "0") {
                
                $scope.errMsg = "Please Enter Period From"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtPeriodFrom").val('');
                setTimeout(function () {
                    $("#txtPeriodFrom").focus();
                }, 500);
                return;
            }


            if (($scope.PeriodTo == undefined || $scope.PeriodTo == null || $scope.PeriodTo == '' || $scope.PeriodTo == "0") && $scope.PeriodFrom != undefined) {
                
                $scope.errMsg = "Please Enter Period To"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#txtPeriodTo").val('');
                setTimeout(function () {
                    $("#txtPeriodTo").focus();
                }, 500);
                return;
            }

        }








        ItemDtlsList = $scope.ItemDtlsList.filter(function (value) {
            return value.ItemId != "";
        });


        if (ItemDtlsList.length <= 0) {
            $scope.errMsg = "Please enter Atleast One Item.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }






        var itemCount = 0;
        if (itemCount == 0) {
            angular.forEach(ItemDtlsList, function (value1, key) {
                if (ErrorFound == false) {
                    if (value1.ItemId == "") {
                        itemCount = itemCount + 1;
                    }
                    if ((value1.ItemId == undefined || value1.ItemId == "" || value1.ItemId == "0")) {
                        $scope.errMsg = "Please select Item ";
                        ErrorFound = true;
                        return;
                    }
                }

                if ((value1.ItemId != "") && (value1.Qty == undefined || value1.Qty == "" || value1.Qty == "0")) {
                    $scope.errMsg = "Please enter the Qty";
                    ErrorFound = true;
                    return;
                }
            });
        }




        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        if (ItemDtlsList.length != null || ItemDtlsList.length != undefined) {
            
            for (i = 0; i < ItemDtlsList.length; i++) {
                for (j = i + 1 ; j < ItemDtlsList.length; j++) {
                    if (ItemDtlsList[i].ItemId == (ItemDtlsList[j].ItemId)) {                        
                        if (ItemDtlsList[i].ItemId != "") {
                            $scope.errMsg = "Item Name " + ItemDtlsList[i].ItemName + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        }



        
        var InputParam = {
            ScheduleName: $scope.ScheduleName,
            ScheduleId: $scope.ScheduleId,
            TruckType: $scope.TruckType,
            EquipmentType: $scope.EquipmentType,
            RunningHrsFrom: $scope.RunningHrsFrom,
            RunningHrsTo: $scope.RunningHrsTo,
            RunningKmFrom: $scope.RunningKmFrom,
            RunningKmFrom: $scope.RunningKmFrom,
            RunningKmTo: $scope.RunningKmTo,
            PeriodFrom: $scope.PeriodFrom,
            PeriodTo: $scope.PeriodTo,
            ItemDtlsList: ItemDtlsList,
        }
        var GetData = ServiceSecheduleAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null) {
                
                $scope.ScheduleId = Response.data.ScheduleId;
                $scope.ScheduleName = Response.data.ScheduleName;
                $scope.TruckType = Response.data.TruckType;
                $scope.EquipmentType = Response.data.EquipmentType;
                $scope.RunningHrsFrom = Response.data.RunningHrsFrom;
                $scope.RunningHrsTo = Response.data.RunningHrsTo;
                $scope.RunningKmFrom = Response.data.RunningKmFrom;
                $scope.RunningKmTo = Response.data.RunningKmTo;
                $scope.PeriodFrom = Response.data.PeriodFrom;
                $scope.PeriodTo = Response.data.PeriodTo;
                $scope.ItemDtlsList = Response.data.ItemDtlsList;
                $scope.ScheduleId = Response.data.ScheduleId;

                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
                //$scope.isError = true;
                //$scope.errMsg = 'Data Saved'
                //ErrorMsgDisplay.ErrorMsg('ErrorDivG');                
                showFirst($scope.ScheduleId);
                GetServicingSchedulelist();

                $scope.isShownAdd = true;
                $scope.isShownEdit = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShown = true;
                $scope.isShownSchName = true;
                $scope.isShownExit = true;
                $scope.isAddRowShown = false;
                $scope.isAddRowDelete = false;

               
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });
    }



    function showFirst(ScheduleId) {
        
        var InputParam = {
            ScheduleId: ScheduleId
        };
        var getData = ServiceSecheduleAJService.GetServSchedulelist(InputParam);
        getData.then(function (pScheduleSerciveDtl) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pScheduleSerciveDtl.data.ErrorMessage != null) {
                $scope.errMsg = pScheduleSerciveDtl.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";
                $scope.isError = true;
                return;
            }
            $scope.ScheduleId = pScheduleSerciveDtl.data[0].ScheduleId;
            $scope.ScheduleName = pScheduleSerciveDtl.data[0].ScheduleName;
            $scope.TruckType = pScheduleSerciveDtl.data[0].TruckType;
            $scope.EquipmentType = pScheduleSerciveDtl.data[0].EquipmentType;
            $scope.RunningHrsFrom = pScheduleSerciveDtl.data[0].RunningHrsFrom;
            $scope.RunningHrsTo = pScheduleSerciveDtl.data[0].RunningHrsTo;
            $scope.RunningKmFrom = pScheduleSerciveDtl.data[0].RunningKmFrom;
            $scope.RunningKmTo = pScheduleSerciveDtl.data[0].RunningKmTo;
            $scope.PeriodFrom = pScheduleSerciveDtl.data[0].PeriodFrom;
            $scope.PeriodTo = pScheduleSerciveDtl.data[0].PeriodTo;
            $scope.ItemDtlsList = pScheduleSerciveDtl.data[0].ItemDtlsList;

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    function clearData() {
        $scope.ScheduleId = undefined;
        $scope.ScheduleName = undefined;
        $scope.TruckType = undefined;
        $scope.EquipmentType = undefined;
        $scope.RunningHrsFrom = undefined;
        $scope.RunningHrsTo = undefined;
        $scope.RunningKmFrom = undefined;
        $scope.RunningKmTo = undefined;
        $scope.PeriodFrom = undefined;
        $scope.PeriodTo = undefined;
        $scope.ItemDtlsList = [];
        DefaultRownGrd();
    }

    function GetServicingSchedulelist() {
        
        var GetData = ServiceSecheduleAJService.GetServSchedulelist();

        GetData.then(function (Input) {
            
            $scope.ScheduleNameList = Input.data;
            $scope.errMsg = "";
            $scope.isError = false;

            GetScheculeservice();
            //DefaultRownGrd();

        }, function (reason) {
            $(UserMasterS).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    function GetScheculeservice() {
        
        var uiEle = angular.element(document.querySelector('#LpScheduleName'));
        $('#LpScheduleName').html('');
        angular.forEach($scope.ScheduleNameList, function (value, key) {
            if (!jQuery.isEmptyObject(value.ScheduleName)) {
                appendlst = appendlst + "<li><a href=\"#\" ng-click=\"commonSource('" + value.ScheduleId + "')\"><span class=\"fa fa-caret-right tree-icon\"></span>" + value.ScheduleName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var uList = $compile(appendlst)($scope);
        uiEle.append(uList);
        appendlst = "";
    }

    $scope.commonSource = function (ScheduleId) {
        
        showFirst(ScheduleId);
    }


    var watchList = $scope.$watch('ScheduleNameList', function () {
        if ($scope.ScheduleNameList != undefined) {
            showFirst($scope.ScheduleNameList[0].ScheduleId);
            watchList();
        }
    });




    $scope.CancelDtls = function () {
        
        clearData();
        AddNew();
        $scope.isShown = true;
        $scope.isShownEdit = true;


        if ($scope.ScheduleId == undefined || $scope.ScheduleId == 0 || $scope.ScheduleId == "") {
            clearData();

            var watchList = $scope.$watch('ScheduleNameList', function () {
                showFirst($scope.ScheduleNameList[0].ScheduleId);
                watchList();
            });
        }
    }

    $scope.EditDtls = function () {
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownExit = false;
        $scope.isShown = false;
        $scope.isShownSchName = true;
        $scope.isAddRowShown = true;
        $scope.isAddRowDelete = true;

    }
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }

    $scope.filter = function () {
        var elem = document.getElementById('LpScheduleName');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchSchedule) != -1 || $scope.SrchSchedule == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }


    $scope.DeleteItemBySchDtlid = function (row) {
        

        ItemDtlsList = $scope.ItemDtlsList.filter(function (value) {
            return value.ItemId != "";
        });


        if (ItemDtlsList.length == 1) {
            $scope.errMsg = "Atleast One Item Required .";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }



        var InputParam = {
            ScheduleId: row.ScheduleId,
            ScheduleDtlsId: row.ScheduleDtlsId
        }
        var GetData = ServiceSecheduleAJService.DeleteItemBySchdtlID(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null) {
                
                showFirst($scope.ScheduleId);
                GetServicingSchedulelist();

                $scope.isShownAdd = false;
                $scope.isShownEdit = false;
                $scope.isShownExit = false;
                $scope.isShownSave = true;
                $scope.isShownClear = true;
                $scope.isShown = false;
                $scope.isShownSchName = false;
                $scope.isShownExit = false;


            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });

    }


    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }


});

