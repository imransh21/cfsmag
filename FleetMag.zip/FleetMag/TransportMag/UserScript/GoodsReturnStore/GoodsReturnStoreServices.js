﻿app.service("GoodsReturnStoreAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }


    this.GetGetPodetailsById = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnStore/GetGoodsReturnPodetails",
            data:JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }


    this.SaveReturnData = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnStore/SaveReturnGoodsStore",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

});