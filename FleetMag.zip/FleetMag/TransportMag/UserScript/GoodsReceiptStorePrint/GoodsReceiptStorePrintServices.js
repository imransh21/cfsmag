﻿app.service("GoodsReceiptStorePrintAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    
    this.GetStoreTransationNo = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/GetRetrieveData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


});