﻿app.controller("CntrlGoodsReceiptStorePrint", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsReceiptStorePrintAJService) {

    DisplayData();

    //function GetGoodsReceiptStorePrintData() {
    //    
    //    var ItemMaster = {
    //        InwrdStoreId: $sessionStorage.InwrdStoreId            
    //    };
    //    var getData = GoodsReceiptStorePrintAJService.getItemById(ItemMaster);
    //    getData.then(function (Response) {
    //        $scope.errMsg = "";
    //        $scope.isError = false;
    //        
    //        if (Response.data.ErrorMessage != null) {
    //            $scope.errMsg = Response.data.ErrorMessage;
    //            $scope.setclass = "popupBase alert alertShowMsg";//added by priya

    //            $scope.isError = true;
    //            return;
    //        }
    //        $scope.GrRefNo = Response.data.GrRefNo;
    //        $scope.GrDate = Response.data.GrDate;
    //        $scope.PoNo = Response.data.PoNo;
    //        $scope.VendorId = Response.data.VendorId;
    //        $scope.VendorName = Response.data.VendorName;
    //        $scope.CustomerDcNo = Response.data.CustomerDcNo;
    //        $scope.CustomerDcDate = Response.data.CustomerDcDate;
    //        $scope.Remark = Response.data.Remark
    //        $scope.PoDetailsList = Response.data.List;
            

    //    });
    //}


    function DisplayData() {
        
        var InputParam = {
            InwrdStoreId: $sessionStorage.InwrdStoreId
        }
        var getData = GoodsReceiptStorePrintAJService.GetStoreTransationNo(InputParam);
        getData.then(function (Response) {
            $scope.InwrdTransNbr = Response.data.InwrdTransNbr;
            $scope.InwrdStoreId = Response.data.InwrdStoreId;
            $scope.InwrdDate = Response.data.InwrdDate;
            $scope.PoNo = Response.data.PoNo;
            $scope.DeliveryAddress = Response.data.DeliveryAddress;
            $scope.CustomerDcNo = Response.data.CustomerDcNo;
            $scope.CustomerDcDate = Response.data.CustomerDcDate;
            $scope.VendorName = Response.data.VendorName;
            $scope.VendorId = Response.data.VendorId;
            $scope.PoDetailsList = Response.data.ltGoodsInwordStoreDtls;
        });
    }

})