﻿app.controller("cntrlGoodIssueJobPrint", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsIssuedjobPrintAJService, GoodsIssueJobAJService) {
    DisplayData();
   

    function DisplayData() {
        
        var InputParam = {
            WisId: $sessionStorage.WisId,
            DepotId: $sessionStorage.DepotId,
        }
        var getData = GoodsIssuedjobPrintAJService.VehicleDetails(InputParam);
        getData.then(function (Response) {
            $scope.VehicleDetailsList = Response.data;
            GetItemDetails(InputParam);
        });
    }


    function GetItemDetails(InputParam) {
        
        var GetItemData = GoodsIssuedjobPrintAJService.GetStockReqDataPrint(InputParam);
        GetItemData.then(function (Response) {
            $scope.VehicleItemDetailsList = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }



})