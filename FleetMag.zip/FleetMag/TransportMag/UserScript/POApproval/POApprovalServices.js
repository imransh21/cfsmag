﻿app.service("POApprovalAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.AcceptData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/AcceptPoDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.getItemByPoId = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/GetpODetailsBypOId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetPOPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/GetPOPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetItemDtlListbyPoNo = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/GetItemDtlListbyPoNo",
            data: JSON.stringify(),
            dataType: "json"
        });
        return response;
    }
    


    this.UpdatePoDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/UpdatePoDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
    this.GetPOApprovalListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/GetPOApprovalListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetItemHistory = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApproval/GetItemHistory",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
});