﻿app.service("POApprovalPrintAJService", function ($http) {

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
   
   
    this.GetPoDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POApprovalPrint/GetpODetailsBypOId",
            data: JSON.stringify(InputParam),
            dataType: "json"

        });
        return response;
    }
    
});