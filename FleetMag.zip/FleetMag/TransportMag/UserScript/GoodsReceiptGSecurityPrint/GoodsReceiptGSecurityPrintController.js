﻿app.controller("CntrlGoodsReceiptGSecurityPrint", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsReceiptGSecurityPrintAJService) {

    GetGoodsReceiptSecurityPrintData();

    function GetGoodsReceiptSecurityPrintData() {
        
         var ItemMaster = {             
            GrRefId: $sessionStorage.GrRefId               
        };

        var getData = GoodsReceiptGSecurityPrintAJService.getItemById(ItemMaster);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.DeliveryAddress = Response.data.DeliveryAddress;
            $scope.GrRefNo = Response.data.GrRefNo;
            $scope.GrDate = Response.data.GrDate;
            $scope.PoNo = Response.data.PoNo;
            $scope.VendorId = Response.data.VendorId;
            $scope.VendorName = Response.data.VendorName;
            $scope.CustomerDcNo = Response.data.CustomerDcNo;
            $scope.CustomerDcDate = Response.data.CustomerDcDate;
            $scope.Remark = Response.data.Remark
            $scope.PoDetailsList = Response.data.List;
            //$sessionStorage.GrRefId = JSON.stringify($scope.GrRefId);

        });
    }

})