﻿app.controller("JobCardCreationCntrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, IndentGenAJService, KeyRefrenceCtrlAJService, ServiceSecheduleAJService, JobCardCreationAJService, HomeIndex, VehicleAJService, IndentGenAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownJobNo = false;
    
    $scope.SearchDtls = true

    $scope.isShownJobNo = true;
    $scope.isShown = true;

    $scope.ComplaintList = [];
    GetVehicleTypeList();
    GetEquipmentTypeList();
    GetServicingSchedulelist();
    GetAllVehicleList();
    DefaultRownGrd();
    DepoLookupList();

    


    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function GetAllVehicleList() {
        
        var GetData = JobCardCreationAJService.GetAllVehicellist();

        GetData.then(function (Input) {
            
            $scope.VehicleList = Input.data;          

        });
    }



    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            var TempVehicleTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVehicleTypeList.unshift(defaltvalue);
            $scope.VehicleTypeList = TempVehicleTypeList;
            $scope.TruckType = "";
            // SearchVehicleById();
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };
   

    function GetEquipmentTypeList() {
        var KeyReference = {
            HeadCode: 'EquipmentType',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.EquipmentTypeList = [];
        GetData.then(function (Response) {
            var TempEquipmentLst = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempEquipmentLst.unshift(defaltvalue);
            $scope.EquipmentTypeList = TempEquipmentLst;
            $scope.EquipmentType = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetServicingSchedulelist() {
        
        var GetData = ServiceSecheduleAJService.GetServSchedulelist();

        GetData.then(function (Input) {
            
            $scope.ScheduleNameList = Input.data;
        }, function (reason) {
            $(UserMasterS).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }



    function DefaultRownGrd() {
        
        for (i = 0; i <= 5; i++) {
            var InputParam = {
                SrNo: "",
                Complain: ""
              
            }
            $scope.ComplaintList.push(InputParam);
        }
    }


    $scope.addNewItem = function () {
        
        var InputParam = {
            SrNo: "",
            Complain: ""
        }
        $scope.ComplaintList.push(InputParam);
    }
  


    function ClearData() {
        $scope.isShownAdd = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownClear = false;
        $scope.isShownVehicle = true;
        $scope.isShownCheckType = true;
        $scope.isShown = true;   
        $scope.WisId = undefined;
        $scope.JobNo = undefined;
        $scope.WisDate = undefined;
        $scope.ScheduleId = undefined;
        $scope.VehicleNo = undefined;
        $scope.CurrentOdoReading = undefined;
        $scope.lastReading = undefined;
        $scope.KMRun = undefined;
        $scope.SpecialInstructions = undefined;
        $scope.LastMeterReading = undefined;
        $scope.EquipmentType = undefined;
        $scope.TruckType1 = undefined;
        $scope.ComplaintList = [];
        
    }

   

    $scope.SaveDtls = function () {

        if ($scope.VehicleId == undefined || $scope.VehicleId == "") {
            $scope.errMsg = "Please Enter Vehicle No";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }


        if ($scope.DepotId == undefined || $scope.DepotId == "") {
            $scope.errMsg = "Please select Depot";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }


        if ($scope.ScheduleId == undefined || $scope.ScheduleId == "") {
            $scope.errMsg = "Please select Service Type";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }


        if ($scope.CurrentOdoReading == undefined || $scope.CurrentOdoReading == "" || $scope.CurrentOdoReading == "0") {
            $scope.errMsg = "Please Enter Current Odo Reading";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }
      

        var specialInst = '';

        ComplaintList = $scope.ComplaintList.filter(function (value) {
            
            return value.SpecialInstructions != "";
        });


        if (ComplaintList.length <= 0) {
            $scope.errMsg = "Please enter Atleast One Item.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        

        angular.forEach($scope.ComplaintList, function (value1, key) {
            
            if (value1.SpecialInstructions != "" && value1.SpecialInstructions != undefined) {
                if (specialInst == '') {
                    specialInst = value1.SpecialInstructions; 
                }
                else {
                    specialInst = specialInst + "," + value1.SpecialInstructions;
                }
                
            }
        });



        

        var InputParam = {
            WisId: $scope.WisId,
            DepotId: $scope.DepotId,
            JobNo: $scope.JobNo,
            WisDate: $scope.WisDate,
            ScheduleId: $scope.ScheduleId,
            VehicleNo: $scope.VehicleNo,
            CurrentOdoReading: $scope.CurrentOdoReading,
            lastReading: $scope.lastReading,
            KMRun: $scope.KMRun,
            SpecialInstructions: specialInst,
            LocationId: $sessionStorage.locationId
        }

        var GetData = JobCardCreationAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null) {
                
                $scope.WisId = Response.data.WisId;
                $scope.JobNo = Response.data.JobNo;
                $scope.WisDate = new Date();
                $scope.ScheduleId = Response.data.ScheduleId;
                $scope.DepotId = Response.data.DepotId;
                $scope.DepotName = Response.data.DepotName;
                $scope.VehicleNo = Response.data.VehicleNo;
                $scope.CurrentOdoReading = Response.data.CurrentOdoReading;
                $scope.lastReading = Response.data.lastReading;
                $scope.KMRun = Response.data.KMRun;

                $scope.isShownAdd = true;
                $scope.isShownEdit = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShown = true;
                $scope.isShownJobNo = true;
                

                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });

    }



    $scope.EditDtls = function () {
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownExit = false;
        $scope.isShown = false;
        $scope.isShownSearch = false;
        
        $scope.isShownJobNo = true;        
        
    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }

    
    $scope.SearchDtls = function () {
        $scope.isShownJobNo = false;

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        

        $("#txtJobNo").autocomplete({
            source: function (request, response) {
                var InputParam = {
                    JobNo: $("#txtJobNo").val(),
                    LocationId: $sessionStorage.locationId
                }
                
                $.ajax({
                    url: baseUrl + '/JOBCardCreation/GetAllworkinstructionlookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        
                        response($.map(data, function (item, key) {
                            return {
                                label: item.JobNo,
                                WisId: item.WisId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
               // var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    $scope.JobNo = i.item.label;
                    $scope.WisId = i.item.WisId;
                    $scope.SearchjobCardCreation($scope.WisId);
                    $scope.isShownJobNo = true;
                    $scope.isShownEdit = true;
                });
            },
            minLength: 1
        });


    }

    $scope.AddDtls = function () {
        
        clearData();
     
        $scope.isShownJobNo = true;
        $scope.isShown = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;        
        $scope.isShownExit = false;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSearch = false;
        
        DefaultRownGrd();

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtVehicleNo").autocomplete({

            source: function (request, response) {
                var InputParam = {
                    VehicleNo: $("#txtVehicleNo").val(),
                    LocationId: $sessionStorage.locationId
                }
                
                $.ajax({
                    url: baseUrl + '/Transport/VehicleMaster/GetVehicleLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.VehicleNo,
                                VehicleId: item.VehicleId,
                                LastInspectionDate: item.LastInspectionDate
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                $scope.$apply(function () {
                    
                    $scope.VehicleNo = i.item.label;
                    $scope.VehicleId = i.item.VehicleId;
                    $scope.LastInspectionDate = i.item.LastInspectionDate;
                    $scope.SearchVehicleById();
                    //$scope.isShownVehicle = true;
                });
            },
            minLength: 1
        });
    }

    function clearData() {
        $scope.WisId = undefined;
        $scope.JobNo = undefined;
        $scope.WisDate = undefined;
        $scope.ScheduleId = undefined;
        $scope.VehicleNo = undefined;
        $scope.CurrentOdoReading = undefined;
        $scope.lastReading = undefined;
        $scope.KMRun = undefined;
        $scope.ComplaintList = [];
         
    }


    $scope.CancelDtls = function () {
        ClearData();
        $scope.errMsg = "";
        $scope.isError = false;
        $scope.isShown = true;
        $scope.isShownExit = true
    }


    
    


    $scope.SearchjobCardCreation = function (WisId) {
        
        var InputParam = {
            WisId: WisId,
            LocationId: $sessionStorage.locationId
        }
        var VehicleData = JobCardCreationAJService.GetJobCardCreationDtlById(InputParam);
        VehicleData.then(function (result) {
            
            $scope.JobNo = result.data[0].JobNo;
            $scope.WisDate = result.data[0].WisDate;
            $scope.VehicleNo = result.data[0].VehicleNo;
            $scope.ScheduleName = result.data[0].ScheduleName;
            $scope.ScheduleId = result.data[0].ScheduleId;
            $scope.DepotId = result.data[0].DepotId;
            $scope.CurrentOdoReading = result.data[0].CurrentOdoReading;
            $scope.LastMeterReading = result.data[0].LastMeterReading;
            $scope.KMRun = result.data[0].KMRun;
            $scope.TruckType1 = result.data[0].TruckTypeName;
            $scope.EquipmentType = result.data[0].EquipTypeName;            
            $scope.string = result.data[0].SpecialInstructions;
            $scope.SpecialInstructionsww = $scope.string.split(",");
            
            $scope.isShownSearch = false;

            $scope.isShownAdd = false;


            angular.forEach($scope.SpecialInstructionsww, function (value1, key) {
                
                if (value1 != "" && value1 != undefined) {
                    $scope.ComplaintList[key].SpecialInstructions = value1;
                }
            });

          
        });
    }



    $scope.SearchVehicleById = function() {
        
        var InputParam = {
            VehicleId: $scope.VehicleId,
            LocationId: $scope.LocationId
        }
        var VehicleData = VehicleAJService.GetVehicleDtlsById(InputParam);
        VehicleData.then(function (result) {
            
            $scope.VehicleId = result.data.VehicleId;
            $scope.LocationId = result.data.LocationId;
            $scope.VehicleNo = result.data.VehicleNo;
            $scope.TruckType1 = result.data.TruckTypeName;
            $scope.EquipmentType = result.data.EquipTypeName;
            $scope.LastMeterReading = result.data.LatestMeterReading;
        });
    }
    

    $scope.KMRunninChange = function () {
        
        $scope.KMRun = $scope.CurrentOdoReading - $scope.LastMeterReading      
    }


    
});