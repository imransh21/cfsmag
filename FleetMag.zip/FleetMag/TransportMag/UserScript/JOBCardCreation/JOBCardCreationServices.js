﻿app.service("JobCardCreationAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

  
    this.saveData = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/JOBCardCreation/SaveDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }



    this.GetAllVehicellist = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/JOBCardCreation/GetVehicleLookup",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    //this.GetAllVehicellist = function (InputParam) {
    //    
    //    var response = $http({
    //        method: "post",
    //        url: baseUrl + "/Transport/VehicleMaster/GetVehicleLookup",
    //        data: JSON.stringify(InputParam),
    //        dataType: "json"
    //    });
    //    return response;
    //}



    this.GetJobCardCreationDtlById = function (InputParam) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/JOBCardCreation/GetAllworkinstruction",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }    

    
})