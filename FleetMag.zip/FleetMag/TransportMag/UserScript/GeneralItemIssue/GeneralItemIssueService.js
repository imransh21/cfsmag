﻿app.service("GeneralItemIssueAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GeneralItemIssue/SavaDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetRequestDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GeneralItemIssue/GetRequestData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
    this.GetIssueDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GeneralItemIssue/GetIssueData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetQlistData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + '/Store/GeneralItemIssue/GetRequestNoLookup',
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

});