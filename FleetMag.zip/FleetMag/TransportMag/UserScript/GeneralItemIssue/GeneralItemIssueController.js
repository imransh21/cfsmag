﻿app.controller("GeneralItemIssueCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, $localStorage, ErrorMsgDisplay, IndentGenAJService, GeneralItemIssueAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShownDispaly = true;
    $scope.isShown = true;
    $scope.RequestDetailsList = [];
    DefaultRownGrd();
    DefaultRownGrd();
    DefaultRownGrd();
    DefaultRownGrd();
    DefaultRownGrd();
    DepoLookupList();
    GetQlistData();
   

    $scope.ExitDtls = function () {
        getIndexpage();
    }
    

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }


    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownIndent = true;
        $scope.isAddRowShown = false;
        $scope.isShownDepo = false;
       // $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isAddRowShown = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = false;
       
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtIssue").autocomplete({
            source: function (request, response) {                
                var InputParam = {
                    IssueRefNo: request.term,
                    LocationId: $sessionStorage.locationId,
                }
                $.ajax({
                    url: baseUrl + '/Store/GeneralItemIssue/GetIssueNoLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.IssueRefNo,
                                GenIssueId: item.GenIssueId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
               var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.IssueRefNo = i.item.label;
                    $scope.GenIssueId = i.item.GenIssueId;
                });
            },
            minLength: 1
        });

    }

    $scope.SaveDtls = function () {
        if ($scope.DepotId == undefined) {
            $scope.errMsg = 'Please Select Depo';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var Error = false;
        angular.forEach($scope.RequestDetailsList, function (value,key) {
            if (Error == false) {
            if (value.PartId == undefined || value.PartId == 0 || value.PartId == '' || value.PartId == null) {
                Error = true;
                $scope.errMsg = 'Please select Part Name';
            }
        }
            if (Error == false) {
            if (value.MakekeyId == undefined || value.MakekeyId == 0 || value.MakekeyId == '' || value.MakekeyId == null) {
                Error = true;
                $scope.errMsg = 'Please select Make';
            }
        }

            if (Error == false) {
                if (value.IssueQty == undefined || value.IssueQty == 0 || value.IssueQty == '' || value.IssueQty == null) {
                    Error = true;
                    $scope.errMsg = 'Please Enter Request Qty';
                }

            }
        });
        if (Error == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var InputParam = {
            GenIssueId:$scope.GenIssueId,
            RequestRefNo:$scope.RequestRefNo,
            RequestDate: $scope.RequestDate,
            GenReqId:$scope.GenReqId,
            DepotId: $scope.DepotId,
            LocationId:$sessionStorage.locationId,
            CreatedBy:$sessionStorage.loginUser,
            ModifiedBy:$sessionStorage.loginUser,
            arrGeneralItemIssueDtls: $scope.RequestDetailsList
        }
        var GetData = GeneralItemIssueAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.GenIssueId = Response.data.GenIssueId;
                $scope.IssueRefNo = Response.data.IssueRefNo;
                $scope.IssueDate = Response.data.IssueDate;
                $scope.errMsg = "Data Saved";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isShownAdd = true;
                $scope.isShownEdit = false;
                $scope.isShownSave = false;
                $scope.isShownSearch = true;
                $scope.isShownExit = true;
                $scope.isShownClear = false;
                $scope.isShown = true;
                $scope.isShownDispaly = true;
                $scope.isShownIndent = true;
                
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');                
            }
        });
   
    }
    
    $scope.DisplayData = function () {
   
    }

    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = true;
        $scope.isShownIndent = true;
        $scope.SelectAllData = 'N';
    }

    function ClearData() {           
        $scope.DepotId = undefined;
        $scope.RequestRefNo = undefined;
        $scope.GenReqId = undefined;
        $scope.RequestDate = undefined;
        $scope.IssueRefNo = undefined;
        $scope.GenIssueId = undefined;
        $scope.IssueDate = undefined;
        $scope.RequestDetailsList = [];
        DefaultRownGrd();
    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;               
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isAddRowShown = true;
    }

    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

  
    function DefaultRownGrd() {
        var InputParam = {
            PartName: '',
            PartId: '',
            Make:'',
            InStock: '',
            RequestQty: '',
            UOM_CD:'',
            Remark:''
        }
        $scope.RequestDetailsList.push(InputParam);
    }

    $scope.addNewItem = function () {
        DefaultRownGrd();
    }


    function GridAutoComplete() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".txtPartNo").autocomplete({

            source: function (request, response) {
                
                var InputParam = {
                    //DepotName: request.term
                    ItemName: request.term,
                    DepotId: $scope.DepotId
                }
                $.ajax({
                    url: baseUrl + '/Store/GeneralItemIssue/GetItemMasterLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.ItemName,
                                ItemCode: item.ItemCode,
                                ItemId: item.ItemId,
                                ItemDesc: item.ItemDesc,
                                FinLedgerCode: item.FinLedgerCode,
                                InStock: item.InStock
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    //$scope.IndentDetailsList[Indexval].ItemDesc = i.item.ItemDesc;
                    $scope.RequestDetailsList[Indexval].PartName = i.item.ItemName;
                    $scope.RequestDetailsList[Indexval].PartCd = i.item.ItemCode;
                    $scope.RequestDetailsList[Indexval].PartId = i.item.ItemId;
                    //$scope.IndentDetailsList[Indexval].Sapcode = i.item.FinLedgerCode;
                   // $scope.RequestDetailsList[Indexval].InStock = i.item.InStock;
                    $scope.RequestDetailsList[Indexval].Make = undefined;
                    $scope.RequestDetailsList[Indexval].MakekeyId = undefined;
                });
            },
            minLength: 2
        });



        $(".txtMake").autocomplete({

            source: function (request, response) {
                

                var InputParam = {
                    MakeDesc: request.term,
                    ItemId: $scope.currentItemId,
                    DepotId: $scope.DepotId
                }
                $.ajax({
                    url: baseUrl + '/Store/GeneralItemIssue/GetPartMake',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.MakeDesc,
                                Pkey: item.KeyId,
                                MakeDesc: item.MakeDesc,
                                InStock: item.InStoack
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.RequestDetailsList[Indexval].Make = i.item.MakeDesc;
                    $scope.RequestDetailsList[Indexval].MakekeyId = i.item.Pkey;
                    $scope.RequestDetailsList[Indexval].InStock = i.item.InStock;
                });
            },

            minLength: 1
        });




        $(".txtUserFor").autocomplete({

            source: function (request, response) {
                
                var InputParam = {
                    KeyCode: request.term,
                    ItemId: $scope.currentItemId
                }
                $.ajax({
                    url: baseUrl + '/Store/GeneralItemIssue/GetUserFor',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.KeyCode,
                                KeyId: item.KeyId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.IndentDetailsList[Indexval].UserFor = i.item.KeyCode;
                    $scope.IndentDetailsList[Indexval].UserForId = i.item.KeyId;
                });
            },
            minLength: 1
        });
    }

    $scope.InitAutoComplete = function () {
        GridAutoComplete();
    }

    $scope.updFlag = function (row, index) {
        
        var strlen = 0;
        $scope.currentItemId = row.PartId;
    }

    $scope.ValidateQty = function (row) {
        if (row.BalQty < row.IssueQty) {
            $scope.errMsg = "Issue Qty not more then Bal Qty";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.IssueQty = undefined;
            return;
        }
    }

    $scope.GetIssueDetails = function () {
        var InputParam = {
            GenIssueId: $scope.GenIssueId,
            LocationId: $sessionStorage.locationId,
        }
        var GetData = GeneralItemIssueAJService.GetIssueDtls(InputParam);
        GetData.then(function (Response) {

            $scope.IssueRefNo = Response.data.IssueRefNo;
            $scope.IssueDate = Response.data.IssueDate;
            $scope.GenIssueId = Response.data.GenIssueId;

            $scope.RequestRefNo = Response.data.RequestRefNo;
            $scope.RequestDate = Response.data.RequestDate;
            $scope.GenReqId = Response.data.GenReqId;

            $scope.DepotId = Response.data.DepotId;
            $scope.RequestDetailsList = Response.data.arrGeneralItemIssueDtls;
        });
    }

    function GetQlistData() {
        var InputParam = {
            RequestRefNo: $scope.RequestRefNo,
            LocationId: $sessionStorage.locationId,
        }
        var GetData = GeneralItemIssueAJService.GetQlistData(InputParam);
        GetData.then(function (Response) {
            $scope.RequiredDetailsLst = Response.data;
        });
    }

    $scope.GetDataSearch = function (row) {
        var InputParam = {
            GenReqId: row.GenReqId,
            LocationId: $sessionStorage.locationId,
        }
        var GetData = GeneralItemIssueAJService.GetRequestDtls(InputParam);
        GetData.then(function (Response) {
            ClearData();
            $scope.isShownAdd = true;
            $scope.isShownEdit = false;
            $scope.isShownSave = false;
            $scope.isShownSearch = true;
            $scope.isShownExit = true;
            $scope.isShownClear = false;
            $scope.isShownDispaly = true;
            $scope.isShown = true;
            $scope.GenReqId = Response.data.GenReqId;
            $scope.RequestRefNo = Response.data.RequestRefNo;
            $scope.RequestDate = Response.data.RequestDate;
            $scope.DepotId = Response.data.DepotId;
            $scope.RequestDetailsList = Response.data.arrGeneralItemRequestDtls;
            $('#divQlist').modal('hide');
        });        
    }

    $scope.GetRequestDetails = function () {
        var InputParam = {
            GenReqId: $scope.GenReqId,
            LocationId: $sessionStorage.locationId,
        }
        var GetData = GeneralItemReqAJService.GetRequestDtls(InputParam);
        GetData.then(function (Response) {
            $scope.GenReqId = Response.data.GenReqId;
            $scope.RequestRefNo = Response.data.RequestRefNo;
            $scope.RequestDate = Response.data.RequestDate;
            $scope.DepotId = Response.data.DepotId;
            $scope.RequestDetailsList = Response.data.arrGeneralItemRequestDtls;
        });

    }

});