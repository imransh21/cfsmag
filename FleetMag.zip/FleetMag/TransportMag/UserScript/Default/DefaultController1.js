﻿app.controller("mvcDefaultCtrl1", function ($scope, $sessionStorage, $state, $filter, $compile, DefaultAJService) {

    $sessionStorage.ModuleCode = 'Portal';

    menuList();
    GetAllLocations();   
    $scope.Logout = function () {
        var CallLogout = DefaultAJService.CallLogout();
        CallLogout.then(function (result) {
            if (result.data == 'Done') {
                $sessionStorage.$reset();
                getLoginpage();
            }
        });
    }

    function getLoginpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl;
    }

    $scope.commonSource = function (MenuItemList) {
        $state.go(MenuItemList);
    }

    function GetAllLocations() {
        var getLocationData = DefaultAJService.GetAllLocationData();
        getLocationData.then(function (result) {
            $scope.locationList = result.data;
            setTimeout(function () {
                $scope.LocationId = $sessionStorage.locationId;
                $scope.UserName = $sessionStorage.loginUser;
                $scope.$apply();
            }, 1000);

        });
    }


    $scope.GoMaintenance = function () {
        
        $sessionStorage.ModuleCode = 'Maintenance';
        //menuList();
        //$sessionStorage.ModuleCode = 'Maintenance';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Maintenance";
    }

    $scope.GoTransportation = function () {
        $sessionStorage.ModuleCode = 'Transport';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Transportation";


    }

    $scope.GoTyreManagement = function () {
        $sessionStorage.ModuleCode = 'Transport';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/TyreManagement";
    }

    $scope.GoMonitoring = function () {
        $sessionStorage.ModuleCode = 'Monitoring';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Monitoring";
    }

    $scope.GoReports = function () {
        $sessionStorage.ModuleCode = 'Reports';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Reports";
    }

    $scope.GoAnalysis = function () {
        $sessionStorage.ModuleCode = 'Analysis';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Analysis";

    }

    $scope.GoConfigration = function () {
        $sessionStorage.ModuleCode = 'Configuration';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Configration";
    }

    $scope.GoStore = function () {
        
        $sessionStorage.ModuleCode = 'Store';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    $scope.GoHome = function () {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    $scope.GoWareHose = function () {
        $sessionStorage.ModuleCode = 'Warehouse';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Warehouse";
    }



    function menuList() {
        
        //var menu = $sessionStorage.menu;
        var menu = $.grep($sessionStorage.menu, function (item, index) {
            return item.ModuleCode === $sessionStorage.ModuleCode;
        });

        $scope.UserName = $sessionStorage.loginUser;
        $scope.UserId = $sessionStorage.UserId;
        var appendlst = "";
        var uiEle = angular.element(document.querySelector('#mainnav-menu'));
        uiEle.html('');
        angular.forEach(menu, function (value, key) {
            if (!jQuery.isEmptyObject(value.SubMenu)) {
                appendlst = appendlst + "<li class=\"nav-item\">" +
                                                    "<a href=\"#\">" +
                                                       // "<span class='fa fa-file menu-icon'></span>" +
                                                        "<label id=\"\" >" + value.Title + " </label>" +
                                                        "<span class=\"caret\"></span>" +
                                                    "</a>" +
                                                    "<ul class=\"dropdown\">";

                angular.forEach(value.SubMenu, function (value, key) {
                    appendlst = appendlst + "<li class=\"nav-item\"><a href=\"#\" ng-click=\"commonSource('" + value.Url + "')\">" + value.Title + "</a></li>";
                    $('#' + value.Url).attr('data-title', value.Title);
                });
                appendlst = appendlst + "</ul></li>";
            }
        });
        // uiEle.remove();
        var menulst = $compile(appendlst)($scope);
        uiEle.append(menulst);
        appendlst = "";
        $('.list-item a').click(function () {
            $('.list-item').removeClass('active');
            $(this).closest('li').toggleClass('active');
        });
    }
});

