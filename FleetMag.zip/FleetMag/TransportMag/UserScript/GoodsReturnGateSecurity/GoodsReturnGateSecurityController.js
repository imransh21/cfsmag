﻿app.controller("CntrlGoodsReturnGSecurity", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsReturnGSecurityAJService) {
    
  
    $scope.isShown = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownPrint = false;
    $scope.isShownTransferId = true;
    $scope.PoItemDetailsList = [];

    DepoLookupList();
    DefaultRows();

    function DepoLookupList() {
        var GetData = GoodsReturnGSecurityAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    } 


        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtPONo").autocomplete({
            
            source: function (request, response) {
                
                if ($scope.DepotId == undefined || $scope.DepotId == 0 || $scope.DepotId == null || $scope.DepotId == '') {
                    $scope.errMsg = 'Please Select Depot';
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    $scope.isError = true;
                    return;
                }
                var InputParam = {
                    PoNo: request.term,
                    DepotId: $scope.DepotId,
                    LocationId: $sessionStorage.locationId
                }
                $.ajax({
                    url: baseUrl + '/Store/GoodsReturnGSecurity/GetPoDetailsLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.PoNo,
                                VendorName: item.VendorName,
                                PoId: item.PoId,
                                VendorId: item.VendorId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.PoNo = i.item.PoNo;
                    $scope.VendorName = i.item.VendorName;
                    $scope.PoId = i.item.PoId;
                    $scope.VendorId = i.item.VendorId;
                    GetPoItemDetails();
                });
            },
            minLength: 0
        }).focus(function (e, i) {
            $("#txtPONo").autocomplete("search", "");
        });

    //Ref No

        $scope.GetAllGoodsDetailsFilter = function () {
            

            if ($scope.DepotId == undefined || $scope.DepotId == '') {
                $scope.errMsg = "Please Select Depot.";

                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            var InputParam = {
                DepotId: $scope.DepotId,
                PoId: $scope.PoId,
                fromDate: $scope.fromDate,
                Todate: $scope.Todate,
                PoNo: $scope.PoNo
            }
            var GetData = GoodsReturnGSecurityAJService.GetGoodsPendingList(InputParam);
            GetData.then(function (Response) {
                
                $scope.GoodsPendingDetailsList = Response.data;
                //for (var i = 0; i <= $scope.GoodsPendingDetailsList.length; i++) {
                //    GetPoItemDetails($scope.GoodsPendingDetailsList[i].GrRefid,i);
                //}
                $scope.isShownSave = true;
                $scope.isShownClear = true;
            });
            
           
            //
            //var InputParam = {
            //    DeportId: $scope.DepotId,
            //    VendorId: $scope.VendorId,
            //}
            //var GetData = POGenerationAJService.GetIndentData(InputParam);
            //GetData.then(function (Response) {
            //    
            //    $scope.IndentList = Response.data;
            //});

        }

        var GrRefid, row;
        $scope.GetPoItemDetails = function (GrRefid, row) {
            
            var InputParam = {
                GrRefid: GrRefid,//$scope.GrRefid,
                //DepotId: $scope.DepoId,
                LocationId: $sessionStorage.locationId
            }
            var GetData = GoodsReturnGSecurityAJService.GetGetGoodsdetailsById(InputParam);
            GetData.then(function (Response) {
                
                var dataConvert = $.parseJSON($.parseJSON(Response.data)).Table;
                $scope.CustomerDcNo = dataConvert[0].CustomerDcNo;
                $scope.CustomerDcDate = dataConvert[0].CustomerDcDate;
                var dataConvert2 = $.parseJSON($.parseJSON(Response.data)).Table1;
                $scope.PoItemDetailsList = dataConvert;
            });

        }


    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownSave = false;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;        
    }

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function ClearData() {
        //$scope.PoRejectRemark = undefined
        $scope.PoId = undefined,
        $scope.PoNo = undefined;
        $scope.PoDate = undefined;
        $scope.VendorId = undefined;
        $scope.DepotId = undefined;
        $scope.VendorName = undefined;
        $scope.PaymentTerm = undefined;
        $scope.IndentList = undefined;
        $scope.DepotAddress = undefined;
        $scope.fromDate = undefined;
        $scope.Todate = undefined;
        $scope.PoNo = undefined;
        $scope.RefNo = undefined;
        $scope.RefNo = undefined;
        $scope.GoodsPendingDetailsList = undefined;
        $scope.PoItemDetailsList = undefined;
    }

  

    function DefaultRows() {
        var InputParam = {
            CheckSelect: 'N',
            ItemName: '',
            ItemPartNo: '',
            Make: '',
            User_For: '',
            HsnNo: '',
            GST: '',
            PoQty: '',
            ReceivedQty: '',
            ReturnQty: '',
            ReturnItemRemark:''
        }
        $scope.PoItemDetailsList.push(InputParam);
    }

    $scope.SaveDtls = function () {
        var cnt = 0;
        for (var i = 0; i < $scope.GoodsPendingDetailsList.length; i++) {
            if ($scope.GoodsPendingDetailsList[i].IsConfirm == "Y") {
                cnt = cnt+1
            }
        }
        if (cnt == 0) {
            $scope.errMsg = "Please Select atlease one checkbox.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            GoodReturnGateSecurityList: $scope.GoodsPendingDetailsList,
            LocationId:$sessionStorage.locationId
        }

        var SaveData = GoodsReturnGSecurityAJService.SaveReturnData(InputParam);
        SaveData.then(function (Response) {
            
            if (Response.data.ErrorMessage != "" && Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
            else {
                
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isShown = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShownPrint = false;


            }

        });

    }

});