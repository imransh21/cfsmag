﻿app.service("GoodsReturnGSecurityAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetGoodsPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnGSecurity/GetGoodsPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

        this.GetGetGoodsdetailsById = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnGSecurity/GetGoodsReturnGateSecurityDtls",
            data:JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

    this.SaveReturnData = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnGSecurity/SaveReturnGoodsGateSecurity",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

});