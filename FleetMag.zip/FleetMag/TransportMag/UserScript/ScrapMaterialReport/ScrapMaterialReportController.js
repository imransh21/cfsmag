﻿app.controller("cntrScrapMaterialReport", function ($scope, $localStorage, $compile, $filter, $sessionStorage, VehicleAJService, IndentGenAJService, ServiceSecheduleAJService, VehicleMaintReportAJService, HomeIndex, KeyRefrenceCtrlAJService, ErrorMsgDisplay, ScrapMaterialReportAJService, MaterialRecvfrmMaintaceDeptAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShownPattern = false;
    $scope.isShown = false;


    var appendlst = "";
   // GetAllDetails();
   // ServiceTypeList();

    DepoLookupList();


    $scope.GetDataSearch = function (row) {
        $scope.JobVehicleNo = row.VEHICLE_NO;
        $scope.JobVehicleId = row.VEHICLE_ID;
        $scope.ScheduleId = row.SCHEDULE_ID;
        $("#JobCardDiv").show();
    }



    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }
        

    $scope.GetMaterialDetails = function () {               
        if ($scope.FilterDepotId == undefined) {
            $scope.errMsg = 'Please Select Depo';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            fromDate: $scope.fromDate,
            Todate: $scope.Todate,
            LocationId: $sessionStorage.locationId
        }
        var GetData = ScrapMaterialReportAJService.GetAllDetailsInputParm(InputParm);
        GetData.then(function (Response) {
            debugger;
             $scope.MaterailList = $.parseJSON($.parseJSON(Response.data)).Table;
            ClearData();            
        });
    }
    
   

    function ClearData() {

        $scope.ExpBeginDate = undefined;
        $scope.ExpCompDate = undefined;
        $scope.ScheduleId = undefined;
        $scope.JobVehicleId = undefined;
        $scope.WisId = undefined;
        $scope.JobNo = undefined;
        $scope.JobVehicleNo = undefined;
        $scope.JobVehicleId = undefined;

        $scope.errMsg = undefined;

    }

    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        newObj.setDate(objDateParts[0]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }


    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
   
   
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
  

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

   
    $scope.selected = function (row) {
        row.Flag = 'U';
    }
});

