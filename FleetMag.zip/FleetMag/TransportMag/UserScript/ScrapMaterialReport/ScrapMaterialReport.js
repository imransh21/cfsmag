﻿app.service("ScrapMaterialReportAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    
    this.GetAllDetailsInputParm = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/ScrapMateriallReport/GetAllDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }   
});