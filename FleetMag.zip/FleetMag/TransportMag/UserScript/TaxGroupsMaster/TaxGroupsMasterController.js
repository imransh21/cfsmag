﻿app.controller("mvcTaxGroupsCtrl", function ($scope, $localStorage, $sessionStorage, $filter, $compile, $timeout, TaxGroupsAJService, TaxHeadAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    
    GetTaxGroupsList();
    var appendlst = "";  
    $scope.TaxGroupHeadsReferenceList = [];
    DefaultRownGrd();
    TaxHeadsLookupList();

    $("#btnAdd").focus();

    $scope.addNewItem = function () {
        var InputParam = {
            TaxHeadId: 0,
            TaxableItemName: "",
            SelectedData: 'N'
        }
        $scope.TaxGroupHeadsReferenceList.push(InputParam);
    }


    function DefaultRownGrd() {
        for (i = 0; i <= 5; i++) {
            var InputParam = {
                TaxHeadId: 0,
                TaxableItemName: "",
                SelectedData: 'N'
            }
            $scope.TaxGroupHeadsReferenceList.push(InputParam);
        }
    }

    function TaxHeadsLookupList() {
        var inputValues = {
            LocationId: $sessionStorage.locationId
        }
        var GetData = TaxHeadAJService.GetAllTaxHeads(inputValues);
        GetData.then(function (Response) {
            $scope.TaxHeadLookupList = Response.data;
        });
    }

    //$scope.IsDisabled = function (row, index) {
    //    if (row.SelectRow == 'N' || row.SelectRow == undefined) {
    //        return true;
    //    }

    //    if (row.SelectRow == 'Y') {
    //        return false;
    //    }
    //}
    
    function GetTaxGroupsList() {
        var inputValues = {
            LocationId: $sessionStorage.locationId
        }
        var GetData = TaxGroupsAJService.GetAllTaxGroups(inputValues);
       
        GetData.then(function (pTaxGroupsMaster) {
            
            $scope.TaxGroupsList = pTaxGroupsMaster.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempTaxGroupsList = $scope.TaxGroupsList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Tax Groups. " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllTaxGroups() {
        var uiEle = angular.element(document.querySelector('#LpTaxGroups'));
        $('#LpTaxGroups').html('');
        angular.forEach($scope.TaxGroupsList, function (value, key) {
            if (!jQuery.isEmptyObject(value.TaxGroupId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.TaxGroupId + "')\">" + value.TaxGroupName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var TaxGroups = $compile(appendlst)($scope);
        uiEle.append(TaxGroups);
        appendlst = "";
    }
  
    function showFirst(TaxGroupId)
    {
       
        var TaxGroupsMaster = {
            TaxGroupId: TaxGroupId
        };

        var getData = TaxGroupsAJService.GetTaxGroupsByID(TaxGroupsMaster);
        getData.then(function (pTaxGroupsMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pTaxGroupsMaster.data.ErrorMessage != null) {
                $scope.errMsg = pTaxGroupsMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
            
            $scope.TaxGroupId = pTaxGroupsMaster.data.TaxGroupId;
            $scope.TaxGroupName = pTaxGroupsMaster.data.TaxGroupName;
            $scope.HsnSacCode = pTaxGroupsMaster.data.HsnSacCode;
            $scope.TaxGroupHeadsReferenceList = pTaxGroupsMaster.data.TaxGroupHeadsReferenceList;

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Tax Groups Master Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (TaxGroupId) {
        showFirst(TaxGroupId);
    }

    function clearTaxGroupsList() {
        $scope.TaxGroupsList = [];
        GetAllTaxGroups();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.TaxGroupId = undefined;
        $scope.TaxGroupName = undefined;
        $scope.HsnSacCode = undefined;
        $scope.TaxGroupHeadsReferenceList = [];
        DefaultRownGrd();
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.TaxGroupName == undefined || $scope.TaxGroupName == "") {
            $scope.errMsg = "Tax Group is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtTaxGroupName").focus();
            return;
        }

        if ($scope.HsnSacCode == undefined || $scope.HsnSacCode == "") {
            $scope.errMsg = "HSN SAC Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtHsnSacCode").focus();
            return;
        }

        if ($scope.TaxGroupHeadsReferenceList.length <= 0) {
            $scope.errMsg = "Please Select atleast One Tax Head";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        }
        
        var SelectLst = $scope.TaxGroupHeadsReferenceList.filter(function (value) {
            return value.TaxHeadId != 0 ;
        });

        var TaxGroups = {
                TaxGroupId: $scope.TaxGroupId,
                TaxGroupName: $scope.TaxGroupName,
                HsnSacCode: $scope.HsnSacCode,
                LocationId: $sessionStorage.locationId,
                TaxGroupHeadsReferenceList: SelectLst //$scope.TaxGroupHeadsReferenceList
            };

        var saveData = TaxGroupsAJService.saveTaxGroupsData(TaxGroups);
        saveData.then(function (pTaxGroups) {

            if (pTaxGroups.data.ErrorMessage != null && pTaxGroups.data.ErrorMessage != "") {
                $scope.errMsg = pTaxGroups.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
             
                $scope.TaxGroupId = pTaxGroups.data.TaxGroupId;
                //$scope.TerminalList = [];
                //clearTaxHeadList();
                //GetTaxHeadList();
                GetTaxGroupsList();
                showFirst($scope.TaxGroupId);
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Tax Groups Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
            if ($scope.TaxGroupsList.length != 0) {
                filteredList = $filter('filter')($scope.TaxGroupsList, { TaxGroupName: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.TaxGroupsList = filteredList;
                    }                   
                }
        }
        else {
            $scope.TaxGroupsList = $scope.tempTaxGroupsList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('TaxGroupsList', function () {
        if ($scope.TaxGroupsList != undefined) {
            showFirst($scope.TaxGroupsList[0].TaxGroupId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
  
});

