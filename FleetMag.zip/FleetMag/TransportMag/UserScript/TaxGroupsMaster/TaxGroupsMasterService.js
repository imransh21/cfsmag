﻿app.service("TaxGroupsAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

  
    this.saveTaxGroupsData = function (TaxGroups) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TaxGroupsMaster/SaveDetails",
            data: JSON.stringify(TaxGroups),
            dataType: "json"
        });
        return response;
    }

    this.GetAllTaxGroups = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TaxGroupsMaster/LoadAllTaxGroups",
            data: JSON.stringify(inputValues),
            dataType: "json"
        });
        return response;
    }

    this.GetTaxGroupsByID = function (TaxGroupsMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TaxGroupsMaster/LoadTaxGroupsByID",
            data: JSON.stringify(TaxGroupsMaster),
            dataType: "json"
        });
        return response;
    }

})