﻿app.controller("cntrlPortalPoApproval", function ($scope, $localStorage, $sessionStorage, $compile, $filter, PatternConfigurationAJService, HomeIndex, PortalPOApprovalAJService, IndentGenAJService, POGenerationAJService, DepotAJService, ErrorMsgDisplay) {
    $scope.isShown = true;
    $scope.isShownPoNo = true;
    $scope.isShownVendor = true;
    $scope.isShownDepot = true;
    $scope.isShownEdit = true;
    $scope.isDisplayShown = true;
    $scope.SelectAllData = "N";
    $scope.DlvSchedul = [];
    DepoLookupList();
    GetVendorNameData();
   // POPendingList();


    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function DepoLookupList() {
        
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    var rows = 5;
    addRow();

    function addRow() {
        $scope.IndentList = [];
        if ($scope.IndentList.length < rows) {
            for (k = $scope.IndentList.length; k < rows; k++) {
                var newItem = { PartName: "", PartNo: "" }
                $scope.IndentList.push(newItem);

            }
        }

    }

    $scope.CurrentIndex1 = function (row) {
        $scope.DtlCurrentIndex = row;
    }

    $scope.IsItemCheck = function (row) {
        


        IndentListDataTest = $scope.IndentList.filter(function (value) {
            return value.IsItemchk == "Y"
        });
        if ($scope.IndentList.length != IndentListDataTest.length) {
            $scope.SelectAllData = 'N';
        }
        else {
            $scope.SelectAllData = 'Y';
        }


    }

    $scope.SelectAllRows = function () {
        
        angular.forEach($scope.IndentList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.IsItemchk = 'N';
            }
            else {
                value.IsItemchk = 'Y';
            }
        })
    }





    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownPoNo = true;
        $scope.isShownVendor = true;
        $scope.isShownDepot = true;
        $scope.isShownEdit = true;
        $scope.isDisplayShown = true;
        $scope.PoPendingDetailsList = undefined;
    }



    function clearData() {

        $scope.PoRejectRemark = undefined
        $scope.PoId = undefined,
        $scope.PoNo = undefined;
        $scope.PoDate = undefined;
        //$scope.VendorId = undefined;
        $scope.DepotId = undefined;

       // $scope.VendorName = undefined;
        $scope.PaymentTerm = undefined;
        $scope.IndentList = undefined;
        $scope.DepotAddress = undefined;
        $scope.fromDate = undefined;
        $scope.Todate = undefined;
        $scope.PoNo = undefined;
    }


    $scope.showFirst = function (PoId) {
        var ItemMaster = {
            PoId: PoId
        };

        var getData = POGenerationAJService.getItemByPoId(ItemMaster);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.PoId = Response.data.PoId;
            $scope.PoNo = Response.data.PoNo;
            $scope.PoDate = Response.data.PoDate;
            $scope.VendorId = Response.data.VendorId;
            $scope.DepotId = Response.data.DepotId;

            $scope.VendorName = Response.data.VendorName;
            $scope.PaymentTerm = Response.data.PaymentTerm;
            $scope.IndentList = Response.data.IndentDtlsList;
            $scope.DepotData();
        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.GetAllPODetailsFilter = function () {
        

        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var InputParam = {
            DepotId: $scope.DepotId,
            PoId: $scope.PoId,
            fromDate: $scope.fromDate,
            Todate: $scope.Todate,
            PoNo: $scope.PoNo,
            VendorId:$scope.VendorId
        }
        var GetData = PortalPOApprovalAJService.GetPOPendingList(InputParam);
          GetData.then(function (Response) {
              $scope.PoPendingDetailsList = Response.data;
              $scope.isShownSave = true;
              }
          );

          $scope.getDelvSchedul=function(indx){
              $scope.SelectPo=indx;
          }
          //
          //var InputParam = {
          //    DeportId: $scope.DepotId,
          //    VendorId: $scope.VendorId,
          //}
          //var GetData = POGenerationAJService.GetIndentData(InputParam);
          //GetData.then(function (Response) {
          //    
          //    $scope.IndentList = Response.data;
          //});

    }


    $scope.AcceptDtls = function () {

        var InputParam = {
            PoId: $scope.PoId,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId,
            DepotId: $scope.DepotId,
            PoApproveStatus: 'A',
            PoRejectRemark: $scope.PoRejectRemark

        }
        var GetData = PortalPOApprovalAJService.AcceptData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.showFirst(Response.data.PoId)
                // $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
            }
        });
    }




    $scope.RejectDtls = function () {

        var InputParam = {
            PoId: $scope.PoId,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId,
            DepotId: $scope.DepotId,
            PoApproveStatus: 'R',
            PoRejectRemark: $scope.PoRejectRemark

        }
        var GetData = PortalPOApprovalAJService.AcceptData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');

                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
            }
        });
    }




    $scope.SearchDtls = function () {
        clearData();
        setTimeout(function () {
            $("#txtPoNo").focus();
        }, 500);
        $scope.isShownPoNo = false;
        $("#divQlist").modal('show');
    }
    $scope.EditDtls = function () {


        if ($scope.PoId == '' || $scope.PoId == undefined) {
            $scope.errMsg = "Please Select Po no ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPoNo").val('');
            setTimeout(function () {
                $("#txtPoNo").focus();
            }, 500);
            return;
        }
        $scope.isShown = false;
        $scope.isShownDepot = false;
        $scope.isDisplayShown = true;

    }

    $scope.DepotData = function () {
        var DepotMaster = {
            DepotId: $scope.DepotId
        };
        var getData = DepotAJService.getDepotById(DepotMaster);
        getData.then(function (pDepotMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pDepotMaster.data.ErrorMessage != null) {
                $scope.errMsg = pDepotMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }

            $scope.DepotAddress = pDepotMaster.data.DepotAddress;


        })
    }

    
    $scope.CurrentIndex = function (row) {
        
        $scope.DtlCurrentIndex = row;
    }

    function POPendingList() {
        var InputParam = {
            DepotId: $scope.DepotId,
            PoNo: $scope.PoNo,
            fromDate: $scope.fromDate,
            Todate: $scope.Todate
        }

        
        var GetData = PortalPOApprovalAJService.GetPOPendingList(InputParam);
        GetData.then(function (Response) {
            $scope.PoPendingDetailsList = Response.data;
        });
    }

    $scope.ItemDtlListby = function (PoNo) {
        
        var ItemList = {
            PoNo: $scope.PoNo
        };
        var GetData = PortalPOApprovalAJService.GetItemDtlListbyPoNo(ItemList);
        GetData.then(function (Response) {
            $scope.IndentDtlListByPo = Response.data;
        });
    }


    $scope.SaveDtls = function () {
        

        Listpo = $scope.PoPendingDetailsList.filter(function (value) {
            return value.IsApprovPO == "Y";
        });

        if (Listpo.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Item.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        List1 = $scope.PoPendingDetailsList.filter(function (value) {
            return (value.IsApprove == "Y" || value.IsReject == "Y");
        });


        if (List1.length <= 0) {
            $scope.errMsg = "Please Select Approve/Reject PO";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        List = $scope.PoPendingDetailsList.filter(function (value) {
            return value.IsApprovPO == "Y" && (value.IsApprove == "Y" || value.IsReject == "Y");;
        });



        var InputParam = {
            List: List //$scope.PoPendingDetailsList
        }

        var GetData = PortalPOApprovalAJService.UpdatePoDtls(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                //$scope.showFirst(Response.data.PoId)
               
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.GetAllPODetailsFilter();
             //   POPendingList();

            }
        });
    }



    $scope.ApproveChange = function (row) {
        
        if (row.IsApprove == "Y") {
            row.IsReject = "N";
            $scope.SelectAllRejectData = "N";
        }
        if (row.IsApprove == "N") {
            $scope.SelectAllData = "N";
        }
    }

    $scope.RejectChange = function (row) {
        

        if (row.IsReject == "Y") {
            row.IsApprove = "N";
            $scope.SelectAllData = "N";
        }
        if (row.IsReject == "N") {
            $scope.SelectAllRejectData = "N";
        }
    }



    $scope.CheckAllPO = function () {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllDataPO == 'N') {
                value.IsApprovPO = "N";
            }
            else {
                if ($scope.SelectAllDataPO == 'Y') {
                    value.IsApprovPO = "Y";
                }
            }
        })
    };





    $scope.SelectAllApproveRows = function (SelectAllData) {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllData == "N") {
                value.IsApprove = "N";
            }
            else {
                if ($scope.SelectAllData == "Y") {
                    value.IsApprove = "Y";
                    value.IsReject = "N";
                    $scope.SelectAllRejectData = "N";
                }
            }
        })
    };

        


    $scope.SelectAllRejectRows = function (SelectAllRejectData) {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllRejectData == "N") {
                value.IsApprove = "N";
                value.IsReject = "N";
            }
            else {
                if ($scope.SelectAllRejectData == "Y") {
                    value.IsReject = "Y";
                    value.IsApprove = "N";
                    $scope.SelectAllData = "N";
                }
            }
        })
    };




    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            PoId: $scope.PoId,
            PoNo: $scope.FilterPoNo,
            VendorName: $scope.FilterVendorName
        }
        var GetData = PortalPOApprovalAJService.GetPOApprovalListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.POAprovalQlist = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.GetAllDataByRow = function (Row) {
        
        $scope.DepotId = Row.FilterDepotId,
        $scope.PoId = Row.PoId,
        $scope.PoNo = Row.FilterPoNo
        $scope.GetAllPODetailsFilter();
        $("#divQlist").modal('hide');
    }


    function GetVendorNameData() {
        var InputParam = {
            LocationId: $sessionStorage.locationId,
            VendorId: $sessionStorage.CustomerId
        }

        var GetData = PortalPOApprovalAJService.GetVendorName(InputParam);
        GetData.then(function (Response) {
            $scope.VendorName = Response.data.VendorName;
            $scope.VendorId = Response.data.VendorId;
        });

    }

    $scope.ViewFile = function (row) {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        var link = document.createElement('a');
        // link.href = baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId;
        //window.location = link.href;
        var wo = window.open(baseUrl + "/SupplierPortal/POApproval/FileDownload?docRefNo=" + row.PoId, 'Snopzer', 'left=20,top=20,width=500,height=500,directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,title=AttachedFile');
        wo.document.title = "My File"
    }

    $scope.addNewItem = function () {
        AddNewDlvSchdl();
    }


    function AddNewDlvSchdl() {
        var inputParam = {
            DeliveryDate: '',
            DeliveryQty: '',
            DeliverySchId: 0,
            PoId:0
        }
        $scope.PoPendingDetailsList[$scope.SelectPo].arrPoDeliverySchedule.push(inputParam);
    }

    $scope.SaveDelvSchedule = function () {
        var ErrorMsg = undefined;
        angular.forEach($scope.PoPendingDetailsList[$scope.SelectPo].arrPoDeliverySchedule, function (value, key) {
            if (ErrorMsg == undefined) {
                if (value.DeliveryDate == undefined || value.DeliveryDate == '' || value.DeliveryDate == null) {
                    ErrorMsg = 'Please Select Delivery Date';
                }

                if (value.DeliveryQty == undefined || value.DeliveryQty == '' || value.DeliveryQty == null) {
                    ErrorMsg = 'Please Enter Delivery Qty';
                }
            }
            if (ErrorMsg == undefined) {
                value.PoId = $scope.PoPendingDetailsList[$scope.SelectPo].PoId;
                value.CreatedBy = $sessionStorage.loginUser;
                value.LocationId = $sessionStorage.locationId;
            }            
        });
        if (ErrorMsg != undefined) {
            $scope.errMsg = ErrorMsg;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        var SaveData = PortalPOApprovalAJService.SaveDelvSchedul($scope.PoPendingDetailsList[$scope.SelectPo].arrPoDeliverySchedule);
        SaveData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');             
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.GetAllPODetailsFilter();
            }
        });

    }

    $scope.RemoveDelveryItem = function (row) {
        
       var tempData= $scope.PoPendingDetailsList[$scope.SelectPo].arrPoDeliverySchedule.filter(function(value)
        { 
           return value.$$hashKey != row.$$hashKey;
       });
       $scope.PoPendingDetailsList[$scope.SelectPo].arrPoDeliverySchedule = tempData;
    }

    $scope.ViewInvoiceFile = function (row) {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        var link = document.createElement('a');
        // link.href = baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId;
        //window.location = link.href;
        var wo = window.open(baseUrl + "/SupplierPortal/POApproval/InvoiceDownload?docRefNo=" + row.InvoiceSeqId, 'Snopzer', 'left=20,top=20,width=500,height=500,directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,title=AttachedFile');
        wo.document.title = "My File"
    }

    $scope.AddInvoiceDtls = function () {
        if ($scope.fu == undefined) {
            $scope.errMsg = 'Please select the file to upload';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            PoId:$scope.PoPendingDetailsList[$scope.SelectPo].PoId,
            InvoiceNo:$scope.InvoiceNo,
            InvoiceDate:$scope.InvoiceDate,
            InvoiceAmount: $scope.InvoiceAmount
        }
        var SaveData = PortalPOApprovalAJService.SaveInvoiceDetails(InputParam);
        SaveData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {

                var d = new Date();
                var dd = d.getDate();
                var mm = d.getMonth() + 1;
                var yy = d.getFullYear();
                var hh = d.getHours();
                var min = d.getMinutes();
                var ss = d.getSeconds();
                var oldFileName = $scope.fu.name
                var splt = oldFileName.split(".");
                var FileName = $scope.InvoiceNo + dd + mm + yy + hh + min + ss + '.' + splt[1];
                    var FileUploadData = PortalPOApprovalAJService.uploadFileToUrl($scope.fu, FileName, Response.data.InvoiceSeqId);
                    FileUploadData.then(function (res) {
                        FileNameServiceData = res.data;
                        angular.forEach(objData, function (value, key) {
                            value.QuotFilePath = FileNameServiceData;
                        });
                    });
               
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.InvoiceNo=undefined;
                $scope.InvoiceDate = undefined;
                $scope.InvoiceAmount = undefined;
                $scope.GetAllPODetailsFilter();
            }
        });
    }
})