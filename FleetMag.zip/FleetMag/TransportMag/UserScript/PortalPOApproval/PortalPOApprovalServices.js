﻿app.service("PortalPOApprovalAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.AcceptData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/POApproval/AcceptPoDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.getItemByPoId = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/GetpODetailsBypOId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetPOPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/POApproval/GetPOPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetItemDtlListbyPoNo = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/POApproval/GetItemDtlListbyPoNo",
            data: JSON.stringify(),
            dataType: "json"
        });
        return response;
    }
    


    this.UpdatePoDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/POApproval/UpdatePoDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
    this.GetPOApprovalListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/POApproval/GetPOApprovalListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVendorName = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/QuotationUploading/GetVendorName",
            dataType: "json"
        });
        return response;
    }
    

    this.SaveDelvSchedul = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/POApproval/SaveDelvSchedule",
            dataType: "json"
        });
        return response;
    }

    this.SaveInvoiceDetails = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/POApproval/SaveInvoiceDetails",
            dataType: "json"
        });
        return response;
    }

    
    this.uploadFileToUrl = function (file, newFileName, InvoiceSeqId) {
        var payload = new FormData();
        payload.append("file", file);
        payload.append('newFileName', newFileName);
        payload.append('InvoiceSeqId', InvoiceSeqId);        
        var response = $http({
            method: 'POST',
            data: payload,
            headers: { 'Content-Type': undefined },
            url: baseUrl + "/SupplierPortal/POApproval/fileupload",
            transformRequest: angular.identity
        })
        return response
    };

});