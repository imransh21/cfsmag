﻿app.controller("AMCReportCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, $localStorage, ErrorMsgDisplay, AMCReportAJService, AMCIndentGenAJService,KeyRefrenceCtrlAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    $scope.isAddRowShown = true;
  

  //  $scope.AddDtls();

    $scope.SelectAllData = 'N';
    $scope.FilterReOrderLevel ='N';
    $scope.FilterMinReOrderLevel ='N';
    $scope.FilterDangerLevel = 'N';
    $scope.FilterItemCode = undefined;
    $scope.FilterItemName = undefined;
    $scope.FilterGroupName = undefined;
    $scope.RequiredStockLst = [];
    $scope.isShownDepo = true
  //  $('#divAddRow').modal('toggle');
    GetAMCType();
    var tempRequiredStockLst = [];

    var d = new Date();    
    function padToFour(number) {
        if (number <= 99) { number = ("00" + number).slice(-2); }
        return number;
    }
    $scope.IndentDetailsList = [];
    DefaultRownGrd();
    GetRequiredStockList();
    DepoLookupList();
    GetAMCQist();

    $scope.addNewItem = function () {
        var InputParam = {
            IndentDtlsRefId: 0,
            PartCd: "",
            Make: "",
            ItemDesc: "",
            Sapcode: "",
            Hsnno: "",
            Qty: "",
            Remark: "",
            UserFor: "",
            ClassName: "",
            PartId: "",
            MakekeyId: "",
            UserForId: "",
            SelectedData: 'N'
        }
        $scope.IndentDetailsList.push(InputParam);
    }
   
 //   $("#btnPurchageList").trigger("click");

    function DefaultRownGrd() {
        for (i = 0; i <= 5; i++) {
            var InputParam = {
                IndentDtlsRefId: 0,
                PartId: "",
                PartCd: "",
                Make: "",
                MakekeyId:"",
                ItemDesc: "",
                Sapcode: "",
                Hsnno: "",
                Qty: "",
                Remark: "",
                UserFor: "",
                UserForId:"",
                ClassName: "",
                SelectedData:'N'
            }
            $scope.IndentDetailsList.push(InputParam);
        }
    }



    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }


    $scope.PrintDtls = function () {
        
        getIndexPrintPage();
    }  

    function getIndexPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Store/IndentGenaration/IndentGenarationPrint";
        target = "_blank";
    }
        



    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownIndent = true;
        $scope.isAddRowShown = false;
        $scope.isShownDepo = false;
       // $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isAddRowShown = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownIndent = false;
       // $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        $("#txtIndentNo").autocomplete({

            source: function (request, response) {
                var InputParam = {
                    IndentNo: $("#txtIndentNo").val()
                }
                $.ajax({
                    url: baseUrl + '/Store/IndentGenaration/GetIndentLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.IndentNo,
                                IndentRefId: item.IndentRefId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText'
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.IndentNo = i.item.IndentNo;
                    $scope.IndentRefId = i.item.IndentRefId;
                    $scope.DisplayData();
                });
            },
            minLength: 1
        });
    }

    $scope.SaveDtls = function () {
       // $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
        
        //if ($scope.NatureOfIndent == "" || $scope.NatureOfIndent == undefined || $scope.NatureOfIndent == null) {
        //    $scope.errMsg = "Please Select Nature of Indent"
        //    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //    $("#lstNatureOfIndent").val('');
        //    setTimeout(function () {
        //        $("#lstNatureOfIndent").focus();
        //    }, 500);
        //    return;
        //}

        if ($scope.DepotCode == "" || $scope.DepotCode == undefined || $scope.DepotCode == null) {
            $scope.errMsg = "Please Select Depot"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstDepo").val('');
            setTimeout(function () {
                $("#lstDepo").focus();
            }, 500);
            return;
        }

       

        //if ($scope.ExpDelvDate == "" || $scope.ExpDelvDate == undefined || $scope.ExpDelvDate == null) {
        //    $scope.errMsg = "Please Select  Expected delivery date"
        //    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //    $("#txtExpDelDate").val('');
        //    setTimeout(function () {
        //        $("#txtExpDelDate").focus();
        //    }, 500);
        //    return;
        //}

       

        var ErrorFound = false;
        var ItemCount = 0;
        angular.forEach($scope.IndentDetailsList, function (value, key) {
            if (value.PartName != "" && value.PartName != undefined && value.PartName != null) {
                if (ErrorFound == false) {
                    ItemCount = ItemCount + 1;

                    if (ErrorFound == false) {
                        if (value.PartCd == "" || value.PartCd == undefined || value.PartCd == null) {
                            $scope.errMsg = "Please Select Part Name"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.PartNo == "" || value.PartNo == undefined || value.PartNo == null) {
                            $scope.errMsg = "Please Enter Part Number"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.PartId == "" || value.PartId == undefined || value.PartId == null) {
                            $scope.errMsg = "Please Select Part Name"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.Make == "" || value.Make == undefined || value.Make == null) {
                            $scope.errMsg = "Please Select Part Make"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.Make == "" || value.Make == undefined || value.Make == null) {
                            $scope.errMsg = "Please Enter Item Make"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.MakekeyId == "" || value.MakekeyId == undefined || value.MakekeyId == null) {
                            $scope.errMsg = "Please Enter Item Make"
                            ErrorFound = true;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value.ItemDesc == "" || value.ItemDesc == undefined || value.ItemDesc == null) {
                            $scope.errMsg = "Please Enter Item Description"
                            ErrorFound = true;
                        }
                    }

                    //if (ErrorFound == false) {
                    //    if (value.Qty == "" || value.Qty == undefined || value.Qty == null) {
                    //        $scope.errMsg = "Please Enter Item Quantity"
                    //        ErrorFound = true;
                    //    }
                    //}

                    //if (ErrorFound == false) {
                    //    if (value.Qty == 0) {
                    //        $scope.errMsg = "Please Enter Item Quantity";
                    //        ErrorFound = true;
                    //    }
                    //}


                    //if (ErrorFound == false) {
                    //    if (value.Qty < 0) {
                    //        $scope.errMsg = "Quantity must be positive value";
                    //        ErrorFound = true;
                    //    }
                    //}

                    //if (ErrorFound == false) {
                    //    if (value.UserForId == "" || value.UserForId == undefined || value.UserForId == null) {
                    //        $scope.errMsg = "Please Select Used for"
                    //        ErrorFound = true;
                    //    }
                    //}

                    //if (ErrorFound == false) {
                    //    if (value.UserFor == "" || value.UserFor == undefined || value.UserFor == null) {
                    //        $scope.errMsg = "Please Select Used for"
                    //        ErrorFound = true;
                    //    }
                    //}
                }
            }
        });

        //if ($scope.IndentDetailsList.length != null || $scope.IndentDetailsList.length != undefined) {
        //    for (i = 0; i < $scope.IndentDetailsList.length; i++) {
        //        for (j = i + 1 ; j < $scope.IndentDetailsList.length; j++) {
        //            if ($scope.IndentDetailsList[i].PartId == ($scope.IndentDetailsList[j].PartId)) {
        //                // got the duplicate element
        //                if ($scope.IndentDetailsList[i].PartId != "") {
        //                    $scope.errMsg = "Item Name " + $scope.IndentDetailsList[i].PartName + " is duplicate.";
        //                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //                    $scope.isError = true;
        //                    return;
        //                }
        //            }
        //        }
        //    }
        //}

        if (ItemCount == 0) {
            $scope.errMsg = "No Item Defined to Save"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            LocationId: $localStorage.locationId,
            IndentNo: $scope.IndentNo,
            IndentDate:$scope.IndentDate,
            NatureOfIndent:$scope.NatureOfIndent,
            DeportCd: $scope.DepotCode,
            ExpDelvDate:$scope.ExpDelvDate,
            IndentRefId: $scope.IndentRefId,            
            IndentDtlsList: $scope.IndentDetailsList,
            CreatedBy:$sessionStorage.loginUser,
            ModifiedBy:$sessionStorage.loginUser
        }
        var GetData = AMCIndentGenAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.IndentNo = Response.data.IndentNo;
                $scope.IndentDate = Response.data.IndentDate;
                $scope.NatureOfIndent = Response.data.NatureOfIndent;
                $scope.DepotCode = Response.data.DeportCd;
                $scope.ExpDelvDate = Response.data.ExpDelvDate;
                $scope.IndentDetailsList = Response.data.IndentDtlsList;
                $scope.isShownAdd = true;
                $scope.isShownEdit = false;
                $scope.isShownSave = false;
                $scope.isShownSearch = true;
                $scope.isShownExit = true;
                $scope.isShownClear = false;
                $scope.isShown = true;
                $scope.isShownDispaly = false;
                $scope.isShownIndent = true;
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });
    }
    
    $scope.DisplayData = function () {
        SerachIndentDetails();
    }

    function SerachIndentDetails() {
        var InputParam = {
            IndentRefId: $scope.IndentRefId,
            IndentDate: $scope.IndentDate,
            ExpairyDate: $scope.IndentDateTo

        }
        var GetData = AMCReportAJService.GetIndentData(InputParam);
        GetData.then(function (Response) {
            $scope.IndentNo = Response.data.IndentNo;
            $scope.IndentDate = Response.data.IndentDate;
            $scope.NatureOfIndent = Response.data.NatureOfIndent;
            $scope.DepotCode = Response.data.DeportCd;
            $scope.ExpDelvDate = Response.data.ExpDelvDate;
            $scope.IndentDetailsList = Response.data.IndentDtlsList;
            console.log($scope.IndentDetailsList);
            $scope.isShownIndent = true;
            $scope.isShownPrint = true;

            $sessionStorage.IndentRefId = JSON.stringify($scope.IndentRefId);
        });
    }



    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = true;
        $scope.SelectAllData = 'N';
        GetRequiredStockList();
        //$scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
    }

    function ClearData() {
        $scope.IndentRefId = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentDate = undefined;
        $scope.NatureOfIndent = undefined;
        $scope.DepotCode = undefined;
        $scope.ExpDelvDate = undefined;
        $scope.IndentDetailsList = [];
        DefaultRownGrd();
    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;               
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isAddRowShown = true;
    }

    $scope.GetRequiredStockListOnDepo = function () {
        
        GetRequiredStockList();
    }
    function GetRequiredStockList() {
        
        var Input = {
            DepotID: $scope.DepotId
        };
        console.log($scope.DepotCode);
        var GetData = AMCIndentGenAJService.GetReqStockList(Input);
        GetData.then(function (Response) {
            $scope.RequiredStockLst = Response.data;
            tempRequiredStockLst =angular.copy($scope.RequiredStockLst);
        });
    }

    $scope.SelectAllRows = function () {        
        angular.forEach($scope.AMCQlst, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.SelectedData = 'Y';
            }
            else {
                if ($scope.SelectAllData == 'Y') {
                    value.SelectedData = 'N';
                }
            }
        })
    };


    $scope.AddSeletedItems = function () {
        
        if ($scope.isShownAdd == true)
            {
            $scope.AddDtls();
            };

        var SelectLst = $scope.AMCQlst.filter(function (value) {
            return value.SelectedData=='Y';
        });

        angular.forEach(SelectLst, function (value, key) {
            if (value.SelectedData == 'Y') {
                var InputParam = {
                    IndentDtlsRefId: 0,
                    PartCd: value.Part_code,
                    PartName: value.Part_Name,
                    PartNo: value.Item_Part_no,
                    Make: value.Make,
                    ItemDesc: value.Part_Desc,
                    Sapcode: "",
                    Hsnno: "",
                    Qty: "",
                    InStock:value.InStock,
                    Remark: "",
                    UserFor: value.Used_for,
                    PartId: value.ITEM_ID,
                    MakekeyId: value.Make_id,
                    UserForId: value.User_For_Id,
                    SerialNo: value.ITEM_SERIAL_NBR,
                    AmcType: value.AmcType,
                    AmcWarrantyType: value.AMC_Status,
                    ExpairyDate: value.WARRANTY_UPTO,
                    InwrdStoreSerlId: value.lngInwrdStoreSerlId
                }
                $scope.IndentDetailsList.unshift(InputParam);
            }
            
        });
        setTimeout(function () { GridAutoComplete(); }, 1000);
        $scope.AMCQlst = $scope.AMCQlst.filter(function (value) {
            return value.SelectedData != 'Y';
        });        
       // $('#divAddRow').modal('toggle');
        $scope.isShownDepo = true;
        $scope.DepotCode = $scope.DepotId
    }

    function DepoLookupList() {
        var GetData = AMCIndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function GridAutoComplete() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".txtPartNo").autocomplete({

            source: function (request, response) {
                
                var InputParam = {
                    //DepotName: request.term
                    ItemName: request.term
                }
                $.ajax({
                    url: baseUrl + '/Store/AMCIndentGenaration/GetItemMasterLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.ItemName,
                                ItemCode: item.ItemCode,
                                ItemId: item.ItemId,
                                ItemDesc: item.ItemDesc,
                                FinLedgerCode: item.FinLedgerCode,
                                SerialNo: item.SerialNo,
                                ExpairyDate: item.ExpairyDate
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    $scope.IndentDetailsList[Indexval].ItemDesc = i.item.ItemDesc;
                    $scope.IndentDetailsList[Indexval].PartName = i.item.ItemName;
                    $scope.IndentDetailsList[Indexval].PartCd = i.item.ItemCode;
                    $scope.IndentDetailsList[Indexval].PartId = i.item.ItemId;
                    $scope.IndentDetailsList[Indexval].Sapcode = i.item.FinLedgerCode;
                    $scope.IndentDetailsList[Indexval].SerialNo = i.item.SerialNo;
                    $scope.IndentDetailsList[Indexval].ExpairyDate = i.item.ExpairyDate;
                    $scope.IndentDetailsList[Indexval].Make = undefined;
                    $scope.IndentDetailsList[Indexval].MakekeyId = undefined;
                });
            },
            minLength: 3
        });



        $(".txtMake").autocomplete({

            source: function (request, response) {
                
             
                var InputParam = {
                    MakeDesc: request.term,
                    ItemId: $scope.currentItemId
                }
                $.ajax({
                    url: baseUrl + '/Store/AMCIndentGenaration/GetPartMake',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.MakeDesc,
                                Pkey: item.KeyId,
                                MakeDesc: item.MakeDesc,
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.IndentDetailsList[Indexval].Make = i.item.MakeDesc;
                    $scope.IndentDetailsList[Indexval].MakekeyId = i.item.Pkey;
                });
            },
            minLength: 1
        });




        $(".txtUserFor").autocomplete({
            
            source: function (request, response) {
                
                var InputParam = {
                    KeyCode: request.term,
                    ItemId: $scope.currentItemId
                }
                $.ajax({
                    url: baseUrl + '/Store/AMCIndentGenaration/GetUserFor',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.KeyCode,
                                KeyId: item.KeyId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.IndentDetailsList[Indexval].UserFor = i.item.KeyCode;
                    $scope.IndentDetailsList[Indexval].UserForId = i.item.KeyId;
                });
            },
            minLength: 1
        });
    }

    $scope.InitAutoComplete = function () {
        GridAutoComplete();

        $('.dateinput').datetimepicker({
            dayOfWeekStart: 1,
            lang: 'en',
            format: 'd/m/Y H:i'
        });

    }

    
    function CompareDates() {
        var CurrentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
        var d1 = CurrentDate.split(" ");
        var Rqdate = d1[0].split("/");
        var Rqtime = d1[1].split(":");
        var CurrentDate = new Date(Rqdate[2], parseInt(Rqdate[1]) - 1, Rqdate[0], Rqtime[0], Rqtime[1]);

        var d1 = $scope.ExpDelvDate.split(" ");
        var ETAdate = d1[0].split("/");
        var ETAtime = d1[1].split(":");
        var ExpDlvDate = new Date(ETAdate[2], parseInt(ETAdate[1]) - 1, ETAdate[0], ETAtime[0], ETAtime[1]);
        
        if (CurrentDate > ExpDlvDate) {         
            $scope.errMsg = "Delivery date not smaller than current date.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.ExpDelvDate = undefined;
            $scope.isError = true;
        }
        
    }
    
    $scope.ChangeDate = function () {
        CompareDates();
    }



    $scope.FilterData = function () {
        GetAMCQist();       
    }

    
    $scope.updFlag = function (row, index) {        
        var strlen = 0;
        $scope.currentItemId = row.PartId;
    }

    function GetAMCType() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'AMC'
        };
        var getData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        getData.then(function (pKeyReference) {
            $scope.AMCTypeLst = pKeyReference.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Tariff Heads information " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    function GetAMCQist() {
        var InputParam = {
            PartName: $scope.FilterItemName,
            PartCd: $scope.FilterItemCode,
            SerialNo: $scope.FilterSerialNo,
            DeportId: $scope.DepotId
        };
        var getData = AMCIndentGenAJService.GetAMCDetailsQlist(InputParam);
        getData.then(function (Res) {
            $scope.AMCQlst =$.parseJSON($.parseJSON(Res.data)).Table;
        }, function (reason) {
            $scope.errMsg = "Error in AMC Qlist" + reason.data;
            $scope.isError = true;
            return;
        });
    }

    $scope.ValidateRenewDate = function (row) {
        var ExpairyDate = row.ExpairyDate;
        var RenewDate = row.RenewDate;
        var ExpairyDatetime = ExpairyDate.split(" ");
        var RenewDateTime = RenewDate.split(" ");
        var ExpairyDT = ExpairyDatetime[0].split("/");
        var RenewDt = RenewDateTime[0].split("/");
        var ExpairyTime = ExpairyDatetime[1].split(":");
        var RenewTime = RenewDateTime[1].split(":");
        var from = new Date(ExpairyDT[2], parseInt(ExpairyDT[1]) - 1, ExpairyDT[0], ExpairyTime[0], ExpairyTime[1]);
        var To = new Date(RenewDt[2], parseInt(RenewDt[1]) - 1, RenewDt[0], RenewTime[0], RenewTime[1]);
        if (To < from) {
            $scope.errMsg = "Renew date not smaller than Expairy date.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.isError = true;
            row.RenewDate = undefined;
            return;
        }
    }

});