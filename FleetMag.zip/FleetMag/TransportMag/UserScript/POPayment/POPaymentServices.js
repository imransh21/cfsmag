﻿app.service("POPaymentAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.AcceptData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/AcceptPoDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.getItemByPoId = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/GetpODetailsBypOId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetPOPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/GetPOPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetItemDtlListbyPoNo = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/GetItemDtlListbyPoNo",
            data: JSON.stringify(),
            dataType: "json"
        });
        return response;
    }
    


    this.UpdatePoDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/UpdatePoDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
    this.GetPOApprovalListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/GetPOApprovalListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.SavePaymentDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/SavePaymentDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
    this.uploadFileToUrl = function (file, newFileName, InvoiceSeqId) {
        var payload = new FormData();
        payload.append("file", file);
        payload.append('newFileName', newFileName);
        payload.append('InvoiceSeqId', InvoiceSeqId);
        var response = $http({
            method: 'POST',
            data: payload,
            headers: { 'Content-Type': undefined },
            url: baseUrl + "/SupplierPortal/POApproval/fileupload",
            transformRequest: angular.identity
        })
        return response
    };

    
    this.SavePaymentDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/SavePaymentDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.PaymentDetailsByInvoiceSeqNo = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POPayment/GetPaymentDetailsByInvoiceId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


});