﻿app.controller("cntrlPOPayment", function ($scope, $localStorage, $sessionStorage, $compile, $filter, KeyRefrenceCtrlAJService, PatternConfigurationAJService, HomeIndex, POPaymentAJService, IndentGenAJService, POGenerationAJService, DepotAJService, ErrorMsgDisplay) {
    $scope.isShown = true;
    $scope.isShownPoNo = true;
    $scope.isShownVendor = true;
    $scope.isShownDepot = true;
    $scope.isShownEdit = true;
    $scope.isDisplayShown = true;
    $scope.SelectAllData = "N";
    DepoLookupList();
    PaymentModeList();
   // POPendingList();
    $scope.arrPoPaymentDtls = [];

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function DepoLookupList() {
        
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    var rows = 5;
    addRow();

    function addRow() {
        $scope.IndentList = [];
        if ($scope.IndentList.length < rows) {
            for (k = $scope.IndentList.length; k < rows; k++) {
                var newItem = { PartName: "", PartNo: "" }
                $scope.IndentList.push(newItem);

            }
        }

    }

    $scope.CurrentIndex1 = function (row) {
        $scope.DtlCurrentIndex = row;
    }

    $scope.IsItemCheck = function (row) {
        


        IndentListDataTest = $scope.IndentList.filter(function (value) {
            return value.IsItemchk == "Y"
        });
        if ($scope.IndentList.length != IndentListDataTest.length) {
            $scope.SelectAllData = 'N';
        }
        else {
            $scope.SelectAllData = 'Y';
        }


    }

    $scope.SelectAllRows = function () {
        
        angular.forEach($scope.IndentList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.IsItemchk = 'N';
            }
            else {
                value.IsItemchk = 'Y';
            }
        })
    }





    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownPoNo = true;
        $scope.isShownVendor = true;
        $scope.isShownDepot = true;
        $scope.isShownEdit = true;
        $scope.isDisplayShown = true;
        $scope.PoPendingDetailsList = undefined;
    }



    function clearData() {

        $scope.PoRejectRemark = undefined
        $scope.PoId = undefined,
        $scope.PoNo = undefined;
        $scope.PoDate = undefined;
        $scope.VendorId = undefined;
        $scope.DepotId = undefined;

        $scope.VendorName = undefined;
        $scope.PaymentTerm = undefined;
        $scope.IndentList = undefined;
        $scope.DepotAddress = undefined;
        $scope.fromDate = undefined;
        $scope.Todate = undefined;
        $scope.PoNo = undefined;
    }


    $scope.showFirst = function (PoId) {
        var ItemMaster = {
            PoId: PoId
        };

        var getData = POGenerationAJService.getItemByPoId(ItemMaster);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.PoId = Response.data.PoId;
            $scope.PoNo = Response.data.PoNo;
            $scope.PoDate = Response.data.PoDate;
            $scope.VendorId = Response.data.VendorId;
            $scope.DepotId = Response.data.DepotId;

            $scope.VendorName = Response.data.VendorName;
            $scope.PaymentTerm = Response.data.PaymentTerm;
            $scope.IndentList = Response.data.IndentDtlsList;
            $scope.DepotData();
        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.GetAllPODetailsFilter = function () {
        debugger;

        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var InputParam = {
            DepotId: $scope.DepotId,
            PoId: $scope.PoId,
            fromDate: $scope.fromDate,
            Todate: $scope.Todate,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId

        }
        var GetData = POPaymentAJService.GetPOPendingList(InputParam);
          GetData.then(function (Response) {
              $scope.PoPendingDetailsList = Response.data;
              $scope.isShownSave= true;
          });

          //
          //var InputParam = {
          //    DeportId: $scope.DepotId,
          //    VendorId: $scope.VendorId,
          //}
          //var GetData = POGenerationAJService.GetIndentData(InputParam);
          //GetData.then(function (Response) {
          //    
          //    $scope.IndentList = Response.data;
          //});

    }


    $scope.AcceptDtls = function () {

        var InputParam = {
            PoId: $scope.PoId,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId,
            DepotId: $scope.DepotId,
            PoApproveStatus: 'A',
            PoRejectRemark: $scope.PoRejectRemark

        }
        var GetData = POPaymentAJService.AcceptData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');


                $scope.showFirst(Response.data.PoId)
                // $scope.isDisplayShown = true;
             

                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
            }
        });
    }




    $scope.RejectDtls = function () {

        var InputParam = {
            PoId: $scope.PoId,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId,
            DepotId: $scope.DepotId,
            PoApproveStatus: 'R',
            PoRejectRemark: $scope.PoRejectRemark

        }
        var GetData = POPaymentAJService.AcceptData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');

                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
            }
        });
    }




    $scope.SearchDtls = function () {
        clearData();
        setTimeout(function () {
            $("#txtPoNo").focus();
        }, 500);
        $scope.isShownPoNo = false;
        $("#divQlist").modal('show');
    }
    $scope.EditDtls = function () {


        if ($scope.PoId == '' || $scope.PoId == undefined) {
            $scope.errMsg = "Please Select Po no ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPoNo").val('');
            setTimeout(function () {
                $("#txtPoNo").focus();
            }, 500);
            return;
        }
        $scope.isShown = false;
        $scope.isShownDepot = false;
        $scope.isDisplayShown = true;

    }

    $scope.DepotData = function () {
        var DepotMaster = {
            DepotId: $scope.DepotId
        };
        var getData = DepotAJService.getDepotById(DepotMaster);
        getData.then(function (pDepotMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pDepotMaster.data.ErrorMessage != null) {
                $scope.errMsg = pDepotMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }

            $scope.DepotAddress = pDepotMaster.data.DepotAddress;


        })
    }

    
    $scope.CurrentIndex = function (row) {
        
        $scope.DtlCurrentIndex = row;
    }

    function POPendingList() {
        var InputParam = {
            DepotId: $scope.DepotId,
            PoNo: $scope.PoNo,
            fromDate: $scope.fromDate,
            Todate: $scope.Todate
        }

        
        var GetData = POPaymentAJService.GetPOPendingList(InputParam);
        GetData.then(function (Response) {
            $scope.PoPendingDetailsList = Response.data;
        });
    }

    $scope.ItemDtlListby = function (PoNo) {
        
        var ItemList = {
            PoNo: $scope.PoNo
        };
        var GetData = POPaymentAJService.GetItemDtlListbyPoNo(ItemList);
        GetData.then(function (Response) {
            $scope.IndentDtlListByPo = Response.data;
        });
    }


    $scope.SaveDtls = function () {
        

        Listpo = $scope.PoPendingDetailsList.filter(function (value) {
            return value.IsApprovPO == "Y";
        });

        if (Listpo.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Item.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        List1 = $scope.PoPendingDetailsList.filter(function (value) {
            return (value.IsApprove == "Y" || value.IsReject == "Y");
        });


        if (List1.length <= 0) {
            $scope.errMsg = "Please Select Approve/Reject PO";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        List = $scope.PoPendingDetailsList.filter(function (value) {
            return value.IsApprovPO == "Y" && (value.IsApprove == "Y" || value.IsReject == "Y");;
        });



        var InputParam = {
            List: List //$scope.PoPendingDetailsList
        }

        var GetData = POPaymentAJService.UpdatePoDtls(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                //$scope.showFirst(Response.data.PoId)
                
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.GetAllPODetailsFilter();
                //var getUrl = window.location;
                //var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                //window.open(baseUrl + "/Areas/Store/POApproval/POApprovalPrint", '_blank');
             //   POPendingList();

            }
        });
    }



    $scope.ApproveChange = function (row) {
        
        if (row.IsApprove == "Y") {
            row.IsReject = "N";
            $scope.SelectAllRejectData = "N";
        }
        if (row.IsApprove == "N") {
            $scope.SelectAllData = "N";
        }
    }

    $scope.RejectChange = function (row) {
        

        if (row.IsReject == "Y") {
            row.IsApprove = "N";
            $scope.SelectAllData = "N";
        }
        if (row.IsReject == "N") {
            $scope.SelectAllRejectData = "N";
        }
    }



    $scope.CheckAllPO = function () {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllDataPO == 'N') {
                value.IsApprovPO = "N";
            }
            else {
                if ($scope.SelectAllDataPO == 'Y') {
                    value.IsApprovPO = "Y";
                }
            }
        })
    };





    $scope.SelectAllApproveRows = function (SelectAllData) {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllData == "N") {
                value.IsApprove = "N";
            }
            else {
                if ($scope.SelectAllData == "Y") {
                    value.IsApprove = "Y";
                    value.IsReject = "N";
                    $scope.SelectAllRejectData = "N";
                }
            }
        })
    };

        


    $scope.SelectAllRejectRows = function (SelectAllRejectData) {
        
        angular.forEach($scope.PoPendingDetailsList, function (value, key) {
            if ($scope.SelectAllRejectData == "N") {
                value.IsApprove = "N";
                value.IsReject = "N";
            }
            else {
                if ($scope.SelectAllRejectData == "Y") {
                    value.IsReject = "Y";
                    value.IsApprove = "N";
                    $scope.SelectAllData = "N";
                }
            }
        })
    };




    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            PoId: $scope.PoId,
            PoNo: $scope.FilterPoNo,
            VendorName: $scope.FilterVendorName
        }
        var GetData = POPaymentAJService.GetPOApprovalListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.POAprovalQlist = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.GetAllDataByRow = function (Row) {
        
        $scope.DepotId = Row.FilterDepotId,
        $scope.PoId = Row.PoId,
        $scope.PoNo = Row.FilterPoNo
        $scope.GetAllPODetailsFilter();
        $("#divQlist").modal('hide');
    }

    $scope.getDelvSchedul = function (indx) {
        $scope.SelectPo = indx;
    }

    $scope.addNewItem = function () {
        AddNewDlvSchdl();
    }


    function AddNewDlvSchdl() {
        var inputParam = {
            InvoiceSeqId:0,
            InvoiceNo: '',
            InvoiceDate: '',
            InvoiceAmount: '',
            PaymentRefNo: '',
            PaymentRefDate: '',
            PaymentModeId: 0,
            BankName: '',
            BankRefNo: '',
            UpdateFlg:'',
        }
        $scope.PoPendingDetailsList[$scope.SelectPo].arrPaymentDetails.push(inputParam);
    }

    $scope.updateChangeFlg = function (row) {
        row.UpdateFlg='U'
    }

    $scope.onFileChange = function (row,elementName) {
        row.UpdateFlg = 'U';
        $('#InvoiceUpload' + elementName).trigger('click');
    };

    $scope.SaveInvoiceDtls = function () {
        var changedRows = $scope.PoPendingDetailsList[$scope.SelectPo].arrPaymentDetails.filter(function (value) {
            return value.UpdateFlg == "U"
        });
        angular.forEach(changedRows, function (value, key) {
            value.PoId = $scope.PoPendingDetailsList[$scope.SelectPo].PoId;
            value.LocationId = $sessionStorage.locationId;
        });

        var SaveData = POPaymentAJService.SavePaymentDtls(changedRows);
        SaveData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
               
                angular.forEach(changedRows, function (value, key) {
                    if (value.InvoiceSeqId != 0) {
                        var d = new Date();
                        var dd = d.getDate();
                        var mm = d.getMonth() + 1;
                        var yy = d.getFullYear();
                        var hh = d.getHours();
                        var min = d.getMinutes();
                        var ss = d.getSeconds();
                        var oldFileName = value.fu.name
                        var splt = oldFileName.split(".");
                        var FileName = value.InvoiceNo + dd + mm + yy + hh + min + ss + '.' + splt[1];
                        var FileUploadData = POPaymentAJService.uploadFileToUrl(value.fu, FileName, value.InvoiceSeqId);
                        FileUploadData.then(function (res) {
                            FileNameServiceData = res.data;
                            angular.forEach(objData, function (value, key) {
                                value.QuotFilePath = FileNameServiceData;
                            });
                        });
                    }
                });

                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.GetAllPODetailsFilter();
            }
        });

    };


    function PaymentModeList() {
        var KeyReference = {
            HeadCode: 'PaymentMode',
            GroupCode: 'Payment'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.PaymentModeList = [];
        GetData.then(function (Response) {
            var TempPaymentModeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempPaymentModeList.unshift(defaltvalue);
            $scope.PaymentModeList = TempPaymentModeList;
            $scope.PaymentModeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    $scope.GetPaymentDtls = function (row, PoId) {
        $scope.arrPoPaymentDtls = [];
        $scope.PaymentInvoice = row.InvoiceNo;
        $scope.PaymentInvoiceDate = row.InvoiceDate;
        $scope.PaymentInvoiceAmount = row.InvoiceAmount;
        $scope.PaymentInvoiceSeqId = row.InvoiceSeqId
        $scope.PaymentPoId = PoId;
        var InputParam = {
            PoId: $scope.PaymentPoId,
            InvoiceSeqId: $scope.PaymentInvoiceSeqId,
            LocationId: $sessionStorage.locationId
        }

        var GetData = POPaymentAJService.PaymentDetailsByInvoiceSeqNo(InputParam);
        GetData.then(function (Response) {
            $scope.PaymentRefNo = Response.data.PaymentRefNo;
            $scope.PaymentRefDate = Response.data.PaymentDate;
            $scope.PoPaymentId = Response.data.PoPaymentId;
            if (Response.data.arrPoPaymentDtls == null || Response.data.arrPoPaymentDtls==undefined) {
                DefaultRowstoPayment();
            }
            else {
                $scope.arrPoPaymentDtls = Response.data.arrPoPaymentDtls;
            }
        });

        
    }

    $scope.SavePaymentDtls = function () {
        var InputParam = {
            PoPaymentId:$scope.PoPaymentId,
            PaymentRefNo:$scope.PaymentRefNo,
            PaymentDate: $scope.PaymentRefDate,
            InvoiceSeqId:$scope.PaymentInvoiceSeqId,
            PoId: $scope.PaymentPoId,
            arrPoPaymentDtls: $scope.arrPoPaymentDtls,
            LocationId: $sessionStorage.locationId,
            CreatedBy:$sessionStorage.loginUser,
            ModifiedBy: $sessionStorage.loginUser,
            InvoiceNo: $scope.PaymentInvoice
        }
        var SaveData = POPaymentAJService.SavePaymentDetails(InputParam);
        SaveData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.PaymentRefNo = Response.data.PaymentRefNo;
                $scope.PaymentRefDate = Response.data.PaymentDate;
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
                $scope.GetAllPODetailsFilter();             
            }
        });

    }


    function DefaultRowstoPayment() {
        var InputParam = {
            PaymentModeId: 0,
            BankRefNo: '',
            BankName: '',
            PaymentAmount:''
        }
        $scope.arrPoPaymentDtls.push(InputParam);
    }
})