﻿app.service("PortalQuotationUploadingAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
       
    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetItemLookupList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/QuotationUploading/ItemNameLookup",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetQuotUpdationList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/QuotationUploading/GetIndentReqDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetPamentTermLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/SupplierPortal/QuotationUploading/GetPaymentTerms",
            dataType: "json"
        });
        return response;
    }

    this.uploadFileToUrl = function (file, newFileName) {
        var payload = new FormData();
        payload.append("file", file);
        payload.append('newFileName', newFileName); 
        var response = $http({
            method: 'POST',
            data: payload,
            headers: { 'Content-Type': undefined },
            url: baseUrl + "/SupplierPortal/QuotationUploading/fileupload",
            transformRequest: angular.identity            
        })
        return response
    };


    this.SaveQuotationData = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/QuotationUploading/SaveQuotationUpLoading",
            dataType: "json"
        });
        return response;
    }

    this.GetViewFile = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/QuotationUploading/FileDownload",
            dataType: "json"
        });
        return response;
    }

    this.GetVendorName = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/SupplierPortal/QuotationUploading/GetVendorName",
            dataType: "json"
        });
        return response;
    }

});