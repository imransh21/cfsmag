﻿app.controller("PortalQuotationUploadCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, PortalQuotationUploadingAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;

    DepoLookupList();
   // GetQuotProcessData();
    PaymentTermLookupList();
    GetVendorNameData();
    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownIndent = true;

    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownIndent = false;
    }

    $scope.SaveDtls = function () {
        var objData = $scope.QuotproessDataList.filter(function (item) {
            return (item.SelectRow == 'Y');
        });

        if (objData.length == 0) {            
            $scope.errMsg = 'There is no indent selected to save';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var ErrorFound = false;
        angular.forEach(objData, function (value, key) {          
                if ((value.GST == undefined || value.GST == '' || value.GST == null) &&(ErrorFound == false)) {                    
                    $scope.errMsg = 'Please enter Gst%';
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                }
                if ((value.QuotAmount == undefined || value.QuotAmount == '' || value.QuotAmount == null || value.QuotAmount == '0') && (ErrorFound == false)) {
                    $scope.errMsg = 'Please enter Quotation Amount';
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                }
                if ((value.DeliveryDays == undefined || value.DeliveryDays == '' || value.DeliveryDays == null || value.DeliveryDays == '0') && (ErrorFound == false)) {
                    $scope.errMsg = 'Please enter Delivery Days';
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                }
                if ((value.PaymentTermId == undefined || value.PaymentTermId == '' || value.PaymentTermId == 0 || value.PaymentTermId == null) && (ErrorFound == false)) {                    
                    $scope.errMsg = 'Please Select Payment Terms';
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                }                
        });
        if (ErrorFound == true) {
            return;
        }

        if ($scope.fu == undefined) {
            $scope.errMsg = 'Please select the file to upload';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');         
            return;
        }
        var d = new Date();
        var dd = d.getDate();
        var mm = d.getMonth()+1;
        var yy = d.getFullYear();
        var hh = d.getHours();
        var min = d.getMinutes();
        var ss = d.getSeconds();
        var oldFileName = $scope.fu.name
        var splt = oldFileName.split(".");
        var FileName = 'IndentQuot' + dd + mm + yy + hh + min + ss + '.' + splt[1];
        uploadFile($scope.fu, FileName, objData);
      
    }


    function uploadFile(file1Q, newFileName,objData) {
        var FileUploadData = PortalQuotationUploadingAJService.uploadFileToUrl(file1Q, newFileName);
        FileUploadData.then(function (res) {
            FileNameServiceData = res.data;
            angular.forEach(objData, function (value, key) {
                value.QuotFilePath = FileNameServiceData;
            });
            var GetData = PortalQuotationUploadingAJService.SaveQuotationData(objData)
            GetData.then(function (Response) {
                //$scope.DepoLookupList = Response.data;
                GetQuotProcessData();
            });
        });
    };


    $scope.DisplayData = function () {
    }



    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = true;
        $scope.SelectAllData = 'N';
    }

    function ClearData() {

    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
    }


    function DepoLookupList() {
        var GetData = PortalQuotationUploadingAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    function PaymentTermLookupList() {
        var GetData = PortalQuotationUploadingAJService.GetPamentTermLookupList();
        GetData.then(function (Response) {
            $scope.PaymentTypeLookupList = Response.data;
        });
    }

    function GetQuotProcessData() {
        if ($scope.DepotId == undefined || $scope.DepotId == '' || $scope.DepotId == null || $scope.DepotId == "") {
            $scope.errMsg = 'Please select Depo';
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var InputParm = {
            DeportId: $scope.DepotId,
            VendorId: $scope.VendorId,
            IndentRefId: $scope.IndentRefId,
            ItemId: $scope.ItemId,
            FromDate: "",
            ToDate: ""
        }
        var GetData = PortalQuotationUploadingAJService.GetQuotUpdationList(InputParm);
        GetData.then(function (Response) {
            $scope.QuotproessDataList = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.FilterIndentProcess = function () {
        GetQuotProcessData();
    }

    $scope.Vendorchange = function () {
        if ($scope.VendorName == undefined || $scope.VendorName == '') {
            $scope.VendorId = undefined;
        }
    }

    $scope.ItemChange = function () {
        if ($scope.ItemName == undefined || $scope.ItemName == '') {
            $scope.ItemId = undefined;
        }
    }

    $scope.IndentChange = function () {
        if ($scope.IndentNo == undefined || $scope.IndentNo == '') {
            $scope.IndentRefId = undefined;
        }
    }

    $scope.IsDisabled = function (row, index) {
        if (row.SelectRow == 'N' || row.SelectRow == undefined) {
            return true;
        }

        if (row.SelectRow == 'Y') {
            return false;
        }
    }

    $scope.ViewFile = function (row) {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        var link = document.createElement('a');
       // link.href = baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId;
        //window.location = link.href;
        var wo = window.open(baseUrl + "/Store/QuotationUploading/FileDownload?docRefNo=" + row.IndentQuotReqRefId, 'Snopzer', 'left=20,top=20,width=500,height=500,directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,title=AttachedFile');
        wo.document.title = "My File"
    }


    function GetVendorNameData() {
        var InputParam = {
            LocationId:$sessionStorage.locationId,
            VendorId: $sessionStorage.CustomerId
        }

        var GetData = PortalQuotationUploadingAJService.GetVendorName(InputParam);
        GetData.then(function (Response) {
            $scope.VendorName = Response.data.VendorName;
            $scope.VendorId = Response.data.VendorId;
        });

    }
});