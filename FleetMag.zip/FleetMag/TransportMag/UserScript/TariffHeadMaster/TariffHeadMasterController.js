﻿app.controller("mvcTariffHeadCtrl", function ($scope, $localStorage, $sessionStorage, $filter, $compile, $timeout, TariffHeadAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    
    GetTariffHeadsList();
    var appendlst = "";  
  
  
    $("#btnAdd").focus();

   
    //====================================================Get Vendor List=====================================================================//
    function GetTariffHeadsList() {
        var inputValues = {
            LocationId: $sessionStorage.locationId
        }
        var GetData = TariffHeadAJService.GetAllTarriffHeads(inputValues);
       
        GetData.then(function (pBillableItemMaster) {
            
            $scope.TariffHeadList = pBillableItemMaster.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempTariffHeadList = $scope.TariffHeadList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Tariff Heads. " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllTariffHeads() {
        var uiEle = angular.element(document.querySelector('#LpTariffHead'));
        $('#LpTariffHead').html('');
        angular.forEach($scope.TariffHeadList, function (value, key) {
            if (!jQuery.isEmptyObject(value.BillItemId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.BillItemId + "')\">" + value.BillItemDescription + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var TariffHead = $compile(appendlst)($scope);
        uiEle.append(TariffHead);
        appendlst = "";
    }
  
    function showFirst(BillItemId)
    {
        
        var BillableItemMaster = {
            BillItemId: BillItemId
        };

        var getData = TariffHeadAJService.GetBillableItemMasterById(BillableItemMaster);
        getData.then(function (pBillableItemMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pBillableItemMaster.data.ErrorMessage != null) {
                $scope.errMsg = pBillableItemMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }

            $scope.BillItemId = pBillableItemMaster.data.BillItemId;
            $scope.TypeOfHead = pBillableItemMaster.data.TypeOfHead;
            $scope.BillItemCode = pBillableItemMaster.data.BillItemCode;
            $scope.BillItemDescription = pBillableItemMaster.data.BillItemDescription;
            $scope.Units = pBillableItemMaster.data.Units;
            $scope.TallyHead = pBillableItemMaster.data.TallyHead;
            $scope.ActivityType = pBillableItemMaster.data.ActivityType;
            $scope.BillActivity = pBillableItemMaster.data.BillActivity;
            $scope.SeqNo = pBillableItemMaster.data.SeqNo;
            //$scope.TdsId = pBillableItemMaster.data.TdsId;
            //$scope.ServiceTaxCategoryCode = pBillableItemMaster.data.ServiceTaxCategoryCode;
            $scope.ApplicableTo = pBillableItemMaster.data.ApplicableTo;

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Tariff Head Master Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (BillItemId) {
        showFirst(BillItemId);
    }

    function clearTariffHeadList() {
        $scope.TariffHeadList = [];
        GetAllTariffHeads();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        $scope.TypeOfHead = "R";
        $scope.ApplicableTo = "D";
        $scope.BillActivity = "A";
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.BillItemId = undefined;
        $scope.TypeOfHead = undefined;
        $scope.BillItemCode = undefined;
        $scope.BillItemDescription = undefined;
        $scope.Units = undefined;
        $scope.TallyHead = undefined;
        $scope.ActivityType = undefined;
        $scope.BillActivity = undefined;
        $scope.SeqNo = undefined;
        //$scope.TdsId = undefined;
        //$scope.ServiceTaxCategoryCode = undefined;
        $scope.ApplicableTo = undefined;
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.BillItemDescription == undefined || $scope.BillItemDescription == "") {
            $scope.errMsg = "Tariff Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtBillItemDescription").focus();
            return;
        }

        if ($scope.TypeOfHead == undefined || $scope.TypeOfHead == "") {
            $scope.errMsg = "Type Of Head is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstTypeOfHead").focus();
            return;
        }
      
        if ($scope.ActivityType == undefined || $scope.ActivityType == "") {
            $scope.errMsg = "Activity Type is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstActivityType").focus();
            return;
        }

        if ($scope.ApplicableTo == undefined || $scope.ApplicableTo == "") {
            $scope.errMsg = "Applicable To is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstApplicableTo").focus();
            return;
        }

        var BillableItemMaster = {
            BillItemId: $scope.BillItemId,
            TypeOfHead: $scope.TypeOfHead,
            BillItemCode: $scope.BillItemCode,
            BillItemDescription: $scope.BillItemDescription,
            Units: $scope.Units,
            TallyHead: $scope.TallyHead,
            ActivityType: $scope.ActivityType,
            BillActivity: $scope.BillActivity,
            SeqNo: $scope.SeqNo,
            //TdsId: $scope.TdsId,
            //ServiceTaxCategoryCode: $scope.ServiceTaxCategoryCode,
            ApplicableTo: $scope.ApplicableTo,
            LocationId: $sessionStorage.locationId
            };

        var saveData = TariffHeadAJService.saveTariffHeadData(BillableItemMaster);
        saveData.then(function (pBillableItemMaster) {

            if (pBillableItemMaster.data.ErrorMessage != null && pBillableItemMaster.data.ErrorMessage != "") {
                $scope.errMsg = pBillableItemMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
             
                $scope.BillItemId = pBillableItemMaster.data.BillItemId;
                //$scope.TerminalList = [];
                //clearTariffHeadList();
                //GetTariffHeadList();
                GetTariffHeadsList();
                showFirst($scope.BillItemId);
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Tariff Head Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
            if ($scope.TariffHeadList.length != 0) {
                    filteredList = $filter('filter')($scope.TariffHeadList, { BillItemDescription: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.TariffHeadList = filteredList;
                    }                   
                }
        }
        else {
            $scope.TariffHeadList = $scope.tempTariffHeadList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('TariffHeadList', function () {
        if ($scope.TariffHeadList != undefined) {
            showFirst($scope.TariffHeadList[0].BillItemId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
  
});

