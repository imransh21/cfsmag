﻿app.service("TariffHeadAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

  
    this.saveTariffHeadData = function (BillableItemMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TariffHeadMaster/SaveDetails",
            data: JSON.stringify(BillableItemMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllTarriffHeads = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TariffHeadMaster/LoadAllTarriffHeads",
            data: JSON.stringify(inputValues),
            dataType: "json"
        });
        return response;
    }

    this.GetBillableItemMasterById = function (BillableItemMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TariffHeadMaster/LoadBillableItemMasterById",
            data: JSON.stringify(BillableItemMaster),
            dataType: "json"
        });
        return response;
    }

})