﻿app.service("QuotationUploadingAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
       
    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetItemLookupList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationUploading/ItemNameLookup",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetQuotUpdationList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationUploading/GetIndentReqDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetPamentTermLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/QuotationUploading/GetPaymentTerms",
            dataType: "json"
        });
        return response;
    }

    this.uploadFileToUrl = function (file, newFileName) {
        var payload = new FormData();
        payload.append("file", file);
        payload.append('newFileName', newFileName); 
        var response = $http({
            method: 'POST',
            data: payload,
            headers: { 'Content-Type': undefined },
            url: baseUrl + "/Store/QuotationUploading/fileupload",
            transformRequest: angular.identity            
        })
        return response
    };


    this.SaveQuotationData = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/Store/QuotationUploading/SaveQuotationUpLoading",
            dataType: "json"
        });
        return response;
    }

    this.GetViewFile = function (InputParam) {
        var response = $http({
            method: "post",
            data: JSON.stringify(InputParam),
            url: baseUrl + "/Store/QuotationUploading/FileDownload",
            dataType: "json"
        });
        return response;
    }
});