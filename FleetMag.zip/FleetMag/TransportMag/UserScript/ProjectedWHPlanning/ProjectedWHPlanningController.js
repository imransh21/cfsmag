﻿app.controller("ProjectedWHPlanningCtrl", function ($scope, $sessionStorage, $filter, ProjectedWHPlanningService, $state) {

    YardListAll();
//    TerminalAll();
//    DestinationList();
//    ShippingLineAll();
    $scope.concateItem = "$";
    $scope.SelClass = false;
    $scope.ImportType = "Import";
    $scope.BlockId = "";
    $scope.PlannedContainerCount = 0;
    $scope.PlannedContainerCount40 = 0;//Added by Pradarshan To Verify the Count of Planned Container. As on 19-07-2018.
    $scope.TransType = "I";
    function YardListAll() {
        
        var GetData = ProjectedWHPlanningService.GetAllBlock();

        GetData.then(function (pYards) {
            $scope.YardList = (pYards.data);
            $scope.errMsg = ""; 
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }
    function TerminalAll() {
        var GetData = ProjectedWHPlanningService.GetAllTerminals();

        GetData.then(function (pTerminals) {
            $scope.TerminalList = $.parseJSON(pTerminals.data);
            var pTerminals = {
                TerminalId: "0", TerminalCode: "All"
            };
            $scope.TerminalList.splice(0, 0, pTerminals);
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Terminal Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function DestinationList() {
        $scope.IsShowLoading = true;

        var GetData = ProjectedWHPlanningService.GetAllDestinations();

        GetData.then(function (pResult) {
            $scope.DestinationList = $.parseJSON(pResult.data);
            var pResult = {
                RailIcdId: "0", RailIcdCode: "All"
            };
            $scope.DestinationList.splice(0, 0, pResult);
            $scope.IsShowLoading = false;
        });
    };

    function ShippingLineAll() {
        var GetData = ProjectedWHPlanningService.ShippingLineAll();

        GetData.then(function (pShippingLine) {
            $scope.Linelst = $.parseJSON(pShippingLine.data);
            var pShippingLine = {
                CustomerId: "0", CustomerCode: "All"
            };
            $scope.Linelst.splice(0, 0, pShippingLine);
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Terminal Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function showFirst(BlockId) {
        $scope.PlannedContainerCount = 0;
        $scope.PlannedContainerCount40 = 0;

        var BlockMaster = {
            BlockId: $scope.BlockIdMain,
            Stack: $scope.StackIdMain
        };
        BlockId = $scope.BlockIdMain;
        var getData = ProjectedWHPlanningService.getYardBlockById(BlockMaster);
        getData.then(function (pBlockMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pBlockMaster.data.ErrorMessage != null) {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
            
            $scope.BlockId = pBlockMaster.data.BlockId;
            $scope.LocationId = pBlockMaster.data.LocationId;
            //$scope.TerminalId = pBlockMaster.data.TerminalId;
            $scope.BlockCode = pBlockMaster.data.BlockCode;
            $scope.RtToTmDistance = pBlockMaster.data.RtToTmDistance;
            $scope.YardLength = pBlockMaster.data.YardLength;
            $scope.YardWidth = pBlockMaster.data.YardWidth;
            $scope.NoOfStacks = pBlockMaster.data.NoOfStacks;
            $scope.PerWtCapacity = pBlockMaster.data.PerWtCapacity;
            $scope.SpecialReserve = pBlockMaster.data.SpecialReserve;
            $scope.MaxWtCapacity = pBlockMaster.data.MaxWtCapacity;
            $scope.Remarks = pBlockMaster.data.Remarks;
            $scope.PerTransTime = pBlockMaster.data.PerTransTime;
            $scope.ColumnList = pBlockMaster.data.BlockColumnMasterList;
            $scope.LaneList = pBlockMaster.data.BlockLaneMasterList;
            $scope.YardBlockLaneColumnList = pBlockMaster.data.YardBlockLaneColumnList;
            $scope.YardContainerSize = pBlockMaster.data.ContSize; //Adde by Pradarshan M on 19-07-2018 for displaying container size selection.

            
            var BlockMaster = {
                BlockId: BlockId,
                StackId: $scope.Stack
            };

            var getDataLane = ProjectedWHPlanningService.LoadLaneDtlsById(BlockMaster);
            getDataLane.then(function (pLane) {
                $scope.LaneWiseDtls = $.parseJSON(pLane.data);
            });
        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Yard Defination";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (Stack) {
        
        $scope.PlannedContainerCount = 0;
        $scope.PlannedContainerCount40 = 0;        
        $scope.StackIdMain = Stack;
        if ($scope.StackIdMain!=null && $scope.StackIdMain!='' && $scope.StackIdMain!=undefined){
            showFirst(Stack);
        }
    }

    $scope.commonSourceBlock = function (BlockId) {
        
        $scope.BlockIdMain = undefined;
        $scope.StackIdMain = undefined;        
        $scope.BlockIdMain = BlockId;
        $scope.LaneList = [];
        $scope.ColumnList = [];
        $scope.LaneWiseDtls = [];
        $scope.StackList = [];
        var InputParam = {
            BlockId: BlockId
        }
        var GetData = ProjectedWHPlanningService.getStackDtlsById(InputParam);
        GetData.then(function (pYards) {
            $scope.StackList = pYards.data;        
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }

    $scope.updYardStatus = function (itemId) {
        //For validation of selection of place and number of containers. By Pradarshan M as on 19-07-2018.
        //
        var element1 = document.querySelector('.' + itemId);
        var angElement1 = angular.element(element1);
        if (angElement1.hasClass('Completed'))
        {
            var element = document.querySelector('.' + itemId);
            var angElement = angular.element(element);
            angElement.toggleClass('Completed');
            return;
        }
        if ($scope.TransType=='I'){
            if ($scope.IGMNo == undefined || $scope.IGMNo == '') {
                alert("Please Select Igm Number ");
                return;
            }
        }else{
            if ($scope.hndTransNoEH == undefined || $scope.hndTransNoEH == '') {
                alert("Please Select Shipping Bill Nbr. ");
                return;
            }
        }

        //if ($scope.hdnContSize == '' || $scope.hdnContSize == undefined) {
        //    alert("Please Select Container Size To Be Planned.");
        //    return;
        //}

        var colId = angElement1[0].id.split($scope.concateItem)[1];

        filteredColList = $filter('filter')($scope.ColumnList, { ColumnId: colId });
        //if (filteredColList[0].ColContSize != '' && filteredColList[0].ColContSize != undefined)
        //{
        //    if ($scope.hdnContSize != filteredColList[0].ColContSize)
        //    {
        //        alert("Only container of size " + filteredColList[0].ColContSize + " allowed");
        //        return;
        //    }
        //}

        //if ($scope.hdnContSize == 20) {
        //    if ((parseInt($scope.Planned20) + parseInt($scope.NoOfStacks)) > parseInt($scope.Count20)) {
        //        alert("Can not Planned More No of Container Then Total.");
        //        return;
        //    }
        //    if (parseInt($scope.PlannedContainerCount) + parseInt($scope.NoOfStacks) + parseInt($scope.Planned20) > parseInt($scope.Count20)) {
        //        alert("Can not Planned More No of Container Than Total.");
        //        return;
        //    }
        //}
        //else {
        //    if ((parseInt($scope.Planned40) + (parseInt($scope.NoOfStacks)/2)) > parseInt($scope.Count40)) {
        //        alert("Can not Planned More No of Container Than Total.");
        //        return;
        //    }
        //    if (((parseInt($scope.PlannedContainerCount40)/2) + (parseInt($scope.NoOfStacks)/2) + parseInt($scope.Planned40)) > parseInt($scope.Count40)) {
        //        alert("Can not Planned More No of Container Than Total.");
        //        return;
        //    }
        //}
        //end

        var element1 = document.querySelector('#' + itemId);
        var angElement1 = angular.element(element1);
        if (angElement1.hasClass('Empty'))
        {
            var element = document.querySelector('.' + itemId);
            var angElement = angular.element(element);
            angElement.toggleClass('Completed');
        //    if ($scope.hdnContSize == 20) {
        //        $scope.PlannedContainerCount = parseInt($scope.PlannedContainerCount) + parseInt($scope.NoOfStacks);
        //    }
        //    else {
        //        $scope.PlannedContainerCount40 = parseInt($scope.PlannedContainerCount40) + parseInt($scope.NoOfStacks);
        //    }
        }
    };

    $scope.getIndexpage = function () {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }



    $scope.DataUpdate = function () {

        if ($scope.BlockId == undefined) {
            alert("Please Select Yard!");
            return;
        }
        if ($scope.TrainNbr == undefined) {
            alert("Please Select Train!");
            return;
        }


        $(".Completed").each(function (index, element) {
            var LaneandColoumn = element.id;
            var SplitVal = LaneandColoumn.split("$");

            var BlockMaster = {
                BlockId: $scope.BlockId,
                TrainId: $scope.TrainNbr,
                LaneId: SplitVal[0],
                ColumnId: SplitVal[1],
                TerminalId: $scope.TerminalId,
                LineId: $scope.CustomerId,
                Destination: $scope.RailIcdId,
                Size: $scope.Size

            };
            var getData = ProjectedWHPlanningService.SaveData(BlockMaster);
            getData.then(function (pBlockMaster) {
                $scope.errMsg = "";
                $scope.isError = false;

                if (pBlockMaster.data.ErrorMessage != null) {
                    $scope.errMsg = pBlockMaster.data.ErrorMessage;
                    $scope.isError = true;
                    return;
                }
                alert("Data Updated");
            }, function () {
                clearData();
                $scope.errMsg = "Error in Updting Yard Data";
                $scope.isError = true;
                return;
            });
        });

    };

    $scope.RemovePlan = function () {

        $.confirm({
            title: 'Remove Plan',
            text: "Do you want to remove plan?",
            content: 'Simple confirm!',
            confirmButtonClass: "btn-primary",
            cancelButtonClass: "btn-primary",
            confirm: function () {
                RemovePlanConfirm()
            }
        });
    }

    function RemovePlanConfirm() {

        if ($scope.TransType == 'I') {
            if ($scope.IGMNo == undefined ) {
                alert("Please enter BL No!");
                return;
            }
        }
        if ($scope.TransType == 'EH') {
            if ($scope.WorkOrderNoEH == undefined) {
                alert("Please enter Shipping Bill No!");
                return;
            }
        }
       

        $scope.errMsg = "";
        $scope.isError = false;


        if ($scope.TransType == 'I') {
            var BlockMaster = {
                Cycle: "I",
                IGMNo: $scope.IGMNo               
            };
        }
        else if ($scope.TransType == 'EH') {
            var BlockMaster = {
                Cycle: $scope.TransType,
                IGMNo: $scope.WorkOrderNoEH
          }
        }
       
        var getData = ProjectedWHPlanningService.RemovePlanDt(BlockMaster);
        getData.then(function (pBlockMaster) {

            if (pBlockMaster.data.ErrorMessage != "") {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                alert(pBlockMaster.data.ErrorMessage);
                return;
            }
            else { //showFirst($scope.BlockId); 
            }
            //alert("Data Updated");
        }, function () {
            clearData();
            $scope.errMsg = "Error in Updting Yard Data";
            $scope.isError = true;
            return;
        });
        if ($scope.isError == false) {
            //showFirst($scope.BlockId);
            RefreshParameters();
        };


    };

    $scope.FetchIGM = function ()
    {
        var ImportDocumentDetails = {
            BlNo: $scope.IGMNo
        }

       var GetData = ProjectedWHPlanningService.BlData(ImportDocumentDetails);

        GetData.then(function (pYards) {
            var YardData = $.parseJSON(pYards.data);
            $scope.BLDate = YardData[0].BlDate;
           // $scope.IGMDocDo = YardData[0].ImpDocNo;
            $scope.IGMNo = YardData[0].BlNo;
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });

    }

    $scope.DataUpdateIGM = function () {
        //
        if ($scope.BlockId == undefined || $scope.BlockId == "") {
            alert("Please Select Yard!");
            return;
        }
        if ($scope.TransType == 'I') {
            if ($scope.IGMNo == undefined || $scope.IGMNo == "") {
                alert("Please enter IGM No and Item No!");
                return;
            }
        }
        if ($scope.TransType == 'EH') {
            if ($scope.hndTransNoEH == undefined || $scope.hndTransNoEH == "") {
                alert("Please enter Work Order No!");
                return;
            }
        }
        if ($scope.TransType == 'MH') {
            if ($scope.hndTransNoMH == undefined || $scope.hndTransNoMH == "") {
                alert("Please enter Work Order No!");
                return;
            }
        }
     
        $scope.errMsg = "";
        $scope.isError = false;

        $(".Completed").each(function (index, element) {
            var LaneandColoumn = element.id;
            var SplitVal = LaneandColoumn.split("$");
            if ($scope.TransType == 'I') {
                var BlockMaster = {
                    BlockId: $scope.BlockId,
                    IGMDocNo: $scope.IGMDocDo,
                    ContSize: 0,
                    LaneId: SplitVal[0],
                    ColumnId: SplitVal[1],
                    Cycle: "I",
                    IGMNo: $scope.IGMNo,
                    ItemNo: $scope.ItemNo,
                    ShippingBillNbr:$scope.WorkOrderNoEH,
                    StackId: $scope.Stack
                };
            }
            else if ($scope.TransType == 'EH')
            {
                var BlockMaster = {
                    BlockId: $scope.BlockId,
                    IGMDocNo: $scope.hndTransNoEH,
                    ContSize: 0,
                    LaneId: SplitVal[0],
                    ColumnId: SplitVal[1],
                    Cycle: $scope.TransType,
                    IGMNo: $scope.WorkOrderNoEH,
                    ItemNo: 0,                    
                    ShippingBillNbr: $scope.WorkOrderNoEH,
                    StackId: $scope.Stack
                }
            }
            else if ($scope.TransType == 'MH') {
                var BlockMaster = {
                    BlockId: $scope.BlockId,
                    IGMDocNo: "",
                    ContSize: $scope.hdnContSize,
                    LaneId: SplitVal[0],
                    ColumnId: SplitVal[1],
                    Cycle: $scope.TransType,
                    IGMNo: $scope.WorkOrderNoMH,
                    ItemNo: 0,
                    WorkOrderNo: $scope.hndTransNoMH
                }
            }
            var getData = ProjectedWHPlanningService.SaveDataIGM(BlockMaster);
            getData.then(function (pBlockMaster) {

                if (pBlockMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pBlockMaster.data.ErrorMessage;
                    $scope.isError = true;
                    alert(pBlockMaster.data.ErrorMessage);
                    return;
                }
                else { //showFirst($scope.BlockId);
                    RefreshParameters();
                }
                //alert("Data Updated");
            }, function () {
                clearData();
                $scope.errMsg = "Error in Updting Yard Data";
                $scope.isError = true;
                return;
            });
            if ($scope.isError == false) {
                //showFirst($scope.BlockId);
               // RefreshParameters();
            };
        }

        );

    };

    $scope.SaveIGMDataColwise = function () {
        if ($scope.BlockId == undefined) {
            alert("Please Select Yard!");
            return;
        }
        if ($scope.TransType == 'I') {
            if ($scope.IGMDocDo == undefined || $scope.IGMDocDo == null) {
                alert("Please enter IGM No and Item No!");
                return;
            }
        }
        if ($scope.TransType == 'EH') {
            if ($scope.hndTransNoEH == undefined || $scope.hndTransNoEH == null ) {
                alert("Please enter Work Order No!");
                return;
            }
        }
        if ($scope.TransType == 'MH') {
            if ($scope.hndTransNoMH == undefined || $scope.hndTransNoMH == null) {
                alert("Please enter Work Order No!");
                return;
            }
        }

      
        $scope.errMsg = "";
        $scope.isError = false;

        $(".Selected").each(function (index, element) {
            
            var LaneandColoumn = element.id;
            var yardid = LaneandColoumn.substr(1, LaneandColoumn.length-1);


            if ($scope.TransType == 'I') {
                var BlockMaster = {
                    BlockId: $scope.BlockId,
                    IGMDocNo: $scope.IGMDocDo,
                    ContSize: $scope.hdnContSize,
                    YardId: yardid,
                    Cycle: "I",
                    IGMNo: $scope.IGMNo,
                    ItemNo: $scope.ItemNo
                };
            }
            else if ($scope.TransType == 'EH') 
            {
                var BlockMaster = {
                    BlockId: $scope.BlockId,
                    IGMDocNo: $scope.hndTransNoEH,
                    ContSize: 0,
                    YardId: yardid,
                    Cycle: $scope.TransType,
                    IGMNo: $scope.WorkOrderNoEH,
                    ItemNo: 0,
                    WorkOrderNo: $scope.hndTransNoEH,
                    ShippingBillNbr: $scope.WorkOrderNoEH,
                    StackId: $scope.Stack
                }
            }
            else if ($scope.TransType == 'MH') 
                    {
                        var BlockMaster = {
                            BlockId: $scope.BlockId,
                            IGMDocNo: "",
                            ContSize: $scope.hdnContSize,
                            YardId: yardid,
                            Cycle: $scope.TransType,
                            IGMNo: $scope.WorkOrderNoMH,
                            ItemNo: 0,
                            WorkOrderNo: $scope.hndTransNoMH

                        }
                    }



            var getData = ProjectedWHPlanningService.SaveDataIGMColWise(BlockMaster);
            getData.then(function (pBlockMaster) {

                if (pBlockMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pBlockMaster.data.ErrorMessage;
                    $scope.isError = true;
                    alert(pBlockMaster.data.ErrorMessage);
                    return;
                }
                else { //showFirst($scope.BlockId);
                    RefreshParameters();
                }
                //alert("Data Updated");
            }, function () {
                clearData();
                $scope.errMsg = "Error in Updting Yard Data";
                $scope.isError = true;
                return;
            });
            //if ($scope.isError == false) {
            //    //showFirst($scope.BlockId);
            //  //  RefreshParameters();
            //};
        }

        );

    };

    $scope.updCellSelect = function (itemId) {
        //
        var strItem = '#' + itemId;
        var element1 = document.querySelector(strItem);
        var angElement1 = angular.element(element1);
        //if ($scope.hdnContSize == '' || $scope.hdnContSize == undefined)
        //{
        //    alert("Please Select Contaier Size To Be Planned.");
        //    return;
        //}
        //if ($scope.CurrColContSize != undefined && $scope.CurrColContSize != '')
        //{
        //    if ($scope.hdnContSize != $scope.CurrColContSize) {
        //        alert("Only container of size " + $scope.CurrColContSize + " allowed");
        //        return;
        //    }
        //}
        if (angElement1.hasClass('Selected')) {
            var element = document.querySelector('#' + itemId);
            var angElement = angular.element(element);
            angElement.toggleClass('Selected');
            //if ($scope.hdnContSize == 20) {
            //    $scope.PlannedContainerCount = parseInt($scope.PlannedContainerCount) - 1;
            //}
            //else {

            //    $scope.PlannedContainerCount40 = parseInt($scope.PlannedContainerCount40) - 1;
            //}
            return;
        }
        //if ($scope.hdnContSize == '' || $scope.hdnContSize == undefined) {
        //    alert("Please Select Contaier Size To Be Planned.");
        //    return;
        //}
        //if ($scope.hdnContSize == 20) {
        //   /* if ($scope.NoOfStacks > $scope.Count20) {
        //        alert("Can not Planned More No of Container Then Total. 3");
        //        return;
        //    }*/
        //    if ((parseInt($scope.PlannedContainerCount) + parseInt($scope.Planned20) + 1) > $scope.Count20) {
        //        alert("Can not Planned More No of Container Than Total.");
        //        return;
        //    }
        //}
        //else {
        //    if ($scope.NoOfStacks > $scope.Count40) {
        //        alert("Can not Planned More No of Container Than Total. ");
        //        return;
        //    }
        //    if ((parseInt($scope.PlannedContainerCount40) + parseInt($scope.Planned40) + 1) > $scope.Count40) {
        //        alert("Can not Planned More No of Container Than Total. ");
        //        return;
        //    }
        //}

        //
        var strItem = '#' + itemId;
        var element1 = document.querySelector(strItem);
        var angElement1 = angular.element(element1);
        if (angElement1.hasClass('Empty')) {
            var element = document.querySelector('#' + itemId);
            var angElement = angular.element(element);
            angElement.toggleClass('Selected');
            //if ($scope.hdnContSize == 20) {
            //    $scope.PlannedContainerCount = parseInt($scope.PlannedContainerCount) + 1;
            //}
            //else {
            //    $scope.PlannedContainerCount40 = parseInt($scope.PlannedContainerCount40) + 1;
            //}
        }
    };

    $scope.SetTransType = function (strTransType)
    {
        $scope.TransType = strTransType;
    }

    $scope.FetchDocEH = function () {
        var ImportDocumentDetails = {
            IGMNo: $scope.WorkOrderNoEH
        }
        $scope.hndTransNoEH = "";
        $scope.ShipLineEH = "";
        $scope.BookByEH = "";
        $scope.Count20 = 0;
        $scope.Count40 = 0;
        $scope.Planned20 = 0;
        $scope.Planned40 = 0;

        var GetData = ProjectedWHPlanningService.FetchDocEH(ImportDocumentDetails);

        GetData.then(function (pYards) {
            var YardData = $.parseJSON(pYards.data);
            //
            //    if (YardData.WorkOrderNo == null || YardData.WorkOrderNo == 0) {
            //        $scope.hndTransNoEH = null;
            //        alert("Work Order No not found");
            //        return;
            //    }
            $scope.hndTransNoEH = YardData.WorkOrderNo;
            $scope.ShipLineEH = YardData.ShippingLine;
            $scope.BookByEH = YardData.Importer;
            $scope.Count20 = YardData.Count20;
            $scope.Count40 = YardData.Count40;
            $scope.Planned20 = YardData.Planned20;
            $scope.Planned40 = YardData.Planned40;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.$apply();
        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });

    }

    $scope.FetchDocMH = function () {
        var ImportDocumentDetails = {
            IGMNo: $scope.WorkOrderNoMH
        }

        var GetData = ProjectedWHPlanningService.FetchDocMH(ImportDocumentDetails);

        GetData.then(function (pYards) {
            $scope.hndTransNoMH = "";
            $scope.ShipLineMH = "";
            $scope.BookByMH = "";
            $scope.Count20 = 0;
            $scope.Count40 = 0;
            $scope.Planned20 = 0;
            $scope.Planned40 = 0;
            var YardData = $.parseJSON(pYards.data);            
            if (YardData.ErrorMessage != "" && YardData.ErrorMessage != null) {
                $scope.errMsg = "Error in getting Yard Defination" + YardData.ErrorMessage;
                alert($scope.errMsg);
                $scope.isError = true;
                return;
            }
            if (YardData.WorkOrderNo == null || YardData.WorkOrderNo == 0) {
                $scope.hndTransNoEH = null;
                alert("Work Order No not found");
                return;
            }
            $scope.hndTransNoMH = YardData.WorkOrderNo;
            $scope.ShipLineMH = YardData.ShippingLine;
            $scope.BookByMH = YardData.Importer;
            $scope.Count20 = YardData.Count20;
            $scope.Count40 = YardData.Count40;
            $scope.Planned20 = YardData.Planned20;
            $scope.Planned40 = YardData.Planned40;
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });

    }

    function RefreshParameters()
    {
        showFirst($scope.BlockId);
        if ($scope.TransType == 'I')
        {
            $scope.FetchIGM();
        }
        if ($scope.TransType == 'EH') {
            $scope.FetchDocEH();
        }
        if ($scope.TransType == 'MH') {
            $scope.FetchDocMH();
        }
    }


     $scope.GetSbDetais=function(){
        var InputParam = {
            SbNumber: $scope.WorkOrderNoEH
        }
        var GetData = ProjectedWHPlanningService.FetchSbDtls(InputParam);
        GetData.then(function (Result) {
            $scope.ShippingDtls = $.parseJSON(Result.data);
            $scope.hndTransNoEH = $scope.ShippingDtls[0].EXP_CFS_CODE;
            $scope.Exporter = $scope.ShippingDtls[0].EXPORTER_DETAILS;
            $scope.Consignee = $scope.ShippingDtls[0].CONSIGNEE_NAME;
        });
     }

     $scope.FetchPlanDetails = function () {
        
         if ($scope.TransType == 'I') {
             var InputParam = {               
                 Cycle: "I",
                 IGMNo: $scope.IGMNo,
                 ItemNo: $scope.ItemNo
             };
         }
         else if ($scope.TransType == 'EH') {
             var InputParam = {               
                 Cycle: $scope.TransType,
                 IGMNo: $scope.WorkOrderNoEH,
                 ItemNo: 0                
             }
         }
         else if ($scope.TransType == 'MH') {
             var BlockMaster = {               
                 Cycle: $scope.TransType,
                 IGMNo: $scope.WorkOrderNoMH,
                 ItemNo: 0
             }
         }
         
         var GetData = ProjectedWHPlanningService.WhPlanDetails(InputParam);
         GetData.then(function (Result) {
             $scope.BlockStackDtls = $.parseJSON(Result.data);
         });
     }
});