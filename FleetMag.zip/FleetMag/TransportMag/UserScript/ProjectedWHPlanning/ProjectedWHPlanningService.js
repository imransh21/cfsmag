﻿app.service("ProjectedWHPlanningService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetAllBlock = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/ProjectedWHPlanning/GetAllBlock",
            dataType: "json"
        });
        return response;
    }

    this.getStackDtlsById = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/ProjectedWHPlanning/LoadStackDetailsById",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    } 



    this.GetAllTerminals = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/TerminalMaster/LoadAllTerminals",
            dataType: "json"
        });
        return response;
    }
    this.GetAllDestinations = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/ICDPendency/LoadAllRailIcds",
            dataType: "json"
        });
        return response;
    }

    this.ShippingLineAll = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/GetLineList",
            dataType: "json"
        });
        return response;
    }
    this.SaveData = function (pBlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/SaveData",
            dataType: "json",
            data: JSON.stringify(pBlockMaster)
        });
        return response;
    }

    this.FetchIGM = function (ImportDocumentDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/FetchIGM",
            dataType: "json",
            data: JSON.stringify(ImportDocumentDetails)
        });
        return response;
    }
    this.SaveDataIGM = function (pBlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/SaveDataIGM",
            dataType: "json",
            data: JSON.stringify(pBlockMaster)
        });
        return response;
    }
    this.getYardBlockById = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/ProjectedWHPlanning/LoadYardBlockById",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    }

  

    this.LoadLaneDtlsById = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/ProjectedWHPlanning/LoadLaneDtlsById",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    }    
    this.SaveDataIGMColWise = function (pBlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/SaveDataIGMWHColWise",
            dataType: "json",
            data: JSON.stringify(pBlockMaster)
        });
        return response;
    }
    this.FetchDocEH = function (ImportDocumentDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/FetchDocEH",
            dataType: "json",
            data: JSON.stringify(ImportDocumentDetails)
        });
        return response;
    }
    this.FetchDocMH = function (ImportDocumentDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/FetchDocMH",
            dataType: "json",
            data: JSON.stringify(ImportDocumentDetails)
        });
        return response;
    }

    this.FetchSbDtls = function (SbNbr) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/GetSbDetails",
            dataType: "json",
            data: JSON.stringify(SbNbr)
        });
        return response;
    }


    this.WhPlanDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/GetWHPlanDetails",
            dataType: "json",
            data: JSON.stringify(InputParam)
        });
        return response;
    }

    this.RemovePlanDt = function (pBlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/RemovePlanDt",
            dataType: "json",
            data: JSON.stringify(pBlockMaster)
        });
        return response;
    }
    this.BlData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/ProjectedWHPlanning/GetBlDetailsWH",
            dataType: "json",
            data: JSON.stringify(InputParam)
        });
        return response;
    }

});