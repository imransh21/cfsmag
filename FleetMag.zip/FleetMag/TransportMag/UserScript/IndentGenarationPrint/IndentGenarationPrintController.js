﻿app.controller("IndentGenPrintCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, IndentGenPrintAJService) {
    getIndentPrintData();

    function getIndentPrintData() {
        
        var InputParam = {
            IndentRefId: $sessionStorage.IndentRefId
        }
        var GetData = IndentGenPrintAJService.GetIndentPrintDetails(InputParam);
         GetData.then(function (Response) {
            $scope.IndentNo = Response.data.IndentNo;
            $scope.IndentDate = Response.data.IndentDate;
            $scope.NatureOfIndent = Response.data.NatureOfIndent;
            $scope.DeportName = Response.data.DeportName;
            $scope.ExpDelvDate = Response.data.ExpDelvDate;
            $scope.IndentDetailsList = Response.data.IndentDtlsList;
            $scope.isShownIndent = true;

        });
    }

});
