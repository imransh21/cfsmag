﻿app.service("IndentGenPrintAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.GetIndentPrintDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenarationPrint/GetIndentPrintDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
});