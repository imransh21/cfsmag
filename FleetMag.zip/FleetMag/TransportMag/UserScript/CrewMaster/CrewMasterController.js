﻿app.controller("mvcCrewCtrl", function ($scope, $localStorage, $filter, $compile, $timeout, CrewAJService, EmpAJService,$sessionStorage) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    
    $scope.isShown2 = true;
    $scope.CrewMemberList = [];
    var appendlst = "";
   
    GetCrewList();
    DepoLookupList();
    GetDesignationList();
    $scope.DepoChange = function () {
   // GetCrewList();
        GetDesignationList();
        GetEmpList();
        BranchList();
        GetSuperviserList();
    }
    $("#btnAdd").focus();   
    debugger;
    $('#hBranchId').val($sessionStorage.locationId);
   // GetAllWarehouses();

    function DepoLookupList() {
        var GetData = CrewAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    function BranchList() {
        var GetData = CrewAJService.GetAllBranch();

        GetData.then(function (pTerminals) {
            $scope.BranchList = $.parseJSON(pTerminals.data);
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Terminals " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    function GetDesignationList() {
        var pDesignation = {
            BranchId: $scope.DepotId
        };
        var GetData = CrewAJService.GetAllDesignations(pDesignation);

        GetData.then(function (pTerminals) {
            $scope.DesignationList = pTerminals.data;
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Designations " + reason.data;
            $scope.isError = true;
            return;
        });
    }
    function GetEmpList() {
        var pEmp = {
            BranchId: $scope.DepotId
        };

        var GetData = EmpAJService.GetAllEmpByBranch(pEmp);

        GetData.then(function (pEmp) {
            $scope.Empl = $.parseJSON(pEmp.data);
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempEmpList = $scope.EmpList;


        }, function (reason) {
            $scope.errMsg = "Error in getting Employee " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetWarehouseList() {
        var pWareHouse = {
            LocationId: $scope.LocationId
        };

        var getData = CrewAJService.GetAllWarehousesBlock(pWareHouse);

        getData.then(function (Response) {
            $scope.WarehouseList = $.parseJSON(Response.data);
        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetSuperviserList() {
        var pSuperviser = {
            BranchId: $scope.DepotId,
            Designation: 'Supervisor'
        };

        var GetData = CrewAJService.GetAllSupervisers(pSuperviser);

        GetData.then(function (pSuperviser) {
            debugger;
            $scope.SuperviserList = pSuperviser.data;
            $scope.errMsg = "";
            $scope.isError = false;

        }, function (reason) {
            $scope.errMsg = "Error in getting Superviser List " + reason.data;
            $scope.isError = true;
            return;
        });
    }



    $scope.AddNewDtls = function () {
        GetDesignationList();
        GetEmpList();
      
        var pCrewMember = {
            Designation: "0",
            CrewMemberId: "0", EmpId: "0", ActiveStatus: "N", Flag: "N"
        };

        $scope.CrewMemberList.push(pCrewMember);
    }


    //$scope.empdes = function (row) {

    //    //alert(row.Designation);
    //    var pDesignation = {
    //        Designation:row.Designation,
    //        BranchId: $scope.LocationId
    //    };
    //     var GetData = CrewAJService.GetAllEmpCodes(pDesignation);

    //    GetData.then(function (pTerminals) {
    //        $scope.Empl = $.parseJSON(pTerminals.data);
    //        $scope.errMsg = "";
    //        $scope.isError = false;
    //    }, function (reason) {
    //        $scope.errMsg = "Error in getting Designations " + reason.data;
    //        $scope.isError = true;
    //        return;
    //    });
    //}
    
    $scope.empname = function (row) {

        //alert(row.Designation);
        var pEmp = {
            EmpId: row.EmpId,
            BranchId: $scope.DepotId
        };
        var GetData = EmpAJService.getEmpById(pEmp);

        GetData.then(function (pTerminals) {
            //  $scope.Empl = $.parseJSON(pTerminals.data);
            if (pTerminals.data.Designation == row.Designation) {
                row.EmployeeName = pTerminals.data.EmployeeName;
            }
            else {
                alert('Designation of this Employee not matches.');
            }
            
            $scope.errMsg = "";
            $scope.isError = false;
        }, function (reason) {
            $scope.errMsg = "Error in getting Designations " + reason.data;
            $scope.isError = true;
            return;
        });
    }
    //====================================================Get Vendor List=====================================================================//
    function GetCrewList() {
        var inputValues = {
            BranchId: $sessionStorage.locationId
        }
        var GetData = CrewAJService.GetAllCrews(inputValues);
       
        GetData.then(function (pCrew) {
            $scope.CrewList = pCrew.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempCrewList = $scope.CrewList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Crew. " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllCrews() {
        var uiEle = angular.element(document.querySelector('#LpCrew'));
        $('#LpCrew').html('');
        angular.forEach($scope.CrewList, function (value, key) {
            if (!jQuery.isEmptyObject(value.CrewId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.CrewId + "')\">" + value.CrewCode + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var Crew = $compile(appendlst)($scope);
        uiEle.append(Crew);
        appendlst = "";
    }

    function showFirst(CrewId)
    {
        debugger;
        var CrewMaster = {
            CrewId: CrewId
        };

        var getData = CrewAJService.getCrewById(CrewMaster);
        getData.then(function (pCrewMaster) {
            debugger;
            $scope.errMsg = "";
            $scope.isError = false;

            if (pCrewMaster.data.ErrorMessage != null) {
                $scope.errMsg = pCrewMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
          
            $scope.DepotId = pCrewMaster.data[0].WisId;
            GetDesignationList();
            GetSuperviserList();
            GetEmpList();
            $scope.CrewId = pCrewMaster.data[0].CrewId;
            $scope.CrewCode = pCrewMaster.data[0].CrewCode;
            $scope.SuperviserId = pCrewMaster.data[0].SuperviserId;
            $scope.CrewMemberList = pCrewMaster.data;

           
        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Crew Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (CrewId) {
        showFirst(CrewId);
    }

    function clearCrewList() {
        $scope.CrewList = [];
        GetAllCrews();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        $scope.CrewMemberList = [];
        var pCrewMember = {
            Designation: 0,
            CrewMemberId: 0, EmpId: 0, ActiveStatus: undefined, Flag: undefined
        };

        $scope.CrewMemberList.push(pCrewMember);
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.CrewId = undefined;
        $scope.CrewCode = undefined;
        $scope.SuperviserId = undefined;
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.CrewCode == undefined || $scope.CrewCode == "") {
            $scope.errMsg = "Crew Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtCrewCode").focus();
            return;
        }

        debugger;
        var CrewMaster = {
            CrewId: $scope.CrewId,
            WisId: $scope.DepotId,
            CrewCode: $scope.CrewCode,           
            SuperviserId: $scope.SuperviserId,
            LocationId: $sessionStorage.locationId,
            EmployeeList: $scope.CrewMemberList
            };

        var saveData = CrewAJService.saveCrewData(CrewMaster);
        saveData.then(function (pCrewMaster) {
            debugger;
            if (pCrewMaster.data.ErrorMessage != null && pCrewMaster.data.ErrorMessage != "") {
                $scope.errMsg = pCrewMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                ErrorPopupMsg('ErrorDivG');
                $scope.errMsg1 = "Data Saved";
                $scope.CrewId = pCrewMaster.data.CrewId;
                //$scope.TerminalList = [];
                clearCrewList();
                GetCrewList();
                GetDesignationList();
                GetEmpList()
                showFirst($scope.CrewId);
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Crew Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
                if ($scope.CrewList.length!=0) {
                    filteredList = $filter('filter')($scope.CrewList, { CrewCode: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.CrewList = filteredList;
                    }                   
                }
        }
        else {
            $scope.CrewList = $scope.tempCrewList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('CrewList', function () {
        if ($scope.CrewList != undefined) {
            showFirst($scope.CrewList[0].CrewId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    $scope.GetWarehouses = function () {
        GetWarehouseList();
    };

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    $scope.OnTypeChange = function (row,index) {
        row.EmpId = undefined;
        row.EmpCode = undefined;
        row.EmployeeName = undefined;
    }

    $scope.InitAutoComplete = function () {
        EmpAuto();
    }
    function EmpAuto() {

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".cssLineList").autocomplete({

            source: function (request, response) {
                debugger;
                //  
                //   alert($(this)[0].element[0].id);
                //   lstEmp
                var hdnindex = $(this)[0].element[0].id.substring(6, $(this)[0].element[0].id.length);
                // lstDesignation

                //var lstDesignationval = $('#lstDesignation' + hdnindex).val().substring(6, $('#lstDesignation' + hdnindex).val().length);
                var lstDesignationval = $('#lstDesignation' + hdnindex)[0][0].text;
                //  alert(lstDesignationval);
                //  var $scope = angular.element(document.getElementById('emplist')).scope();
                //var lstDesignationval = $scope.DesignationList[hdnindex].Designation;

                if (lstDesignationval == '') {
                    alert('Select Designation');
                    return;
                }
                // 
                var getUrl = window.location;
                //  alert(getUrl);
                var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                //  alert(baseUrl);
                // 
                $.ajax({
                    url: baseUrl + '/CrewMaster/LoadAllEmpCodes',
                    data: "{ 'Designation': '" + lstDesignationval + "','EmpCode': '" + request.term + "','BranchId': " + $('#lstDepo').val() + "}",
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        debugger;
                        // alert($.parseJSON(data));
                        //   
                        response($.map($.parseJSON(data), function (item, key) {
                            return {
                                label: item.EmpCode,
                                EmployeeName: item.EmployeeName,
                                EmpId: item.EmpId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                debugger;
                var cid = $(e.target)[0].id;
                //alert(cid.length);
                var hdnindex = cid.substring(6, cid.length);
                //alert(hdnindex);
                $('#hEmpId' + hdnindex).val(i.item.EmpId);
                $('#EmployeeName' + hdnindex).val(i.item.EmployeeName);
                //  alert($('#hdnPortId' + hdnindex).val());
                var $scope = angular.element(document.getElementById('emplist')).scope();
                for (j = 0; j < $('.cssLineList').length ; j++) {
                    angular.forEach($scope.CrewMemberList, function (avalue, akey) {
                        var currentIndex1 = $scope.CrewMemberList.indexOf(avalue);
                        if (j == hdnindex && currentIndex1 == hdnindex) {
                            avalue.EmpId = $('#hEmpId' + j).val();
                            avalue.EmpCode = i.item.label;
                            avalue.EmployeeName = $('#EmployeeName' + j).val();
                        }
                    })
                }
            },
            minLength: 1
        });
    }
});

