﻿app.service("CrewAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetAllSupervisers = function (pSuperviser) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllSupervisers",
            data: JSON.stringify(pSuperviser),
            dataType: "json"
        });
        return response;
    }

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    
    this.GetAllDesignations = function (pDesignation) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllDesignations",
            data: JSON.stringify(pDesignation),
            dataType: "json"
        });
        return response;
    }
    this.GetAllEmpCodes = function (pDesignation) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllEmpCodes",
            data: JSON.stringify(pDesignation),
            dataType: "json"
        });
        return response;
    }
    this.GetAllBranch = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllLocatioNs",
            dataType: "json"
        });
        return response;
    }

    this.GetAllWarehousesBlock = function (Warehouse) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllWarehousesBlock",
            data: JSON.stringify(Warehouse),
            dataType: "json"
        });
        return response;
    }


    this.saveCrewData = function (CrewMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/SaveDetails",
            data: JSON.stringify(CrewMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllCrews = function (CrewMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadAllCrews",
            data: JSON.stringify(CrewMaster),
            dataType: "json"
        });
        return response;
    }

    this.getCrewById = function (CrewMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/CrewMaster/LoadCrewById",
            data: JSON.stringify(CrewMaster),
            dataType: "json"
        });
        return response;
    }

})