﻿app.controller("mvcDriverCtrl", function ($scope, $localStorage, $filter, $compile, $timeout, DriverAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
   
   
    var appendlst = "";  
    GetDriverList();
  
    $("#btnAdd").focus();

   
    //====================================================Get Vendor List=====================================================================//
    function GetDriverList() {
        var inputValues = {
            BranchId: 0
        }
        var GetData = DriverAJService.GetAllDrivers(inputValues);
       
        GetData.then(function (pDriver) {
            
            $scope.DriverList = pDriver.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempDriverList = $scope.DriverList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Driver. " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllDrivers() {
        var uiEle = angular.element(document.querySelector('#LpDriver'));
        $('#LpDriver').html('');
        angular.forEach($scope.DriverList, function (value, key) {
            if (!jQuery.isEmptyObject(value.DriverId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.DriverId + "')\">" + value.DriverName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var Driver = $compile(appendlst)($scope);
        uiEle.append(Driver);
        appendlst = "";
    }
  
    function showFirst(DriverId)
    {
        
        var DriverMaster = {
            DriverId: DriverId
        };

        var getData = DriverAJService.getDriverById(DriverMaster);
        getData.then(function (pDriverMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pDriverMaster.data.ErrorMessage != null) {
                $scope.errMsg = pDriverMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
         
            $scope.DriverId = pDriverMaster.data.DriverId;
            $scope.DriverName = pDriverMaster.data.DriverName;
            $scope.VendorId = pDriverMaster.data.TransporterID;
            $scope.DriverMobileNo = pDriverMaster.data.DriverMobileNo;
            $scope.LicenseNumber = pDriverMaster.data.LicenseNumber;
            $scope.ValidityDate = pDriverMaster.data.ValidityDate;
            $scope.VendorName = pDriverMaster.data.VendorName;
           // $scope.VendorList = $scope.tempVendorList;
            

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Driver Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (DriverId) {
        showFirst(DriverId);
    }

    function clearDriverList() {
        $scope.DriverList = [];
        GetAllDrivers();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.DriverId = undefined;
        $scope.DriverName = undefined;
        $scope.DriverMobileNo = undefined;
        $scope.LicenseNumber = undefined;
        $scope.ValidityDate = undefined;
        $scope.VendorId = undefined;
        $scope.VendorName = undefined;
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.DriverName == undefined || $scope.DriverName == "") {
            $scope.errMsg = "Driver Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDriverName").focus();
            return;
        }

        if ($scope.LicenseNumber == undefined || $scope.LicenseNumber == "") {
            $scope.errMsg = "License Number is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDriverLicenseNbr").focus();
            return;
        }
      
        if ($scope.ValidityDate == undefined || $scope.ValidityDate == "") {
            $scope.errMsg = "Validity Date is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtValidityDate").focus();
            return;
        }

        var DriverMaster = {
            DriverId: $scope.DriverId,
            DriverName: $scope.DriverName,           
            DriverMobileNo: $scope.DriverMobileNo,
            LicenseNumber: $scope.LicenseNumber,
            ValidityDate: $scope.ValidityDate,
            TransporterID: $scope.VendorId,
            LocationId: $localStorage.locationId
            };

        var saveData = DriverAJService.saveDriverData(DriverMaster);
        saveData.then(function (pDriverMaster) {

            if (pDriverMaster.data.ErrorMessage != null && pDriverMaster.data.ErrorMessage != "") {
                $scope.errMsg = pDriverMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
             
                $scope.DriverId = pDriverMaster.data.DriverId;
                //$scope.TerminalList = [];
                //clearDriverList();
                //GetDriverList();
           
                showFirst($scope.DriverId);
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Driver Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
                if ($scope.DriverList.length!=0) {
                    filteredList = $filter('filter')($scope.DriverList, { DriverName: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.DriverList = filteredList;
                    }                   
                }
        }
        else {
            $scope.DriverList = $scope.tempDriverList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('DriverList', function () {
        if ($scope.DriverList != undefined) {
            showFirst($scope.DriverList[0].DriverId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
  
});

