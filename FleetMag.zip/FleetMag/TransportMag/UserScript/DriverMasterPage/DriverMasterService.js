﻿app.service("DriverAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

  
    this.saveDriverData = function (DriverMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/DriverMaster/SaveDetails",
            data: JSON.stringify(DriverMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllDrivers = function (DriverMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/DriverMaster/LoadAllDrivers",
            data: JSON.stringify(DriverMaster),
            dataType: "json"
        });
        return response;
    }

    this.getDriverById = function (DriverMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/DriverMaster/LoadDriverById",
            data: JSON.stringify(DriverMaster),
            dataType: "json"
        });
        return response;
    }

})