﻿app.service("RoleAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    //this.GetAllPorts = function () {
    //    var response = $http({
    //        method: "post",
    //        url: baseUrl + "/ServiceMaster/LoadAllPorts",
    //        dataType: "json"
    //    });
    //    return response;
    //}


    this.GetAllJobMenuItems = function (pJobMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/LoadAllJobMenuItems",
            data: JSON.stringify(pJobMaster),
            dataType: "json"
        });
      //  
        return response;
    }

    this.GetJobMenuItems = function (pJobMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/LoadMenuItems",
            data: JSON.stringify(pJobMaster),
            dataType: "json"
        });
        //  
        return response;
    }

    this.saveData = function (JobMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/SaveDetails",
            data: JSON.stringify(JobMaster),
            dataType: "json"
        });
        return response;
    }
    this.GetAllJobs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/LoadAllJobs",
            dataType: "json"
        });
        return response;
    }

    // All Menu Items and Data of perticulare Job.

    this.getJobById = function (JobMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/LoadAllJobMenuItems",
            data: JSON.stringify(JobMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetJobMasterByID = function (JobMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/RoleDefinition/LoadJobById",
            data: JSON.stringify(JobMaster),
            dataType: "json"
        });
        return response;
    }
})