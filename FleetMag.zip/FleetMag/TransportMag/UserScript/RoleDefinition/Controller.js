﻿app.controller("mvcRoleCtrl", function ($scope, $localStorage, $compile, $filter, RoleAJService, HomeIndex, ErrorMsgDisplay) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    var appendlst = "";
    JobList();
    




    function GetAllJobMenuItems() {
        //   
        var JobMaster = {
            JobId: $scope.JobId
        };
        var getData = RoleAJService.GetAllJobMenuItems(JobMaster);

        getData.then(function (Response) {
            $scope.JobMenuItems = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting RailIcd " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetAllMenuItems() {
        
        var getData = RoleAJService.GetJobMenuItems();

        getData.then(function (Response) {
            
            $scope.JobMenuItems = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting RailIcd " + reason.data;
            $scope.isError = true;
            return;
        });
    };   


    function JobList() {
        var GetData = RoleAJService.GetAllJobs();

        GetData.then(function (pJobs) {
            $scope.JobList = pJobs.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempJobList = $scope.JobList

            //GetAllJobs();

        }, function (reason) {
            $(JobS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    function GetAllJobs() {
        var uiEle = angular.element(document.querySelector('#LpJobs'));
        $('#LpJobs').html('');
        angular.forEach($scope.JobList, function (value, key) {
            if (!jQuery.isEmptyObject(value.JobName)) {
                appendlst = appendlst + "<li><a href=\"#\" ng-click=\"commonSource('" + value.JobId + "')\"><span class=\"fa fa-caret-right tree-icon\"></span>" + value.JobName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var JobList = $compile(appendlst)($scope);
        uiEle.append(JobList);
        appendlst = "";
    }

    $scope.commonSource = function (JobId) {
        showFirst(JobId);
        $scope.isShownEdit = false;
        $scope.isShown = true;
    }

    function showFirst(JobId) {
        var JobMaster = {
            JobId: JobId
        };


        // job Nane and Id of Perticular Job.
        var getJobData = RoleAJService.GetJobMasterByID(JobMaster);
        getJobData.then(function (pJobDtls) {
            $scope.JobId = pJobDtls.data.JobId;
            $scope.JobName = pJobDtls.data.JobName;

        });



        var getData = RoleAJService.getJobById(JobMaster);
        getData.then(function (pJobMaster) {

            $scope.errMsg = "";
            $scope.isError = false;

            if (pJobMaster.data.ErrorMessage != null) {
                $scope.errMsg = pJobMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }          
            $scope.JobMenuItems =pJobMaster.data;
        }, function () {
            clearData();

          
            $scope.isError = true;
            return;
        });
    }


    $scope.filter = function () {
        var filteredList;

        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {

            if ($scope.JobList.length != 0) {
                filteredList = $filter('filter')($scope.JobList, {JobName: $scope.SrchRecord });

                if (filteredList != undefined) {
                    $scope.JobList = filteredList;

                }

            }
        }
        else {
            $scope.JobList = $scope.tempJobList;
        }   

    }


    ////====================================================Watch for first page load=====================================================================//
    var watchlist = $scope.$watch('JobList', function () {
        if ($scope.JobList != undefined) {
            showFirst($scope.JobList[0].JobId);
            watchlist();
        }
    });

    $scope.SaveDtls = function () {
        
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;

        if ($scope.JobName == undefined || $scope.JobName == "") {           
         
           
            $scope.errMsg = "Please Enter Role Name"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtRole").val('');
            setTimeout(function () {
                $("#txtRole").focus();
            }, 500);
            return;
        }

     


        if (emptyData == false) {
            //var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);
            var JobMaster = {
                JobId: $scope.JobId,
                JobName: $scope.JobName,
                List: $scope.JobMenuItems               
            };

            var saveData = RoleAJService.saveData(JobMaster);
            saveData.then(function (pJobMaster) {

                if (pJobMaster.data.ErrorMessage != null && pJobMaster.data.ErrorMessage != "") {
                    $scope.errMsg = pJobMaster.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.errMsg = "";
                    $scope.isError = false;
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    JobList();
                    showFirst(pJobMaster.data.JobId);
                }
            }, function () {
                clearData();
                //$(JobMasterS).each(function (index, item) {
                //    if (item.Key == 'Message3') {
                //        $scope.setclass = "popupBase alert alertShowMsg";
                //        $scope.errMsg = item.value;
                //    }
                //});

                $scope.isError = true;
                return;
            });
        }
    }
    
    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
       clearData();
      
       $scope.isShown = false;
       $scope.isShownEdit = true;
    }
    //====================================================End Add Event=====================================================================//
    //====================================================Add Event=====================================================================//
    $scope.CancelDtls = function () {
        clearData();        
        $scope.isShown = true;
        $scope.isShownEdit = true;
    }
    //====================================================End Add Event=====================================================================//
    //====================================================edit event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = true;
    }
    //====================================================End Edit Event=====================================================================//
    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
    //====================================================End Cancel Event=====================================================================//
     //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.JobId = undefined;
        $scope.JobName = undefined;
        $scope.JobMenuItems = [];
        GetAllMenuItems();
    }
    //====================================================End Clear form data=====================================================================//
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }




});

