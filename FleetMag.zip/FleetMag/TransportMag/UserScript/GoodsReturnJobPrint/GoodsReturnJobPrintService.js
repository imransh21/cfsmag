﻿app.service("GoodReturnJobPrintAJService", function ($http) {

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
      

    this.VehicleDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetStockJobVehicleDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetStockReqDataPrint = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetStockReqData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

});