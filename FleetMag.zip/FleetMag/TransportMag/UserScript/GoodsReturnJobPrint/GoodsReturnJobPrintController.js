﻿app.controller("cntrlGoodReturnJob", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodReturnJobPrintAJService) {
    DisplayData();

    function DisplayData() {
        
        var InputParam = {
            WisId: $sessionStorage.WisId,
            DepotId: $sessionStorage.DepotId,
        }
        var getData = GoodReturnJobPrintAJService.VehicleDetails(InputParam);
        getData.then(function (Response) {
            $scope.VehicleDetailsList = Response.data;
            GetItemDetails(InputParam);
        });
    }


    function GetItemDetails(ItemDtlsParam) {
        var GetItemData = GoodReturnJobPrintAJService.GetStockReqDataPrint(ItemDtlsParam);
        GetItemData.then(function (Response) {
            $scope.VehicleItemDetailsList = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }


    
})