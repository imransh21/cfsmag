﻿app.controller("mvcEmployeeCtrl", function ($scope, $sessionStorage, $filter, $compile, $timeout, EmployeeService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;


    var appendlst = "";
    GetEmpList();

    $("#btnAdd").focus();


   //====================================================Get Employee List=====================================================================//
    function GetEmpList() {
        debugger;
        var pEmp = {
            BranchId: $sessionStorage.locationId
        };
        var GetData = EmployeeService.GetAllEmployees(pEmp);
       
        GetData.then(function (pEmp) {
            $scope.EmpList = pEmp.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempEmpList = $scope.EmpList;
           

        }, function (reason) {
            $scope.errMsg = "Error in getting Employee " + reason.data;
            $scope.isError = true;
            return;
        });
    }

 
    function GetAllEmp() {
        var uiEle = angular.element(document.querySelector('#LpEmp'));
        $('#LpEmp').html('');
        angular.forEach($scope.EmpList, function (value, key) {
            if (!jQuery.isEmptyObject(value.EmpId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.EmpId + "')\">" + value.EmployeeName + "</a></li>";
               
            }
        });       
        var Employee = $compile(appendlst)($scope);
        uiEle.append(Employee);
        appendlst = "";
    }

    function showFirst(EmpId)
    {
        debugger;
        var EmpMaster = {
            EmpId: EmpId
        };

        var getData = EmployeeService.getEmpById(EmpMaster);
        getData.then(function (pEmpMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pEmpMaster.data.ErrorMessage != null) {
                $scope.errMsg = pEmpMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
          
            $scope.EmpId = pEmpMaster.data.EmpId;
            $scope.EmpCode = pEmpMaster.data.EmpCode;
            $scope.EmployeeName = pEmpMaster.data.EmployeeName;
            $scope.BranchId = pEmpMaster.data.BranchId;
            $scope.Designation = pEmpMaster.data.Designation;
            $scope.ActiveStatus = pEmpMaster.data.ActiveStatus;
            $scope.PreferedArea = pEmpMaster.data.PreferedArea;
            $scope.Dob = pEmpMaster.data.Dob;
            $scope.CellNo = pEmpMaster.data.CellNo;
            $scope.EmgContNo = pEmpMaster.data.EmgContNo;
            $scope.Address = pEmpMaster.data.Address;
            $scope.City = pEmpMaster.data.City;
            $scope.State = pEmpMaster.data.State;
          //  $("#txtState").data('ui-autocomplete')._trigger('source', 'autocompletesource', {});
            $scope.Pin = pEmpMaster.data.Pin;
            $scope.DomPerDayRate = pEmpMaster.data.DomPerDayRate;
            $scope.OtRate = pEmpMaster.data.OtRate;
            $scope.EmployeeCard = pEmpMaster.data.EmployeeCard;
            $scope.IntPerDayRate = pEmpMaster.data.IntPerDayRate;
            $scope.Rating = pEmpMaster.data.Rating;
            $scope.Department = pEmpMaster.data.Department;
          
        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Employee Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (EmpId) {
        showFirst(EmpId);
    }

    function clearEmpList() {
        $scope.EmpList = [];
        GetAllEmp();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
       
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
       
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    
   
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        debugger;
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.EmpCode == undefined || $scope.EmpCode == "") {
            $scope.errMsg = "Employee Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtEmployeeCode").focus();
            return;
        }

        if ($scope.EmployeeName == undefined || $scope.EmployeeName == "") {
            $scope.errMsg = "Employee Name   is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtEmployeeName").focus();
            return;
        }

        if ($scope.Designation == undefined || $scope.Designation == "") {
            $scope.errMsg = " Designation is required.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDesignation").focus();
            return;
        }
        if ($scope.State == undefined || $scope.State == "") {
            $scope.errMsg = " State is required.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtState").focus();
            return;
        }
      
       
        var EmpMaster = {
            EmpId: $scope.EmpId,
            EmpCode: $scope.EmpCode,
            BranchId: $sessionStorage.locationId,
            EmployeeName: $scope.EmployeeName,
            Designation: $scope.Designation,
            ActiveStatus: $scope.ActiveStatus,
            PreferedArea: $scope.PreferedArea,
            Dob: $scope.Dob,
            CellNo: $scope.CellNo,
            EmgContNo: $scope.EmgContNo,
            Address: $scope.Address,
            City: $scope.City,
            State: $scope.State,
            Pin: $scope.Pin,
            DomPerDayRate: $scope.DomPerDayRate,
            OtRate: $scope.OtRate,
            EmployeeCard:$scope.EmployeeCard,
            IntPerDayRate: $scope.IntPerDayRate,
            Rating: $scope.Rating,
            Department : $scope.Department
            };

        var saveData = EmployeeService.saveEmpData(EmpMaster);
        saveData.then(function (pEmpMaster) {

            if (pEmpMaster.data.ErrorMessage != null && pEmpMaster.data.ErrorMessage != "") {
                $scope.errMsg = pEmpMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
                $scope.EmpId = pEmpMaster.data.EmpId;               
                clearEmpList();
                GetEmpList();
                showFirst($scope.EmpId);
            }
        }, function () {
            clearFields();
            $scope.errMsg = "Error in saving Employee Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
                if ($scope.EmpList.length!=0) {
                    filteredList = $filter('filter')($scope.EmpList, { EmployeeName: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.EmpList = filteredList;
                    }                   
                }
        }
        else {
            $scope.EmpList = $scope.tempEmpList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('EmpList', function () {
        if ($scope.EmpList != undefined) {
            showFirst($scope.EmpList[0].EmpId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//
  
    $scope.updFlag = function (row) {     
            row.Flag = "U";       
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    

    function clearData() {
        $scope.EmpId = undefined;
        $scope.EmpCode = undefined;
        $scope.EmployeeName = undefined;
        $scope.BranchId = undefined;
        $scope.Designation = undefined;
        $scope.ActiveStatus = 'N';
        $scope.PreferedArea = undefined;
        $scope.Dob = undefined;
        $scope.CellNo = undefined;
        $scope.EmgContNo = undefined;
        $scope.Address = undefined;
        $scope.City = undefined;
        $scope.State = undefined;
        $scope.Pin = undefined;
        $scope.DomPerDayRate = undefined;
        $scope.OtRate = undefined;
        $scope.EmployeeCard = undefined;
        $scope.IntPerDayRate = undefined;
        $scope.Rating = undefined;
        $scope.Department = undefined;
       // $scope.SCList = [];
    }

});

