﻿app.service("LoginAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.validateUserDtls = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/ValidateUser",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllLocationData = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/GetAllLocations",
            dataType: "json"
        });
        return response;
    }

    //save new User
    this.SaveData = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/Save",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }

    //forgot passwrod
    this.ForgotPwdDtls = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/SendForgotPwdMail",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }


    //forgot UserId
    this.ForgotUserIdDtls = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/SendForgotUserIdMail",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }


    //check username
    this.CheckUserName = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/CheckForUsername",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }
})