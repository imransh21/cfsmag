﻿app.controller("mvcLoginCtrl", function ($scope, $sessionStorage,$state, LoginAJService) {
   
    //===========================Password validation===========================
   
    $scope.errMsg = "";
    GetAllLocations();


    function GetAllLocations() {
        var getLocationData = LoginAJService.GetAllLocationData();
        getLocationData.then(function (result) {
            var defaltvalue = {
                LocationId: "",
                LocationName: "Select"
            }
            var tempLocation = result.data;
            tempLocation.unshift(defaltvalue);
            $scope.locationList = tempLocation;           
            $scope.LocationId = "";           
        });
    }
    //====================================================Validate User=====================================================================//    
    $scope.validateUser = function () {
        $scope.MailSentMsg = "";
        $scope.isMailSent = false;
      
     
        if ($scope.userName == undefined || $scope.userName == "") {

            $(login).each(function (index, item) {
                if (item.Key == 'Message1') {
                    //$scope.class = "popupBase alert alertShowMsg";
                    ErrorPopupMsg('ErrorDiv');
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;


            //$scope.errMsg = setErrorMsg($(login), 'Message1');
            //$scope.class = "popupBase alert alertShowMsg";
            //$scope.isError = true;
            //return;
        }

        if ($scope.password == undefined || $scope.password == "") {
            $(login).each(function (index, item) {
                if (item.Key == 'Message2') {
                    ErrorPopupMsg('ErrorDiv');
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        }
           
        var userMaster = {
            UserName: $scope.userName,
            Password: $scope.password,
            LocationId: $scope.LocationId,
            CaptchaCode: $scope.txtCaptchaCode,
            Otp: $scope.Otp
        };

        var getUserData = LoginAJService.validateUserDtls(userMaster);
        getUserData.then(function (msg) {

            if (msg.data != '') {
                if (msg.data.ErrorMessage != '') {
                    ErrorPopupMsg('ErrorDiv');
                    $scope.errMsg = msg.data.ErrorMessage;                   
                }
                else {
                    $sessionStorage.loginUser = $scope.userName;
                    userNameTemp = $sessionStorage.loginUser;                    
                    $sessionStorage.locationId = $scope.LocationId;
                    $sessionStorage.jobId = msg.data.JobId;
                    $sessionStorage.CustomerId = msg.data.CustomerId;
                    $sessionStorage.CustomerRefCode = msg.data.CustomerRefCode;
                    $sessionStorage.UserType = msg.data.UserType;
                    $sessionStorage.menu = msg.data.Menu;
                    if ($sessionStorage.UserType == 'I') {
                        getIndexpage();
                    }
                    else {                     
                        getSupplierPoratalpage();
                    }
                }
            }          
            //if (msg.data.Menu.length != 0) {
            //    // alert(msg.data.LocationId);
            //    $localStorage.jobId = msg.data.JobId;
            
            //    $localStorage.menu = msg.data.Menu;
            
            //    $localStorage.adminUserStatus = msg.data.AdminUserStatus;
            //    if (msg.data.PasswordChangeDate == "" || msg.data.ForgetPassword=="Y") {
            //        $localStorage.needPasswordChange = true;
            //    }
            //    else {
            //        $localStorage.needPasswordChange = false;
            //    }
            //    getIndexpage();
            //}
            //else {
            //    ErrorPopupMsg('ErrorDiv');
            //    $scope.errMsg = msg.data;
            //}
            
        }, function () {
            clearData();
            //alert('Error in Login');
            $(login).each(function (index, item) {
                if (item.Key == 'Message3') {
                    ErrorPopupMsg('ErrorDiv');
                   
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            //throw Error();
            return;
        });
    }
    

    

    //====================================================End Validate User=====================================================================//
    $scope.preventPaste = function (e) {
        e.preventDefault();
        return false;
    };
    //====================================================Redirect to IndexPage=====================================================================//
    $("#btnOK").click(function () {
        //alert('ok click.....');
        $scope.class = "popupBase alert display:none !important;"
        $scope.errMsg = "";
           });
   
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";       
    }

    function getSupplierPoratalpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/SupplierPortal";   
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    //====================================================Clear Screen=====================================================================//
    function clearData() {
        $scope.userName = "";
        $scope.password = "";
        $scope.txtCaptchaCode = "";
    }
    //====================================================End Clear Screen=====================================================================//

  //====================================================Forgot Password=====================================================================//
  
    $scope.SendForgotPwdMail = function () {
      
        $scope.errMsg = "";
        $scope.isError = false;
        
        if ($scope.ForgetUserName == undefined || $scope.ForgetUserName == "") {
            $(login).each(function (index, item) {
                if (item.Key == 'Message1') {
                    ErrorPopupMsg('ErrorDiv');
                    //  $('#diverrmsg').addClass("alertShowMsg");
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        }

        var userMaster = {
            UserName: $scope.ForgetUserName
        };
        
        var getUserData = LoginAJService.ForgotPwdDtls(userMaster);
        getUserData.then(function (msg) {
            if (msg.data == "Sent mail to registered Mail Id.") {
                $scope.MailSentMsg = msg.data;
                $scope.isMailSent = true;
                //$scope.userName = undefined;
                $scope.errMsg = msg.data;
                $scope.isError = false;
                ErrorPopupMsg('ErrorDivG');
                $('#ForgotPasword').modal('hide');
            }
            else {
                clearData();

                $scope.errMsg = msg.data;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
        }, function () {
            clearData();
            $(login).each(function (index, item) {
                if (item.Key == 'Message12') {
                    ErrorPopupMsg('ErrorDiv');
                    //  $('#diverrmsg').addClass("alertShowMsg");
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }
    //====================================================End Forgot Password=====================================================================//


    //====================================================Forgot UserId=====================================================================//

    $scope.SendForgotUserIdMail = function () {
        
        $scope.errMsg = "";
        $scope.isError = false;
        
        if ($scope.ForgetUserMailId == undefined || $scope.ForgetUserMailId == "") {
            $(login).each(function (index, item) {
                if (item.Key == 'Message1') {
                    ErrorPopupMsg('ErrorDiv');
                    //  $('#diverrmsg').addClass("alertShowMsg");
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        }

        var userMaster = {
            MailId: $scope.ForgetUserMailId
        };
        
        var getUserData = LoginAJService.ForgotUserIdDtls(userMaster);
        getUserData.then(function (msg) {
            if (msg.data == "Sent mail to registered Mail Id.") {
                $scope.MailSentMsg = msg.data;
                $scope.isMailSent = true;
                //$scope.userName = undefined;
                $scope.errMsg = msg.data;
                $scope.isError = false;
                ErrorPopupMsg('ErrorDivG');
                $('#ForgotUserId').modal('hide');
            }
            else {
                clearData();

                $scope.errMsg = msg.data;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
        }, function () {
            clearData();
            $(login).each(function (index, item) {
                if (item.Key == 'Message12') {
                    ErrorPopupMsg('ErrorDiv');
                    //  $('#diverrmsg').addClass("alertShowMsg");
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }
    //====================================================End Forgot UserId=====================================================================//




    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
});

