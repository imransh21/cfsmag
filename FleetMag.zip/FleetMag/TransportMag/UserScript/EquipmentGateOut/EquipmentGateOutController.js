﻿app.controller("ctrEquipGateOutPendency", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, EquipmentGateOutAJService, HomeIndex) {
    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = true;
    $scope.isShownPrint = false;
    $scope.isShownTransferId = true;
    $scope.EquipTransferDtls = [];
    $scope.isShownJob = true;
  

  //  RowList();
  
    function RowList() {
        
        var InputParam = {
            JobNo: "",
            JobDate: "",
            EquipmentName: "",
            EquipmentType: "",
            ToLocation: "",
            Purpose: ""
        }
        $scope.EquipTransferDtls.push(InputParam);
    }
   
      $scope.GetDataFilter = function () {
          
          var InputParam = {
              locationId: $sessionStorage.locationId,
              JobId: $scope.JobId,
              FromDt: $scope.fromDate,
              ToDt: $scope.Todate
          }
          var GetData = EquipmentGateOutAJService.GetPendingList(InputParam);
          GetData.then(function (Response) {
              
              $scope.EquipTransferDtls = Response.data;            
              $scope.isShownSave = true;
          });        

      }

      $scope.CheckAll = function () {
          
          angular.forEach($scope.EquipTransferDtls, function (value, key) {
              if ($scope.SelectAllData == 'N') {
                  value.IsCheck = "N";
              }
              else {
                  if ($scope.SelectAllData == 'Y') {
                      value.IsCheck = "Y";
                  }
              }
          })
      };


      $scope.SaveDtls = function () {
          
        var ErrorTemp = undefined;
            
        var temp = $scope.EquipTransferDtls.filter(function (value) {
            return value.IsCheck == "Y";
        });

        if (temp.length == 0) {
            $scope.errMsg = "Please Select at least one checkbox.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

              var InputParam = {
             locationId:$sessionStorage.locationId,
             ApproveBy: $sessionStorage.loginUser,
            arrEquipmentTransferDtls: $scope.EquipTransferDtls
        }
        var GetData = EquipmentGateOutAJService.SaveTransferDtls(InputParam);
        GetData.then(function (Response) {
            
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null || Response.data.ErrorMessage == undefined) {
                //$scope.JobNo = Response.data.JobNo;
                //$scope.JobId = Response.data.JobId;
                //$scope.JobDate = Response.data.JobDate;
                $scope.isshownAdd = false;
                $scope.isShown = true;
                $scope.isShownSearch = true;
                $scope.isShownAdd = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShownPrint = false;
                $scope.SuccessMsg = "Data Saved........................";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;                
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });


    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
  
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    function ClearData() {
        $scope.JobNo = undefined;
        $scope.JobId = undefined;
        $scope.fromDate = undefined;
        $scope.Todate = undefined;
        $scope.EquipTransferDtls = [];

    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isshownAdd = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownTransferId = true;
        
    }

    $scope.ClearDetails = function () {
        $scope.isShown = true;
        $scope.isShownLease = true;
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShownTransferId = true;
        $scope.isshownAdd = false;
        $scope.isShownJob = true
        ClearData();
    }

  
});