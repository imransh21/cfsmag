﻿app.controller("ctrEqipmentTransfer", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, EquipmentTransferAJService, HomeIndex) {
    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownPrint = false;
    $scope.isShownTransferId = true;
    $scope.EquipTransferDtls = [];
    $scope.isShownJob = true;
    GetVehicleList();
    GetAllLocations();
    

      function GetVehicleList() {
          
          var GetData = EquipmentTransferAJService.GetVehicleList();
          $scope.VehicleList = [];
          GetData.then(function (Response) {
              //var defaltvalue = {
              //    VehicleId: "",
              //    VehicleNo: "Select"
              //}
              var tempVehicleList = Response.data;
              //tempVehicleList.unshift(defaltvalue);
              $scope.VehicleList = tempVehicleList;
          }, function (reason) {
              $scope.errMsg = "Error in getting Equipment " + reason.data;
              $scope.isError = true;
              return;
          });
      };

      function GetAllLocations() {
          var getLocationData = EquipmentTransferAJService.GetAllLocationData();
          getLocationData.then(function (result) {
              //var defaltvalue = {
              //    LocationId: "",
              //    LocationName: "Select"
              //}
              var tempLocation = result.data;
              //tempLocation.unshift(defaltvalue);
              $scope.locationList = tempLocation;
              $scope.LocationId = "";
          });
      }

    

      $scope.TruckTypeChange = function (EquipId) {
          
          $scope.EquipmentType = undefined;
          //var currentSelected = $filter('filter')($scope.VehicleTypeList, { Pkey: EquipTypeId })[0]
          var InputParam = {
              VehicleId: EquipId,
              LocationId: $sessionStorage.locationId,
          }
          var GetData = EquipmentTransferAJService.GetEquipTypeList(InputParam);
          GetData.then(function (Response) {
              
              if (Response.data[0].EquipmentType != undefined ) {
                  $scope.EquipmentType = Response.data[0].EquipmentType;
                 
              }
              else {
                  $scope.EquipmentType = undefined;
                 
              }
           
          })
          }


    //$scope.ValidateDepo = function () {
    //    if ($scope.FromDepoId == $scope.ToDepoId) {
    //        $scope.errMsg = 'Same depo goods transfer not allowed';
    //        $scope.ToDepoId = undefined;
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }
    //}
          
      $scope.SaveDtls = function () {
          
        var ErrorTemp = undefined;
        if ($scope.EquipmentName == undefined || $scope.EquipmentName == '') {
                    ErrorTemp = "Please Select Equipment Name ";
          }
            
        if ($scope.ToLocation == undefined || $scope.ToLocation == '') {
                    ErrorTemp = "Please Select To Location";
          }

        if (ErrorTemp != undefined) {
            $scope.errMsg = ErrorTemp;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            LocationId: $sessionStorage.locationId,
            EquipmentId: $scope.EquipmentName,
            ToLocationId: $scope.ToLocation,
            Purpose:$scope.Purpose
        }
        var GetData = EquipmentTransferAJService.SaveTransferDtls(InputParam);
        GetData.then(function (Response) {
            
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null || Response.data.ErrorMessage == undefined) {
                $scope.JobNo = Response.data.JobNo;
                $scope.JobId = Response.data.JobId;
                $scope.JobDate = Response.data.JobDate;
                $scope.isshownAdd = false;
                $scope.isShown = true;
                $scope.isShownSearch = true;
                $scope.isShownAdd = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShownPrint = false;
                $scope.SuccessMsg = "Data Saved........................";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;                
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });


    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
  
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    function ClearData() {
        $scope.JobNo = undefined;
        $scope.JobDate = undefined;
        $scope.EquipmentName = undefined;
        $scope.EquipmentType = undefined;
        $scope.ToLocation = undefined;
        $scope.Purpose = undefined;
        $scope.LocationId = undefined;
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isshownAdd = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownTransferId = true;
       
        
    }

    $scope.ClearDetails = function () {
        $scope.isShown = true;
        $scope.isShownLease = true;
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShownTransferId = true;
        $scope.isshownAdd = false;
        $scope.isShownJob = true

        if ($("#txtJobNo").hasClass('ui-autocomplete-input')) {
            $("#txtJobNo").autocomplete("destroy");
            $("#txtJobNo").removeData('autocomplete');
        }
        ClearData();
    }

    $scope.SearchDtls = function () {
        
        ClearData();
        $scope.isAddRowShown = true;
      

        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownTransferId = false;
        $scope.isShownJob = false;

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtJobNo").autocomplete({
            source: function (request, response) {

                
                var InputParam = {
                    JobNo: request.term,
                    LocationId: $sessionStorage.locationId
                }
                $.ajax({
                    url: baseUrl + '/Transport/EquipmentTransfer/GetTransferLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.JobNo,
                                JobId: item.JobId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.JobNo = i.item.label;
                    $scope.JobId = i.item.JobId;
                    $scope.SearchData();
                });
            },
            minLength: 0
        }).focus(function (e, i) {
            $(".txtJobNo").autocomplete("search", "");
        });



    }


    $scope.SearchData = function () {
        GetTransforDetailsById();
    }

    function GetTransforDetailsById() {
        var InputParam = {
            JobId: $scope.JobId,
            LocationId:$sessionStorage.locationId
        }
        var GetData = EquipmentTransferAJService.RetrieveData(InputParam);
        GetData.then(function (Response) {
            
            $scope.JobNo = Response.data.JobNo;
            $scope.JobDate = Response.data.JobDate;
            $scope.JobId = Response.data.JobId;
            $scope.EquipmentName = Response.data.EquipmentId;
            $scope.ToLocation = Response.data.ToLocationId;
            $scope.Purpose = Response.data.Purpose;
            $scope.TruckTypeChange($scope.EquipmentName);
            $scope.isShownJob = true;
            $scope.isShownSave = false;
           
        });
    }
});