﻿app.service("EquipmentTransferAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetVehicleList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/GetVehicleList",
            dataType: "json"
        });
        return response;
    }

    this.GetEquipTypeList = function (InputData) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/GetEquimentList",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

    this.GetAllLocationData = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Login/GetAllLocations",
            dataType: "json"
        });
        return response;
    }

   
    this.SaveTransferDtls = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/SaveEqipTransferDtls",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

    this.RetrieveData = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipmentTransfer/RetrieveData",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

});