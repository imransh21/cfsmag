﻿app.service("GoodsIssueJobAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleJobDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsIssueJob/GetStockJobVehicleDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetItemJobDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsIssueJob/GetStockReqData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.SaveStockIssue = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsIssueJob/SaveMaterialIssue",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetStockListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsIssueJob/GetStockListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


});