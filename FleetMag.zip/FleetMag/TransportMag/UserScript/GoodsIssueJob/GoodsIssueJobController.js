﻿app.controller("CntrlGoodsIssueJob", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay,  GoodsIssueJobAJService) {

    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownPrint = false;
    DepoLookupList();

    function DepoLookupList() {
        var GetData = GoodsIssueJobAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    $scope.VehicleDetails = function () {
        if ($scope.WisId == undefined || $scope.WisId == "" || $scope.WisId == '') {
            $scope.errMsg = "Please select the JobCardNo from the List"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            WisId: $scope.WisId,
            DepotId: $scope.DepotId
        }

        var GetData = GoodsIssueJobAJService.GetVehicleJobDetails(InputParam);
        GetData.then(function (Response) {
            $scope.VehicleDetailsList = Response.data;
            $sessionStorage.WisId = $scope.WisId;
            $sessionStorage.DepotId = $scope.DepotId;
            GetItemDetails(InputParam);
            $scope.isShownSave = true;            
            $scope.isShownPrint = true;
           
        });

    }


    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            JobNo: $scope.FilterJobCardNo,
            VehicleNo: $scope.FilterVehicleNo
        }
        var GetData = GoodsIssueJobAJService.GetStockListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.RequiredJobCardLst = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }


    $scope.GetDataSearch = function (row) {
     
        clearData();
        $scope.isShown = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;

        $scope.JobNo = row.JOB_NO;
        $scope.WisDate = row.WIS_DATE;
        $scope.WisId = row.WIS_ID;
        $scope.DepotId = $scope.FilterDepotId;
        $scope.VehicleDetails();
        
        $("#divQlist").modal('hide');
                
    }



    function GetItemDetails(ItemDtlsParam) {
        
        var GetItemData = GoodsIssueJobAJService.GetItemJobDetails(ItemDtlsParam);
        GetItemData.then(function (Response) {
            
            $scope.VehicleItemDetailsList =$.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.AddDtls = function () {
        clearData();  
    }

    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownSave = false;
        $scope.isShownClear = false;
        $scope.isShownPrint = false;
    }

    $scope.SearchDtls = function () {
        clearData();
        $scope.isShown = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $("#divQlist").modal('show');

        }

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function clearData() {       
        $scope.isShown = true;
        $scope.DepotId = undefined;
        $scope.JobNo = undefined;
        $scope.WisDate = undefined;
        $scope.VehicleDetailsList = [];
        $scope.VehicleItemDetailsList = [];
    }

    $scope.IssueQtyChange = function (row) {
        if (row.IN_STOCK <= 0) {            
            $scope.errMsg = "Stock not available to issue"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.CurrentIssueQty = 0;
            return;
        }

        var RequiredQty = row.REQUEST_QTY - row.issue_qty
        if (row.CurrentIssueQty < 0) {            
            $scope.errMsg = "Please Enter positive values"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.CurrentIssueQty = 0;
            return;
        }

        if (row.CurrentIssueQty > RequiredQty) {
            $scope.errMsg = "Issuing More then requested qty not allowed"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');        
            row.CurrentIssueQty = 0;
            return;
        }


    }


     $scope.PrintDtls = function () {
        
        getGoodIssueJobPrintPage();
    }

     function getGoodIssueJobPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Store/GoodsIssueJob/GoodsIssueJobPrint";

    }


    $scope.SaveDtls = function () {
        var MeterialList = [];
        angular.forEach($scope.VehicleItemDetailsList, function (value, key) {
            var inpparam={
                WisId:value.wis_id,
                MId:value.M_ID,
                ItemId:value.ITEM_ID,
                DeportId:$scope.DepotId,
                RequestQty:value.REQUEST_QTY-value.issue_qty,
                IssueQty:value.CurrentIssueQty                
            }
            MeterialList.push(inpparam);
        });

        var InputParam = {
            WisId: $scope.WisId,
            MaterialDetails: MeterialList
        }
        var SaveInventryData = GoodsIssueJobAJService.SaveStockIssue(InputParam);
        SaveInventryData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.errMsg = "Data Saved........................."
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                
                var InputParam = {
                    WisId: $scope.WisId,
                    DepotId: $scope.DepotId
                }
                GetItemDetails(InputParam);
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });
    }

});