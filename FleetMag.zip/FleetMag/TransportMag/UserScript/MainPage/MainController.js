﻿app.controller("mvcMainCtrl", function ($scope, $sessionStorage, $state, $filter, $compile, MainAJService) {

    GetAllLocations();
   // menuList();

    $scope.Logout = function () {
        var CallLogout = MainAJService.CallLogout();
        CallLogout.then(function (result) {
            if (result.data == 'Done') {
                $sessionStorage.$reset();
                getLoginpage();
            }
        });
    }

    function getLoginpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl;
    }

    function GetAllLocations() {
        var getLocationData = MainAJService.GetAllLocationData();
        getLocationData.then(function (result) {
            $scope.locationList = result.data;
            setTimeout(function () {
                $scope.LocationId = $sessionStorage.locationId;
                $scope.UserName = $sessionStorage.loginUser;
                $scope.$apply();
            }, 1000);

        });
    }

    function getLoginpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl;
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";      
    }
 
    $scope.GoMaintenance = function () {
        $sessionStorage.ModuleCode = 'Maintenance';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Maintenance";        
    }

    $scope.GoTransportation = function () {    
        $sessionStorage.ModuleCode = 'Transport';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Transportation";       
    }

    $scope.GoTyreManagement = function () {
        $sessionStorage.ModuleCode = 'Transport';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/TyreManagement";
    }

    $scope.GoMonitoring = function () {
        $sessionStorage.ModuleCode = 'Monitoring';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Monitoring";       
    }

    $scope.GoReports = function () {
        $sessionStorage.ModuleCode = 'Reports';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Reports";
      
    }

    $scope.GoAnalysis = function () {
        $sessionStorage.ModuleCode = 'Analysis';
        //menuList();
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Analysis";
      
    }

    $scope.GoConfigration = function () {
        $sessionStorage.ModuleCode = 'Configuration';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Configration";
    }

    $scope.GoHome = function () {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    $scope.GoStore = function () {
        $sessionStorage.ModuleCode = 'Store';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    $scope.GoWareHose = function () {
        $sessionStorage.ModuleCode = 'Warehouse';
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Warehouse";
    }

    $scope.commonSource = function (MenuItemList) {
        $state.go(MenuItemList);
    }

});

