﻿app.service("BookingAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.GetContTypeLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetContTypeListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetCommodityLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetCommodityListLookup",
            dataType: "json"
        });
        return response;
    }



    this.GetCargoPkgLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetCargoPkgListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetContainerList = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetContainerDetails",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }



    this.GetCargoList = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetCargoDetails",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }

    this.EmployeeLookup = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetAccountManagerLookup",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }
    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/SavaDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.GetBookingDetailsById = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetBookingDtlsByID",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }
    
    this.GetInsuredList = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetInsuredDetails",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }


    this.GetBookingCargoDetailsById = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetCargoBookingDtlsByID",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }


    this.saveCargoData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/SavaCargoDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetBookingContainerDetailsById = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetContainerBookingDtlsByID",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }


    this.GetBookingWarehouseContainerDetailsById = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetWarehouseContainerBookingDtlsByID",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }


    this.saveWHContainerJobData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/SavaWHJobDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetBookingWareHouseCargoDetailsById = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/Booking/GetWareHouseCargoBookingDtlsByID",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }
})