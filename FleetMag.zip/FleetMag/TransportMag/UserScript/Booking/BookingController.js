﻿app.controller("cntrlBooking", function ($scope, $rootScope, $sessionStorage, $filter, $compile, $timeout, BookingAJService, ErrorMsgDisplay, KeyRefrenceCtrlAJService, ItemMasterAJService, IndentGenAJService) {
    $scope.isShown = true;
    $scope.isShownDepot = true;
    $scope.isShownBookingNo = true;
    ContTypeLookupList();
    CommodityTypeLookupList();
    CargoPkgTypeLookupList();
    GetContainerList(0);
    EmployeeLookupList();
    GetCARGOList(0);
    GetVehicleTypeList();
    var rows = 4;
    function ContTypeLookupList() {
        var GetData = BookingAJService.GetContTypeLookupList();
        GetData.then(function (Response) {
            $scope.contTypeList = Response.data;
        });
    }
    GetUnitLists();

    GetInsuredList(0)

    DepoLookupList();

    $scope.GetCargoJobData = function (CargoDtlId) {
        
        GetCargoJobData(CargoDtlId);
    }

    $scope.GetWHCargoJobData = function (CargoDtlId) {
        
        GetWHCargoJobData(CargoDtlId);
    }


    function GetWHCargoJobData(CargoDtlId) {
        
        var InputParam = {
            BookingId: $scope.BookingId,
            //LocationId: $scope.LocationId
            CargoDtlId: CargoDtlId,
            LocationId: $sessionStorage.locationId
        }
        var BookingData = BookingAJService.GetBookingWareHouseCargoDetailsById(InputParam);
        BookingData.then(function (result) {

            
            $scope.WHCargoDtlId = result.data.CargoDtlId
            $scope.WHCargoBookingNo = result.data.BookingNo;
            $scope.WHCargoOrigin = result.data.OriginCity;
            $scope.WHCargoDest = result.data.DestCity;
            $scope.WHCargoBookedQuantity = result.data.CargoBookedQuantity;
         //   $scope.WHCargoBookedWeight = result.data.CargoBookedWeight
            $scope.WHCargoAllocatedQuantity = result.data.CargoAllocatedQuantity,
            //  $scope.WHCargoAllocatedWeight = result.data.CargoAllocatedWeight,
            $scope.WHCargoCurrentQty = result.data.CargoCurrentQty,
            $scope.WHCargoCommodity = result.data.WarehouseCargoCommodity;

        });
    }


    function GetCargoJobData(CargoDtlId) {
        
        var InputParam = {
            BookingId: $scope.BookingId,
            //LocationId: $scope.LocationId
            CargoDtlId: CargoDtlId,
            LocationId: $sessionStorage.locationId
        }
        var BookingData = BookingAJService.GetBookingCargoDetailsById(InputParam);
        BookingData.then(function (result) {

            
            $scope.CargoDtlId = result.data.CargoDtlId
            $scope.CargoBookingNo = result.data.BookingNo;
            $scope.CargoOrigin = result.data.OriginCity;
            $scope.CargoDest = result.data.DestCity;
            $scope.CargoBookedQuantity = result.data.CargoBookedQuantity;
            $scope.CargoBookedWeight = result.data.CargoBookedWeight
            $scope.CargoAllocatedQuantity = result.data.CargoAllocatedQuantity,
            $scope.CargoAllocatedWeight = result.data.CargoAllocatedWeight,
              $scope.CargoCurrentQty = result.data.CargoCurrentQty,
            $scope.CargoCurrentWeight = result.data.CargoCurrentWeight

        });
    }

    $scope.GetWarehouseContainerJobData = function (CargoDtlId) {
        
        GetWarehouseContainerJobData(CargoDtlId);
    }


    function GetWarehouseContainerJobData(ContainerDtlId) {
        
        var InputParam = {
            BookingId: $scope.BookingId,
            //LocationId: $scope.LocationId
            CargoDtlId: ContainerDtlId,
            LocationId: $sessionStorage.locationId
        }
        var BookingData = BookingAJService.GetBookingWarehouseContainerDetailsById(InputParam);
        BookingData.then(function (result) {

            
            $scope.WHContainerDtlId = ContainerDtlId;
            $scope.WHContBookingNo = result.data.BookingNo;
            $scope.WHContainerOrigin = result.data.OriginCity;
            $scope.WHContainerDest = result.data.DestCity;
            $scope.WarehouseContainerBookedQuantity = result.data.WarehouseContainerBookedQuantity;

            $scope.WarehouseContainerAllocatedQuantity = result.data.WarehouseContainerAllocatedQuantity,

              $scope.WarehouseContainerCurrentQty = result.data.WarehouseContainerCurrentQty,
            $scope.WarehouseContainerSize = result.data.WarehouseContainerSize,
               $scope.WarehouseContainerType = result.data.WarehouseContainerType,
             $scope.WarehouseContainerCommodity = result.data.WarehouseContainerCommodity
        });
    }



    $scope.GetContainerJobData = function (CargoDtlId) {
        
        GetContainerJobData(CargoDtlId);
    }

    function GetContainerJobData(ContainerDtlId) {
        
        var InputParam = {
            BookingId: $scope.BookingId,
            //LocationId: $scope.LocationId
            CargoDtlId: ContainerDtlId,
            LocationId: $sessionStorage.locationId
        }
        var BookingData = BookingAJService.GetBookingContainerDetailsById(InputParam);
        BookingData.then(function (result) {

            
            $scope.ContainerDtlId = ContainerDtlId;
            $scope.ContainerBookingNo = result.data.BookingNo;
            $scope.ContainerOrigin = result.data.OriginCity;
            $scope.ContainerDest = result.data.DestCity;
            $scope.ContainerBookedQuantity = result.data.ContainerBookedQuantity;

            $scope.ContainerAllocatedQuantity = result.data.ContainerAllocatedQuantity,

              $scope.ContainerCurrentQty = result.data.ContainerCurrentQty,
            $scope.ContainerSize = result.data.ContainerSize,
               $scope.ContainerType = result.data.ContainerType,
             $scope.ContainerCommodity = result.data.ContainerCommodity
        });
    }



    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function GetUnitLists() {
        //   
        var getData = ItemMasterAJService.GetUnit();

        getData.then(function (Response) {
            $scope.UnitList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Roles " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            var TempVehicleTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVehicleTypeList.unshift(defaltvalue);
            $scope.VehicleTypeList = TempVehicleTypeList;
            $scope.TruckType1 = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function EmployeeLookupList() {

        var p = {
            BranchId: 1// $sessionStorage.locationId
        }
        
        var EmployeeLookup = BookingAJService.EmployeeLookup(p);
        EmployeeLookup.then(function (result) {
            $scope.EmployeeLookupData = (result.data);
        });
    }


    function CommodityTypeLookupList() {
        var GetData = BookingAJService.GetCommodityLookupList();
        GetData.then(function (Response) {
            $scope.CommodityList = Response.data;
        });
    }

    function CargoPkgTypeLookupList() {
        var GetData = BookingAJService.GetCargoPkgLookupList();
        GetData.then(function (Response) {
            $scope.CargoPkgList = Response.data;
        });
    }




    function GetContainerList(BookingId) {
        
        var Input = {
            BookingId: $scope.BookingId
        }
        var GetData = BookingAJService.GetContainerList(Input);
        GetData.then(function (Response) {
            
            $scope.ContainerLst = Response.data;
            if ($scope.ContainerLst.length < rows) {
                for (i = $scope.ContainerLst.length; i < rows; i++) {
                    var newItem = { ContSize: 0, CommodityId: 0, ContType: "", IsRef: 'N', IsHaz: 'N', IsOdc: 'N' }
                    $scope.ContainerLst.push(newItem);
                }
            }
        });
    }


    function GetInsuredList(BookingId) {
        
        var Input = {
            BookingId: $scope.BookingId
        }
        var GetData = BookingAJService.GetInsuredList(Input);
        GetData.then(function (Response) {
            $scope.InsuranceLst = Response.data;
            if ($scope.InsuranceLst.length < rows) {
                for (i = $scope.InsuranceLst.length; i < rows; i++) {
                    var newItem = { VendorId: 0, ValidDate: "" }
                    $scope.InsuranceLst.push(newItem);
                }
            }
        });
    }

    $scope.CurrentIndex1 = function (row) {
        $scope.DtlCurrentIndex = row;
    }

    $scope.CurrentIndexCont = function (row) {
        $scope.DtlCurrentIndexCont = row;
    }
    function GetCARGOList(BookingId) {
        
        var Input = {
            BookingId: $scope.BookingId
        }
        var GetData = BookingAJService.GetCargoList(Input);
        GetData.then(function (Response) {
            $scope.CargoLst = Response.data;
            if ($scope.CargoLst.length < rows) {
                for (i = $scope.CargoLst.length; i < rows; i++) {
                    var newItem = { CommodityId: 0, CargoPkgId: "", IsLqd: 'N', Quantity: 0, Weight: 0, Unit: '', Volume: 0, VehicleType: '', FclLcl: '' }
                    $scope.CargoLst.push(newItem);
                }
            }

        });
    }


    $scope.SaveDtls = function () {



        var InputParam = {
            BillParty: $scope.BillParty,
            DepotId: $scope.DepotId,
            BookingId: $scope.BookingId,
            BookingNo: $scope.BookingNo,
            ShipperId: $scope.ShipperId,
            ConsigneeId: $scope.ConsigneeId,
            ForwardingAgentId: $scope.ForwardingAgentId,
            ContactRefNo: $scope.ContactRefNo,
            OriginId: $scope.OriginId,
            DestinationId: $scope.DestinationId,
            PickupAddress: $scope.PickupAddress,
            DestinationId: $scope.DestinationId,
            DropupAddress: $scope.DropupAddress,
            BookedBy: $scope.BookedBy,
            AccountManagerId: $scope.AccountManagerId,
            EffectFrom: $scope.EffectFrom,
            EffectTo: $scope.EffectTo,
            MovementType: $scope.MovementType,
            FlatBuildingPlotOrigin: $scope.FlatBuildingPlotOrigin,
            FlatBuildingPlotDest: $scope.FlatBuildingPlotDest,
            SectorAreaStreetOrigin: $scope.SectorAreaStreetOrigin,

            SectorAreaStreetDest: $scope.SectorAreaStreetDest,
            CityPincodeOrigin: $scope.CityPincodeOrigin,
            CityPincodeDest: $scope.CityPincodeDest,


            BookingCargoList: $scope.CargoLst,
            BookingContList: $scope.ContainerLst,
            BookingInsuranceList: $scope.InsuranceLst

        }
        var GetData = BookingAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                
                $scope.BookingId = Response.data.BookingId;
                $scope.SearchBooking();
                $scope.isShown = true;
                $scope.isShownDepot = true;
                $scope.isShownBookingNo = true;
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });
    }


    $scope.SaveCargoJob = function () {

        

        var InputParam = {
            LocationId: $sessionStorage.locationId,
            Size: 0,
            BookingId: $scope.BookingId,
            NoOfContainer: $scope.CargoCurrentQty,
            Weight: $scope.CargoCurrentWeight,
            JobType: 'Cargo',
            CargoDtlId: $scope.CargoDtlId


        }
        var GetData = BookingAJService.saveCargoData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                

                //$scope.SearchBooking();
                GetCARGOList($scope.BookingId);
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });
    }


    $scope.SaveContainerJob = function () {

        

        var InputParam = {
            LocationId: $sessionStorage.locationId,
            Size: $scope.ContainerSize,
            BookingId: $scope.BookingId,
            NoOfContainer: $scope.ContainerCurrentQty,
            Weight:0,
            JobType: 'Container',
            CargoDtlId: $scope.ContainerDtlId


        }
        var GetData = BookingAJService.saveCargoData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                

                //$scope.SearchBooking();
                GetContainerList($scope.BookingId);
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });
    }






    $scope.SaveWHContJob = function () {

        

        var InputParam = {
            LocationId: $sessionStorage.locationId,
            Size: $scope.ContainerSize,
            BookingId: $scope.BookingId,
            NoOfContainer: $scope.WarehouseContainerCurrentQty,
            Weight: 0,
            JobType: 'Container',
            CargoDtlId: $scope.WHContainerDtlId,
            RequiredArea: $scope.RequiredArea,
            Isorigin:$scope.Isorigin,
            Isdestination:$scope.Isdestination

        }
        var GetData = BookingAJService.saveWHContainerJobData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                

                //$scope.SearchBooking();
                GetContainerList($scope.BookingId);
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });
    }

    $scope.SaveWHCargoJob = function () {

        

        var InputParam = {
            LocationId: $sessionStorage.locationId,
            Size: 0,
            BookingId: $scope.BookingId,
            NoOfContainer: $scope.WHCargoCurrentQty,
            Weight: 0,
            JobType: 'Cargo',
            CargoDtlId: $scope.WHCargoDtlId,
            RequiredArea: $scope.WHCargoRequiredArea,
            Isorigin: $scope.Isorigin,
            Isdestination: $scope.Isdestination

        }
        var GetData = BookingAJService.saveWHContainerJobData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                

                //$scope.SearchBooking();
                GetContainerList($scope.BookingId);
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });
    }

    $scope.SearchBooking = function () {
        SearchBookingById();
    }



    function SearchBookingById() {
        
        var InputParam = {
            BookingId: $scope.BookingId,
            //LocationId: $scope.LocationId
            LocationId: $sessionStorage.locationId
        }
        var BookingData = BookingAJService.GetBookingDetailsById(InputParam);
        BookingData.then(function (result) {

            
            $scope.BookingDate = result.data.BookingDate;
            $scope.BookingNo = result.data.BookingNo;
            $scope.BookBy = result.data.BookBy;
            $scope.BookedByName = result.data.BookedByName;
            $scope.ShipperId = result.data.ShipperId;
            $scope.ShipperAddress = result.data.ShipperAddress
            $scope.ShipperName = result.data.ShipperName,
            $scope.ShipperCity = result.data.ShipperCity,
            $scope.ShipperStreet = result.data.ShipperStreet,
             $scope.ShipperState = result.data.ShipperState,
            //$scope.//PanNo = result.data.PanNo,
            //$scope.//TanNo = result.data.TanNo,
            $scope.ShipperPostalCode = result.data.ShipperPostalCode,
            $scope.ShipperEmail = result.data.ShipperEmail,
            $scope.ShipperPhoneNumber = result.data.ShipperPhoneNumber,

            $scope.ShipperContactPerson = result.data.ShipperContactPerson


            $scope.ConsigneeId = result.data.ConsigneeId,
              $scope.ConsigneeAddress = result.data.ConsigneeAddress
            $scope.ConsigneeName = result.data.ConsigneeName,
            $scope.ConsigneeCity = result.data.ConsigneeCity,
            $scope.ConsigneeStreet = result.data.ConsigneeStreet,
             $scope.ConsigneeState = result.data.ConsigneeState,
            //$scope.//PanNo = result.data.PanNo,
            //$scope.//TanNo = result.data.TanNo,
            $scope.ConsigneePostalCode = result.data.ConsigneePostalCode,
            $scope.ConsigneeEmail = result.data.ConsigneeEmail,
            $scope.ConsigneePhoneNumber = result.data.ConsigneePhoneNumber,

            $scope.ConsigneeContactPerson = result.data.ConsigneeContactPerson



            $scope.ForwardingAgentId = result.data.ForwardingAgentId,
              $scope.ForwardingAddress = result.data.ForwardingAddress
            $scope.ForwardingName = result.data.ForwardingName,
            $scope.ForwardingCity = result.data.ForwardingCity,
            $scope.ForwardingStreet = result.data.ForwardingStreet,
             $scope.ForwardingState = result.data.ForwardingState,
            //$scope.//PanNo =result.data.PanNo,
            //$scope.//TanNo =result.data.TanNo,
            $scope.ForwardingPostalCode = result.data.ForwardingPostalCode,
            $scope.ForwardingEmail = result.data.ForwardingEmail,
            $scope.ForwardingPhoneNumber = result.data.ForwardingPhoneNumber,

            $scope.ForwardingContactPerson = result.data.ForwardingContactPerson


            $scope.BillParty = result.data.BillParty,

              $scope.BillPartyName = result.data.BillPartyName,

            $scope.ContactRefNo = result.data.ContactRefNo,
            $scope.OriginId = result.data.OriginId,
             $scope.OriginCity = result.data.OriginCity;
            $scope.DestCity = result.data.DestCity;
            $scope.DestinationId = result.data.DestinationId,
            $scope.PickupAddress = result.data.PickupAddress,
            $scope.DestinationId = result.data.DestinationId,
            $scope.DropupAddress = result.data.DropupAddress,

            $scope.AccountManagerId = result.data.AccountManagerId,
            $scope.EffectFrom = result.data.EffectFrom,
            $scope.EffectTo = result.data.EffectTo,
            $scope.MovementType = result.data.MovementType

            $scope.FlatBuildingPlotOrigin = result.data.FlatBuildingPlotOrigin
            $scope.FlatBuildingPlotDest = result.data.FlatBuildingPlotDest
            $scope.SectorAreaStreetOrigin = result.data.SectorAreaStreetOrigin

            $scope.SectorAreaStreetDest = result.data.SectorAreaStreetDest
            $scope.CityPincodeOrigin = result.data.CityPincodeOrigin
            $scope.CityPincodeDest = result.data.CityPincodeDest

            GetContainerList($scope.BookingId)
            GetCARGOList($scope.BookingId);
            GetInsuredList($scope.BookingId);
        });
    }


    function ClearData() {
        $scope.BookBy = undefined;
        $scope.BookedByName = undefined;
        $scope.BookingId = undefined;
        $scope.BookingNo = undefined;
        $scope.BookingDate = undefined;
        $scope.ShipperId = undefined;;
        $scope.ShipperAddress = undefined;
        $scope.ShipperName = undefined;
        $scope.ShipperCity = undefined;
        $scope.ShipperStreet = undefined;
        $scope.ShipperState = undefined;
        //$scope.//PanNo = result.data.PanNo,
        //$scope.//TanNo = result.data.TanNo,
        $scope.ShipperPostalCode = undefined;
        $scope.ShipperEmail = undefined;
        $scope.ShipperPhoneNumber = undefined;

        $scope.ShipperContactPerson = undefined;


        $scope.ConsigneeId = undefined;
        $scope.ConsigneeAddress = undefined;
        $scope.ConsigneeName = undefined;
        $scope.ConsigneeCity = undefined;
        $scope.ConsigneeStreet = undefined;
        $scope.ConsigneeState = undefined;
        //$scope.//PanNo = result.data.PanNo,
        //$scope.//TanNo = result.data.TanNo,
        $scope.ConsigneePostalCode = undefined;
        $scope.ConsigneeEmail = undefined;
        $scope.ConsigneePhoneNumber = undefined;

        $scope.ConsigneeContactPerson = undefined;



        $scope.ForwardingAgentId = undefined;
        $scope.ForwardingAddress = undefined;
        $scope.ForwardingName = undefined;
        $scope.ForwardingCity = undefined;
        $scope.ForwardingStreet = undefined;
        $scope.ForwardingState = undefined;
        //$scope.//PanNo =result.data.PanNo,
        //$scope.//TanNo =result.data.TanNo,
        $scope.ForwardingPostalCode = undefined;
        $scope.ForwardingEmail = undefined;
        $scope.ForwardingPhoneNumber = undefined;

        $scope.ForwardingContactPerson = undefined;


        $scope.BillParty = undefined;

        $scope.BillPartyName = undefined;

        $scope.ContactRefNo = undefined;
        $scope.OriginId = undefined;
        $scope.OriginCity = undefined;
        $scope.DestCity = undefined;
        $scope.DestinationId = undefined;
        $scope.PickupAddress = undefined;
        $scope.DestinationId = undefined;
        $scope.DropupAddress = undefined;

        $scope.AccountManagerId = undefined;
        $scope.EffectFrom = undefined;
        $scope.EffectTo = undefined;
        $scope.MovementType = undefined;

        $scope.FlatBuildingPlotOrigin = undefined;
        $scope.FlatBuildingPlotDest = undefined;
        $scope.SectorAreaStreetOrigin = undefined;

        $scope.SectorAreaStreetDest = undefined;
        $scope.CityPincodeOrigin = undefined;
        $scope.CityPincodeDest = undefined;
        $scope.DepotId = undefined;
        GetContainerList(0)
        GetCARGOList(0);
        GetInsuredList(0);
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownDepot = false;
        $scope.isShown = false;
        $scope.isShownBookingNo = true;

    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isShownBookingNo = false;
        $scope.isShownDepot = false;
        setTimeout(function () {
            $("#lstDepo").focus();
        }, 500);
        $scope.isShownPoNo = false;

    }

    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShown = true;
        $scope.isShownDepot = true;
        $scope.isShownBookingNo = true;
    }

});

