﻿app.controller("CntrlGoodsReceiptGSecurity", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay,IndentGenAJService, GoodsReceiptGSecurityAJService) {

    $scope.isShown = true;
    $scope.isShownpo = true;
    $scope.isShownGrr = true;
    $scope.isShownPrint = true;
    $scope.GetPoDetails = function () {
        debugger;
        //   
        var o = {
            PoNo: $scope.PoNo
        };
        var getData = GoodsReceiptGSecurityAJService.GetPoData(o);

        getData.then(function (Response) {
            $scope.PoDetailsList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    var rows=5;
    addRow();

    function addRow() {
        $scope.PoDetailsList = [];
        if ($scope.PoDetailsList.length < rows) {
            for (k = $scope.PoDetailsList.length; k < rows; k++) {
                var newItem = { ItemName: "", ItemNo:""}
                $scope.PoDetailsList.push(newItem);

            }
        }

    }
    DepoLookupList();

    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    $scope.AddDtls = function () {
        
        clearData();
        //$scope.isShownSave = true;
        setTimeout(function () {
            $("#lstDepo").focus();
        }, 500);
        
        $scope.isShownpo = false;
        $scope.isShownPrint = true;


    }

    $scope.CancelDtls = function () {
        clearData();
       
    }

    $scope.SearchDtls = function () {
        clearData();
        $scope.isShownpo = true;
        $scope.isShownGrr = false;
        setTimeout(function () {
            $("#txtGrrNo").focus();
        }, 500);

    }

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function clearData() {
        $scope.isShownPrint = true;
        $scope.isShown = true;
        $scope.isShownpo = true;
        $scope.isShownGrr = true;
        $scope.DepotId = undefined;
        $scope.GrRefNo = undefined;
        $scope.GrDate = undefined;
        $scope.PoNo = undefined;
        $scope.VendorId =undefined;
        $scope.CustomerDcNo=undefined;
        $scope.CustomerDcDate=undefined;
        $scope.Remark = undefined;
        $scope.VendorName = undefined;
        $scope.DeliveryAddress = undefined;
        $scope.PoDetailsList = undefined;
        addRow();
    }





    $scope.updFlag = function (row, index) {
        
        var strlen = 0;
        if (row.ReceivedQty != "" && row.ReceivedQty != undefined) {
            if (parseFloat(row.ReceivedQty) < parseFloat(row.PoQty)) {
                row.ShortQty = parseFloat(row.PoQty) - parseFloat(row.ReceivedQty);
                row.ExcessQty = 0;

            } else if (parseFloat(row.ReceivedQty) > parseFloat(row.PoQty)) {
                row.ExcessQty = parseFloat(row.ReceivedQty) - parseFloat(row.PoQty);
                row.ShortQty = 0;

            }
        }else
        {
            row.ExcessQty = 0;
            row.ShortQty = 0;
        }

    }



    $scope.showFirst =function (GrRefId) {
        var ItemMaster = {
            GrRefId: GrRefId
        };

        var getData = GoodsReceiptGSecurityAJService.getItemById(ItemMaster);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya
                $scope.isError = true;
                return;
            }
            $scope.GrRefNo = Response.data.GrRefNo;
            $scope.GrDate = Response.data.GrDate;
            $scope.PoNo = Response.data.PoNo;
            $scope.VendorId = Response.data.VendorId;
            $scope.VendorName = Response.data.VendorName;
            $scope.CustomerDcNo = Response.data.CustomerDcNo;
            $scope.CustomerDcDate = Response.data.CustomerDcDate;
            $scope.Remark = Response.data.Remark
            $scope.DepotId = Response.data.DepotId;
            $scope.DeliveryAddress = Response.data.DeliveryAddress;

            $sessionStorage.GrRefId = JSON.stringify($scope.GrRefId);
            $scope.PoDetailsList = Response.data.List;
            $scope.isShownPrint = false;
        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }




    $scope.SaveDtls = function () {
        



     
        if ($scope.PoNo == '' || $scope.PoNo == undefined) {
            $scope.errMsg = "Please Select Po No."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPONo").val('');
            setTimeout(function () {
                $("#txtPONo").focus();
            }, 500);
            return;
        }


        if ($scope.CustomerDcNo == '' || $scope.CustomerDcNo == undefined) {
            $scope.errMsg = "Please Enter Customer Dc No ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtCustomerDcNo").val('');
            setTimeout(function () {
                $("#txtCustomerDcNo").focus();
            }, 500);
            return;
        }


        if ($scope.CustomerDcDate == '' || $scope.CustomerDcDate == undefined) {
            $scope.errMsg = "Please Select Customer Dc Date."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtCustomerDcDate").val('');
            setTimeout(function () {
                $("#txtCustomerDcDate").focus();
            }, 500);
            return;
        }


        PoListData = $scope.PoDetailsList.filter(function (value) {
            return value.IsItemchk == "Y";
        });

        if (PoListData.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Item No.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var ErrorFound = false;
        angular.forEach($scope.PoDetailsList, function (value, key) {
            if (ErrorFound == false) {
                if (value.IsItemchk == "Y" && (value.ReceivedQty <=0 ||value.ReceivedQty==undefined||value.ReceivedQty=="")) {

                    $scope.errMsg = "Please Enter Received Qty";

                    ErrorFound = true;
                    return;
                }
            }
            })

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            DepotId:$scope.DepotId,
            PoNo: $scope.PoNo,
            VendorId: $scope.VendorId,
            CustomerDcNo: $scope.CustomerDcNo,
            CustomerDcDate: $scope.CustomerDcDate,
            Remark: $scope.Remark,
            List: PoListData
        }
        var GetData = GoodsReceiptGSecurityAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.GrRefId = Response.data.GrRefId;
               
                $scope.showFirst($scope.GrRefId);
                $scope.isShown = true;
                $scope.isShownpo = true;
                // GetAllIndentDetails();
            }
        });
    }



    $scope.PrintDtls = function () {
        
        getIndexPrintPage();
    }

    function getIndexPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Store/GoodsReceiptGSecurity/GoodsReceiptGSecurityPrint";
        target = "_blank";
    }

})