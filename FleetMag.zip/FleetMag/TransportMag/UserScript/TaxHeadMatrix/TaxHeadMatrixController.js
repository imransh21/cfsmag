﻿app.controller("mvcTaxHeadMatrixCtrl", function ($scope, $localStorage, $sessionStorage, $filter, $compile, $timeout, TaxHeadMatrixAJService, TaxGroupsAJService,TaxHeadAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    
    GetTaxGroupsList();
    $scope.TaxGroupHeadsReferenceList = [];

    $("#btnAdd").focus();

    
    function GetTaxGroupsList() {
        var inputValues = {
            LocationId: $sessionStorage.locationId
        }
        var GetData = TaxGroupsAJService.GetAllTaxGroups(inputValues);
       
        GetData.then(function (pTaxGroupsMaster) {
            
            $scope.TaxGroupsList = pTaxGroupsMaster.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempTaxGroupsList = $scope.TaxGroupsList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Tax Groups. " + reason.data;
            $scope.isError = true;
            return;
        });
    }
    
    $scope.TaxGroupCange = function () {
        var pTaxMatrix = {
            TaxGroupId: $scope.TaxGroupId,
            LocationId: $sessionStorage.locationId
        };
        var GetTableData = TaxHeadMatrixAJService.GetAlltaxMatrixList(pTaxMatrix);
        
        GetTableData.then(function (pRailIcd) {
            $scope.dataset = $.parseJSON($.parseJSON(pRailIcd.data));
        }, function (reason) {
            $scope.errMsg = "Error in getting Data " + reason.data;
            $scope.isError = true;
            return;
        });

    }


    function clearTaxGroupsList() {
        $scope.TaxGroupsList = [];
        //GetAllTaxGroups();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        //$scope.TaxGroupId = undefined;
        //$scope.TaxGroupName = undefined;
        //$scope.HsnSacCode = undefined;
        //$scope.TaxGroupHeadsReferenceList = [];
        //DefaultRownGrd();
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
   

    //====================================================Watch for first page load=====================================================================//
    //var watchList = $scope.$watch('TaxGroupsList', function () {
    //    if ($scope.TaxGroupsList != undefined) {
    //        showFirst($scope.TaxGroupsList[0].TaxGroupId);
    //        watchList();
    //    }
    //});
    //====================================================End of Watch for first page load==============================================================//

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
  
});

