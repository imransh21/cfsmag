﻿app.service("TaxHeadMatrixAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

  
    this.GetAlltaxMatrixList = function (pTaxMatrix) {
        var response = $http({
            method: "post",
            url: baseUrl + "/TaxHeadMatrix/LoadAlltaxMatrixList",
            dataType: "json",
            data: JSON.stringify(pTaxMatrix)
        });
        return response;
    }

})