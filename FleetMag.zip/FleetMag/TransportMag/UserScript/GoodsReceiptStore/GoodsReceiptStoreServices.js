﻿app.service("GoodsReceiptStoreAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/SaveDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetPoData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/LoadPoDetailsByPoNo",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.getItemById = function (UserMaster) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/GetGrrDetailsByGrId",
            data: JSON.stringify(UserMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetStoreTransationNo = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/GetRetrieveData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetStockListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReceiptStore/GetStockListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

});