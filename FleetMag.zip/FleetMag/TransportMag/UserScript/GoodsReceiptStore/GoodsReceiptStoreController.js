﻿app.controller("CntrlGoodsReceiptStore", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay,IndentGenAJService, GoodsReceiptStoreAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isAddClick = true;
    $scope.isInWrdTrans = true;
    $scope.PoDetailsList = [];
    $scope.isShownrr = true;
    $scope.isShownpo = true;
    
    for (i = 0; i <= 5; i++) {
        DefaultRownGrd();
    }
    DepoLookupList();
    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }
    //var d = new Date();
    //$scope.InwrdDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());

    $scope.InwrdDate = undefined;

    $scope.GetPoDetails = function () {        
        var o = {
            PoNo: $scope.PoNo
        };
        var getData = GoodsReceiptStoreAJService.GetPoData(o);

        getData.then(function (Response) {
            $scope.PoDetailsList = Response.data;
        

        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }


    $scope.CancelDtls = function () {
        ClearData();
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShown = true;
        $scope.isShownDispaly = false;
        $scope.isShownIndent = true;
        $scope.isAddClick = true;
        $scope.isShownrr = true;
        $scope.isShownPrint = false;
        
        for (i = 0; i <= 5; i++) {
            DefaultRownGrd();
        }
    }


   
        
    

    $scope.AddDtls = function () {
        ClearData();
        $scope.isInWrdTrans = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isAddClick = true;
        $scope.isShown = true;
        $scope.isShownrr = false;
        $scope.isShownpo = true;
        
        
        for (i = 0; i <= 5; i++) {
            DefaultRownGrd();
        }
        var d = new Date();
        $scope.InwrdDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
    }

    $scope.ChangeQnty = function (row) {

        if (row.PoQty > row.ReceivedStoreQty && row.ReceivedStoreQty!=0) {

            row.ShortQty = row.PoQty - row.ReceivedStoreQty;
        }
        else {
            row.ShortQty = 0;
        }
        if (row.PoQty < row.ReceivedStoreQty ) {
            row.ExcessQty = row.ReceivedStoreQty - row.PoQty;
        } else {
            row.ExcessQty = 0;
        }
    }

    $scope.SelectRow=function(row,index){
        $scope.SelectRowIndex = index
        if ($scope.PoDetailsList[$scope.SelectRowIndex].ltGoodsInwordStoreWrrntDtls== undefined) {
            $scope.PoDetailsList[$scope.SelectRowIndex].ltGoodsInwordStoreWrrntDtls = [];
        }
    }

    $scope.AddSubGridRows=function(){
        DefaultSubRownGrd();
    }

    function DefaultSubRownGrd(){
        
        var inputParamSub = {
            ItemSerialNbr: "",
            WarrantyUpto:""
        }        
        $scope.PoDetailsList[$scope.SelectRowIndex].ltGoodsInwordStoreWrrntDtls.push(inputParamSub);
    }
    

    function DefaultRownGrd() {
        var InwordStoreWrrntDtls = [];
        var inputParamSub = {
            ItemSerialNbr: "",
            WarrantyUpto: ""
        }
        InwordStoreWrrntDtls.push(inputParamSub);

        var InputParam = {
            ItemName:"",
            ItemNo:"",
            Make:"",
            UserFor:"",
            HSNCode:"",
            GST:"",
            PoAmt:"",
            PoQty:"",
            ReceivedQty:"",
            ReceivedStoreQty: "",
            ltGoodsInwordStoreWrrntDtls:InwordStoreWrrntDtls
        }
        $scope.PoDetailsList.push(InputParam);
    }

    function padToFour(number) {
        if (number <= 99) { number = ("00" + number).slice(-2); }
        return number;
    }

    $scope.SaveDtls = function () {
        


        if ($scope.DepotId == undefined || $scope.DepotId == "0") {
            $scope.errMsg = "Please select Depot";
             ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.GrRefId == undefined || $scope.GrRefId == "0") {
            $scope.errMsg = "Please Enter GR No";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        var ErrorFound = false;
        angular.forEach($scope.PoDetailsList, function (value, key) {
            if (ErrorFound == false) {
                if ((value.ReceivedStoreQty <= 0 || value.ReceivedStoreQty == undefined || value.ReceivedStoreQty == "")) {
                    $scope.errMsg = "Please Enter Received Qty";
                    ErrorFound = true;
                    return;
                }
            }
        })

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var d = new Date();
        $scope.InwrdDate =  padToFour(d.getDate())  + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
        var InputParam = {
            InwrdTransNbr: $scope.InwrdTransNbr,
            InwrdStoreId: $scope.InwrdStoreId,
            GrRefId:$scope.GrRefId,
            InwrdDate:$scope.InwrdDate,
            PoNo:$scope.PoNo,
            VendorName:$scope.VendorName,
            VendorId:$scope.VendorId,
            DeliveryAddress:$scope.DeliveryAddress,
            CustomerDcNo:$scope.CustomerDcNo,
            CustomerDcDate: $scope.CustomerDcDate,
            DepotId: $scope.DepotId,
            Remark: $scope.Remark,
            ltGoodsInwordStoreDtls: $scope.PoDetailsList
        }
        var getData = GoodsReceiptStoreAJService.saveData(InputParam);
        getData.then(function (Response) {
            
            if (Response.data.ErrorMessage != "") {
                alert(Response.data.ErrorMessage);
                var d = new Date();
                $scope.InwrdDate = padToFour(d.getDate()) + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
            }
            else {
                $scope.InwrdTransNbr = Response.data.InwrdTransNbr;
                $scope.InwrdDate = Response.data.InwrdDate;
                $scope.InwrdStoreId = Response.data.InwrdStoreId;
                $scope.InwrdTransNbr = Response.data.InwrdTransNbr
                //$scope.PoDetailsList = Response.data.ltGoodsInwordStoreDtls;
                //RetrieveData()
                //alert('Data Saved');
               // var d = new Date();
               // $scope.InwrdDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
                $scope.isShownrr = true;
                $scope.isShownReceive = true;
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isShownAdd = true;  
                $scope.isShownSearch = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownExit = false;
                $scope.isShownPrint = false;
                $scope.isShownClear = false;
                

            }
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function ClearData() {
        $scope.InwrdDate = undefined;
        $scope.InwrdTransNbr = undefined;
        $scope.InwrdStoreId = undefined;
        $scope.PoNo = undefined;
        $scope.VendorName = undefined;
        $scope.DeliveryAddress = undefined;
        $scope.CustomerDcNo = undefined;
        $scope.CustomerDcDate = undefined;
        $scope.GrRefNo = undefined;
        $scope.GrDate = undefined;
        $scope.DepotName = undefined;
        $scope.DepotId = undefined;
        $scope.Remark = undefined;
        $scope.PoDetailsList = [];
        

    }

    $scope.InitDateutoComp = function () {
        $('.dateinput').datetimepicker({
            dayOfWeekStart: 1,
            lang: 'en',
            format: 'd/m/Y H:i'
        });
    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isInWrdTrans = false;
        $scope.isShownrr = true;
      //  $("#divQlist").modal('show');
        
       // $scope.isShown = true;
       // var d = new Date();
       /// $scope.InwrdDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtInwordTransNo").autocomplete({
            
            source: function (request, response) {
                var InputParam = {
                    InwrdTransNbr: $("#txtInwordTransNo").val()
                }
                $.ajax({
                    url: baseUrl + '/Store/GoodsReceiptStore/InwordRefLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.InwrdTransNbr,
                                InwrdStoreId: item.InwrdStoreId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.InwrdTransNbr = i.item.InwrdTransNbr;
                    $scope.InwrdStoreId = i.item.InwrdStoreId;
                    $sessionStorage.InwrdStoreId = JSON.stringify(i.item.InwrdStoreId);
                    DisplayData();
                });
            },
            minLength: 1
        });



    }
    function DisplayData() {
        
        var InputParam = {
            InwrdStoreId: $scope.InwrdStoreId
        }
        var getData = GoodsReceiptStoreAJService.GetStoreTransationNo(InputParam);
        getData.then(function (Response) {
            $scope.InwrdTransNbr = Response.data.InwrdTransNbr;
            $scope.InwrdStoreId = Response.data.InwrdStoreId;
            $scope.InwrdDate = Response.data.InwrdDate;
            $scope.PoNo = Response.data.PoNo;
            $scope.DeliveryAddress = Response.data.DeliveryAddress;
            $scope.CustomerDcNo = Response.data.CustomerDcNo;
            $scope.CustomerDcDate = Response.data.CustomerDcDate;
            $scope.VendorName = Response.data.VendorName;
            $scope.VendorId = Response.data.VendorId;
            $scope.DepotName = Response.data.DepotName;
            $scope.DepotId = Response.data.DepotId;
            $scope.GrRefNo = Response.data.GrRefNo;
            $scope.Remark = Response.data.Remark;
            $scope.PoDetailsList = Response.data.ltGoodsInwordStoreDtls;
            $scope.isShownPrint = true;
            $scope.isShownEdit = true;
            $scope.isShownReceive = true;


        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    $scope.EditDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownClear = true;
        $scope.isShownAdd = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = true;
        $scope.isShownReceive = false;
        $scope.isShownPrint = false;
       
    }


    $scope.showFirst = function (GrRefId) {
        
        var InputParam = {
            GrRefId: GrRefId
        };
        var getData = GoodsReceiptStoreAJService.getItemById(InputParam);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.GrRefId = Response.data.GrRefId;
            $scope.GrRefNo = Response.data.GrRefNo;
            $scope.GrDate = Response.data.GrDate;
            $scope.PoNo = Response.data.PoNo;
            $scope.VendorId = Response.data.VendorId;
            $scope.VendorName = Response.data.VendorName;
            $scope.CustomerDcNo = Response.data.CustomerDcNo;
            $scope.CustomerDcDate = Response.data.CustomerDcDate;
           // $scope.Remark = Response.data.Remark;
            $scope.DeliveryAddress = Response.data.DeliveryAddress;
            $scope.DepotName = Response.data.DepotName;
            $scope.DepotId = Response.data.DepotId;
            $scope.PoDetailsList = Response.data.List;

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.GetPoDetails = function () {
        var o = {
            PoNo: $scope.PoNo
        };
        var getData = GoodsReceiptStoreAJService.GetPoData(o);

        getData.then(function (Response) {
            $scope.PoDetailsList = Response.data;


        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    $scope.PrintDtls = function () {
        
        getIndexPrintPage();
    }

    function getIndexPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Store/GoodsReceiptStore/GoodsReceiptStorePrint";

    }


    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            PoNo: $scope.FilterPoNo,
            GrRefNo: $scope.FilterGrrNo
        }
        var GetData = GoodsReceiptStoreAJService.GetStockListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.GoodRetunStoreQlist = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.GetAllDataByRow = function (Row) {
        

        $scope.showFirst(Row.GR_REF_ID);
        //$scope.WisId = Row.WisId,
        //$scope.DepotId = Row.DepotId,
        //$scope.JobNo = Row.JobCardNoQlist,
        //$scope.VehicleNo = Row.VehicleNoQlist,
        //$scope.InwrdStoreId = Row.InwardStoreId
        //DisplayData();
        $("#divQlist").modal('hide');

        //$scope.isShownAdd = false;
        //$scope.isShownEdit = false;
        //$scope.isShownSave = false;
        //$scope.isShownSearch = true;
        //$scope.isShownExit = false;
        //$scope.isShownClear = false;

        $scope.isInWrdTrans = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isAddClick = true;
        $scope.isShown = true;
        $scope.isShownrr = false;
        $scope.isShownpo = true;
    }

});