﻿app.controller("cntrlDailyChecks", function ($scope, $localStorage, $compile, $filter, DailyAJService, HomeIndex, KeyRefrenceCtrlAJService, ErrorMsgDisplay) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShownPattern = false;
    $scope.isShown = false;

    //$scope.UserLocationsList = [];
    var appendlst = "";
    
    //ChecksList();
    GetCheckTypeList();

    GetVehicleTypeList();
    GetEquipmentTypeList();
    GetAllChecklilstData();
    
    function ChecksList() {
        
        var GetData = DailyAJService.GetAllCheckList();

        GetData.then(function (pDepot) {
            
            $scope.ChecksList = pDepot.data;
            $scope.errMsg = "";
            $scope.isError = false;

            //GetAllDepot();

        }, function (reason) {
            $(UserMasterS).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    function GetCheckTypeList() {
        var KeyReference = {
            HeadCode: 'Checks Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.CheckTypeList = [];
        GetData.then(function (Response) {
            
            $scope.CheckTypeList = Response.data;

        }, function (reason) {
            $scope.errMsg = "Error in getting CheckTypeList " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    //$scope.SaveDtls = function () {
    //    $scope.errMsg = "";
    //    $scope.isError = false;
    //    var emptyData = false;
    //    var i1 = 0;
    //    

    //    if (emptyData == false) {
    //        

    //        var VehicleChecks = {
    //            vVehicleCheckDtls: $scope.ChecksList
    //        };

    //        var saveData = DailyAJService.saveData(VehicleChecks);
    //        saveData.then(function (pVehicleChecks) {

    //            if (pVehicleChecks.data.ErrorMessage != null && pVehicleChecks.data.ErrorMessage != "") {
    //                $scope.errMsg = pVehicleAxleConfigHdr.data.ErrorMessage;
    //                $scope.setclass = "popupBase alert alertShowMsg";
    //                $scope.isError = true;
    //                return;
    //            }
    //            else {
    //                
    //                $scope.isShown = true;
    //                $scope.isShownbtn = true
    //                $scope.errMsg = "";
    //                $scope.isError = false;
    //                $scope.isShownPattern = true;
    //                //         $scope.AssetIntId = pVehicleAxleConfigHdr.data;
    //                //    $scope.SearchAssetCodeDtls();
    //                $scope.errMsg = "Data Saved";
    //                ErrorPopupMsg('ErrorDivG');
    //                //VehicleTypeList();
    //                //GetMasterData();

    //            }
    //        }, function () {
    //            //clearFields();
    //            //$(JobMasterS).each(function (index, item) {
    //            //    if (item.Key == 'Message3') {
    //            //        $scope.setclass = "popupBase alert alertShowMsg";
    //            //        $scope.errMsg = item.value;
    //            //    }
    //            //});

    //            $scope.isError = true;
    //            return;
    //        });
    //    }
    //}



    $scope.SaveDtls = function () {
        
        var myRedObjectsNEW = $filter('filter')($scope.ChecksList, { Flag: "N" });
        var myRedObjectsEDIT = $filter('filter')($scope.ChecksList, { Flag: "U" });

        var MergeObject = myRedObjectsNEW.concat(myRedObjectsEDIT);

        angular.forEach(MergeObject, function (value, key) {
            var pCheckType = {};
            var TempObj = [];
            angular.forEach(value.CheckTypeLst, function (value1, key) {
                pCheckType = {
                    CheckValueRefId: value.CheckValueRefId,
                    CheckTypeRefId: value1.Pkey,
                    CodeValue: value1.CodeValue
                }
                TempObj.push(pCheckType)
            });
            value.CheckTypeLst = TempObj

            var pVehicleType = {};
            TempObj2 = [];
            angular.forEach(value.VehicleTypeList, function (value2, key) {
                var pVehicleType = {
                    CheckValueRefId: value.CheckValueRefId,
                    VehicleTypeRefId: value2.Pkey,
                    CodeValue: value2.CodeValue
                }
                TempObj2.push(pVehicleType)
            });
            value.VehicleTypeList = TempObj2


            var pEquipmentType = {};
            TempObj3 = [];
            angular.forEach(value.EquipmentTypeList, function (value3, key) {
                var pEquipmentType = {
                    CheckValueRefId: value.CheckValueRefId,
                    EquipmentTypeRefId: value3.Pkey,
                    CodeValue: value3.CodeValue
                }
                TempObj3.push(pEquipmentType)
            });
            value.EquipmentTypeList = TempObj3
        });



        if (MergeObject.length == 0) {
            $scope.errMsg = "Please Select atleast one check type."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        }

        if (MergeObject.length != 0) {
            var saveData = DailyAJService.saveData(MergeObject);
            saveData.then(function (msg) {                              
                if (msg.data.ErrorMessage == "" || msg.data.ErrorMessage == undefined) {
                    $scope.errMsg = 'Data Saved'
                    ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                    $scope.isShown = true;                    
                    
                }
                else {
                    $scope.errMsg = msg.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
            });
        }
    }


    $scope.CancelDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        $scope.isShownPattern = false;
        $scope.isShown = false;
    }

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
    //====================================================End Cancel Event=====================================================================//
    //====================================================Clear form data=====================================================================//
    //function clearData() {
    //    $scope.DepotCode = undefined;
    //    $scope.DepotName = undefined;
    //    $scope.DepotAddress = undefined;
    //    $scope.ContactPerson = undefined;
    //    $scope.MobileNo = undefined;
    //    $scope.MailId = undefined;
    //    $scope.DepotId = undefined;
    //   // $scope.JobId = undefined;

    //    $scope.UserLocationsList = [];
    //}
    //====================================================End Clear form data=====================================================================//
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    //====================================================Add New Row Event=====================================================================//
    //$scope.AddNewDtls = function () {

    //    var pService = {
    //        //ServiceId: "0", ServiceCode: "", ServiceName: "", Flag: "N", RailOperatorId: "", CtoIcdCode: "", ServiceStatus: "N"
    //        SeqNbr: "", RailIcdId:""
    //    };        
    //    $scope.ServicePorts.push(pService);
    //}
    //====================================================End Add New Row Event=====================================================================//
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }


    function GetVehicleTypeList() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VehicleTypeList = [];
        GetData.then(function (Response) {
            var TempVehicleTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVehicleTypeList.unshift(defaltvalue);
            $scope.VehicleTypeList = TempVehicleTypeList;
            $scope.TruckType1 = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetEquipmentTypeList() {
        var KeyReference = {
            HeadCode: 'EquipmentType',
            GroupCode: 'Vehicle'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.EquipmentTypeList = [];
        GetData.then(function (Response) {
            var TempEquipmentLst = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempEquipmentLst.unshift(defaltvalue);
            $scope.EquipmentTypeList = TempEquipmentLst;
            $scope.EquipmentType = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Equipment Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };





    
    function GetAllChecklilstData() {
        
        var CheckTypeConfigList = DailyAJService.GetAllCheckTypeConfingData();
        
        CheckTypeConfigList.then(function (result) {
            
            $scope.ChecksList = result.data;
            //alert(result.data);
            //var CheckTypeConfig = $.parseJSON(result.data);

            ////for (i = 0; i < CheckTypeConfig.length; i++)
            ////{
            //    var ChecktypeList = [];
            //    var VehicleTypeList = [];
            //    var EquipmentTypeList = [];
            //    alert(CheckTypeConfig[i].CheckTypeLst);
            //    angular.forEach(CheckTypeConfig[i].CheckTypeLst, function (value, key) {
            //        var Param = {
            //            CheckTypeRefId: value.Pkey,
            //            CodeValue: value.CodeValue                     
            //        }
            //        ChecktypeList.push(Param);
            //    });

            //    angular.forEach(CheckTypeConfig[i].VehicleTypeList, function (value, key) {
            //        var Param = {
            //            VehicleTypeRefId: value.Pkey,
            //            CodeValue: value.CodeValue
            //        }
            //        VehicleTypeList.push(Param);
            //    });

            //    angular.forEach(CheckTypeConfig[i].EquipmentTypeList, function (value, key) {
            //        var Param = {
            //            VehicleTypeRefId: value.Pkey,
            //            CodeValue: value.CodeValue
            //        }
            //        EquipmentTypeList.push(Param);
            //    });

            //    CheckTypeConfig[i].CheckTypeLst = ChecktypeList;
            //    CheckTypeConfig[i].VehicleType = VehicleTypeList;
            //    CheckTypeConfig[i].EquipmentType = EquipmentTypeList;
                //$scope.ChecksList = CheckTypeConfig;
           // }
        });
    }




    $scope.selected = function (row) {
        row.Flag = 'U';
    }
});

