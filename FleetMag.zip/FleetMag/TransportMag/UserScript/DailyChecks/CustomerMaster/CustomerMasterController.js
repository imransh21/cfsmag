﻿app.controller("mvcCustomerCtrl", function ($scope, $rootScope, $sessionStorage, $filter, $compile, $timeout, CustomerAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isLineGroup = true; //false
    $scope.isCTO = false;
    //$scope.WagonTypeList = locale.WagonType;
    //$scope.DeckModeList = locale.DeckMode;
    
    var appendlst = "";
    CustomerTypeList();
    //PrincipleCustList();
    
   // GetTerminalList();
    CustomerListAll();
    GetAllState();
    $scope.CustomerTerminalList = [];

    if ($scope.CustomerList != undefined) {
        if ($scope.CustomerList.length > 0) {
            $scope.CustomerId = $scope.CustomerList[0].CustomerId;
        }
    }

    $("#btnAdd").focus();
   
    //====================================================Get All Customer Type Master=====================================================================//
    function CustomerTypeList() {
        var GetData = CustomerAJService.GetAllCustomerType();
        GetData.then(function (pCustomerTypes) {
            $scope.CustomerTypeList = (pCustomerTypes.data);
            $scope.errMsg = "";
            $scope.isError = false;

        }, function (reason) {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in getting Transporters " + reason.data;
            $scope.isError = true;
            return;
        });
    }
    //====================================================End Get All Customer Type Master=====================================================================//

    //====================================================Get All Principle Customers=====================================================================//
    function PrincipleCustList() {
        var GetData = CustomerAJService.GetAllPrincipleCustomers();
        
      
        GetData.then(function (pPrincipleCustomers) {
            $scope.PrincipleCustList = $.parseJSON(pPrincipleCustomers.data);
            //alert($.parseJSON(pPrincipleCustomers.data));
            $scope.errMsg = "";
            $scope.isError = false;

        }, function (reason) {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in getting Principle Customers " + reason.data;
            $scope.isError = true;
            return;
        });
    }
    //====================================================End Get All Principle Customers=====================================================================//

  
   
    //====================================================Get All Itvs=====================================================================//
    function CustomerListAll() {
        
        var GetData = CustomerAJService.GetAllCustomerConfigs();

        GetData.then(function (pCustomers) {
            
            $scope.CustomerList = (pCustomers.data);
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempCustomerList = $scope.CustomerList;
            //GetAllCustomers();

        }, function (reason) {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in getting Customer Configuration " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllState() {
        var GetData = CustomerAJService.GetAllState();

        GetData.then(function (pState) {
            
            $scope.StateList = (pState.data);
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempStateList = $scope.StateList;
            //GetAllCustomers();

        }, function (reason) {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in getting State Configuration " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllCustomers() {
        
        var uiEle = angular.element(document.querySelector('#LpCustomer'));
        $('#LpCustomer').html('');
        angular.forEach($scope.CustomerList, function (value, key) {
            if (!jQuery.isEmptyObject(value.CustomerCode)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.CustomerId + "')\">" + value.CustomerCode + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var Customers = $compile(appendlst)($scope);
        uiEle.append(Customers);
        appendlst = "";
    }

    function showFirst(CustomerId)
    {
        var CustomerMaster = {
            CustomerId: CustomerId
        };

        var getData = CustomerAJService.getCustomerById(CustomerMaster);
        getData.then(function (pCustomerMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pCustomerMaster.data.ErrorMessage != null) {
                $scope.errMsg = pCustomerMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }

            $scope.CustomerCode = pCustomerMaster.data.CustomerCode;
            $scope.CustomerId = pCustomerMaster.data.CustomerId;
            $scope.LocationId = pCustomerMaster.data.LocationId;
            $scope.CustomerName = pCustomerMaster.data.CustomerName;
            $scope.LocalAddress = pCustomerMaster.data.LocalAddress;
            $scope.LocalContactDetails = pCustomerMaster.data.LocalContactDetails;
            $scope.LocalContactNumber = pCustomerMaster.data.LocalContactNumber;
            $scope.LocalMailId = pCustomerMaster.data.LocalMailId;
            $scope.HoAddress = pCustomerMaster.data.HoAddress;
            $scope.PanNo = pCustomerMaster.data.PanNo;
            $scope.TanNo = pCustomerMaster.data.TanNo;
            $scope.Gstin = pCustomerMaster.data.Gstin;
            $scope.CustomerStatus = pCustomerMaster.data.CustomerStatus;
            //$scope.PrincipleMasterList = pCustomerMaster.data.PrincipleLines;
            $scope.PrincipleMasterList = pCustomerMaster.data.CustomersList;
            $scope.CtoBondList = pCustomerMaster.data.CtoBondList;
            $scope.WagonList = pCustomerMaster.data.WagonList;
            $scope.CustomerTerminalList = pCustomerMaster.data.CustomerTerminalList;
            $scope.LicenseNo = pCustomerMaster.data.LicenseNo;
            $scope.FaxNo = pCustomerMaster.data.FaxNo;
            $scope.TelephoneNo = pCustomerMaster.data.TelephoneNo;
            $scope.DoValidFreeDays = pCustomerMaster.data.DoValidFreeDays;
            $scope.PCSCode = pCustomerMaster.data.PCSCode;
            $scope.PortRefernceCode = pCustomerMaster.data.PortRefernceCode;
            //$scope.CustomersList = pCustomerMaster.data.CustomersList;
            
            $scope.StateId = pCustomerMaster.data.StateId;
            $scope.StateName = pCustomerMaster.data.StateName;
            $scope.CityId = pCustomerMaster.data.CityId;
            $scope.CityName = pCustomerMaster.data.CityName;
            $scope.CustomerTypeList = pCustomerMaster.data.CustomerTypes;

            //if (pCustomerMaster.data.CustomerTypes.length != 0) {
                //var foundIsLineGroup;
                //var foundIsCto;

                //angular.forEach($scope.CustomerTypeList, function (value, key) {
                //    $("#chk" + value.CustomerTypeId).prop('checked', false);
                //    $("#chk" + value.CustomerTypeId).on('change', onH1Clicked);

                //    if (value.LineGroup == 'Y') {
                //        foundIsLineGroup = true;
                //    }
                //    $scope.isCTO = false;
                //});

                //angular.forEach(pCustomerMaster.data.CustomerTypes, function (value, key) {
                //    $("#chk" + value.CustomerTypeId).prop('checked', true);
                    
                //    if (value.CustomerTypeId == 3) {
                //        foundIsCto = true; 
                //    }
                //});
                    
                //if (!$scope.$$phase) {
                //        $apply();
                //}

                //if (foundIsLineGroup) {
                //    $scope.isLineGroup = true;
                //}

                //if (foundIsCto) {
                //    $scope.isCTO = true;
                //}
            //}
            //else {
               
            //    angular.forEach($scope.CustomerTypeList, function (value, key) {
            //        $("#chk" + value.CustomerTypeId).prop('checked', false);
            //       // $("#chk" + value.CustomerTypeId).on('change', onH1Clicked);
            //        $scope.isCTO = false;
            //        });

            //       if (!$scope.$$phase) {
            //           $apply();
            //        }
            //}
           
        }, function () {
            clearData();
            CustomerTypeList();
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in fetching Customer Configuration";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (CustomerId) {
        showFirst(CustomerId);
    }


    
    function clearCustomerList() {
        $scope.CustomerList = [];
        GetAllCustomers();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        CustomerTypeList();
        $scope.isShown = false;
        $scope.CustomerStatus = 'Y';
        $scope.isCTO = false;

        //angular.forEach($scope.CustomerTypeList, function (value, key) {
        //    $("#chk" + value.CustomerTypeId).prop('checked', false);
        //    //$("#chk" + value.CustomerTypeId).on('change', onH1Clicked);
        //});

        //if (!$scope.$$phase) {
        //    $apply();
        //}
        //    // var newList = { ActiveStatus: 'Y', PcmId: 0, ParentCustomerId: 0 }
        //var newList = { ActiveStatus: 'Y', PcmId: 0, ParentCustomerId: 0 }
        //   $scope.PrincipleMasterList.push(newList);

       // var newWagonList = { WagonNbr: '', WagonId: 0, WagonType: 'A', DeckMode: 'S', ActiveStatus: 'Y' }
      //  $scope.WagonList.push(newWagonList);

        //var newItem = { TerminalId: 0, CtmId: 0, ReferenceCode: "", CtmStatus: 'Y' }
        //$scope.CustomerTerminalList.push(newItem);
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;

        if ($scope.CustomerId == undefined || $scope.CustomerId == 0 || $scope.CustomerId == "") {
            clearData();

            var watchList = $scope.$watch('CustomerList', function () {
                showFirst($scope.CustomerList[0].CustomerId);
                watchList();
            });
        }
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();
        $rootScope.RemoveTab('divCustMstr');
        $rootScope.GlobcommonSource('divDashboard');
    }

   

    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.CustomerCode = undefined;
        $scope.CustomerId = undefined;
        $scope.LocationId = undefined;
        $scope.CustomerName = undefined;
        $scope.LocalAddress = undefined;
        $scope.LocalContactDetails = undefined;
        $scope.LocalContactNumber = undefined;
        $scope.LocalMailId = undefined;
        $scope.HoAddress = undefined;
        $scope.PanNo = undefined;
        $scope.TanNo = undefined;
        $scope.Gstin = undefined;
        $scope.CustomerStatus = 'N';
        $scope.CustomersList = [];
        $scope.CtoBondList = [];
        $scope.WagonList = [];
        $scope.CustomerTerminalList = [];
        $scope.LicenseNo = undefined;
        $scope.TelephoneNo = undefined;
        $scope.FaxNo = undefined;
        $scope.DoValidFreeDays = undefined;
        $scope.PCSCode = undefined;
        $scope.PortRefernceCode = undefined;
        $scope.PrincipleMasterList = [];
        $scope.StateId = undefined;
        $scope.StateName = undefined;
        $scope.CityId = undefined;
        $scope.CityName = undefined;
        //$('#hdnStateId').val('');
        $scope.CustomerTypeList = [];
    }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.CustomerCode == undefined || $scope.CustomerCode == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Customer Code is required.";
           // $("#txtCustomerCode").focus();
            return;
        }

        if ($scope.CustomerName == undefined || $scope.CustomerName == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Customer Name is required.";
            $("#txtCustomerName").focus();
            return;
        }

        if ($scope.LocalAddress == undefined || $scope.LocalAddress == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Local Address is required.";
            $("#txtLocalAddress").focus();
            return;
        } 

        if ($scope.LocalContactDetails == undefined || $scope.LocalContactDetails == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Local Contact Person is required.";
            $("#txtLocalContactDetails").focus();
            return;
        }

        if ($scope.LocalContactNumber == undefined || $scope.LocalContactNumber == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Local Contact Number is required.";
            $scope.isError = true;
            $("#txtLocalContactNumber").focus();
            return;
        }

        if ($scope.LocalMailId == undefined || $scope.LocalMailId == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Email ID is required.";
            $("#txtLocalMailId").focus();
            return;
        }

        if ($scope.Gstin == undefined || $scope.Gstin == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "GSTIN is required.";
            $("#txtGstin").focus();
            return;
        }

        //if ($scope.PCSCode == undefined || $scope.PCSCode == "") {
        //    $scope.setclass = "popupBase alert alertShowMsg";
        //    $scope.errMsg = "PCS Code is required.";
        //    $("#txtPCSCode").focus();
        //    return;
        //}

        if ($scope.LicenseNo == undefined || $scope.LicenseNo == "") {
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "License No is required.";
            $("#txtLicenseNo").focus();
            return;
        }

        
        var arrCustTypeList = [];
        var sClass = document.getElementsByClassName("chkList");

        if (sClass.length != 0) {
            for (var i = 0; i < sClass.length; i++) {
                var ActiveStatus1;
                if (sClass[i].checked) {
                    ActiveStatus1 = 'Y';
                }
                else {
                    ActiveStatus1 = 'N';
                }
                //if (sClass[i].checked) {
                    var pCustomerTypes = {
                        CustomerId: $scope.CustomerId,
                        CustomerTypeId: sClass[i].id.substring(3, sClass[i].id.length),
                        ActiveStatus: ActiveStatus1
                    }
                    arrCustTypeList.push(pCustomerTypes);
               // }
            }
        }

        //var arrpLineList = [];
       
        //if ($scope.PrincipleMasterList.length != 0) {
        //    for (var i = 0; i < $scope.PrincipleMasterList.length; i++) {
        //        if ($scope.PrincipleMasterList[i].ParentCustomerId > 0) {
        //            var pLists = {
        //                CustomerId: $scope.CustomerId,
        //                ParentCustomerId: $scope.PrincipleMasterList[i].ParentCustomerId,
        //                PcmId: $scope.PrincipleMasterList[i].PcmId
        //            }
        //            arrpLineList.push(pLists);
        //        }
        //    }
        //}

        //var arrpWagonList = [];

        //if ($scope.WagonList != undefined && $scope.WagonList.length != 0) {
        //    for (var i = 0; i < $scope.WagonList.length; i++) {
        //        if ($scope.WagonList[i].WagonNbr != '' && $scope.WagonList[i].WagonType != '' && $scope.WagonList[i].DeckMode != '') {
        //            var pLists = {
        //                RailOperatorId: $scope.CustomerId,
        //                WagonId: $scope.WagonList[i].WagonId,
        //                WagonNbr: $scope.WagonList[i].WagonNbr,
        //                WagonType: $scope.WagonList[i].WagonType,
        //                DeckMode: $scope.WagonList[i].DeckMode,
        //                ActiveStatus: $scope.WagonList[i].ActiveStatus
        //            }
        //            arrpWagonList.push(pLists);
        //        }
        //    }
        //}

        //var arrpCtoBondList = [];

        //if ($scope.CtoBondList != undefined && $scope.CtoBondList.length != 0) {
        //    for (var i = 0; i < $scope.CtoBondList.length; i++) {
        //        if ($scope.CtoBondList[i].BondNbr != '' && $scope.CtoBondList[i].BondExpiryDate != '') {
        //            var pLists = {
        //                RailOperatorId: $scope.CustomerId,
        //                CbdId: $scope.CtoBondList[i].CbdId,
        //                BondNbr: $scope.CtoBondList[i].BondNbr,
        //                BondExpiryDate: $scope.CtoBondList[i].BondExpiryDate,
        //                RailIcdId: $scope.CtoBondList[i].RailIcdId,
        //                ActiveStatus: $scope.CtoBondList[i].ActiveStatus
        //            }
        //            arrpCtoBondList.push(pLists);
        //        }
        //    }
        //}

        //var arrCustomerTerminalList = [];

        //if ($scope.CustomerTerminalList.length != 0) {
        //    for (var i = 0; i < $scope.CustomerTerminalList.length; i++) {
        //        if ($scope.CustomerTerminalList[i].TerminalId > 0) {
        //            var pLists = {
        //                //add master
        //                TerminalId: $scope.CustomerTerminalList[i].TerminalId,
        //                CtmId: $scope.CustomerTerminalList[i].CtmId,
        //                ReferenceCode: $scope.CustomerTerminalList[i].ReferenceCode,
        //                CtmStatus: $scope.CustomerTerminalList[i].CtmStatus

        //            }
        //            arrCustomerTerminalList.push(pLists);
        //        }
        //    }
        //}
        
        var CustomerMaster = {
      
            CustomerCode: $scope.CustomerCode,
            CustomerId: $scope.CustomerId,
            LocationId: $scope.LocationId,
            CustomerName: $scope.CustomerName,
            LocalAddress: $scope.LocalAddress,
            LocalContactDetails: $scope.LocalContactDetails,
            LocalContactNumber: $scope.LocalContactNumber,
            LocalMailId: $scope.LocalMailId,
            HoAddress: $scope.HoAddress,
            PanNo: $scope.PanNo,
            TanNo: $scope.TanNo,
            Gstin: $scope.Gstin,
            CustomerStatus: $scope.CustomerStatus,
            CustomerTypes: arrCustTypeList,
         //   PrincipleLines: arrpLineList,
           // WagonList: arrpWagonList,
            //CtoBondList: arrpCtoBondList,
            //CustomerTerminalList: arrCustomerTerminalList
            DoValidFreeDays: $scope.DoValidFreeDays,
            FaxNo: $scope.FaxNo,
            TelephoneNo: $scope.TelephoneNo,
            PCSCode: $scope.PCSCode,
            PortRefernceCode: $scope.PortRefernceCode,
            LicenseNo: $scope.LicenseNo,
            //StateId: $('#hdnStateId').val()
            StateId: $scope.StateId,
            CityId: $scope.CityId,
            LocationId: $sessionStorage.locationId
            
        };
        var saveData = CustomerAJService.saveCustomerData(CustomerMaster);
        saveData.then(function (pCustomerMaster) {

            if (pCustomerMaster.data.ErrorMessage != null && pCustomerMaster.data.ErrorMessage != "") {
                $scope.errMsg = pCustomerMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.CustomerId = pCustomerMaster.data.CustomerId;
                //$scope.TerminalList = [];
                clearCustomerList();
                CustomerListAll();
                showFirst($scope.CustomerId);
            }
        }, function () {
            clearFields();
            $scope.setclass = "popupBase alert alertShowMsg";
            $scope.errMsg = "Error in saving Customer Configuration";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
                if ($scope.CustomerList.length!=0) {
                    //filteredList = $filter('filter')($scope.CustomerList, { CustomerCode: $scope.SrchRecord });
                    filteredList = $filter('filter')($scope.CustomerList, { CustomerName: $scope.SrchRecord });
                    
                    if (filteredList != undefined) {
                        $scope.CustomerList = filteredList;   
                    }
                   
                }
        }
        else {
            $scope.CustomerList = $scope.tempCustomerList;
        }
    }

    //$scope.filterState = function () {
    //    var filteredStateList;
    //    
    //    if ($scope.SrchRecordState != "" && $scope.SrchRecordState != undefined) {

    //        if ($scope.StateList.length != 0) {
    //            //filteredList = $filter('filter')($scope.CustomerList, { CustomerCode: $scope.SrchRecord });
    //            filteredStateList = $filter('filter')($scope.StateList, { StateName: $scope.SrchRecordState });

    //            if (filteredStateList != undefined) {
    //                $scope.StateList = filteredStateList;
    //            }

    //        }
    //    }
    //    else {
    //        $scope.StateList = $scope.tempStateList;
    //    }
    //}

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('CustomerList', function () {
        if ($scope.CustomerList != undefined) {
            showFirst($scope.CustomerList[0].CustomerId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    $scope.AddNewDtls = function () {
        var newList = { ActiveStatus: 'Y', PcmId: 0, ParentCustomerId: 0 }
            $scope.PrincipleMasterList.push(newList);
    }

    //$scope.AddNewWagon = function () {
    //    var newList = { WagonNbr: '', WagonId: 0, WagonType: 'A', DeckMode: 'S', ActiveStatus: 'Y' }
    //    $scope.WagonList.push(newList);
    //}

    //$scope.AddNewBond = function () {
    //        var newList = { BondNbr: '', BondExpiryDate: '', CbdId: 0, RailIcdId: 0, ActiveStatus: 'Y' }
    //        $scope.CtoBondList.push(newList); 
    //}

    $scope.AddNewTerminal = function () {
        var newItem = { TerminalId: 0, CtmId: 0, ReferenceCode: "", CtmStatus: 'Y' }
        $scope.CustomerTerminalList.push(newItem);
    }

    $scope.closeBond = function () {
        $scope.flagB = 'C';
    }

    $scope.popUpBond = function () {
        $scope.flagB = 'O';

        if ($scope.CtoBondList == undefined) {
            var newList = { BondNbr: '', BondExpiryDate: '', CbdId: 0, RailIcdId: 0, ActiveStatus: 'Y' }
            $scope.CtoBondList.push(newList);
        }
        
    }

    $scope.$on('ngRepeatFinished', function () {
        $("input[id*='txtBondExpiryDate']").datetimepicker({
            dayOfWeekStart: 1,
            lang: 'en',
            format: 'd/m/Y H:i'
        });
    });

});

