﻿app.service("CustomerAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetAllCustomerType = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadAllCustomerTypes",
            dataType: "json"
        });
        return response;
    }

    this.GetAllPrincipleCustomers = function () {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadAllPrincipleCustomers",
            dataType: "json"
        });
        return response;
    }

    this.saveCustomerData = function (CustomerMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/SaveDetails",
            data: JSON.stringify(CustomerMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllCustomerConfigs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadAllCustomers",
            dataType: "json"
        });
        return response;
    }

    this.GetAllState = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/GetStateMasterAll",
            dataType:"json"
        });
        return response;
    }

    this.GetAllCity = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/GetCityMasterAll",
            dataType: "json"
        });
        return response;
    }

    this.GetAllCTOCustomerConfigs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadAllCTOCustomers",
            dataType: "json"
        });
        return response;
    }
    this.getCustomerById = function (CustomerMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadCustomerById",
            data: JSON.stringify(CustomerMaster),
            dataType: "json"
        });
        return response;
    }
    this.GetAllRakOperatorCustomerConfigs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/CustomerMaster/LoadAllRakeOperatorCustomers",
            dataType: "json"
        });
        return response;
    }
})