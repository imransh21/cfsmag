﻿app.service("DailyAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetAllCheckList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/DailyChecks/LoadAllChecks",
            dataType: "json"
        });
        return response;
    }


    this.saveData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/DailyChecks/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetAllCheckTypeConfingData = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/DailyChecks/GetAllCheckConfingData",
            dataType: "json"
        });
        return response;
    }
        
});