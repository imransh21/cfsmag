﻿app.controller("mvcTaxHeadCtrl", function ($scope, $localStorage, $sessionStorage, $filter, $compile, $timeout, TaxHeadAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    
    GetTaxHeadsList();
    var appendlst = "";  
    
    $("#btnAdd").focus();
       
    function GetTaxHeadsList() {
        var inputValues = {
            LocationId: $sessionStorage.locationId
        }
        var GetData = TaxHeadAJService.GetAllTaxHeads(inputValues);
       
        GetData.then(function (pTaxHeadMaster) {
            
            $scope.TaxHeadList = pTaxHeadMaster.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempTaxHeadList = $scope.TaxHeadList;
           
        }, function (reason) {
            $scope.errMsg = "Error in getting Tax Heads. " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllTaxHeads() {
        var uiEle = angular.element(document.querySelector('#LpTaxHead'));
        $('#LpTaxHead').html('');
        angular.forEach($scope.TaxHeadList, function (value, key) {
            if (!jQuery.isEmptyObject(value.TaxHeadId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.TaxHeadId + "')\">" + value.TaxableItemName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var TaxHead = $compile(appendlst)($scope);
        uiEle.append(TaxHead);
        appendlst = "";
    }
  
    function showFirst(TaxHeadId)
    {
        
        var TaxHeadMaster = {
            TaxHeadId: TaxHeadId
        };

        var getData = TaxHeadAJService.GetTaxHeadMasterById(TaxHeadMaster);
        getData.then(function (pTaxHeadMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pTaxHeadMaster.data.ErrorMessage != null) {
                $scope.errMsg = pTaxHeadMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }

            $scope.TaxHeadId = pTaxHeadMaster.data.TaxHeadId;
            $scope.TaxHeadRefId = pTaxHeadMaster.data.TaxHeadRefId;
            $scope.TaxableItemName = pTaxHeadMaster.data.TaxableItemName;
            $scope.TallyHead = pTaxHeadMaster.data.TallyHead;

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Tax Head Master Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (TaxHeadId) {
        showFirst(TaxHeadId);
    }

    function clearTaxHeadList() {
        $scope.TaxHeadList = [];
        GetAllTaxHeads();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.TaxHeadId = undefined;
        $scope.TaxHeadRefId = undefined;
        $scope.TaxableItemName = undefined;
        $scope.TallyHead = undefined;
        }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.TaxHeadRefId == undefined || $scope.TaxHeadRefId == "") {
            $scope.errMsg = "Tax Head Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtTaxHeadRefId").focus();
            return;
        }

        if ($scope.TaxableItemName == undefined || $scope.TaxableItemName == "") {
            $scope.errMsg = "Tax Head Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtTaxableItemName").focus();
            return;
        }
      
        if ($scope.TallyHead == undefined || $scope.TallyHead == "") {
            $scope.errMsg = "ERP Reference Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtTallyHead").focus();
            return;
        }

        var TaxHeadMaster = {
                TaxHeadId: $scope.TaxHeadId,
                TypeOfHead: $scope.TypeOfHead,
                TaxHeadRefId: $scope.TaxHeadRefId,
                TaxableItemName: $scope.TaxableItemName,
                TallyHead: $scope.TallyHead,
                LocationId: $sessionStorage.locationId
            };

        var saveData = TaxHeadAJService.saveTaxHeadData(TaxHeadMaster);
        saveData.then(function (pTaxHeadMaster) {

            if (pTaxHeadMaster.data.ErrorMessage != null && pTaxHeadMaster.data.ErrorMessage != "") {
                $scope.errMsg = pTaxHeadMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
             
                $scope.TaxHeadId = pTaxHeadMaster.data.TaxHeadId;
                //$scope.TerminalList = [];
                //clearTaxHeadList();
                //GetTaxHeadList();
                GetTaxHeadsList();
                showFirst($scope.TaxHeadId);
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Tax Head Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
            if ($scope.TaxHeadList.length != 0) {
                filteredList = $filter('filter')($scope.TaxHeadList, { TaxableItemName: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.TaxHeadList = filteredList;
                    }                   
                }
        }
        else {
            $scope.TaxHeadList = $scope.tempTaxHeadList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('TaxHeadList', function () {
        if ($scope.TaxHeadList != undefined) {
            showFirst($scope.TaxHeadList[0].TaxHeadId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
  
});

