﻿app.service("RackDefnPrintAJService", function ($http) {
    
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.GetBlockMasterRackDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/RackDefinationPrint/GetBlockMasterRackDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
           
        });
        return response;
    }
});