﻿app.controller("RackDefnPrintCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, RackDefnPrintAJService) {
    
    getIndentPrintData();
    $scope.size = "130";
    function getIndentPrintData() {
        
        $scope.BlockId = $sessionStorage.BlockId
        var InputParam = {
            BlockId: $sessionStorage.BlockId
        }
        var GetData = RackDefnPrintAJService.GetBlockMasterRackDetails(InputParam);
        
        GetData.then(function (Response) {
            $scope.blocklist = Response.data.blocklist;
            $scope.isShownIndent = true;
            $sessionStorage.BlockId = undefined;
            $sessionStorage.BlockId = 0;

        });
    }

});
