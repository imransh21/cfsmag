﻿app.controller("cntrlVehicleMaintReport", function ($scope, $localStorage, $compile, $filter, $sessionStorage, VehicleAJService, IndentGenAJService, ServiceSecheduleAJService, VehicleMaintReportAJService, HomeIndex, KeyRefrenceCtrlAJService, ErrorMsgDisplay) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShownPattern = false;
    $scope.isShown = false;

    $("#JobCardDiv").hide();

    //$scope.UserLocationsList = [];
    var appendlst = "";
    DepoLookupList();
    ServiceTypeList();
    
    $scope.CloseJobCardDiv = function () {
    $("#JobCardDiv").hide();
    }

    $scope.GetDataSearch = function (row) {
        $scope.JobVehicleNo = row.VEHICLE_NO;
        $scope.JobVehicleId = row.VEHICLE_ID;
        $scope.ScheduleId = row.SCHEDULE_ID;
        $("#JobCardDiv").show();

    }



    $scope.SaveJobDtls = function () {
        

        if ($scope.ExpBeginDate == undefined || $scope.ExpBeginDate == "") {
            $scope.errMsg = "Please Enter Expected Begin Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.ExpCompDate == undefined || $scope.ExpCompDate == "") {
            $scope.errMsg = "Please Enter Expected Comp Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        var fDate = getDDMMYYYYHHMI($scope.ExpBeginDate);
        var tDate = getDDMMYYYYHHMI($scope.ExpCompDate);
        var curdate = new Date();

        if (fDate < curdate) {
            $scope.errMsg = " Expected Begin Date should be greater than Current Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if (tDate < fDate) {
            $scope.errMsg = " Expected Comp Date should be greater than Expected Begin Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.ScheduleId == undefined || $scope.ScheduleId == "0") {
            $scope.errMsg = "Please Select Schedule Type";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.JobVehicleNo == undefined || $scope.JobVehicleNo == "") {
            $scope.errMsg = "Vehicle not Done";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }
       
        
        var InputParam = {
            VehicleNo: $scope.JobVehicleNo,
            ExpBeginDate: $scope.ExpBeginDate,
            ExpCompDate: $scope.ExpCompDate,
            ScheduleId: $scope.ScheduleId,
            DepotId: $scope.FilterDepotId,
            LocationId: $sessionStorage.locationId
        }
        var getData = VehicleMaintReportAJService.saveJobData(InputParam);
        getData.then(function (Response) {
            
            if (Response.data.ErrorMessage != "" && Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                ErrorFound = true;
                return;
            }
            else {
                $scope.WisId = Response.data.WisId;
                $scope.JobNo = Response.data.JobNo;
                $("#JobCardDiv").hide();
                $scope.isShownrr = true;
                $scope.isShownReceive = true;
                $scope.errMsg = 'Job No. ' + Response.data.JobNo + ' Opened.'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                DepotFilterlistChange();
                ClearData();
            }
        });

    }


    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function ServiceTypeList() {
        var GetData = ServiceSecheduleAJService.GetServSchedulelist();
        GetData.then(function (Response) {
            $scope.ServiceTypeList = Response.data;
        });
    }

    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            VehicleNo: $scope.FilterVehicleNo,
            AssetNo: $scope.FilterAssetNo,
            OwnLease: $scope.FilterOwnLease,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleAJService.GetVehicleMaintReportListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.RequiredJobCardLst = $.parseJSON($.parseJSON(Response.data)).Table;
            ClearData();
            $scope.LEG = 'true';
        });
    }
    
   

    function ClearData() {

        $scope.ExpBeginDate = undefined;
        $scope.ExpCompDate = undefined;
        $scope.ScheduleId = undefined;
        $scope.JobVehicleId = undefined;
        $scope.WisId = undefined;
        $scope.JobNo = undefined;
        $scope.JobVehicleNo = undefined;
        $scope.JobVehicleId = undefined;

        $scope.errMsg = undefined;

    }

    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        newObj.setDate(objDateParts[0]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }


    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
    //====================================================End Cancel Event=====================================================================//
    //====================================================Clear form data=====================================================================//
    //function clearData() {
    //    $scope.DepotCode = undefined;
    //    $scope.DepotName = undefined;
    //    $scope.DepotAddress = undefined;
    //    $scope.ContactPerson = undefined;
    //    $scope.MobileNo = undefined;
    //    $scope.MailId = undefined;
    //    $scope.DepotId = undefined;
    //   // $scope.JobId = undefined;

    //    $scope.UserLocationsList = [];
    //}
    //====================================================End Clear form data=====================================================================//
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }
    //====================================================End Redirect to IndexPage=====================================================================//
    //====================================================Add New Row Event=====================================================================//
    //$scope.AddNewDtls = function () {

    //    var pService = {
    //        //ServiceId: "0", ServiceCode: "", ServiceName: "", Flag: "N", RailOperatorId: "", CtoIcdCode: "", ServiceStatus: "N"
    //        SeqNbr: "", RailIcdId:""
    //    };        
    //    $scope.ServicePorts.push(pService);
    //}
    //====================================================End Add New Row Event=====================================================================//
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

   
    $scope.selected = function (row) {
        row.Flag = 'U';
    }
});

