﻿app.service("VehicleMaintReportAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    
    this.saveJobData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/VehicleMaintReport/SavaJobDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

   
        
});