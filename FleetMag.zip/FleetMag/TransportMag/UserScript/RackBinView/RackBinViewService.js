﻿app.service("mvcRackBinViewService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetWHLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/GetWarehouseBlockList",
            dataType: "json"
        });
        return response;
    }

    this.GetRakeLookupList = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/GetRakeListByWhId",
            dataType: "json",
            data : inputParam
        });
        return response;
    }

    this.GetWDetails = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/GetWhDetails",
            dataType: "json",
            data: inputParam
        });
        return response;
    }

    this.CreateBlock = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/CreateBlock",
            dataType: "json",
            data: inputParam
        });
        return response;
    }

    this.getYardBlockById = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseDefination/LoadYardBlockWHById",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    }

    this.updateYardStatus = function (YardBlockLaneColumnSts) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseDefination/UpdYardActiveStatus",
            data: JSON.stringify(YardBlockLaneColumnSts),
            dataType: "json"
        });
        return response;
    }

    //this.CommodityList = function () {
    //    var response = $http({
    //        method: "post",
    //        url: baseUrl + "/Warehouse/WarehouseDefination/GetCommodityDtls",
    //        dataType: "json"
    //    });
    //    return response;
    //}

    this.RemoveBlock = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/RemoveBlock",
            dataType: "json",
            data: inputParam
        });
        return response;
    }


    this.UpdateBlock = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseCreation/UpdateBlock",
            dataType: "json",
            data: inputParam
        });
        return response;
    }

})