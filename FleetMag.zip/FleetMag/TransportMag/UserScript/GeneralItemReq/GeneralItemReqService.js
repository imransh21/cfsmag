﻿app.service("GeneralItemReqAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (pKeyReference) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GeneralItemReq/SavaDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetRequestDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GeneralItemReq/GetRequestData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
    this.GetReqStockList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetRequiredStockList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }



    this.GetIndentPrint = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/IndentGenarationPrint",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

   

});