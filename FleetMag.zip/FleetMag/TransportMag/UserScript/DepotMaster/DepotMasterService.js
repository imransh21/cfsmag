﻿app.service("DepotAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.GetAllLocations = function (pUserMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/UserMaster/LoadAllLocations",
            dataType: "json",
            data: JSON.stringify(pUserMaster)
        });
        return response;
    }
    this.saveUserData = function (DepotMaster) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/DepotMaster/SaveDetails",
            data: JSON.stringify(DepotMaster),
            dataType: "json"
        });
        return response;
    }
    this.GetAllDepot = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/DepotMaster/LoadAllDepots",
            dataType: "json"
        });
        return response;
    }
    this.GetAllJobs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/DepotMaster/LoadAllJobs",
            dataType: "json"
        });
        return response;
    }

    this.getDepotById = function (DepotMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/DepotMaster/LoadDepotById",
            data: JSON.stringify(DepotMaster),
            dataType: "json"
        });
        return response;
    }
})