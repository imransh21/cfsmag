﻿app.service("POMappingrAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POMapping/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }

    this.GetIndentData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POMapping/LoadAllIndentPendingForHodApp",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetAllVendorData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POMapping/GetAllVendorDtls",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }



    
});