﻿    app.controller("mvcPOMappingCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, POMappingrAJService,HomeIndex) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    $scope.IsHodApprove = 'N';
    $scope.IsReject = 'N';
    $scope.IsApprove = 'N';
    $scope.IsIndentchk = 'N';
    $scope.Count = 0;
    GetAllIndentDetails();
    GetAllVendorDetails();

    var d = new Date();
    $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
    function padToFour(number) {
        if (number <= 99) { number = ("00" + number).slice(-2); }
        return number;
    }
    $scope.IndentDetailsList = [];



    $scope.RejectChange = function (row) {
        

        if (row.IsReject == "Y") {
            row.IsApprove = "N";

        }

    }


    $scope.ApproveChange = function (row) {
        
        if (row.IsApprove == "Y") {
            row.IsReject = "N";
        }

    }



    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }




    $scope.SaveDtls = function () {
        
         
        var ErrorFound = false;
        var intCount = 0;
        var ErrorFound = false;
        angular.forEach($scope.IndentList, function (value, key) {
            if (ErrorFound == false) //{
            //    if (ErrorFound == false) {
            //        if (value.IsIndentchk == "N") {
            //            $scope.errMsg = "Please Select Indent CheckBox For Indent No:- " + value.IndentNo
            //            ErrorFound = true;                        
            //            return;
            //        }
            //    }
            //}

            if (value.IsIndentchk == "Y" ) {
                angular.forEach(value.IndentDtlsList, function (value1, key) {

                    if (ErrorFound == false) {
                        if (value1.VendorName == "0" || value1.VendorName == "" || value1.VendorName == undefined) {
                            $scope.errMsg = "Please select Vendor Name For Indent No:- " + value.IndentNo 
                            ErrorFound = true;
                            $("#VendorName").focus();
                            return;
                        }
                    }
                    if (ErrorFound == false) {
                        if (value1.PoNo == "0" || value1.PoNo == "" || value1.PoNo == undefined) {
                            $scope.errMsg = "Please Enter PO No For Indent No:- " + value.IndentNo
                            ErrorFound = true;
                            $("#PoNo").focus(); 
                            return;
                        }
                    }
                    if (ErrorFound == false) {
                        if (value1.Amount == "" || value1.Amount == "0") {
                            $scope.errMsg = "Please Enter Amount For Indent No:- " + value.IndentNo
                            ErrorFound = true;
                            $("#Amount").focus();
                            return;
                        }
                    }
                    if (ErrorFound == false) {
                        if (value1.GST == "" || value1.GST == "0" || value1.GST == undefined) {
                            $scope.errMsg = "Please Enter GST For Indent No:- " + value.IndentNo
                            ErrorFound = true;
                            $("#GST").focus();
                            return;
                        }
                    }


                    if (ErrorFound == false) {
                        if (value1.PoQty == "" || value1.PoQty == "0" || value1.PoQty == undefined) {
                            $scope.errMsg = "Please PO QTY For Indent No:- " + value.IndentNo
                            ErrorFound = true;
                            $("#PoQty").focus();
                            return;
                        }
                    }

                    if (ErrorFound == false) {
                        if (value1.ExpextedDeliveryDate == "" || value1.ExpextedDeliveryDate == "0" || value1.ExpextedDeliveryDate == undefined) {
                            $scope.errMsg = "Please Expexted Delivery Date For Indent No:- " + value.IndentNo
                            ErrorFound = true;
                            $("#ExpextedDeliveryDate").focus();
                            return;
                        }
                    }

                });
            }
        });
        


        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        PoMappingDetailsList = $scope.IndentList.filter(function (value) {
            
            return value.IsIndentchk == "Y" //&& value.IsHodApprove == "Y";

        });

        var InputParam = {
            List: PoMappingDetailsList
        }
        var GetData = POMappingrAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {                
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                GetAllIndentDetails();
            }
        });
    }

    $scope.DisplayData = function () {
        SerachIndentDetails();
    }

    function GetAllIndentDetails() {
        //var InputParam = {
        //    IndentRefId: $scope.IndentRefId
        //}
        var GetData = POMappingrAJService.GetIndentData();
        GetData.then(function (Response) {
                        
            $scope.IndentList = Response.data;            

        });
    }



    function GetAllVendorDetails() {
        
        var GetData = POMappingrAJService.GetAllVendorData();
        GetData.then(function (Response){
            $scope.VendorList = Response.data;
        });
    }



    $scope.CurrentIndex = function (row) {
        $scope.DtlCurrentIndex = row;
    }

    $scope.CurrentItemIndex = function (row) {
        $scope.ItemCurrentIndex = row;
    }

    $scope.CancelDtls = function () {
        GetAllIndentDetails();
    }
















});