﻿app.service("WhRackDefnAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveYardData = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/RackDefination/SaveDetails",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    }

    this.GetAllTerminalYards = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/RackDefination/LoadAllTerminalYards",
            dataType: "json"
        });
        return response;
    }

    this.getYardBlockById = function (BlockMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/RackDefination/LoadYardBlockRackById",
            data: JSON.stringify(BlockMaster),
            dataType: "json"
        });
        return response;
    }

    this.updateYardStatus = function (YardBlockLaneColumnSts) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/WarehouseDefination/UpdYardActiveStatus",
            data: JSON.stringify(YardBlockLaneColumnSts),
            dataType: "json"
        });
        return response;
    }

    //this.CommodityList = function () {
    //    var response = $http({
    //        method: "post",
    //        url: baseUrl + "/Warehouse/WarehouseDefination/GetCommodityDtls",
    //        dataType: "json"
    //    });
    //    return response;
    //}

    this.GetTreeView = function (userMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Warehouse/RackDefination/GetTreeView",
            data: JSON.stringify(userMaster),
            dataType: "json"
        });
        return response;
    }
})