﻿app.controller("mvcWhRackDefnCtrl", function ($scope, $sessionStorage, $filter, $compile, WhRackDefnAJService, IndentGenAJService, KeyRefrenceCtrlAJService, VehicleAJService, WhDefnAJService, HomeIndex) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.ShowLoader = false;
    $scope.isShownLease = true;
    $scope.LaneHeight1 = '35px';
    $scope.nooflanes = 0;
    $scope.noofcolumns = 0;
    $scope.isShownPoliceType = true;

    //$scope.YardReservationList = locale.YardReservation;
    var appendlst = "";
    GetTreeView();
    DepoLookupList();
    WarehouseTypeList();
    GetVecticalList();
    PolicyTypeList();
    GetWarehouseLeaseFrom();
   // YardListAll();
    RackBinWHAll();
    GetUomList();
    GetGradeList();

    $scope.GetLeaseSelect = function () {
        if ($scope.OwnLease == 'L') {
            $scope.isShownLease = false;
        }
        else {
            $scope.isShownLease = true;

        }
    }

    $scope.PolicyTypeListChange = function () {
        if (($scope.PolicyTypeId != undefined || $scope.PolicyTypeId != null)) {
            $scope.isShownPoliceType = false;
        }
        else {
            $scope.isShownPoliceType = true;

        }
    }

    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            
            $scope.DepoLookupList = Response.data;
        });
    }

    function WarehouseTypeList() {
        var KeyReference = {
            HeadCode: 'WHType',
            GroupCode: 'WHType'
            //HeadCode: 'Warehouse Type',
            //GroupCode: 'Warehouse'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.WarehouseTypeList = [];
        GetData.then(function (Response) {
            var TempWarehouseTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempWarehouseTypeList.unshift(defaltvalue);
            $scope.WarehouseTypeList = TempWarehouseTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function PolicyTypeList() {
        var KeyReference = {
            HeadCode: 'Policy Type',
            GroupCode: 'Policy'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.PolicyTypeList = [];
        GetData.then(function (Response) {
            var TempPolicyTypeList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //TempPolicyTypeList.unshift(defaltvalue);
            $scope.PolicyTypeList = TempPolicyTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Policy Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetWarehouseLeaseFrom() {
        var InputParam = {
            VendorName: "",
            VehicleLeaseStatus: 'W',
            LocationId: $sessionStorage.locationId
        }

        var GetData = VehicleAJService.GetVendorDtls(InputParam);
        $scope.VehicleLeaseList = [];
        GetData.then(function (Response) {
            var TempVehicleList = Response.data;
            var defaltvalue = {
                VendorId: "",
                VendorName: "Select"
            }
            TempVehicleList.unshift(defaltvalue);
            $scope.WarehouseLeaseList = TempVehicleList;
            $scope.LeaseFromWarehouse = "";

        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Lease From List " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    if ($scope.YardList != undefined) {
        if ($scope.YardList.length > 0) {
            //$scope.BlockId = $scope.YardList[0].YardBlocks[0].BlockId;
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
        }
    }

    $("#btnAdd").focus();



    //====================================================Get All Itvs=====================================================================//
    function YardListAll() {
         var GetData = WhRackDefnAJService.GetAllTerminalYards();

        GetData.then(function (pYards) {
            $scope.YardList = pYards.data;
            $scope.errMsg = "";
            $scope.isError = false;
            
            $scope.tempYardList = angular.copy($scope.YardList);
            //GetAllYards();

        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }

     function GetAllYards() {
         var uiEle = angular.element(document.querySelector('#LpYard'));
         $('#LpYard').html('');

         angular.forEach($scope.YardList, function (value, key) {
             //if (!jQuery.isEmptyObject(value.YardBlocks)) {
             appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\">" +
                                                     "" + value.TerminalCode +
                                                     "</a>" +
                                                     "<ul type=\"square\">";

             angular.forEach(value.YardBlocks, function (value, key) {
                    //$scope.uOYardList = value.YardBlocks;
                     appendlst = appendlst + "<li><span class=\"tree-icon1\"></span><a href=\"#\" class=\"Yrdblk\" ng-click=\"commonSource('" + value.BlockId + "')\">" + value.BlockCode + "</a></li>";
                     //$('#' + value.Url).attr('data-title', value.Title);
                 });
                 appendlst = appendlst + "</ul></li>";
            // }
         });


        //uiEle.remove();
         //var YardList = $compile(appendlst)($scope);
        // uiEle.append(YardList);
        appendlst = "";
    }

     function showFirst(BlockId) {
         
         clearData();
         $scope.isShownPoliceType = true;
        var BlockMaster = {
            BlockId: BlockId
        };

        var getData = WhRackDefnAJService.getYardBlockById(BlockMaster);
        getData.then(function (pBlockMaster) {
            
            if (pBlockMaster.data.ParentBlockId == 0) {
                //clearData();
                $scope.isShown = true;
                return;
            }
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.isShown = true;
            $scope.isShownLease = true;

            if (pBlockMaster.data.ErrorMessage != null) {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
            
            $scope.BlockId = pBlockMaster.data.BlockId;
            $scope.LocationId = pBlockMaster.data.LocationId;
            $scope.DepotId = pBlockMaster.data.DepotId;
            $scope.BlockCode = pBlockMaster.data.BlockCode;
            $scope.RtToTmDistance = pBlockMaster.data.RtToTmDistance;
            $scope.YardLength = pBlockMaster.data.YardLength;
            $scope.YardWidth = pBlockMaster.data.YardWidth;
            $scope.NoOfStacks = pBlockMaster.data.NoOfStacks;
            $scope.PerWtCapacity = pBlockMaster.data.PerWtCapacity;
            $scope.SpecialReserve = pBlockMaster.data.SpecialReserve;
            $scope.MaxWtCapacity = pBlockMaster.data.MaxWtCapacity;
            $scope.Remarks = pBlockMaster.data.Remarks;
            $scope.PerTransTime = pBlockMaster.data.PerTransTime;
            $scope.ColumnList = pBlockMaster.data.BlockColumnMasterList;
            $scope.LaneList = pBlockMaster.data.BlockLaneMasterList;
            $scope.YardBlockLaneColumnList = pBlockMaster.data.YardBlockLaneColumnList;
            $scope.NoOfPlugReefer = pBlockMaster.data.NoOfPlugReefer;
            $scope.nooflanes = pBlockMaster.data.NoOfLanes;
            $scope.TempNoOfLanes = pBlockMaster.data.NoOfLanes;
            $scope.noofcolumns = pBlockMaster.data.NoOfColumns;
            $scope.TempNoOfcolumns = pBlockMaster.data.NoOfColumns;
            $scope.COMMODITY = pBlockMaster.data.CommodityType;
            //$scope.WhType = pBlockMaster.data.WareHouseType;
            $scope.WareHouseTypeId = pBlockMaster.data.WarehouseTypeId;
            $scope.OwnLease = pBlockMaster.data.OwnLease;
            $scope.LeaseFromWarehouse = pBlockMaster.data.LeaseFrom;
            $scope.LeaseAgreementRefNo = pBlockMaster.data.LeaseAgreeRefNo;
            $scope.LeasePeriod = pBlockMaster.data.LeasePeriod;
            $scope.PolicyTypeId = pBlockMaster.data.PolicyTypeId;
            $scope.Insurer = pBlockMaster.data.Insurer;
            $scope.PolicyNumber = pBlockMaster.data.PolicyNumber;
            $scope.SumInsured = pBlockMaster.data.SumInsured;
            $scope.PolicyEffectFrom = pBlockMaster.data.PolicyEffectFrom;
            $scope.PolicyEffectTo = pBlockMaster.data.PolicyEffectTo;
            $scope.VecticalTypeId = pBlockMaster.data.VecticalTypeId; //$filter('filter')($scope.FilteredRackBinWHList, { BlockCode: $scope.BlockCode })[0].VecticalTypeId;            
            $scope.ParentBlockId = pBlockMaster.data.ParentBlockId;
            $scope.GradeId = pBlockMaster.data.GradeId;
            $sessionStorage.BlockId = $scope.BlockId;
            
            $scope.WHLength = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: $scope.ParentBlockId })[0].YardLength;
            $scope.WHWidth = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: $scope.ParentBlockId })[0].YardWidth;
            setTimeout(function () {           
            for (i = 1; i <= $scope.LaneList.length; i++) {
                var LaneHeight = $scope.LaneList[i-1].LaneLength;
                var pHeight = (LaneHeight * 5) + 'px';
                $('#L' + i).css('line-height', pHeight);

            }            
            }, 100);

            setTimeout(function () {           
                for (i = 1; i <= $scope.ColumnList.length; i++) {
                    
                    var ColWidth = $scope.ColumnList[i - 1].ColumnWidth;
                    var pWidth = (ColWidth * 5) + 'px';
                    $('#C' + i).css('min-width', pWidth);
                }
            }, 100);

            $scope.ColumnList 
            $scope.UomId = $scope.LaneList[0].UomId;

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Yard Defination";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (BlockId) {
        showFirst(BlockId);
    }

    function clearYardList() {
        $scope.YardList = [];
        GetAllYards();
    }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        angular.element('#myInput').focus();
        //for (var i = 0; i < 5; i++){
        //    AddLane();
        //    AdColumn();
        //}
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        
        if ($scope.BlockId == undefined || $scope.BlockId == "") {
            $scope.errMsg = "Please Select Rack Code.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        }

        $scope.isShown = false;
       // $scope.isShownPoliceType = true;
        // $scope.isShownPoliceType = false;
        if (($scope.PolicyTypeId != 0)) {
            $scope.isShownPoliceType = false ;
        }
        else {
            $scope.isShownPoliceType = true;

        }
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;
        $scope.isShownPoliceType = true;
        if ($scope.BlockId == undefined || $scope.BlockId == 0 || $scope.BlockId == "") {
            clearData();

            //var watchList = $scope.$watch('YardList', function () {
            //    for (var i = 0; i < $scope.YardList.length; i++) {
            //        if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
            //            $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
            //            break;
            //        }
            //    }

            //    showFirst($scope.BlockId);
            //    watchList();
            //});
        } else {
                showFirst($scope.BlockId);
        }
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    //$scope.ExitDtls = function () {
    //    getIndexpage();
    //}
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage("/Home/Warehouse");
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        
        $sessionStorage.BlockId=undefined
        $scope.BlockId = undefined;
        $scope.LocationId = undefined;
        $scope.DepotId = undefined;
        $scope.BlockCode = undefined;
        $scope.RtToTmDistance = undefined;
        $scope.YardLength = undefined;
        $scope.YardWidth = undefined;
        $scope.NoOfStacks = undefined;
        $scope.PerWtCapacity = undefined;
        $scope.SpecialReserve = undefined;
        $scope.MaxWtCapacity = undefined;
        $scope.Remarks = undefined;
        $scope.PerTransTime = undefined;
        $scope.NoOfPlugReefer = undefined;
        $scope.nooflanes = 0;
        $scope.noofcolumns = 0;
        $scope.LaneList = [];
        $scope.ColumnList = [];
        $scope.COMMODITY = undefined;
        $scope.WareHouseTypeId = undefined;
        $scope.OwnLease = undefined;
        $scope.LeaseFromWarehouse = undefined;
        $scope.LeaseAgreementRefNo = undefined;
        $scope.LeasePeriod = undefined;
        $scope.PolicyTypeId = undefined;
        $scope.Insurer = undefined;
        $scope.PolicyNumber = undefined;
        $scope.SumInsured = undefined;
        $scope.PolicyEffectFrom = undefined;
        $scope.PolicyEffectTo = undefined;
        $scope.VecticalTypeId = undefined;
        $scope.GradeId = undefined;
        $scope.WHLength = undefined;
        $scope.WHWidth = undefined;

    }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//

    $scope.SaveDtls = function () {
        
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.DepotId == undefined || $scope.DepotId == "") {
            $scope.errMsg = "Depot is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstDepo").focus();
            return;
        }

        //if ($scope.WareHouseTypeId == undefined || $scope.WareHouseTypeId == "") {
        //    $scope.errMsg = "WareHouse Code is required";
        //    $scope.isError = true;
        //    ErrorPopupMsg('ErrorDiv');
        //    $("#lstDepo").focus();
        //    return;
        //}

        if ($scope.BlockCode == undefined || $scope.BlockCode == "") {
            $scope.errMsg = "Rack Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtBlockCode").focus();
            return;
        }
        //if (new Date($scope.PolicyEffectTo) > new Date($scope.PolicyEffectFrom)) {
        //    
        //if ($scope.PolicyEffectFrom != undefined && $scope.PolicyEffectTo != undefine) {
        //    var fDate = getDDMMYYYYHHMI($scope.PolicyEffectFrom);
        //    var tDate = getDDMMYYYYHHMI($scope.PolicyEffectTo);
        //    if (fDate > tDate) {
        //        $scope.errMsg = "To Date should be greater than From Date";
        //        $scope.isError = true;
        //        ErrorPopupMsg('ErrorDiv');
        //        $("#txtPolicyEffectFrom").focus();
        //        return false;
        //    }
        //}

        //else {
        //    if ($scope.BlockCode.length > 2) {

        //        $scope.errMsg = "Block Code not More then two Charactors";
        //        $scope.isError = true;
        //        ErrorPopupMsg('ErrorDiv');
        //        $("#txtBlockCode").focus();
        //        return;
        //    }
        //    else {
        //        if ($scope.BlockCode.length < 2) {

        //            $scope.errMsg = "Block Code not Less then two Charactors";
        //            $scope.isError = true;
        //            ErrorPopupMsg('ErrorDiv');
        //            $("#txtBlockCode").focus();
        //            return;
        //        }
        //    }
        //}
        if ($scope.ParentBockId <= 0 || $scope.WareHouseTypeId == undefined) {
            $scope.errMsg = "Warehouse Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstWhCode").focus();
            return;
        }

        //if ($scope.RtToTmDistance == undefined || $scope.RtToTmDistance == "") {
        //    $scope.errMsg = "Distance from RT is required";
        //    $scope.isError = true;
        //    $("#txtRtToTmDistance").focus();
        //    return;
        //} 

        //if ($scope.NoOfStacks < 0) {
        //    $scope.errMsg = "Permitted No Of Stacks Negative not allowed.";
        //    $scope.isError = true;
        //    ErrorPopupMsg('ErrorDiv');
        //    $("#txtYardLength").focus();
        //    return;
        //}
        if ($scope.YardLength == undefined || $scope.YardLength == "") {
           // $scope.errMsg = "Block Length is required";
            $scope.errMsg = "Rack Length is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardLength").focus();
            return;
        }

        if ($scope.YardWidth == undefined || $scope.YardWidth == "") {
           // $scope.errMsg = "Width is required";
            $scope.errMsg = "Rack Width is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardWidth").focus();
            return;
        }

        if ($scope.PerWtCapacity == undefined || $scope.PerWtCapacity == "" || $scope.PerWtCapacity == "0") {

            $scope.errMsg = "Permissible Capacity is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtPerWtCapacity").focus();
            return;
        }

        if ($scope.MaxWtCapacity == undefined || $scope.MaxWtCapacity == "" || $scope.MaxWtCapacity == "0") {

            $scope.errMsg = "Maximum Capacity is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtMaxWtCapacity").focus();
            return;
        }

        if ($scope.COMMODITY == undefined || $scope.COMMODITY == "") {

            $scope.errMsg = "Commodity is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstSpecialCmdt").focus();
            return;
        }

        if ($scope.Remarks == undefined || $scope.Remarks == "") {

            $scope.errMsg = "Remarks is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtRemarks").focus();
            return;
        }

        if ($scope.PolicyTypeId != 0 && $scope.PolicyTypeId != undefined) {
            if ($scope.Insurer == undefined || $scope.Insurer == "") {

                $scope.errMsg = "Insurer is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtInsurer").focus();
                return;
            }
            if ($scope.PolicyNumber == undefined || $scope.PolicyNumber == "") {

                $scope.errMsg = "Policy No is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyNumber").focus();
                return;
            }
            if ($scope.PolicyEffectFrom == undefined || $scope.PolicyEffectFrom == "") {

                $scope.errMsg = "Policy Effect From is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyEffectFrom").focus();
                return;
            }

            if ($scope.PolicyEffectTo == undefined || $scope.PolicyEffectTo == "") {

                $scope.errMsg = "Policy Effect To is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyEffectTo").focus();
                return;
            }


            //if (new Date($scope.PolicyEffectTo) > new Date($scope.PolicyEffectFrom)) {
            //    
            if ($scope.PolicyEffectFrom != undefined && $scope.PolicyEffectTo != undefined) {
                var fDate = getDDMMYYYYHHMI($scope.PolicyEffectFrom);
                var tDate = getDDMMYYYYHHMI($scope.PolicyEffectTo);
                if (fDate > tDate) {
                    $scope.errMsg = "Policy Effect From should be less than Policy Effect To";
                    $scope.isError = true;
                    ErrorPopupMsg('ErrorDiv');
                    $("#txtPolicyEffectFrom").focus();
                    return false;
                }
            }


            if ($scope.SumInsured == undefined || $scope.SumInsured == "" || $scope.SumInsured == "0") { //UomId

                $scope.errMsg = "Sum Insured is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtSumInsured").focus();
                return;
            }

        }

        if ($scope.UomId == undefined || $scope.UomId == "" || $scope.UomId == "0") {

            $scope.errMsg = "Uom is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstUomId").focus();
            return;
        }


        
        if ($scope.LaneList.length > 0) {
            for (i = 0; i < $scope.LaneList.length; i++) {
               

                    if ($scope.LaneList[i].LaneCode == "") {
                        $scope.errMsg = "Level Reference Code Is Mandatory ";
                        ErrorPopupMsg('ErrorDiv');
                        $scope.isError = true;
                        return;
                    }
                    if ($scope.LaneList[i].LaneLength <= 0) {
                        $scope.errMsg = "Level Reference Height Is Mandatory ";
                        ErrorPopupMsg('ErrorDiv');
                        $scope.isError = true;
                        return;
                    }
                    //if ($scope.LaneList[i].UomId <= 0) {
                    //    $scope.errMsg = "Level Reference UOM Is Mandatory ";
                    //    ErrorPopupMsg('ErrorDiv');
                    //    $scope.isError = true;
                    //    return;
                    //}
                    for (j = i + 1 ; j < $scope.LaneList.length; j++) {
                    if ($scope.LaneList[i].LaneCode == ($scope.LaneList[j].LaneCode)) {
                        // got the duplicate element
                        if ($scope.LaneList[i].LaneCode != "") {
                            $scope.errMsg = "Level Reference Code " + $scope.LaneList[i].LaneCode + " is duplicate.";
                            ErrorPopupMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        } else {
            $scope.errMsg = "Level Reference is mandatory ";
            ErrorPopupMsg('ErrorDiv');
            $scope.isError = true;
            return;
        }

        if ($scope.ColumnList.length > 0) {
            for (i = 0; i < $scope.ColumnList.length; i++) {
                
                    if ($scope.ColumnList[i].ColumnCode == "") {
                        $scope.errMsg = "Bay Reference Code Is Mandatory ";
                        ErrorPopupMsg('ErrorDiv');
                        $scope.isError = true;
                        return;
                    }
                    if ($scope.ColumnList[i].ColumnWidth <= 0) {
                        $scope.errMsg = "Bay Reference Width Is Mandatory ";
                        ErrorPopupMsg('ErrorDiv');
                        $scope.isError = true;
                        return;
                    }
                    //if ($scope.ColumnList[i].UomId <= 0) {
                    //    $scope.errMsg = "Bay Reference UOM Is Mandatory ";
                    //    ErrorPopupMsg('ErrorDiv');
                    //    $scope.isError = true;
                    //    return;
                    //}
                    for (j = i + 1 ; j < $scope.ColumnList.length; j++) {
                    if ($scope.ColumnList[i].ColumnCode == ($scope.ColumnList[j].ColumnCode)) {
                        // got the duplicate element
                        if ($scope.ColumnList[i].ColumnCode != "") {
                            $scope.errMsg = "Column Code " + $scope.ColumnList[i].ColumnCode + " is duplicate.";
                            ErrorPopupMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        } else {
            $scope.errMsg = "Bay Reference is mandatory ";
            ErrorPopupMsg('ErrorDiv');
            $scope.isError = true;
            return;
        }

        LengthChange();
        WidthChange();

        if ($scope.isLengthError == true) {
            $scope.isLengthError = false;
            return;
        }

        if ($scope.isWidthError == true) {
            $scope.isWidthError = false;
            return;
        }

        var arrLaneList = [];

        if ($scope.LaneList.length != 0) {
            
            for (var i = 0; i < $scope.LaneList.length; i++) {
                if ($scope.LaneList[i].LaneCode != undefined) {
                    var pLists = {
                        BlockId: $scope.BlockId,
                        LaneId: $scope.LaneList[i].LaneId,
                        LaneCode: $scope.LaneList[i].LaneCode,
                        LaneLength: $scope.LaneList[i].LaneLength,
                        //UomId: $scope.LaneList[i].UomId
                        UomId: $scope.UomId
                    }
                    arrLaneList.push(pLists);
                }
            }
        }

        var arrColumnList = [];

        if ($scope.ColumnList.length != 0) {
            for (var i = 0; i < $scope.ColumnList.length; i++) {
                if ($scope.ColumnList[i].ColumnCode != undefined) {
                    var pPriSec;
                    if (i == 0) {
                        pPriSec = 'P';
                    } else if (i % 2 == 0) {
                        pPriSec = 'P';
                    } else {
                        pPriSec = 'S';
                    }
                    var pLists = {
                        BlockId: $scope.BlockId,
                        ColumnId: $scope.ColumnList[i].ColumnId,
                        ColumnCode: $scope.ColumnList[i].ColumnCode,
                        PriSec: pPriSec,
                        ColumnWidth: $scope.ColumnList[i].ColumnWidth,
                        //UomId: $scope.ColumnList[i].UomId
                        UomId: $scope.UomId
                    }
                    arrColumnList.push(pLists);
                }
            }
        }

        var BlockMaster = {
            BlockId: $scope.BlockId,
            LocationId: $sessionStorage.locationId,
            DepotId: $scope.DepotId,
            BlockCode: $scope.BlockCode,
            RtToTmDistance: $scope.RtToTmDistance,
            YardLength: $scope.YardLength,
            YardWidth: $scope.YardWidth,
            //NoOfStacks: $scope.NoOfStacks,
            NoOfStacks: 1,
            PerWtCapacity: $scope.PerWtCapacity,
            SpecialReserve: $scope.SpecialReserve,
            MaxWtCapacity: $scope.MaxWtCapacity,
            Remarks: $scope.Remarks,
            PerTransTime: $scope.PerTransTime,
            NoOfPlugReefer: $scope.NoOfPlugReefer,
            NoofLanes: $scope.nooflanes,
            NoofColumns: $scope.noofcolumns,
            BlockLaneMasterList: arrLaneList,
            BlockColumnMasterList: arrColumnList,
            WareHouseTypeId: $scope.WareHouseTypeId,
            CommodityType: $scope.COMMODITY,
            OwnLease: $scope.OwnLease,
            LeaseFrom: $scope.LeaseFromWarehouse,
            LeaseAgreeRefNo: $scope.LeaseAgreementRefNo,
            LeasePeriod: $scope.LeasePeriod,
            PolicyTypeId: $scope.PolicyTypeId,
            Insurer: $scope.Insurer,
            PolicyNumber:$scope.PolicyNumber,
            SumInsured: $scope.SumInsured,
            PolicyEffectFrom:$scope.PolicyEffectFrom,
            PolicyEffectTo:$scope.PolicyEffectTo,
            RackBinType: 'N',
            VecticalTypeId: $scope.VecticalTypeId,
            ParentBlockId: $scope.ParentBlockId,
            GradeId: $scope.GradeId
        };
        
        $scope.ShowLoader = true;
        var saveData = WhRackDefnAJService.saveYardData(BlockMaster);
        saveData.then(function (pBlockMaster) {
            $scope.ShowLoader = false;
            if (pBlockMaster.data.ErrorMessage != null && pBlockMaster.data.ErrorMessage != "") {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved Successfully";
                ErrorPopupMsg('ErrorDivG');
                $scope.BlockId = pBlockMaster.data.BlockId;
                //$scope.TerminalList = [];
                clearYardList();
                YardListAll();
                $scope.isShownLease = true;
                $scope.isShownPoliceType = true;
                //clearData();
                count = 0;
                appendlst = "";
                //var uiEle = angular.element(document.querySelector('#trview'));
                //uiEle.html('');
                //$scope.TreeViewList = undefined;
                //GetTreeView();
                //$('#scrolling-listSearch').find('button').removeAttr('disabled', 'disabled');
                //var uiEle = angular.element(document.querySelector('#trview'));
                //uiEle.html('');
                //$scope.TreeViewList = undefined;
                GetTreeView();
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Yard Defination";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        });
    }

    $scope.filter = function () {
        var elem = document.getElementById('trview');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchCtrl) != -1 || $scope.SrchCtrl == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }

    //$scope.filter = function () {
    //    var filteredList = [];
    //    var filteredYardBlockList;
    //    
    //    if ($scope.SrchCtrl != "" && $scope.SrchCtrl != undefined) {
    //        if ($scope.YardList.length > 0) {
    //            for (var i = 0; i < $scope.YardList.length; i++) {
    //                filteredYardBlockList = $filter('filter')($scope.YardList[i].YardBlocks, { BlockCode: $scope.SrchCtrl });

    //                if (filteredYardBlockList.length != undefined && filteredYardBlockList.length != 0) {
    //                    filteredList = filteredYardBlockList;

    //                   // filteredList.push(filteredYardBlockList);
    //                }
    //            }

    //            if (filteredList != undefined && filteredList.length != 0) {
    //                //$scope.YardList.push(filteredList);
    //                $scope.YardList[0].YardBlocks = filteredList;
    //            }
    //        }

    //    }
    //    else {
    //        $scope.YardList =angular.copy($scope.tempYardList);
    //    }
    //}

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('YardList', function () {
        if ($scope.YardList != undefined) {
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
            showFirst($scope.BlockId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewLane = function () {
        var i = $scope.LaneList.length;
        var AscChar = 65;
        var char = String.fromCharCode(AscChar + i)
        var newItem = { LaneCode: char, LaneId: 0, LaneLength: 0, UomId: 0 }

        $scope.LaneList.push(newItem);
        
        $scope.nooflanes = (parseInt($scope.nooflanes) + 1) 
    }

    //====================================================End of new lane addition==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewColumn = function () {
        var ColSeq = $scope.ColumnList.length;
        var Seq = padToFour(ColSeq + 1);
        var newItem = { ColumnCode: Seq, ColumnId: 0, ColumnWidth: 0, UomId: 0 }

        $scope.ColumnList.push(newItem);
        $scope.noofcolumns = (parseInt($scope.noofcolumns) + 1)
    }
    //====================================================End of new lane addition==============================================================//

    $scope.updYardStatus = function (cList, lList) {
        var YardBlockLaneColumnSts = {
            BlockId: $scope.BlockId,
            LaneId: lList.LaneId,
            ColumnId: cList.ColumnId
        };

        //Updation to db is pending. discussion required


        //var UpdData = WhRackDefnAJService.updateYardStatus(YardBlockLaneColumnSts);
        //UpdData.then(function (pYardBlockLaneColumnSts) {

        //if (pYardBlockLaneColumnSts.data.ErrorMessage != null && pYardBlockLaneColumnSts.data.ErrorMessage != "") {
        //    $scope.errMsg = pYardBlockLaneColumnSts.data.ErrorMessage;
        //        $scope.isError = true;
        //        return;
        //    }
        //    else {
        //        $scope.errMsg = "";
        //        $scope.isError = false;
        //    }
        //}, function () {
        //    $scope.errMsg = "Error in updating Yard Status";
        //    $scope.isError = true;
        //    return;
        //});
    }

    $scope.LaneDataChange = function () {
        //if (($scope.TempNoOfLanes > 0)) {
        //    if ($scope.NoofLanes < $scope.TempNoOfLanes) {
        //        
        //        $scope.errMsg = "No Of Lanes should be greater than" + $scope.TempNoOfLanes + "";
        //        $scope.isError = true;
        //        ErrorPopupMsg('ErrorDiv');
        //        $scope.NoofLanes = angular.copy($scope.TempNoOfLanes);
        //        return
        //    }
        //}
        if (($scope.nooflanes == undefined) || ($scope.nooflanes == 0)) {
            $scope.LaneList = [];
            return
        }

        



        $scope.LaneList = [];
        var AscChar = 65;
        for (i = 0; i < $scope.nooflanes; i++) {
            var InputParam = {
                LaneCode: String.fromCharCode(AscChar + i),
                LaneId: 0,
                LaneLength: 0
            }
            $scope.LaneList.push(InputParam);
        }
    }

    $scope.ColumnDataChange = function () {
        if (($scope.noofcolumns == undefined) || ($scope.noofcolumns == 0)) {
            $scope.ColumnList = [];
            return
        }
        $scope.ColumnList = [];
        var ColSeq = 0
        for (i = 0; i < $scope.noofcolumns; i++) {
            var InputParam = {
                ColumnCode: padToFour(ColSeq + 1),
                ColumnId: 0,
                ColumnWidth: 0
            }
            ColSeq = ColSeq + 1;
            $scope.ColumnList.push(InputParam);
        }
    }


    function padToFour(number) {
        if (number <= 999) { number = ("00" + number).slice(-2); }
        return number;
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        //setTimeout(function () {
        //    $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        //}, 2000);

        $('#iconClose,#iconClose2').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    //function GetCommodity() {
    //    var getData = WhRackDefnAJService.CommodityList('');
    //    getData.then(function (result) {
    //        $scope.CmdtCode = $.parseJSON(result.data);
    //    });
    //}

    $scope.ClearSearch = function (event) {
        if (event.keyCode === 8) {
            $scope.SrchCtrl = "";
            $scope.YardList = angular.copy($scope.tempYardList);
        }
    };

    function RackBinWHAll() {
        var GetData = WhDefnAJService.GetAllTerminalYards();

        GetData.then(function (pYards) {
            $scope.RackbinWH = pYards.data;            
            $scope.FilteredRackBinWHList = $filter('filter')($scope.RackbinWH[0].YardBlocks, { RackBinType: 'Y', ParentBlockId: 0});
            
            //GetAllYards();

        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }


    function GetVecticalList() {
        var KeyReference = {
            HeadCode: 'VERTICAL',
            GroupCode: 'WAREHOUSE'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.VecticalList = [];
        GetData.then(function (Response) {
            var TempVecticalList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVecticalList.unshift(defaltvalue);
            $scope.VecticalList = TempVecticalList;
            
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Vectical Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    $scope.OnWHCodeChange = function (pBlockId) {
        
        
        $scope.WareHouseTypeId = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: pBlockId })[0].WarehouseTypeId;
        $scope.VecticalTypeId = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: pBlockId })[0].VecticalTypeId;
        $scope.WHLength = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: pBlockId })[0].YardLength;
        $scope.WHWidth = $filter('filter')($scope.FilteredRackBinWHList, { BlockId: pBlockId })[0].YardWidth;
    }

    $scope.GetWidth = function (index) {
        //alert(index);
        return '20px';

    }

    $scope.LaneheightChange = function (Item,index) {
        
        //$('#L1').val(100);
      
        var LaneHeight = Item.LaneLength;


        // Lane Height Validation      

        var pHeight = (LaneHeight * 5) + 'px';
        $('#L' + index).css('line-height', pHeight);        
    }

    $scope.OnLengthChange = function (Item) {
        LengthChange();
    }

    function LengthChange() {
        
        if ($scope.YardLength == undefined || $scope.YardLength == "") {
            $scope.errMsg = "Please insert the Rack Length ";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            setTimeout(function () {
                $('#txtYardLength').focus();
            }, 1000);
            return;
        }
       
        var TotalLaneLength = 0;
        var RemainingLength = 0;
       // var LaneHeight = Item.LaneLength;

        for (j = 0 ; j < $scope.LaneList.length; j++) {
            if ($scope.LaneList[j].LaneLength != "") {
                TotalLaneLength = TotalLaneLength + parseInt($scope.LaneList[j].LaneLength);
            }
        }

        if (TotalLaneLength > $scope.YardLength) {
            $scope.errMsg = "Total Level Height should be less than " + $scope.YardLength + " ( Rack Length )";
            $scope.isError = true;
            $scope.isLengthError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        }
    };

    $scope.OnWidthChange = function (Item) {
        WidthChange();
    }

    function WidthChange() {
        if ($scope.YardWidth == undefined || $scope.YardWidth == "") {
            $scope.errMsg = "Please insert the Rack Width ";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            setTimeout(function () {
                $('#txtYardWidth').focus();
            }, 1000);
            return;
        }
        var TotalYardWidth = 0;     

        for (j = 0 ; j < $scope.ColumnList.length; j++) {
            if ($scope.ColumnList[j].ColumnWidth != "") {
                TotalYardWidth = TotalYardWidth + parseInt($scope.ColumnList[j].ColumnWidth);
            }
        }

     

        if (TotalYardWidth > $scope.YardWidth) {
            $scope.errMsg = "Total Bay Width should be less than Rack Width "; // + RemainingLength;
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $scope.isWidthError = true;
            //$scope.PerWtCapacity = 0;
            return;
        }
    }


    $scope.OnCreateLane = function (Item, index) {
        //
        ////$('#L1').val(100);
        //var LaneHeight = Item.LaneLength;
        //var pHeight = (LaneHeight * 5) + 'px';
        //$('#L' + index).css('line-height', pHeight);
    }

    $scope.ColWidthChange = function (Item,index) {
       
        //$('#L1').val(100);
        var ColWidth = Item.ColumnWidth;
        var pWidth = (ColWidth * 5) + 'px';
        $('#C' + index).css('min-width', pWidth);
       // $('#C' + index).css('line-width', pWidth + 'px');
    }

    function GetTreeView() {
     //   $scope.isShownPoliceType = true;
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = WhRackDefnAJService.GetTreeView(o);

        getData.then(function (Response) {

            $scope.TreeViewList = Response.data;
            menuList($scope.TreeViewList.Menu);
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });

    };

  

    var appendlst = "";
    var count = 0;  
    function menuList(menu) {
      
        $('#scrolling-listSearch .fa-spinner').css({ 'display': 'block' });


        if (count == 0) {
            appendlst = appendlst + "<ul id='trview' class='treeView groupView' >";
            count = count + 1;
        } else {
            appendlst = appendlst + "<ul class='Lbod'>";
        }
        angular.forEach(menu, function (value, key) {
            if (!jQuery.isEmptyObject(value)) {
                appendlst = appendlst + "<li class=\"nav-item\">" +
                                                    "<button type=\"button\"  ng-click=\"commonSource('" + value.BlockId + "'," + "'" + value.BlockCode + "'," + value.ParentBlockId + ",'" + value.WHBlockCode + "')\">" +
                                                        "<span></span>" + value.BlockCode +
                                                       // "<label id=\"\" >" +  + " </label>" +
                                                        //"<span class=\"fa fa-caret-up\"></span>" +
                                                    "</button>"

                if (value.SubMenu.length != 0) {
                    menuList(value.SubMenu);
                }

                appendlst = appendlst + "</li>";


            }

        });
        appendlst = appendlst + "</ul>";
        //uiEle.remove();
        var menulst = $compile(appendlst)($scope);
        var uiEle = angular.element(document.querySelector('#trview'));
        uiEle.html('');
        uiEle.replaceWith(menulst);

        $('#scrolling-listSearch .fa-spinner').css({ 'display': 'none' });
        $('#scrolling-listSearch ul.Lbod').addClass('hide');
        $('#scrolling-listSearch li button').click(function () {
            $('#scrolling-listSearch li').removeClass('active');
            $(this).closest('li').find('ul').toggleClass('hide');
            $(this).closest('li').addClass('active');
        });
    }

    function GetUomList() {
        var KeyReference = {
            HeadCode: 'Area',
            GroupCode: 'UOM'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.UomList = [];
        GetData.then(function (Response) {
            var TempUomList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //TempUomList.unshift(defaltvalue);
            $scope.UomList = TempUomList;
            
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting UOM Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetGradeList() {
        var KeyReference = {
            HeadCode: 'RackGrade',
            GroupCode: 'RackGrade'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.GradeList = [];
        GetData.then(function (Response) {
            var TempGradeList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //TempGradeList.unshift(defaltvalue);
            $scope.GradeList = TempGradeList;
            
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Grade Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    // added by deepti on 14-03-2019


    $scope.PrintDtls = function () {
        if ($scope.BlockId == undefined || $scope.BlockId == "") {
            $scope.errMsg = "Please Select Rack Code.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        }
        $sessionStorage.BlockId = $scope.BlockId;
        $sessionStorage.ParentBlockId = $scope.ParentBlockId;
        getIndexPrintPage();
    }

    function getIndexPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.open( baseUrl + "/Warehouse/RackDefination/RackDefinationPrint","_blank");
        //target = "_blank";
       
    }
    //end by deepti on 14-03-2019


    $scope.OnDepotChange = function () {
        
        $scope.FilteredRackBinWHList = $filter('filter')($scope.RackbinWH[0].YardBlocks, { RackBinType: 'Y', ParentBlockId: 0, DepotId: $scope.DepotId });
    }

    $scope.OnCapacityChange = function (pType) {
        
        if ($scope.PerWtCapacity >= 0 && $scope.MaxWtCapacity >= 0) {
            if (pType == 'Permissible') {
                if ($scope.PerWtCapacity > $scope.MaxWtCapacity) {
                    $scope.errMsg = "Permissible Capacity should bre less than Maximum Capacity.";
                    $scope.isError = true;

                    ErrorPopupMsg('ErrorDiv');
                    $scope.PerWtCapacity = 0;
                    setTimeout(function () {
                        
                        $("#txtPermissibleCapacity").focus();
                    }, 1000);
                    return;
                }
            }
            if (pType == 'Maximum') {
                if ($scope.PerWtCapacity > $scope.MaxWtCapacity) {
                    $scope.errMsg = "Maximum Capacity should be greater than Permissible Capacity.";
                    $scope.isError = true;
                    ErrorPopupMsg('ErrorDiv');
                    $scope.MaxWtCapacity = 0;
                    setTimeout(function () {                        
                        $("#txtMaximumCapacity").focus();
                    }, 1000);
                    return;
                }
            }

        }
    }

    $scope.OnRackLengthChange = function (pYardLength) {
        if (pYardLength > $scope.WHLength) {
            $scope.errMsg = "Rack Length should be less than Warehouse Length.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            setTimeout(function () {
                $("#txtYardLength").focus();
            }, 1000);
            return;
        }
    }

    $scope.OnRackLengthChange = function (pYardLength) {
        
        if (pYardLength > $scope.WHLength) {
            $scope.errMsg = "Rack Length should be less than Warehouse Length.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            setTimeout(function () {
                $("#txtYardLength").focus();
            }, 1000);
            return;
        }
    }

    $scope.OnRackWidthChange = function (pYardWidth) {
        if (pYardWidth > $scope.WHWidth) {
            $scope.errMsg = "Rack Width should be less than Warehouse Width.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            setTimeout(function () {
                $("#txtYardWidth").focus();
            }, 1000);
            return;
        }
    }
    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setDate(objDateParts[0]);
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }
    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
}); 

