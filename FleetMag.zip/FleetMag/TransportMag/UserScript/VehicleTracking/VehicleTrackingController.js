﻿app.controller("VehicleTrackingCtrl", function ($scope, $sessionStorage, $filter, ErrorMsgDisplay, HomeIndex, VehicleTrackingAJService) {
    var LatLog = [];
    var image = '../Content/images/vehLoc.png';
    GetVehicleList();


    function GetVehicleList(VehicleId) {
        var InputParam = {
            VehicleId: VehicleId,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleTrackingAJService.GetVehicleList(InputParam);
        GetData.then(function (Response) {
            $scope.VehicleList = $.parseJSON($.parseJSON(Response.data)).Table;

            angular.forEach($scope.VehicleList, function (value, key) {
                var ParamStr = {};
                var ParamStr = {
                    Title: value.vehicle_no,
                    lat: value.Latitude,
                    lng: value.Longitude
                }
                LatLog.push(ParamStr);
                 //LatLog = [{ Title: 'Vashi', lat: 19.074, lng: 73.000 },
                 //   { Title: 'Ghansoli', lat: 19.116, lng: 73.005 },
                 //   { Title: 'KoparKhairne', lat: 19.099, lng: 73.006 },
                 //   { Title: 'Mbp', lat: 19.102, lng: 73.022 }];
            });
            setTimeout(function () { $("#MapLink").src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAieSnCF-sTGxZ0hDBDZFRwXH4zMjqqBUQ&callback=" + initMap2(LatLog) }, 1000);

        });
    }



    function initMap2(LatLog) {
        // var Vashi = LatLog;        
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 13,
            center: { lat:LatLog[0].lat, lng:LatLog[0].lng}
        });
       // contentString = 'Vashi';
        var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var markers = LatLog.map(function (LatLog1, i) {
            marker = new google.maps.Marker({
                position: LatLog1,
                label: labels[i % labels.length],
                Title: LatLog1.Title,
                icon: image
            });
            var content =  "<b>Vehicle RegNo :</b>" + LatLog1.Title + "<h4><b>Lat :</b>" + LatLog1.lat + " <b>Lng:</b>" + LatLog1.lng + '</h4>'
            var infowindow = new google.maps.InfoWindow();
            google.maps.event.addListener(marker, 'click', (function (marker, content, infowindow) {
                return function () {
                    infowindow.setContent(content);
                    infowindow.open(map, marker);
                };
            })(marker, content, infowindow));
            return marker;
        });

        var markerCluster = new MarkerClusterer(map, markers,
              { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    }


    function initMap3(LatLog) {
        // var Vashi = LatLog;        
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 18,
            center: { lat: LatLog[0].lat, lng: LatLog[0].lng }
        });
        // contentString = 'Vashi';
        var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        var markers = LatLog.map(function (LatLog1, i) {
            marker = new google.maps.Marker({
                position: LatLog1,
                label: labels[i % labels.length],
                Title: LatLog1.Title,
                icon: image
            });
            var content = "<b>Vehicle RegNo :</b>" + LatLog1.Title + "<h4><b>Lat :</b>" + LatLog1.lat + " <b>Lng:</b>" + LatLog1.lng + '</h4>'
            var infowindow = new google.maps.InfoWindow();
            google.maps.event.addListener(marker, 'click', (function (marker, content, infowindow) {
                return function () {
                    infowindow.setContent(content);
                    infowindow.open(map, marker);
                };
            })(marker, content, infowindow));
            return marker;
        });

        var markerCluster = new MarkerClusterer(map, markers,
              { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    }

    function initMap1(LatLog) {
        var Vashi = LatLog;
        var map = new google.maps.Map(document.getElementById('map'), { zoom: 13, center: Vashi });
        var marker = new google.maps.Marker({ position: Vashi, map: map, icon: image });
    };

    $scope.GetVehicleData = function (row) {
       var LatLogTemp = [];
        var InputParam = {
            VehicleId: row.vehicle_id,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleTrackingAJService.GetVehicleList(InputParam);
        GetData.then(function (Response) {
            $scope.VehicleSelect = $.parseJSON($.parseJSON(Response.data)).Table;
            var ParamStr = {};
            angular.forEach($scope.VehicleSelect, function (value, key) {
                 ParamStr = {
                    Title: value.vehicle_no,
                    lat: value.Latitude,
                    lng: value.Longitude
                }
                 LatLogTemp.push(ParamStr);
            });
            setTimeout(function () { $("#MapLink").src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyAieSnCF-sTGxZ0hDBDZFRwXH4zMjqqBUQ&callback=" + initMap3(LatLogTemp) }, 1000);
        });
    }
});

