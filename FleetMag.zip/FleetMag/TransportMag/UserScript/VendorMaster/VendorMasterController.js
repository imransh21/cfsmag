﻿app.controller("mvcVendorCtrl", function ($scope, $localStorage, $compile, $filter, RoleAJService, VendorMasterAJService, HomeIndex, ErrorMsgDisplay) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.isShownRefCode = true;
    $scope.VendorStatus = "N";
    $scope.VehicleInsurarStatus = "N";
    $scope.VehicleLeaseStatus = "N";
    $scope.VehicleLeaseBroker = "N";
    $scope.VehiclePurchaseVendor = "N";
    var appendlst = "";

    GetVendorList();

    if ($scope.VendorId != undefined) {
        if ($scope.VendorId.length > 0) {
            $scope.VendorId = $scope.VendorId[0].VendorId;
            $scope.commonSource($scope.VendorId);
        }
    }

   
    $scope.filter = function () {
        var elem = document.getElementById('LpVendor');
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchRecord) != -1 || $scope.SrchRecord == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }


    $scope.AddDtls = function () {
        ClearData();
        $scope.isShown = false;
        $scope.isShownRefCode = false;
    }

    $scope.EditDtls = function () {
        
        $scope.isShown = false;
        $scope.isShownRefCode = true;
    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }


    $scope.SaveDtls = function () {
        
        $scope.errMsg = "";
        $scope.isError = false;
        var vendorMasterData = false;

        if ($scope.VendorRefCode == "" || $scope.VendorRefCode == undefined || $scope.VendorRefCode == "0") {            
            $scope.errMsg = "Vendor Ref Code is required";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtVendorRefCode").val('');
            setTimeout(function () {
                $("#txtVendorRefCode").focus();
            }, 500);
            return;          
        }


        if ($scope.VendorName == "" || $scope.VendorName == undefined || $scope.VendorName == "0") {
            $scope.errMsg = "Vendor Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtVendorName").focus();
            return;
        }

        if ($scope.Address == "" || $scope.Address == undefined || $scope.Address == "0") {
            $scope.errMsg = "Vendor Address is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtAddress").focus();
            return;
        }

        if ($scope.OperMailid == "" || $scope.OperMailid == undefined || $scope.OperMailid == "0") {
            $scope.errMsg = "Operation Email id is required Or Invalid";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtOperMailId").focus();
            return;
        }


        if ($scope.FinanceMailid == "" || $scope.FinanceMailid == undefined || $scope.FinanceMailid == "0") {
            $scope.errMsg = "Finance Email id is required Or Invalid";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtFinanceMailId").focus();
            return;
        }

        if ($scope.ContactNumber == "" || $scope.ContactNumber == undefined || $scope.ContactNumber == "0") {
            $scope.errMsg = "Contact Number is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtContactPerson").focus();
            return;
        }


        if ($scope.ServiceTaxNumber == "" || $scope.ServiceTaxNumber == undefined || $scope.ServiceTaxNumber == "0") {
            $scope.errMsg = "GST Number is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtServiceTaxNumber").focus();
            return;
        }


        if ($scope.PanNo == "" || $scope.PanNo == undefined || $scope.PanNo == "0") {
            $scope.errMsg = "PAN Number is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtPanNo").focus();
            return;
        }

        if (vendorMasterData == false) {
            var vendorMaster = {
                VendorId: $scope.VendorId,
                VendorRefCode: $scope.VendorRefCode,
                VendorName: $scope.VendorName,                
                Address: $scope.Address,
                OperMailid: $scope.OperMailid,
                FinanceMailid: $scope.FinanceMailid,
                PanNo: $scope.PanNo,
                FinanceReferenceCode: $scope.FinanceReferenceCode,
                VendorStatus: $scope.VendorStatus,
                ContactDetails: $scope.ContactDetails,
                ContactNumber: $scope.ContactNumber,
                ContactFaxNumber: $scope.ContactFaxNumber, 
                ServiceTaxNumber: $scope.ServiceTaxNumber, 
                VehicleInsurarStatus: $scope.VehicleInsurarStatus,
                VehicleLeaseStatus: $scope.VehicleLeaseStatus,
                VehicleLeaseBroker: $scope.VehicleLeaseBroker,
                VehiclePurchaseVendor: $scope.VehiclePurchaseVendor
            };

            var saveData = VendorMasterAJService.saveData(vendorMaster);
            saveData.then(function (vendorMaster) {
                if (vendorMaster.data.ErrorMessage != null && vendorMaster.data.ErrorMessage != "") {
                    $scope.errMsg = vendorMaster.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.isShownRefCode = true;
                    $scope.errMsg = "";
                    $scope.isError = false;
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    GetVendorList();
                    showFirst(vendorMaster.data.VendorId);
                }
            }, function () {
                ClearData();
                $scope.isError = true;
                return;
            });
        }
    }


    function GetVendorList() {
        
        var GetData = VendorMasterAJService.GetAllVendor();

        GetData.then(function (pVendor) {
            
            $scope.VendorList = pVendor.data;
            $scope.errMsg = "";
            $scope.isError = false;

            GetAllVendor();

        }, function (reason) {
            $(VendorMaser).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }



    function GetAllVendor() {
        
        var uiEle = angular.element(document.querySelector('#LpVendor'));
        $('#LpVendor').html('');
        angular.forEach($scope.VendorList, function (value, key) {
            if (!jQuery.isEmptyObject(value.VendorName)) {
                appendlst = appendlst + "<li><a href=\"#\" ng-click=\"commonSource('" + value.VendorId + "')\"><span class=\"fa fa-caret-right tree-icon\"></span>" + value.VendorName + "</a></li>";
                //$('#' + value.TerminalId).attr('data-title', value.TerminalCode);
            }
        });
        //uiEle.remove();
        var uList = $compile(appendlst)($scope);
        uiEle.append(uList);
        appendlst = "";
    }



    function showFirst(VendorId) {
        
        var VendorMaster = {
            VendorId: VendorId
        };
        var getData = VendorMasterAJService.getVendorById(VendorMaster);
        getData.then(function (pVendorMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pVendorMaster.data.ErrorMessage != null) {
                $scope.errMsg = pVendorMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";
                $scope.isError = true;
                return;
            }
            $scope.VendorId = pVendorMaster.data.VendorId
            $scope.VendorRefCode = pVendorMaster.data.VendorRefCode
            $scope.VendorName = pVendorMaster.data.VendorName
            $scope.Address = pVendorMaster.data.Address
            $scope.ContactDetails = pVendorMaster.data.ContactDetails
            $scope.ContactNumber = pVendorMaster.data.ContactNumber
            $scope.ContactFaxNumber = pVendorMaster.data.ContactFaxNumber
            $scope.OperMailid = pVendorMaster.data.OperMailid
            $scope.FinanceMailid = pVendorMaster.data.FinanceMailid
            $scope.PanNo = pVendorMaster.data.PanNo
            $scope.ServiceTaxNumber = pVendorMaster.data.ServiceTaxNumber
            $scope.FinanceReferenceCode = pVendorMaster.data.FinanceReferenceCode
            $scope.VendorStatus = pVendorMaster.data.VendorStatus
            $scope.VehicleInsurarStatus = pVendorMaster.data.VehicleInsurarStatus
            $scope.VehicleLeaseStatus = pVendorMaster.data.VehicleLeaseStatus
            $scope.VehicleLeaseBroker = pVendorMaster.data.VehicleLeaseBroker
            $scope.VehiclePurchaseVendor = pVendorMaster.data.VehiclePurchaseVendor


            var o = {
                VendorName: pVendorMaster.data.VendorName
            };            

        }, function () {
            ClearData();

            $(VendorMaster).each(function (index, item) {
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.commonSource = function (VendorId) {
        
        showFirst(VendorId);
    }


    var watchList = $scope.$watch('VendorList', function () {
        if ($scope.DepotList != undefined) {
            showFirst($scope.DepotList[0].DepotId);
            watchList();
        }
    });


    $scope.clearDtls = function () {
        
        ClearData();
        AddNew();
        $scope.isShown = true;
        $scope.isShownRefCode = true;

        if ($scope.VendorId == undefined || $scope.VendorId == 0 || $scope.VendorId == "") {
            ClearData();
            var watchList = $scope.$watch('VendorList', function () {
                showFirst($scope.VendorList[0].DepotId);
                watchList();
            });
        }
    }
    

    function AddNew() {           
        var pVendorMaster = {
            VendorMaster: ''
        };       
    }

    function ClearData() {
        $scope.VendorId = undefined;
        $scope.VendorName = undefined;
        $scope.VendorRefCode = undefined;
        $scope.Address = undefined;
        $scope.ContactDetails = undefined;
        $scope.ContactNumber = undefined;
        $scope.ContactFaxNumber = undefined;
        $scope.OperMailid = undefined;
        $scope.FinanceMailid = undefined;
        $scope.PanNo = undefined;
        $scope.ServiceTaxNumber = undefined;
        $scope.FinanceReferenceCode = undefined;
        $scope.VendorStatus = "N";

        $scope.VehicleInsurarStatus = "N";
        $scope.VehicleLeaseStatus = "N";
        $scope.VehicleLeaseBroker = "N";
        $scope.VehiclePurchaseVendor = "N";
    }


    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }
        

});