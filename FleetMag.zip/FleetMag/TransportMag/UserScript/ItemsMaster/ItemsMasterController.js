﻿app.controller("ItemCntrl", function ($scope, $localStorage, $compile, $filter, ItemMasterAJService, HomeIndex,KeyRefrenceCtrlAJService, ErrorMsgDisplay) {

    $scope.MakeList = [];
    $scope.VendorList = [];
    $scope.DepotList = [];
    GetDepotLists();
    GetItemType();
    var pitemId = 0;
    var rows = 10;
    function addRow() {
        if ($scope.VendorList == undefined || $scope.VendorList == "" || $scope.VendorList == null) {
            $scope.VendorList = [];
        }



        if ($scope.VendorList.length < rows) {
            for (k = $scope.VendorList.length; k < rows; k++) {
                var newItem = [{ VendorName: "", VendorId: 0 }]
                $scope.VendorList.push(newItem[0]);
            }
        }

    }
    addRow();
    function MakeaddRow() {


        if ($scope.MakeList == undefined || $scope.MakeList == "" || $scope.MakeList == null) {
            $scope.MakeList = [];
        }




        if ($scope.MakeList.length < rows) {
            for (k = $scope.MakeList.length; k < rows; k++) {
                var newItem = [{ MakeDesc: "", KeyId: 0 }]

                $scope.MakeList.push(newItem[0]);

            }
        }

    }
    MakeaddRow();
    GetUsedForLists();
    GetTreeView();
    GetUnitLists();
    $scope.isShownTypeDrp = true;
    $scope.isShown = true;
    $scope.isShownEdit = true;
    $scope.isShownTreeEdit = false;
    $scope.SelectAllData = 'N';

    function GetUsedForLists() {
        //   
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetUsedForList(o);

        getData.then(function (Response) {
            $scope.UsedForList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetDepotLists() {
        //   
        
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetDepotList(o);

        getData.then(function (Response) {
            $scope.DepotList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetUnitLists() {
        //   
        var getData = ItemMasterAJService.GetUnit();

        getData.then(function (Response) {
            $scope.UnitList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting Roles " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    function GetMakeLists() {
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetMakeList(o);

        getData.then(function (Response) {
            $scope.MakeList = Response.data;

            MakeaddRow();
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVendorLists() {
        //   
        var o = {
            ItemId: $scope.ItemId
        };
        var getData = ItemMasterAJService.GetVendorLists(o);

        getData.then(function (Response) {
            $scope.VendorList = Response.data;
            addRow();
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };


    $scope.MinStocLevelCheckMain = function () {


        var Total = 0;
        var TotalMin = $scope.MinStocLevel;
        
        if ($scope.MinStocLevel == '' || $scope.MinStocLevel == undefined) {
            $scope.errMsg = "Please Enter Minimum stock value."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtMinStocLevelid").val('');
            setTimeout(function () {
                $("#txtMinStocLevelid").focus();
            }, 500);
            return;
        }
        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel);
                }
            }
            if (parseFloat(Total) > parseFloat(TotalMin)) {
                $scope.errMsg = "Total Minimum stock value is greater than  Minimum stock"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtMinStocLevelid").val('');
                setTimeout(function () {
                    $("#txtMinStocLevelid").focus();
                }, 500);
                return;
            }

        }
    }


    $scope.MinStocLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.MinStocLevel;
        
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel == '' ? 0 : $scope.DepotList[i].MinStocLevel);
                }
            }

            $scope.MinStocLevel = Total;
    }



    $scope.ReOrderLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.ReOrderLevel;
        
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].ReOrderLevel != '' || $scope.DepotList[i].ReOrderLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].ReOrderLevel == '' ? 0 : $scope.DepotList[i].ReOrderLevel);
                }
            }
            $scope.ReOrderLevel = Total;
    }

    $scope.DongLevelCheck = function (row, index) {


        var Total = 0;
        var TotalMin = $scope.DangerLevel;
        
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].DangerLevel != '' || $scope.DepotList[i].DangerLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].DangerLevel == '' ? 0 : $scope.DepotList[i].DangerLevel);
                }
            }
            $scope.DangerLevel = Total;
    }


    $scope.AddDtls = function () {
        $scope.isShown = false;
        $scope.isShownEdit = true;
        $scope.isShownTypeDrp = false
        $scope.isShownTreeEdit = true;
        GetUsedForLists();
        GetDepotLists();
        addRow();
        MakeaddRow();
        $('#scrolling-listSearch').find('button').attr('disabled', 'disabled');
    }


    $scope.SelectAllRows = function () {
        angular.forEach($scope.UsedForList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.KeyStatus = 'Y';
            }
            else {
                if ($scope.SelectAllData == 'Y') {
                    value.KeyStatus = 'N';
                }
            }
        })
    };
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;
        var emptyData = false;



        if ($scope.ItemType == undefined || $scope.ItemType == "") {
            $scope.errMsg = "Please Select Item Type."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#lstGroupItem").val('');
            setTimeout(function () {
                $("#lstGroupItem").focus();
            }, 500);
            return;
        }

        if ($scope.ItemCode == undefined || $scope.ItemCode == "") {
            $scope.errMsg = "Please Enter Item Code."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemCode").val('');
            setTimeout(function () {
                $("#txtItemCode").focus();
            }, 500);
            return;
        }

        if ($scope.ItemName == undefined || $scope.ItemName == "") {
            $scope.errMsg = "Please Enter Item Name."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemName").val('');
            setTimeout(function () {
                $("#txtItemName").focus();
            }, 500);
            return;
        }
        if ($scope.ItemDesc == undefined || $scope.ItemDesc == "") {
            $scope.errMsg = "Please Enter Item Desc."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $("#txtItemDesc").val('');
            setTimeout(function () {
                $("#txtItemDesc").focus();
            }, 500);
            return;
        }





        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].MinStocLevel != '' || $scope.DepotList[i].MinStocLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].MinStocLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.MinStocLevel)) {
                    $scope.errMsg = "Total Minimum stock value is Not Equal to  Minimum stock."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    return;
                }
            }
        }



        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].ReOrderLevel != '' || $scope.DepotList[i].ReOrderLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].ReOrderLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.ReOrderLevel)) {
                    $scope.errMsg = "Total ReOrder Level value is Not Equal to ReOrder Level."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    return;
                }
            }

        }

        if ($scope.DepotList != undefined && $scope.DepotList.length != 0) {
            var Total = 0;
            for (var i = 0; i < $scope.DepotList.length; i++) {
                if ($scope.DepotList[i].DangerLevel != '' || $scope.DepotList[i].DangerLevel != undefined) {
                    Total = parseFloat(Total) + parseFloat($scope.DepotList[i].DangerLevel);
                }
            }
            if (parseFloat(Total) > 0) {
                if (parseFloat(Total) != parseFloat($scope.DangerLevel)) {
                    $scope.errMsg = "Total Danger Level value is Not Equal to Danger Level."
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');                 
                    return;
                }
            }

        }


        VendorListData = $scope.VendorList.filter(function (value) {
            return value.VendorId != undefined && value.VendorId != "";
        });
        

        if ($scope.ItemType == "I") {


            if ($scope.MinStocLevel == '' || $scope.MinStocLevel == undefined || $scope.MinStocLevel <=0 ) {
                $scope.errMsg = "Please Enter Minimum stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtMinStocLevelid").val('');
                setTimeout(function () {
                    $("#txtMinStocLevelid").focus();
                }, 500);
                return;
            }

            if ($scope.ReOrderLevel == '' || $scope.ReOrderLevel == undefined ||$scope.ReOrderLevel <=0) {
                $scope.errMsg = "Please Enter Re order Level stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtReOrderLevelid").val('');
                setTimeout(function () {
                    $("#txtReOrderLevelid").focus();
                }, 500);
                return;
            }

            if ($scope.DangerLevel == '' || $scope.DangerLevel == undefined || $scope.DangerLevel <=0) {
                $scope.errMsg = "Please Enter Danger stock value."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');

                $("#txtDangerLevel").val('');
                setTimeout(function () {
                    $("#txtDangerLevel").focus();
                }, 500);
                return;
            }

            if (VendorListData.length <= 0) {
                
                $scope.errMsg = "Please Enter atleast one vendor";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }
            
            makeListData = $scope.MakeList.filter(function (value) {
                return value.KeyId != undefined && value.KeyId != "";
            });

            if (makeListData.length <= 0) {
                
                $scope.errMsg = "Please Enter atleast one Make";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }

            UsedListData = $scope.UsedForList.filter(function (value) {
                return value.KeyStatus =="Y";
            });
            if (UsedListData.length <= 0) {
                
                $scope.errMsg = "Please Select atleast one Used For";
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.isError = true;
                return;

            }

        }
        if ($scope.VendorList.length != null || $scope.VendorList.length != undefined) {
            for (i = 0; i < $scope.VendorList.length; i++) {
                for (j = i + 1 ; j < $scope.VendorList.length; j++) {
                    if ($scope.VendorList[i].VendorId == ($scope.VendorList[j].VendorId)) {
                        // got the duplicate element
                        if ($scope.VendorList[i].VendorId != "") {
                            $scope.errMsg = "Vendor Name " + $scope.VendorList[i].VendorName + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        }


        if ($scope.MakeList.length != null || $scope.MakeList.length != undefined) {
            for (i = 0; i < $scope.MakeList.length; i++) {
                for (j = i + 1 ; j < $scope.MakeList.length; j++) {
                    if ($scope.MakeList[i].KeyId == ($scope.MakeList[j].KeyId)) {
                        // got the duplicate element
                        if ($scope.MakeList[i].KeyId != "") {
                            $scope.errMsg = "Make Name " + $scope.MakeList[i].MakeDesc + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }
            }
        }


        if (emptyData == false) {
            var arrList = [];
            
            var InventoryItemMaster = {
                ItemId: $scope.ItemId,
                PItemId: $scope.PItemId,
                ItemType: $scope.ItemType,
                ItemName: $scope.ItemName,
                ItemCode: $scope.ItemCode,
                FinLedgerCode: $scope.FinLedgerCode,
                ItemDesc: $scope.ItemDesc,
                MinStocLevel: $scope.MinStocLevel,
                AverageRate: $scope.AverageRate,
                ReOrderLevel: $scope.ReOrderLevel,
                DangerLevel: $scope.DangerLevel,
                CurrStockDetail: $scope.CurrStockDetail,
                UomId: $scope.UomId,
                ItemAssetType:$scope.ItemAssetType,
                VendorList: $scope.VendorList,
                DepotList: $scope.DepotList,
                MakeList: $scope.MakeList,
                UsedForList: $scope.UsedForList,
                IsGeneral : $scope.chkIsGeneral
            };

            var saveData = ItemMasterAJService.saveUserData(InventoryItemMaster);
            saveData.then(function (pItemMasterAJService) {

                if (pItemMasterAJService.data.ErrorMessage != null && pItemMasterAJService.data.ErrorMessage != "") {
                    $scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    return;
                }
                else {
                    $scope.isShown = true;
                    $scope.isShownEdit = true;

                    $scope.isError = false;
                    $scope.isShownTreeEdit = false;
                    $scope.errMsg = "Data Saved";
                    ErrorPopupMsg('ErrorDivG');
                    clearData();
                    count = 0;
                    appendlst = "";
                    var uiEle = angular.element(document.querySelector('#trview'));
                    uiEle.html('');
                    $scope.TreeViewList = undefined;
                    GetTreeView();
                    $('#scrolling-listSearch').find('button').removeAttr('disabled', 'disabled');
                }
            }, function () {
                clearFields();
                $(UserMasterS).each(function (index, item) {
                    if (item.Key == 'Message3') {
                        $scope.setclass = "popupBase alert alertShowMsg";
                        $scope.errMsg = item.value;
                    }
                });

                $scope.isError = true;
                return;
            });
        }

    }


    function GetTreeView() {
        
        var o = {
            ItemId: $scope.ItemId,
            ItemName: $scope.SrchUser
        };
        var getData = ItemMasterAJService.GetTreeView(o);

        getData.then(function (Response) {

            $scope.TreeViewList = Response.data;
            menuList($scope.TreeViewList.Menu);
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    var appendlst = "";
    var count = 0;
    function menuList(menu) {
        
        $('#scrolling-listSearch .fa-spinner').css({ 'display': 'block' });


        if (count == 0) {
            appendlst = appendlst + "<ul id='trview' class='treeView groupView' >";
            count = count + 1;
        } else {
            appendlst = appendlst + "<ul class='Lbod'>";

        }


        angular.forEach(menu, function (value, key) {
            if (!jQuery.isEmptyObject(value)) {
                appendlst = appendlst + "<li class=\"nav-item\">" +
                                                    "<button type=\"button\"  ng-click=\"commonSource('" + value.ItemId + "'," + "'" + value.ItemCode + "'," + value.PItemId + ",'" + value.ItemType + "')\">" +
                                                        "<span></span>" + value.ItemName +
                                                    "</button>"

                if (value.SubMenu.length != 0) {
                    menuList(value.SubMenu);
                }

                appendlst = appendlst + "</li>";


            }

        });

        appendlst = appendlst + "</ul>";
        //uiEle.remove();
        var menulst = $compile(appendlst)($scope);
        var uiEle = angular.element(document.querySelector('#trview'));
        uiEle.html('');
        uiEle.replaceWith(menulst);

        //$('#scrolling-listSearch .fa-spinner').css({ 'display': 'none' });
        //$('#scrolling-listSearch ul.Lbod').addClass('hide');
        $('#scrolling-listSearch li button').click(function () {
            $('#scrolling-listSearch li').removeClass('active');
            $(this).closest('li').find('ul').toggleClass('hide');
            $(this).closest('li').addClass('active');
        });
    }


    $scope.commonSource = function (ItemId, ItemCode, PItemId, ItemType) {
        $scope.isShownEdit = false;
        //showFirst(ItemId);
        $scope.ItemId = ItemId;
        AssignFirst($scope.ItemId);        
        $scope.ParentCode = ItemCode;
        $scope.PItemId = ItemId;        
        $scope.ItemType = ItemType
        $scope.ItemTypeTemp = ItemType
        
        if ($scope.ItemType == 'G') {
            $('#divGroup').removeClass('hide');
            $('#divItem').addClass('hide');
        }
        else {
            $('#divItem').removeClass('hide');
            $('#divGroup').addClass('hide');
        }
         
    }


    function showFirst(ItemId) {
        var ItemMaster = {
            ItemId: ItemId
        };

        var getData = ItemMasterAJService.getItemById(ItemMaster);
        getData.then(function (pItemMaster) {
            debugger;
            $scope.errMsg = "";
            $scope.isError = false;

            if (pItemMaster.data.ErrorMessage != null) {
                $scope.errMsg = pItemMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            
            $scope.ItemId = pItemMaster.data.ItemId;
            $scope.PItemId = pItemMaster.data.PItemId;
            $scope.ItemType = pItemMaster.data.ItemType;
            $scope.ItemName = pItemMaster.data.ItemName;
            $scope.ParentCode = pItemMaster.data.ParentCode;
            $scope.ItemCode = pItemMaster.data.ItemCode;
            $scope.FinLedgerCode = pItemMaster.data.FinLedgerCode;
            $scope.ItemDesc = pItemMaster.data.ItemDesc;
            $scope.MinStocLevel = pItemMaster.data.MinStocLevel;
            $scope.ReOrderLevel = pItemMaster.data.ReOrderLevel;

            $scope.DangerLevel = pItemMaster.data.DangerLevel;
            $scope.UomId = pItemMaster.data.UomId;
            $scope.AverageRate = pItemMaster.data.AverageRate;
            $scope.InStock = pItemMaster.data.InStock;
            $scope.PipeLineStock = pItemMaster.data.PipeLineStock;
            $scope.ItemAssetType = String(pItemMaster.data.ItemAssetType);
            $scope.chkIsGeneral = pItemMaster.data.IsGeneral;

            GetDepotLists();
            GetUsedForLists();
            GetMakeLists();
            GetVendorLists();
            $scope.isShownTreeEdit = true;
            if ($scope.ItemType == 'G') {
                $('#divGroup').removeClass('hide');
                $('#divItem').addClass('hide');
            }
            else {
                $('#divItem').removeClass('hide');
                $('#divGroup').addClass('hide');
            }

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    function AssignFirst(ItemId) {
        var ItemMaster = {
            ItemId: ItemId
        };

        var getData = ItemMasterAJService.getItemById(ItemMaster);
        getData.then(function (pItemMaster) {
            debugger;
            $scope.errMsg = "";
            $scope.isError = false;

            if (pItemMaster.data.ErrorMessage != null) {
                $scope.errMsg = pItemMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }

            $scope.ItemId = pItemMaster.data.ItemId;
           // $scope.PItemId = pItemMaster.data.PItemId;
            $scope.ItemType = pItemMaster.data.ItemType;
            $scope.ItemName = pItemMaster.data.ItemName;
           // $scope.ParentCode = pItemMaster.data.ParentCode;
            $scope.ItemCode = pItemMaster.data.ItemCode;
            $scope.FinLedgerCode = pItemMaster.data.FinLedgerCode;
            $scope.ItemDesc = pItemMaster.data.ItemDesc;
            $scope.MinStocLevel = pItemMaster.data.MinStocLevel;
            $scope.ReOrderLevel = pItemMaster.data.ReOrderLevel;

            $scope.DangerLevel = pItemMaster.data.DangerLevel;
            $scope.UomId = pItemMaster.data.UomId;
            $scope.AverageRate = pItemMaster.data.AverageRate;
            $scope.InStock = pItemMaster.data.InStock;
            $scope.PipeLineStock = pItemMaster.data.PipeLineStock;
            $scope.ItemAssetType = String(pItemMaster.data.ItemAssetType);
            $scope.chkIsGeneral = pItemMaster.data.IsGeneral;

            GetDepotLists();
            GetUsedForLists();
            GetMakeLists();
            GetVendorLists();
            $scope.isShownTreeEdit = true;
            if ($scope.ItemType == 'G') {
                $('#divGroup').removeClass('hide');
                $('#divItem').addClass('hide');
            }
            else {
                $('#divItem').removeClass('hide');
                $('#divGroup').addClass('hide');
            }

        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }


    $scope.EditDtls = function () {
        $scope.isShownTypeDrp = true;
        $scope.isShown = false;
        $scope.isShownEdit = true;
        $scope.isShownTreeEdit = true;
        $('#scrolling-listSearch').find('button').attr('disabled', 'disabled');
    }
    $scope.TypeChnage = function (type) {

        if (type == 'G') {

            if ($scope.ItemTypeTemp == "I") {
                $scope.errMsg = "Can Not Add Group Under Item."
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstGroupItem").val('');
                setTimeout(function () {
                    $("#lstGroupItem").focus();
                }, 500);
                return;
            }

            $('#divGroup').removeClass('hide');
            $('#divItem').addClass('hide');
        }
        else {
            if ($scope.PItemId == undefined || $scope.PItemId == 0) {
                $scope.errMsg = "Please Select Group"
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $("#lstGroupItem").val('');
                setTimeout(function () {
                    $("#lstGroupItem").focus();
                }, 500);
                return;
            }
            else {
                $scope.ItemId = undefined;
                $scope.ItemCode = undefined;
                $scope.ItemName = undefined;
                $scope.ItemDesc = undefined;
                $('#divItem').removeClass('hide');
                $('#divGroup').addClass('hide');
            }
        }


    }


    function clearData() {
        
        $scope.ItemId = undefined;
        $scope.PItemId = undefined;
        $scope.ItemType = undefined;
        $scope.ItemName = undefined;
        $scope.ItemCode = undefined;
        $scope.FinLedgerCode = undefined;
        $scope.ItemDesc = undefined;
        $scope.MinStocLevel = undefined;
        $scope.ReOrderLevel = undefined;
        $scope.ParentCode = undefined;
        $scope.DangerLevel = undefined;
        $scope.UomId = undefined;
        $scope.AverageRate = undefined;
        $scope.VendorList = undefined;
        $scope.DepotList = undefined;
        $scope.ItemTypeTemp = undefined;
        $scope.MakeList = undefined;
        $scope.UsedForList = undefined;
        $scope.SelectAllData = 'N';
        $scope.ItemAssetType = undefined;
    }


    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownTreeEdit = false;
        $scope.isShownTypeDrp = true;
        $('#divGroup').removeClass('hide');
        $('#divItem').addClass('hide');
        $('#scrolling-listSearch').find('button').removeAttr('disabled', 'disabled');

    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }



    $scope.AddNewRow = function () {
        
        if ($scope.VendorList == undefined || $scope.VendorList == "" || $scope.VendorList == null) {
            $scope.VendorList = [];
        }
        var newItem = [{ VendorName: "", VendorId: 0 }]

        $scope.VendorList.push(newItem[0]);




    }

    $scope.AddNewRowMake = function () {
        
        if ($scope.MakeList == undefined || $scope.MakeList == "" || $scope.MakeList ==null) {
            $scope.MakeList = [];
        }
        var newItem = [{ MakeDesc: "", KeyId: 0 }]

        $scope.MakeList.push(newItem[0]);




    }
    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }


    $scope.filter = function () {
        $('.treeView li li').each(function (indext) {
            $(this).closest('ul').removeClass('hide');
            $(this).removeClass('hide');
            

            var tstvalue = $(this).text();
            if (tstvalue.toUpperCase().indexOf($scope.SrchUser.toUpperCase()) == -1) {                
                $(this).addClass('hide');
            }
            else {
                $(this).closest('ul.Lbod').removeClass('hide');
                //alert('no')
            }
            //var tstvalue = $(this).text();
            //if (tstvalue.toUpperCase().indexOf($scope.SrchUser.toUpperCase()) > -1) {
            //    $(this).removeClass('hide');
            //    $(this).closest('ul').removeClass('hide');
            //}
            //else {
            //    $(this).closest('ul').addClass('hide');
            //    $(this).addClass('hide');
                
            //}
        });     
    }


    function GetItemType() {
        var KeyReference = {
            HeadCode: 'Type',
            GroupCode: 'Item'
        };
        var getData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        getData.then(function (pKeyReference) {
            $scope.ItemTypeLst = pKeyReference.data;     
        }, function (reason) {
            $scope.errMsg = "Error in getting Tariff Heads information " + reason.data;
            $scope.isError = true;
            return;
        });
    }

});