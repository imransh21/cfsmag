﻿app.controller("ctrEquipGateOutFromDist", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, EquipGateOutFromDistAJService, HomeIndex) {
    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = true;
    $scope.isShownPrint = false;
    $scope.isShownTransferId = true;
    $scope.EquipGateFromDistList = [];
    $scope.isShownJob = true;
 
      $scope.GetDataFilter = function () {
          
          var InputParam = {
              locationId: $sessionStorage.locationId,
              JobId: $scope.JobId,
              FromDt: $scope.fromDate,
              ToDt: $scope.Todate
          }
          var GetData = EquipGateOutFromDistAJService.GetPendingList(InputParam);
          GetData.then(function (Response) {
              
              $scope.EquipGateFromDistList = Response.data;
              $scope.isShownSave = true;
          });        

      }

      $scope.CheckAll = function () {
          
          angular.forEach($scope.EquipGateFromDistList, function (value, key) {
              if ($scope.SelectAllData == 'N') {
                  value.IsCheck = "N";
              }
              else {
                  if ($scope.SelectAllData == 'Y') {
                      value.IsCheck = "Y";
                  }
              }
          })
      };


      $scope.SaveDtls = function () {
          
        var ErrorTemp = undefined;
            
        var temp = $scope.EquipGateFromDistList.filter(function (value) {
            return value.IsCheck == "Y";
        });

        if (temp.length == 0) {
            $scope.errMsg = "Please Select at least one checkbox.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

          var InputParam = {
             locationId:$sessionStorage.locationId,
             ApproveBy: $sessionStorage.loginUser,
             arrEquipmentTransferDtls: $scope.EquipGateFromDistList
        }
              var GetData = EquipGateOutFromDistAJService.SaveTransferDtls(InputParam);
        GetData.then(function (Response) {
            
            if (Response.data.ErrorMessage == "" || Response.data.ErrorMessage == null || Response.data.ErrorMessage == undefined) {
            
                $scope.isshownAdd = false;
                $scope.isShown = true;
                $scope.isShownSearch = true;
                $scope.isShownAdd = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownClear = false;
                $scope.isShownPrint = false;
                $scope.SuccessMsg = "Data Saved........................";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;                
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });


    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage('/Home/Configration');
    }
  
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";
    }

    function ClearData() {
        $scope.JobNo = undefined;
        $scope.JobId = undefined;
        $scope.fromDate = undefined;
        $scope.Todate = undefined;
        $scope.EquipGateFromDistList = [];

    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isshownAdd = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownTransferId = true;
        
    }

    $scope.ClearDetails = function () {
        $scope.isShown = true;
        $scope.isShownLease = true;
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShownTransferId = true;
        $scope.isshownAdd = false;
        $scope.isShownJob = true
        ClearData();
    }

  
});