﻿app.service("EquipGateOutFromDistAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetPendingList = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipGateOutFromDist/GetPendingList",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
   
    this.SaveTransferDtls = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/EquipGateOutFromDist/SaveDetails",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

   

});