﻿app.service("POGenerationAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
    this.saveData = function (pKeyReference) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/SaveDetails",
            data: JSON.stringify(pKeyReference),
            dataType: "json"
        });
        return response;
    }


    this.GetIndentData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/LoadAllDetailsByVendorId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    this.getItemByPoId = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/GetpODetailsBypOId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
    this.RemoveItems = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/POGeneration/removePaymentTerms",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
});