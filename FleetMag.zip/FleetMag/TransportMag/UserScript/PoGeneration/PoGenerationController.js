﻿app.controller("cntrlPoGeneration", function ($scope, $sessionStorage, $compile, $filter, KeyRefrenceCtrlAJService ,PatternConfigurationAJService, HomeIndex, POGenerationAJService, IndentGenAJService, DepotAJService, ErrorMsgDisplay) {
    $scope.isShown = true;
    $scope.isShownPoNo = true;
    $scope.isShownVendor = true;
    $scope.isShownDepot = true;
    $scope.isShownEdit = true;
    $scope.isDisplayShown = true;
    $scope.SelectAllData = 'N';
    $scope.PoTermList = [];
    DepoLookupList();
    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    var rows = 5;
    addRow();

    function addRow() {
        $scope.IndentList = [];
        if ($scope.IndentList.length < rows) {
            for (k = $scope.IndentList.length; k < rows; k++) {
                var newItem = { PartName: "", PartNo: "" }
                $scope.IndentList.push(newItem);

            }
        }

    }

    $scope.CurrentIndex = function (row) {
        $scope.DtlCurrentIndex = row;
    }


    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }


    $scope.IsItemCheck = function (row) {
        
     

        IndentListDataTest = $scope.IndentList.filter(function (value) {
            return value.IsItemchk == "Y"
        });
        if ($scope.IndentList.length != IndentListDataTest.length) {
            $scope.SelectAllData = 'N';
        }
        else {
            $scope.SelectAllData = 'Y';
        }


    }

    $scope.SelectAllRows = function () {
        
        angular.forEach($scope.IndentList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.IsItemchk = 'N';
            }
            else {
                value.IsItemchk = 'Y';
            }
        })
        }
   


    $scope.GetAllIndentDetails = function () {
        

        if ($scope.VendorId == '' || $scope.VendorId == undefined) {
            $scope.errMsg = "Please Select Vendor ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtVendor").val('');
            setTimeout(function () {
                $("#txtVendor").focus();
            }, 500);
            return;
        }

        if ($scope.DepotId == '' || $scope.DepotId == undefined) {
            $scope.errMsg = "Please Select Depot ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#lstDepo").val('');
            setTimeout(function () {
                $("#lstDepo").focus();
            }, 500);
            return;
        }

        var InputParam = {            
            DeportId: $scope.DepotId,
            VendorId: $scope.VendorId,
            PoType: $scope.PoType
        }
        var GetData = POGenerationAJService.GetIndentData(InputParam);
        GetData.then(function (Response) {
            
            //$scope.IndentNo = Response.data.IndentNo;
            //$scope.IndentDate = Response.data.IndentDate;
            //$scope.NatureOfIndent = Response.data.NatureOfIndent;
            //$scope.DepotCode = Response.data.DeportCd;
            //   $scope.ExpDelvDate = Response.data.ExpDelvDate;
            $scope.IndentList = Response.data;
            // $scope.IndentDetailsList = Response.data.IndentDtlsList;
            //$scope.isShownIndent = true;

            //$scope.isDisplayShown = true;
            //$scope.isShownVendor = true;
        });
    }

    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownPoNo = true;
        $scope.isShownVendor = true;
        $scope.isShownDepot = true;
        $scope.isShownEdit = true;
        $scope.isDisplayShown = true;
    }



    function clearData() {
      
        $scope.PoId=undefined,
        $scope.PoNo = undefined;
        $scope.PoDate = undefined;
        $scope.VendorId = undefined;
        $scope.DepotId = undefined;

        $scope.VendorName = undefined;
        $scope.PaymentTerm = undefined;
        $scope.IndentList = undefined;
        $scope.DepotAddress = undefined;
        $scope.SchDelDate = undefined;
        $scope.PoTermList = [];
    }


    $scope.showFirst = function (PoId) {
        var ItemMaster = {
            PoId: PoId
        };

        var getData = POGenerationAJService.getItemByPoId(ItemMaster);
        getData.then(function (Response) {
            $scope.errMsg = "";
            $scope.isError = false;
            
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                $scope.errMsg = Response.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
            $scope.PoId = Response.data.PoId;
            $scope.PoNo = Response.data.PoNo;
            $scope.PoApproveStatus = Response.data.PoApproveStatus;
            $scope.PoDate = Response.data.PoDate;
            $scope.VendorId = Response.data.VendorId;
            $scope.DepotId = Response.data.DepotId;
            $scope.PoQty = Response.data.PoQty;
            $scope.VendorName = Response.data.VendorName;
            $scope.PaymentTerm = Response.data.PaymentTerm;
            $scope.IndentList = Response.data.IndentDtlsList;
            $scope.PoTermList = Response.data.arrPaymentTerms;
            $scope.BillingAddress = Response.data.BillingAddress;
            $scope.DeliveryAddress = Response.data.DeliveryAddress;
            $scope.BillSubmitAddress = Response.data.BillSubmitAddress;
            $scope.SchDelDate = Response.data.SchDelDate;
            $scope.DepotData();
        }, function () {
            clearData();

            $(UserMasterS).each(function (index, item) {//added by priya
                if (item.Key == 'Message3') {
                    $scope.setclass = "popupBase alert alertShowMsg";

                    $scope.errMsg = item.value;
                }
            });
            $scope.isError = true;
            return;
        });
    }

    $scope.InitAutoComplete = function () {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".poTermsList").autocomplete({
            source: function (request, response) {
                var KeyReference = {
                    HeadCode: 'Terms',
                    GroupCode: 'PO'
                };
                var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
                GetData.then(function (Response) {
                    response($.map(Response.data, function (item, key) {
                        return {
                            label: item.CodeValue,
                            Pkey: item.Pkey,
                            CodeValue: item.CodeValue,
                            PoTermDesc: item.Description
                        }
                    }));
                });            
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.PoTermList[Indexval].PoTermRefCode = i.item.CodeValue;
                    $scope.PoTermList[Indexval].PoTermCode = i.item.Pkey;
                    $scope.PoTermList[Indexval].PoTermDesc = i.item.PoTermDesc;
                });
            },
            minLength: 3
        });
    }

    $scope.SaveDtls = function () {


        if ($scope.SchDelDate == '' || $scope.SchDelDate == undefined) {
            $scope.errMsg = "Please Enter Scheduled Delivery Date ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtVendor").val('');
            setTimeout(function () {
                $("#txtVendor").focus();
            }, 500);
            return;
        }
        
        if ($scope.VendorId == '' || $scope.VendorId == undefined) {
            $scope.errMsg = "Please Select Vendor ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtVendor").val('');
            setTimeout(function () {
                $("#txtVendor").focus();
            }, 500);
            return;
        }

        if ($scope.DepotId == '' || $scope.DepotId == undefined) {
            $scope.errMsg = "Please Select Depot ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#lstDepo").val('');
            setTimeout(function () {
                $("#lstDepo").focus();
            }, 500);
            return;
        }
        var ErrorFound = false;
        //angular.forEach($scope.IndentList, function (value, key) {
        //    if (ErrorFound == false) {
        //        if (value.IsIndentchk == "Y" && value.IsFinalApprove == "N") {

        //            $scope.errMsg = "Please Select Final Approve CheckBox For Indent No:- " + value.IndentNo

        //            ErrorFound = true;
        //            return;
        //        }
        //    } if (ErrorFound == false) {
        //        if (value.IsIndentchk == "N" && value.IsFinalApprove == "Y") {

        //            $scope.errMsg = "Please Select Indent CheckBox For Indent No:- " + value.IndentNo
        //            ErrorFound = true;
        //            return;
        //        }
        //    }

        //if (value.IsIndentchk == "Y" && value.IsFinalApprove == "Y") {
        if ($scope.IndentList == undefined) {
            $scope.errMsg = "Please Select Atleast One Item.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;

        }

        if ($scope.IndentList != undefined) {
            IndentListData = $scope.IndentList.filter(function (value) {
                return value.IsItemchk == "Y";
            });
        }

        if (IndentListData.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Item.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        angular.forEach(IndentListData, function (value1, key) {
            
            //if (ErrorFound == false) {
            //    if (value1.IsApprove == "N" && value1.IsReject == "N") {

            //        $scope.errMsg = "Please Select Approve/Reject Item For Indent No:- " + value.IndentNo
            //        ErrorFound = true;
            //        return;
            //    }
            //}
            if (ErrorFound == false) {

                if (value1.PoRate == "" || value1.PoRate == undefined || value1.PoRate <= 0) {

                    $scope.errMsg = "Please Enter Po Rate for Item No:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }

                if (value1.PoAmount == "" || value1.PoAmount ==undefined ||value1.PoAmount <=0 ) {

                    $scope.errMsg = "Please Enter Po Amt for Item No:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }

                if (value1.PoAmountWithTax == "" || value1.PoAmountWithTax == undefined || value1.PoAmountWithTax <= 0) {

                    $scope.errMsg = "Please Enter Amount With Tax for Item No:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }

                if (value1.PoQty == "" || value1.PoQty == undefined || value1.PoQty <= 0) {

                    $scope.errMsg = "Please Enter Po Qtyfor Item No:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }
            }

        });
        //}
        //});

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if ($scope.PoTermList == undefined || $scope.PoTermList == '' || $scope.PoTermList == null) {
            $scope.errMsg = "Please Select Terms and Conditions"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        ErrorFound = false;
        angular.forEach($scope.PoTermList, function (value1, key) {
            if (ErrorFound == false) {
                if (value1.PoTermRefCode == "" || value1.PoTermRefCode == null || value1.PoTermRefCode == '' || value1.PoTermRefCode == "") {
                    $scope.errMsg = "Please select Term Reference Code"
                    ErrorFound = true;
                }              
                if (value1.PoTermCode == "" || value1.PoTermCode == null || value1.PoTermCode == '' || value1.PoTermCode == "") {
                    $scope.errMsg = "Please select Term Reference Code"
                    ErrorFound = true;
                }
                if (value1.PoTermDesc == "" || value1.PoTermDesc == null || value1.PoTermDesc == '' || value1.PoTermDesc == "") {
                    $scope.errMsg = "Please enter Description"
                    ErrorFound = true;
                }
                if (ErrorFound == false) {
                    value1.PoId = $scope.PoId;
                    value1.LocationId=$sessionStorage.locationId;
                    value1.DepotId=$scope.DepotId;
                    value1.CreatedBy=$sessionStorage.loginUser;
                    value1.ModifiedBy=$sessionStorage.loginUser;
                }
            }
        });

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            PoId: $scope.PoId,
            PoNo: $scope.PoNo,
            PoType:$scope.PoType,
            VendorId: $scope.VendorId,
            DepotId: $scope.DepotId,
            PaymentTerm: $scope.PaymentTerm,
            PoQty: $scope.PoQty,
            BillingAddress:$scope.BillingAddress,
            DeliveryAddress:$scope.DeliveryAddress,
            BillSubmitAddress:$scope.BillSubmitAddress,
            IndentDtlsList: IndentListData,
            arrPaymentTerms: $scope.PoTermList,
            SchDelDate:$scope.SchDelDate
        }
        var GetData = POGenerationAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.showFirst(Response.data.PoId)
                $scope.isDisplayShown = true;
                $scope.isShown = true;
                $scope.isShownPoNo = true;
                $scope.isShownVendor = true;
                $scope.isShownDepot = true;
            }
        });
    }

    $scope.AddDtls=function()
    {
        clearData();
        $scope.isShown = false;
        
        $scope.isShownPoNo = true;
        $scope.isShownVendor = false;
        $scope.isShownDepot = false;
        $scope.isDisplayShown = false;
    }



    $scope.SearchDtls = function () {
        clearData();
        setTimeout(function () {
            $("#txtPoNo").focus();
        }, 500);
        $scope.isShownPoNo = false;
       
    }
    $scope.EditDtls = function () {

       
        if ($scope.PoId == '' || $scope.PoId == undefined) {
            $scope.errMsg = "Please Select Po no ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPoNo").val('');
            setTimeout(function () {
                $("#txtPoNo").focus();
            }, 500);
            return;
        }

        if ($scope.PoApproveStatus == 'A') {
            $scope.errMsg = "Po Is Approve you Can Not Edit ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPoNo").val('');
            setTimeout(function () {
                $("#txtPoNo").focus();
            }, 500);
            return;
        }
        if ($scope.PoApproveStatus == 'R') {
            $scope.errMsg = "Po Is Reject you Can Not Edit ."
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');

            $("#txtPoNo").val('');
            setTimeout(function () {
                $("#txtPoNo").focus();
            }, 500);
            return;
        }
        $scope.isShown = false;
        $scope.isShownDepot = false;
        $scope.isDisplayShown = true;

    }

    $scope.DepotData=function()
    {    var DepotMaster = { 
        DepotId: $scope.DepotId
    };
        var getData = DepotAJService.getDepotById(DepotMaster);
        getData.then(function (pDepotMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pDepotMaster.data.ErrorMessage != null) {
                $scope.errMsg = pDepotMaster.data.ErrorMessage;
                $scope.setclass = "popupBase alert alertShowMsg";//added by priya

                $scope.isError = true;
                return;
            }
          
            $scope.DepotAddress = pDepotMaster.data.DepotAddress;
          

        })
    }

    $scope.addNewItem = function () {
        var InputParam = {
            PoId:$scope.PoId,            
            PoTermId:0,
            PoTermCode:"",
            PoTermRefCode:"",
            PoTermDesc:"",
            LocationId:$sessionStorage.locationId,
            DepotId: $scope.DepotId,
            CreatedBy:$sessionStorage.loginUser,
            ModifiedBy:$sessionStorage.loginUser
        }
        $scope.PoTermList.push(InputParam);
    }

    $scope.checkDuplicateTerm = function (row) {
        var checkvalue = [];
         checkvalue = $scope.PoTermList.filter(function (value) {
            return value.PoTermRefCode == row.PoTermRefCode
        });
        if (checkvalue.length > 1) {
            $scope.errMsg = "Duplicate terms and conditions found";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.PoTermRefCode = undefined;
            row.PoTermCode = undefined;
            $scope.isError = true;
            return;
        }
    };

    $scope.RemoveItem = function (row) {
        var index = $scope.PoTermList.indexOf(row);
        $scope.PoTermList.splice(index, 1);
        if (row.PoTermId != 0 || row.PoTermId != "" || row.PoTermId != undefined) {
            var InputParam = {
                PoTermId: row.PoTermId
            }
            var GetData = POGenerationAJService.RemoveItems(InputParam);
            GetData.then(function (Responce) {
                if (Responce.data.ErrorMessage != null) {
                    $scope.errMsg = Responce.data.ErrorMessage;
                    $scope.setclass = "popupBase alert alertShowMsg";
                    $scope.isError = true;
                    return;
                }
            });
        }
    }

    $scope.CalculateAmount = function(row) {
        debugger;
        row.PoAmount = parseInt(row.PoQty) * parseFloat(row.PoRate);
        row.PoAmountWithTax = (parseFloat(row.PoAmount) + (parseFloat(row.PoAmount) * (parseFloat(row.TaxPersentage) / 100)));
    }
})