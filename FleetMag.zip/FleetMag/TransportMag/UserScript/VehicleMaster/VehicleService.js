﻿app.service("VehicleAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.SaveDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/SaveVehicleData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetVehicleDtlsById = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleDtlsByID",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVendorDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVendorLookup",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleMasterWeeklyListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleMasterWeeklyListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleMasterDailyListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleMasterDailyListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleMasterMonthlyListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleMasterMonthlyListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleMaintReportListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleMaster/GetVehicleMaintReportListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetPatternDataById = function (pVehicleManufacturerDetails) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/PatternConfiguration/GetPatternDataById",
            data: JSON.stringify(pVehicleManufacturerDetails),
            dataType: "json"
        });
        return response;
    }

    this.GetTyremappingByVehicleId = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/GetVehicleTyreMappingByVehicleID",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }
    this.GetAssetNoList = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/GetAssetList",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

    this.GetAssetDetailsByAssetId = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/TyreManagement/GetTyreConfigrationById",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

    this.SaveAssetDetails = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/SaveDetails",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

    this.SaveNewDetails = function (pVehicleTyreMapping) {
        
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/SaveNewPattern",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

   
    this.RemoveAssetDetails = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/RemoveDetails",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

    this.SwapAssets = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/SwapAssets",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }

    this.DeleteData = function (pVehicleTyreMapping) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/VehicleTyreMapping/DeleteTyreMapping",
            data: JSON.stringify(pVehicleTyreMapping),
            dataType: "json"
        });
        return response;
    }
    


});