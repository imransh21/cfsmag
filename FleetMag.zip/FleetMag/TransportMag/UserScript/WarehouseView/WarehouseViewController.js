﻿app.controller("mvcWarehouseViewCtrl", function ($scope, $sessionStorage, $filter, $compile, WarehouseViewAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.FilterDt = [];
    var appendlst = "";    
    //GetLineName();
    //DestinationList();
   // GetRakeOperator(); 
    ReportFilterLookup();

    

    function GetLineName() {
        
        var getLineName = WarehouseViewAJService.GetLineNameDtls("");
        getLineName.then(function (Response) {
            $scope.LineList = Response.data;
        }, function (reason) {
            $scope.error = reason.data;
            alert('Error in fetching Line Details');
        });
    }

    function DestinationList() {
        $scope.IsShowLoading = true;

        var GetData = WarehouseViewAJService.GetAllDestinations();

        GetData.then(function (pResult) {
            $scope.DestinationList = $.parseJSON(pResult.data);
            $scope.IsShowLoading = false;
        });
    };

    function GetRakeOperator() {
        var getRakeOperator = WarehouseViewAJService.getRakeoperatorDtls("1");
        getRakeOperator.then(function (Response) {
            $scope.RakeOperatorList = Response.data;
        }, function (reason) {
            $scope.error = reason.data;
            alert('Error in fetching Rake Operator');
        });
    }

    $scope.Display = function () {
        GetYardContainerDetails();
    }

    function GetYardContainerDetails() {
        var FilterString = '';
        angular.forEach($scope.FilterDt, function (value, key) {
            if (value.FilterDataType == 'VARCHAR2') {
                FilterString = FilterString + ' and ' + value.FilterField + '="' + value.FilterValue + '"';
            } else {
                if (value.FilterDataType == 'NUMBER') {
                    FilterString = FilterString + ' and ' + value.FilterField + '=' + value.FilterValue ;
                }
            }
        });

        var ContainerDetails = {
            BlockId: $('#lstBlockList').val(),
            FilterText: FilterString
        }
        var getContDetails = WarehouseViewAJService.getWhBalDetails(ContainerDetails);
        getContDetails.then(function (Response) {
            $scope.ContDetails = Response.data;
        }, function (reason) {
            $scope.error = reason.data;
            alert('Error in fetching Yard Container Details');
        });
    }

    function ReportFilterLookup() {
        
        var InputParam = {
            RepParamCode: 'WHVIEW'
        }
        var getFilterData = WarehouseViewAJService.getReportFilterLookup(InputParam);
        getFilterData.then(function (Response) {
            $scope.RepFilterData = $.parseJSON($.parseJSON(Response.data));
        }, function (reason) {
            $scope.error = reason.data;
            alert('Error in fetching Report Filter Data');
        });
    }

    $scope.AddFilter = function () {
        var InputFilterData = {
            FilterFieldnm: $scope.FilterField.RepParamName,
            FilterField: $scope.FilterField.ColumnName,
            FilterValue: $scope.FilterValue,
            FilterDataType:$scope.FilterField.ColumnDatatype
        }
        $scope.FilterDt.push(InputFilterData);
    }

    $scope.DeleteFilter = function (row) {
        var index = $scope.FilterDt.indexOf(row);
        $scope.FilterDt.splice(index, 1);
    }
    $scope.exportData = function () {
        var blob = new Blob([document.getElementById('Exportable').innerHTML], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        });
        saveAs(blob, "WareHouseDetails.xls");
    };
});

