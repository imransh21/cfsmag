﻿app.service("WarehouseViewAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetLineNameDtls = function (ContainerDetails) {
        var response = $http({
            method: "POST",
            contentType: "application/json; charset=utf-8",
            url: baseUrl + "/Warehouse/WarehouseView/LineLookup",
            dataType: "json",
            data: JSON.stringify(ContainerDetails)
            // data: formToJSON()
        });
        return response;
    }



    this.getReportFilterLookup = function (InputParam) {
        // 
        
        var response = $http({
            method: "POST",
            contentType: "application/json; charset=utf-8",
            url: baseUrl + "/Warehouse/WarehouseView/GetReportFilterData",
            dataType: "json",
            data: JSON.stringify(InputParam)
        });
        return response;
    }

    this.GetAllDestinations = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/WarehouseView/LoadAllRailIcds",
            dataType: "json"
        });
        return response;
    }

    this.getRakeoperatorDtls = function (seltext) {
        var response = $http({
            method: "POST",
            contentType: "application/json; charset=utf-8",
            url: baseUrl + "/WarehouseView/RailOperatorLookup",
            dataType: "json",
            data: "{ 'seltext': '" + seltext + "'}"
        });
        return response;
    }

    this.getWhBalDetails = function (ContainerDetails) {
        // 
        var response = $http({
            method: "POST",
            contentType: "application/json; charset=utf-8",
            url: baseUrl + "/WarehouseView/WH_BAL_Details",
            dataType: "json",
            data: JSON.stringify(ContainerDetails)
        });
        return response;
    }

  

})