﻿app.controller("CntrlGoodsTransfer", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay,  GoodsTransferAJService) {

    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownPrint = false;
    $scope.isShownTransferId = true;
    $scope.arrGoodsTransferDtls = [];

    DepoLookupList();
    DefaultRowinTable();



    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function DepoLookupList() {
        var GetData = GoodsTransferAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    } 

    function DefaultRowinTable() {
        var InputParam = {
            ItemName: "",
            ItemId: 0,
            BalQty: "",
            TransferQty:""
        }
        $scope.arrGoodsTransferDtls.push(InputParam);
    }


    $scope.ValidateDepo = function () {
        if ($scope.FromDepoId == $scope.ToDepoId) {
            $scope.errMsg = 'Same depo goods transfer not allowed';
            $scope.ToDepoId = undefined;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
    }


    function GridAutoComplete() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".txtPartNo").autocomplete({

            source: function (request, response) {
                
                var InputParam = {
                    //DepotName: request.term
                    ItemName: request.term,
                    LocationId:$sessionStorage.locationId
                }
                $.ajax({
                    url: baseUrl + '/Store/GoodsTransfor/GetItemNameListLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        var results = FilterAutoComplite(data, request.term);
                        response($.map(results.slice(0, 10), function (item, key) {
                            return {
                                label: item.ItemName,
                                ItemCode: item.ItemCode,
                                ItemId: item.ItemId                               
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {                  
                    $scope.arrGoodsTransferDtls[Indexval].ItemName = i.item.ItemName;
                    $scope.arrGoodsTransferDtls[Indexval].ItemCode = i.item.ItemCode;
                    $scope.arrGoodsTransferDtls[Indexval].ItemId = i.item.ItemId;
                    $scope.GetBalQtyFromDepoItem($scope.arrGoodsTransferDtls[Indexval]);
                 });
            },
            minLength: 0
        }).focus(function (e, i) {
            $(".txtPartNo").autocomplete("search", "");
        });
    }

    $scope.GetBalQtyFromDepoItem = function (ItemIdTemp) {
        FindBalance(ItemIdTemp);
    }

    function FindBalance(ItemIdTemp) {
        var InputParam = {
            DepotId: $scope.FromDepoId,
            ItemId: ItemIdTemp.ItemId
        }
        var GetData = GoodsTransferAJService.GetBalQty(InputParam);
        GetData.then(function (Response) {
            ItemIdTemp.BalQty = Response.data.BalQty;
        });
    }

    $scope.AddRowItem = function () {
        var InputParam = {
            ItemName: "",
            ItemId: 0,
            BalQty: "",
            TransferQty: ""
        }
        $scope.arrGoodsTransferDtls.push(InputParam);
    }

    $scope.RemoveRowItem = function (item) {
        var index = $scope.arrGoodsTransferDtls.indexOf(item);
        $scope.arrGoodsTransferDtls.splice(index, 1);
    }

    $scope.ValidateQty = function (row) {
        if (row.BalQty < row.TransferQty) {
            $scope.errMsg = "Transfer Qty not more the Inventry Qty"
            row.TransferQty = undefined;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        }
    }

    function FilterAutoComplite(DataList, term) {
        if (term != "") {
            var filterData = DataList.filter(function (value) {
                return value.ItemName.toLowerCase().indexOf(term.toLowerCase()) > -1;                
            });
        }
        else {
            filterData = DataList;
        }
        return filterData;
    }


    $scope.InitAutoComplete = function () {
        GridAutoComplete();
    }

    $scope.SaveDtls = function () {
        if ($scope.FromDepoId == 0 || $scope.FromDepoId == undefined || $scope.FromDepoId == '') {
            $scope.errMsg = "Please select From Deport";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if ($scope.ToDepoId == 0 || $scope.ToDepoId == undefined || $scope.ToDepoId == '') {
            $scope.errMsg = "Please select To Deport";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var ErrorTemp = undefined;
        angular.forEach($scope.arrGoodsTransferDtls, function (value, key) {
            if (ErrorTemp == undefined) {
                if (value.ItemId==undefined || value.ItemId=='' || value.ItemId==0){
                    ErrorTemp = "Please Select Item Name ";
                }
            }
            if (ErrorTemp == undefined) {
                if (value.TransferQty == undefined || value.TransferQty == '' || value.TransferQty == 0) {
                    ErrorTemp = "Please Enter Transfer Qty";
                }
            }
        });

        if (ErrorTemp != undefined) {
            $scope.errMsg = ErrorTemp;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        var InputParam = {
            TransferRefNo:$scope.TransferRefNo,
            TransferDate:$scope.TransferDate,
            TransferId:$scope.TransferId,
            FromDepoId:$scope.FromDepoId,
            ToDepoId:$scope.ToDepoId,
            CreatedBy:$sessionStorage.loginUser,
            ModifiedBy: $sessionStorage.loginUser,
            LocationId:$sessionStorage.locationId,
            arrGoodsTransferDtls: $scope.arrGoodsTransferDtls
        }
        var GetData = GoodsTransferAJService.SaveTransferDtls(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.TransferRefNo = Response.data.TransferRefNo;
                $scope.TransferId = Response.data.TransferId;
                $scope.TransferDate = Response.data.TransferDate;
                $scope.SuccessMsg = "Data Saved........................";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;                
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });


    }

  
    function ClearData() {
        $scope.TransferRefNo = undefined;
        $scope.TransferDate = undefined;
        $scope.TransferId = undefined;
        $scope.FromDepoId = undefined;
        $scope.ToDepoId = undefined;
        $scope.arrGoodsTransferDtls = [];
        DefaultRowinTable();
    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownEdit = false;
        $scope.isShownSave = true;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShown = false;
        $scope.isShownTransferId = true;
        if ($("#txtTransferRefNo").hasClass('ui-autocomplete-input')) {
            $("#txtTransferRefNo").autocomplete("destroy");
            $("#txtTransferRefNo").removeData('autocomplete');
        }
        
    }

    $scope.ClearDetails = function () {
        $scope.isShown = true;
        $scope.isShownLease = true;
        $scope.isShownAdd = true;
        $scope.isShownEdit = false;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownClear = false;
        $scope.isShownTransferId = true;
        if ($("#txtTransferRefNo").hasClass('ui-autocomplete-input')) {
            $("#txtTransferRefNo").autocomplete("destroy");
            $("#txtTransferRefNo").removeData('autocomplete');
        }
        ClearData();
    }

    $scope.SearchDtls = function () {
        ClearData();
        $scope.isAddRowShown = true;
        $scope.isShownAdd = false;
        $scope.isShownEdit = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $scope.isShownDispaly = true;
        $scope.isShownTransferId = false;

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtTransferRefNo").autocomplete({
            source: function (request, response) {

                
                var InputParam = {
                    TransferRefNo: request.term,
                    LocationId: $sessionStorage.locationId
                }
                $.ajax({
                    url: baseUrl + '/Store/GoodsTransfor/GetTransferLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.TransferRefNo,
                                TransferId: item.TransferId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.TransferRefNo = i.item.label;
                    $scope.TransferId = i.item.TransferId;
                    $scope.SearchData();
                });
            },
            minLength: 0
        }).focus(function (e, i) {
            $(".txtTransferRefNo").autocomplete("search", "");
        });



    }


    $scope.SearchData = function () {
        GetTransforDetailsById();
    }

    function GetTransforDetailsById() {
        var InputParam = {
            TransferId: $scope.TransferId,
            LocationId:$sessionStorage.locationId
        }
        var GetData = GoodsTransferAJService.RetrieveData(InputParam);
        GetData.then(function (Response) {
            $scope.TransferRefNo = Response.data.TransferRefNo;
            $scope.TransferDate = Response.data.TransferDate;
            $scope.TransferId = Response.data.TransferId;
            $scope.FromDepoId = Response.data.FromDepoId;
            $scope.ToDepoId = Response.data.ToDepoId;
            $scope.arrGoodsTransferDtls = Response.data.arrGoodsTransferDtls;
            if ($scope.arrGoodsTransferDtls.length != 0) {
                angular.forEach($scope.arrGoodsTransferDtls, function (value, key) {
                    FindBalance(value);
                });
            }
        });
    }
});