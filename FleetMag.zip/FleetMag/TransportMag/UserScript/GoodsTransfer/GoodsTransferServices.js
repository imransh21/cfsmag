﻿app.service("GoodsTransferAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetBalQty = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsTransfor/GetBalQty",
            data:JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }
   
    this.SaveTransferDtls = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsTransfor/SaveGoodsTransferDtls",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

    this.RetrieveData = function (InputData) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsTransfor/RetrieveData",
            data: JSON.stringify(InputData),
            dataType: "json"
        });
        return response;
    }

});