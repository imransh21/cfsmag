﻿app.service("GoodsReturnJobAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDepoLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/IndentGenaration/GetDepoListLookup",
            dataType: "json"
        });
        return response;
    }

    this.GetVehicleJobDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetStockJobVehicleDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetItemJobDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetStockReqData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.SaveStockIssue = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/SaveMaterialIssue",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetAllGoodRetunQlist = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetAllGoodRetunQlist",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    
    this.GetStockListByDepot = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Store/GoodsReturnJob/GetStockListByDepot",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

});