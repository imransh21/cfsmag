﻿app.controller("CntrlGoodsReturnJob", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, GoodsReturnJobAJService) {

    $scope.isShown = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownExit = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownPrint = false;
    DepoLookupList();

    function DepoLookupList() {
        var GetData = GoodsReturnJobAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    $scope.VehicleDetails = function () {
        if ($scope.WisId == undefined || $scope.WisId == "" || $scope.WisId == '') {
            $scope.errMsg = "Please select the JobCardNo from the List"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var InputParam = {
            WisId: $scope.WisId,
            DepotId: $scope.DepotId

        }
        var GetData = GoodsReturnJobAJService.GetVehicleJobDetails(InputParam);
        GetData.then(function (Response) {
            $scope.VehicleDetailsList = Response.data;
            $sessionStorage.WisId = $scope.WisId;
            $sessionStorage.DepotId = $scope.DepotId;
            GetItemDetails(InputParam);
            $scope.isShownSave = true;
            $scope.isShownPrint = true;
        });

    }

    function GetItemDetails(ItemDtlsParam) {
        var GetItemData = GoodsReturnJobAJService.GetItemJobDetails(ItemDtlsParam);
        GetItemData.then(function (Response) {
            $scope.VehicleItemDetailsList = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.AddDtls = function () {
        clearData();
    }

    $scope.CancelDtls = function () {
        clearData();
        $scope.isShown = true;
        $scope.isShownSearch = true;
        $scope.isShownExit = true;
        $scope.isShownSave = false;
        $scope.isShownClear = false;
        $scope.isShownPrint = false;
    }

    $scope.SearchDtls = function () {
        clearData();
        $scope.isShown = false;
        $scope.isShownSearch = false;
        $scope.isShownExit = false;
        $scope.isShownClear = true;
        $("#divQlist").modal('show');
    }

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function clearData() {
        $scope.isShown = true;
        $scope.DepotId = undefined;
        $scope.JobNo = undefined;
        $scope.WisDate = undefined;
        $scope.VehicleDetailsList = [];
        $scope.VehicleItemDetailsList = [];
    }

    $scope.ReturnQtyChange = function (row) {
        if (row.BalQty == 0) {
            $scope.errMsg = "Balance Qty not available for Return"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.CurrentReturnQty = 0;
            return;
        }

        if (row.CurrentReturnQty < 0) {
            $scope.errMsg = "Please Enter positive values"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.CurrentReturnQty = 0;
            return;
        }

        if (row.BalQty < row.CurrentReturnQty) {
            $scope.errMsg = "Current Return not more then Balance Qty"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            row.CurrentReturnQty = 0;
            return;
        }
    }


    $scope.PrintDtls = function () {
        
        getGoodReturnJobPrintPage();
    }

    function getGoodReturnJobPrintPage() {
        
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Store/GoodsReturnJob/GoodsReturnJobPrint";

    }


    $scope.SaveDtls = function () {
        var MeterialList = [];
        angular.forEach($scope.VehicleItemDetailsList, function (value, key) {
            var inpparam = {
                WisId: value.wis_id,
                MId: value.M_ID,
                ItemId: value.ITEM_ID,
                DeportId: $scope.DepotId,
                UsedQty: value.BalQty,
                ReturnQty: value.CurrentReturnQty
            }
            MeterialList.push(inpparam);
        });

        var InputParam = {
            WisId: $scope.WisId,
            MaterialDetails: MeterialList
        }
        var SaveInventryData = GoodsReturnJobAJService.SaveStockIssue(InputParam);
        SaveInventryData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.errMsg = "Data Saved........................."
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                var InputParam = {
                    WisId: $scope.WisId,
                    DepotId: $scope.DepotId
                }
                GetItemDetails(InputParam);
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });
    }

    $scope.FilterData = function () {
        
        var InputPram = {
            DepotId: $scope.DepotId,
            JobNo: $scope.JobNo
        }

        var GetData = GoodsReturnJobAJService.GetAllGoodRetunQlist(InputPram);
        GetData.then(function (Response) {
            $scope.GoodRetunQlist = $.parseJSON($.parseJSON(Response.data)).Table;           
        });

    }


    $scope.GetAllDataByRow = function (Row) {
        
        $scope.WisId = Row.WisId,
        $scope.DepotId = Row.DepotId,
        $scope.JobNo = Row.JobCardNoQlist,
        $scope.VehicleNo = Row.VehicleNoQlist,
        $scope.VehicleDetails();
        $("#divQlist").modal('hide');
        $scope.isShown = false;
    }

    //$scope.GetAllGoodsReurnList = function () {       
    //    

    //    DepotId: $scope.FilterDepotId,
    //    JobNo: $scope.FilterJobCardNo,
    //    VehicleNo: $scope.FilterVehicleNo
    //    $scope.FilterData();       

    //}



    $scope.DepotFilterlistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            JobNo: $scope.FilterJobCardNo,
            VehicleNo: $scope.FilterVehicleNo
        }
        var GetData = GoodsReturnJobAJService.GetStockListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.GoodRetunQlist = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }


    

});