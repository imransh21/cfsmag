﻿app.controller("JobAllocationCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, IndentGenAJService, JobAllocationAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    $scope.isAddRowShown = true;
    $scope.CrewAllocationSublst = [];
    $scope.FilterJobStatus = 'P';
    //  GetJobAllocationList();
    VendorListAll();
    DepoLookupList();
    GetCrewAllocationList();
    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }


    function VendorListAll() {

    
        var GetData = JobAllocationAJService.GetAllVendorConfigs();

        GetData.then(function (pVendors) {
            $scope.VendorList = (pVendors.data);
            $scope.errMsg = "";
            $scope.isError = false;

            //GetAllCustomers();

        }, function (reason) {
            ErrorPopupMsg('ErrorDiv');
            $scope.errMsg = "Error in getting Vendor Configuration " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    EmployeeLookupList();
    ServiceLookupList();


    function ServiceLookupList() {

        //if ($localStorage.loginUser == 'admin') {
        //    location = 0;
        //}
        //else {


        //    location = $localStorage.locationId;

        //}
        //var inputType = {
        //    BranchId: location
        //}
        var ServiceLookup = JobAllocationAJService.ServiceLookup();
        ServiceLookup.then(function (result) {
            $scope.ServiceLookupLookupData = (result.data);
        });
    }




    function EmployeeLookupList() {
   
        //if ($localStorage.loginUser == 'admin') {
        //    location = 0;
        //}
        //else {


        //    location = $localStorage.locationId;

        //}
        //var inputType = {
        //    BranchId: location
        //}
        var EmployeeLookup = JobAllocationAJService.EmployeeLookup();
        EmployeeLookup.then(function (result) {
            $scope.EmployeeLookupData = (result.data);
        });
    }

    function GetJobAllocationList() {
        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        
        //if (($scope.FilterFromDate != "" && $scope.FilterFromDate != undefined) && ($scope.FilterToDate == "" && $scope.FilterToDate == undefined)) {
        //    // alert("Please enter Estimated To Date");
        //    ErrorPopupMsg('ErrorDiv');
        //    $scope.errMsg = " Please enter Estimated To Date";
        //    $scope.isError = true;
        //    return;
        //}

        //if (($scope.FilterFromDate == "" && $scope.FilterFromDate == undefined) && ($scope.FilterToDate != "" && $scope.FilterToDate != undefined)) {
        //    // alert("Please enter Estimated Start From Date");
        //    ErrorPopupMsg('ErrorDiv');
        //    $scope.errMsg = " Please enter Estimated Start From Date";
        //    $scope.isError = true;
        //    return;
        //}
        ////Date validation
        //if ($scope.FilterFromDate != undefined && $scope.FilterToDate != "") {
        //    var fDate = getDDMMYYYYHHMI($scope.FilterFromDate);
        //    var tDate = getDDMMYYYYHHMI($scope.FilterToDate);

        //    if (fDate > tDate) {
        //        ErrorPopupMsg('ErrorDiv');
        //        $scope.errMsg = " To Date should be greater than From Date";
        //        $scope.isError = true;
        //        //  alert($scope.errMsg);
        //        //  $("#txtEffectTo").focus();
        //        return;
        //    }
        //}
        var iList = {
            JobNo: $scope.FilterJobNo == "" ? undefined : $scope.FilterJobNo,
            DepotId: $scope.DepotId,
            WisStatus: $scope.FilterJobStatus == "" ? undefined : $scope.FilterJobStatus,//          WisStatus: $scope.FilterJobStatus == undefined ? "P" : $scope.FilterJobStatus, // 
            ExpBeginDate: $scope.FilterFromDate == "" ? undefined : $scope.FilterFromDate,
            ExpCompDate: $scope.FilterToDate == "" ? undefined : $scope.FilterToDate,

        };

        var JobAlocation = JobAllocationAJService.GetALLJobAllocation(iList);
        JobAlocation.then(function (result) {
            $scope.isShown = true;
            $scope.pndJobAllocationlst = result.data;
            if ($scope.RowIndex != undefined) {
                $scope.seletedJob = $scope.pndJobAllocationlst[$scope.RowIndex];
            }
            $scope.filteredItems = $filter('orderBy')($scope.pndJobAllocationlst, $scope.sortingOrder, $scope.reverse);
            //groupToPages();
        });

    }



    $scope.DisplayDtls = function () {
        GetJobAllocationList();
    }

    $scope.AcceptJobDetails = function (selectedJob) {

        if (selectedJob.ScheduleDate == undefined || selectedJob.ScheduleDate=="") {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.errMsg = "Please Enter Schedule Date.";
            $scope.isError = true;
            $("#txtScheduleDate").val('');
            setTimeout(function () {
                $("#txtScheduleDate").focus();
            }, 500);
            return;
           
        }


        var InputParm = {
            SpecialInstructions: selectedJob.SpecialInstructions,
            Remark: selectedJob.Remark,
            ScheduleDate: selectedJob.ScheduleDate,
            AcceptedDate: selectedJob.AcceptedDate,
            WisId: selectedJob.WisId,
            DepotId: $scope.DepotId,
            WisStatus: 'A',
            ScheduleId: selectedJob.ScheduleId
        }
        var JobAlocation = JobAllocationAJService.SaveWorkInstAcceptUpdate(InputParm);
        JobAlocation.then(function (result) {
            if (result.data.ErrorMessage == "") {
                $scope.errMsg = "Job Card Accepted...........................!";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            //groupToPages();
        });

    }

    $scope.RejectJobDetails = function (selectedJob) {
        var InputParm = {
            SpecialInstructions: selectedJob.SpecialInstructions,
            Remark: selectedJob.Remark,
            ScheduleDate: selectedJob.ScheduleDate,
            AcceptedDate: selectedJob.AcceptedDate,
            WisId: selectedJob.WisId,
            DepotId: $scope.DepotId,
            WisStatus: 'R'
        }
        var JobAlocation = JobAllocationAJService.SaveWorkInstAcceptUpdate(InputParm);
        JobAlocation.then(function (result) {
            if (result.data.ErrorMessage == "") {
                $scope.errMsg = "Job Card Rejected...........................!";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            //groupToPages();
        });

    }


    $scope.getClickJobDetails = function (row, indx) {
        
        $scope.seletedJob = row;
        $scope.RowIndex = indx;
        $('#targer' + indx).attr('data-target', "#Tr" + indx);
        //GetVehicleLookup(row, indx);
        $('#targer' + indx).toggleClass('fa-minus');
        //GetVehicleDetails(row.WisId);
        //GetMaterialListValues(row.BranchId);
        //GetMaterialDetailsList(row.WisId);
        //GetAllServices(row);//Changed By Pradarshan M for 13-07-2018 For sendng additonal parameters for seleted Additional Services.
        //GetServiceDetails(row.WisId);
        GetcrewDetails(row.WisId);
        creselectedwis(row.CrewId, row, indx);
        $scope.GetMaterialDetails();
        $scope.GetMaterialJobDetails();
        //GetAllActivityType();
        //GetActivityTypeDetails(row.WisId);
        //GetDocumentTableList(row.WisId);
        //GetDocumentITableList(row.WisId);
        ////DocumentImageList
        //GetAllDocumentType();
        ////crewse
        //creselectedwis(row.CrewId, row, indx);

    }
    function GetcrewDetails(jobId) {
        
        var inputType = {
            WisId: jobId
        }
        var crewdtls = JobAllocationAJService.CrewDetailsListService(inputType);
        crewdtls.then(function (result) {
            $scope.CrewDetails = (result.data);
        });
    }

    function GetCrewAllocationList() {
        //var location = $localStorage.locationId;
        //if ($localStorage.loginUser == 'admin') {
        //    location = 0;
        //}
        //else {


        //    location = $localStorage.locationId;

        //}





        var inputValues = {
            BranchId: $scope.DepotId
        }
        var CrewAllocation = JobAllocationAJService.getCrewAllocationList(inputValues);
        CrewAllocation.then(function (result) {
            $scope.CrewAllocationlst = (result.data);
        });
    }





    function creselectedwis(pCrewId, row, index) {
        
        // GetCrewAllocationList();
        angular.forEach($scope.CrewAllocationlst, function (value, key) {
            
            if (index != key) {
                
                value.Chkchange = false;
                $('#chk' + key)[0].checked = false;
            }
            if (value.CrewId == pCrewId) {
                
                var inputParam = {
                    CrewId: pCrewId,
                    WisId: row.WisId
                }

                var CrewAllocationSUB = JobAllocationAJService.getworkinstruction(inputParam);
                CrewAllocationSUB.then(function (result) {
                    
                    //$scope.CrewAllocationSublst = $.parseJSON(result.data);
                    $scope.seletedJob.Vendorid = result.data.VendorId;
                    $scope.seletedJob.NoOfLoaders = result.data.NoOfLoaders;
                    $scope.seletedJob.VendorAmount = result.data.VendorAmount;
                    $scope.seletedJob.CrewId = pCrewId;

                });

                $('#chk' + key)[0].checked = true;
            }
            else {
                $scope.seletedJob.Vendorid = undefined;
                $scope.seletedJob.NoOfLoaders = undefined;

            }
        });
        var inputParam = {
            CrewId: pCrewId,
            WisId: $scope.seletedJob.WisId
        }
        // $('#chk' + index).attr('checked', true);
        //$('#chk' + index).selected = true;
        $scope.CrewAllocationSublst = [];
        $scope.CurrentSeletedCrew = row;
        var CrewAllocationSUB = JobAllocationAJService.getCrewAllocationSUBList(inputParam);
        CrewAllocationSUB.then(function (result) {
            
            $scope.CrewAllocationSublst = (result.data);
            var packers = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Engineer' });//||Designation: 'Carpenter'
            var carpenter = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Carpenter' });//||Designation: 'Carpenter'

            $scope.CrewAllocationSublstP = packers.concat(carpenter);
            $scope.CrewAllocationSublstH = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Helper' });//||Designation: 'Carpenter'
            //  $scope.CrewAllocationSublst
        });

    }



    $scope.AddNewCrew = function () {
        var newList = { CdId: 0, WisId: $scope.seletedJob.WisId, CrewId: $scope.seletedJob.CrewId, EmployeeId: 0, PrefLocation: "", FromDateTime: $scope.seletedJob.ExpBeginDate, ToDateTime: $scope.seletedJob.ExpCompDate }
        $scope.CrewAllocationSublst.push(newList);
    }







    $scope.CrewSeleted = function (pCrewId, row, index) {
        
        creselectedwis(pCrewId, row, index);

    }
    $scope.findPrefLocation = function (item, row) {
        //validation for duplicate
        //alert(item);
        // alert(row.Cdd);
        var cnt = 0;
        for (var i = 0; i < $scope.CrewAllocationSublst.length; i++) {
            for (var j = 0; j < $scope.CrewAllocationSublst.length; j++) {
                if (i != j) {
                    if ($scope.CrewAllocationSublst[j] != undefined) {
                        if ($scope.CrewAllocationSublst[i].EmployeeId == $scope.CrewAllocationSublst[j].EmployeeId) {
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.errMsg = " Duplicate Crew Member!";
                            $scope.isError = true;
                            $scope.CrewAllocationSublst[j].EmployeeId = 0;
                            return;

                        }
                    }
                }

            }
        }
        var rowdata = $scope.EmployeeLookupData.filter(function (emp) {
            return (emp.EmpId == item);
        });
        row.PrefLocation = rowdata[0].PreferedArea;
        row.Designation = rowdata[0].Designation;
        row.FromDateTime = $scope.seletedJob.ExpBeginDate;
        row.ToDateTime = $scope.seletedJob.ExpCompDate;

    }


    $scope.SaveCrewDtls = function () {
        //date validation crew register leave
        

        //take list of all emp from date to date, compare if emp is is equelk
        for (var i = 0; i < $scope.CrewAllocationSublst.length; i++) {


            var fDate = getDDMMYYYYHHMI($scope.CrewAllocationSublst[i].FromDateTime);
            var tDate = getDDMMYYYYHHMI($scope.CrewAllocationSublst[i].ToDateTime);
            if (fDate > tDate) {
                ErrorPopupMsg('ErrorDiv');
                // $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i] });
                // $scope.errMsg = " To Date should be greater than From Date";
                $scope.errMsg = "for " + $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i].EmployeeId })[0].EmployeeName + "- To Date should be greater than From Date";

                $scope.isError = true;
                return;
            }

            if ($scope.SCList != null) {
                for (var j = 0; j < $scope.SCList.length; j++) {
                    if ($scope.SCList[j].EmpId == $scope.CrewAllocationSublst[i].EmployeeId) {
                        var fDatej = getDDMMYYYYHHMI($scope.SCList[j].FromDate);
                        var tDatej = getDDMMYYYYHHMI($scope.SCList[j].ToDate);

                        if ((fDate > fDatej && fDate < tDatej) || (tDate > fDatej && tDate < tDatej)) {
                            ErrorPopupMsg('ErrorDiv');
                            $scope.errMsg = $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i].EmployeeId })[0].EmployeeName + " is on leave,Cannot allocate";
                            $scope.isError = true;
                            return false;
                        }


                    }
                }

            }
        }

            var inputdata = {
                CrewDetails: $scope.CrewAllocationSublst,
                NoOfLoaders: $scope.seletedJob.NoOfLoaders,
                Vendorid: $scope.seletedJob.Vendorid,
                CrewId: $scope.seletedJob.CrewId,
                WisId: $scope.seletedJob.WisId,
                VendorAmount: $scope.seletedJob.VendorAmount
            }
            
            var errorcheck = ""
            var UpdateWorkinst = JobAllocationAJService.UpdateCrewDtls(inputdata);
            UpdateWorkinst.then(function (result) {
                
                $scope.ErrorList = (result.data);
                for (var j = 0; j < $scope.ErrorList.length; j++) {
                    if ($scope.ErrorList[j].ErrorMessage != null) {
                        errorcheck = "Error"
                        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                        $scope.errMsg = $scope.ErrorList[j].ErrorMessage;
                        $scope.isError = true;
                        return false;
                    }

                }
                if (errorcheck == "") {
                    GetcrewDetails($scope.seletedJob.WisId);


                    creselectedwis11($scope.seletedJob.CrewId);
                    //  creselectedwis(row.CrewId, row, indx);
                    $('#divCrewAllocation').modal('hide');
                }

            });
        
    }


    function creselectedwis11(pCrewId) {

        var inputParam = {
            CrewId: pCrewId,
            WisId: $scope.seletedJob.WisId
        }

        var CrewAllocationSUB = JobAllocationAJService.getworkinstruction(inputParam);
        CrewAllocationSUB.then(function (result) {
            //$scope.CrewAllocationSublst = $.parseJSON(result.data);
            $scope.seletedJob.Vendorid = result.data.Vendorid;
            $scope.seletedJob.NoOfLoaders = result.data.NoOfLoaders;
            $scope.seletedJob.CrewId = pCrewId;
        });

        var inputParam = {
            CrewId: pCrewId,
            WisId: $scope.seletedJob.WisId
        }
        // $('#chk' + index).attr('checked', true);
        //$('#chk' + index).selected = true;
        $scope.CrewAllocationSublst = [];
        // $scope.CurrentSeletedCrew = row;
        var CrewAllocationSUB = JobAllocationAJService.getCrewAllocationSUBList(inputParam);
        CrewAllocationSUB.then(function (result) {
            $scope.CrewAllocationSublst = result.data;
            var Engineer = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Engineer' });//||Designation: 'Carpenter'
            var carpenter = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Carpenter' });//||Designation: 'Carpenter'

            $scope.CrewAllocationSublstP = packers.concat(carpenter);
            $scope.CrewAllocationSublstH = $filter('filter')($scope.CrewAllocationSublst, { Designation: 'Helper' });//||Designation: 'Carpenter'
            //  $scope.CrewAllocationSublst
        });
    }





    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        newObj.setDate(objDateParts[0]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }


    $scope.DeleteCrew = function (row) {
        
        var index = $scope.CrewAllocationSublst.indexOf(row);
        var inputParam = {
            EmployeeId: row.EmployeeId,
            WisId: row.WisId
        }
        var DeleteCrewDetails = JobAllocationAJService.DeleteCrewdtls(inputParam);
        DeleteCrewDetails.then(function (result) {
            if (result.data == "Done") {
                //  alert("Record Deleted");
           
                $scope.errMsg = "Record Deleted Successfully";
                
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.CrewAllocationSublst.splice(index, 1);
                GetcrewDetails(row.WisId);
            }
        });
    }

    $scope.addNewItem = function () {
        var InputParam = {
            ItemName:"",
            ItemId: 0,
            Make: "",
            Unitname: "",
            RequestQty: "",
    
        }
        $scope.MaterialList.push(InputParam);
    }


    $scope.GetMaterialDetails = function () {
        //   
        var o = {
            ScheduleId: $scope.seletedJob.ScheduleId,
            WisId: $scope.seletedJob.WisId,
            DeportId: $scope.DepotId
        };
        var getData = JobAllocationAJService.GetMaterialData(o);

        getData.then(function (Response) {
            $scope.MaterialList = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };




    $scope.GetMaterialJobDetails = function () {
        //   
        var o = {
            //ScheduleId: $scope.seletedJob.ScheduleId,
            WisId: $scope.seletedJob.WisId
        };
        var getData = JobAllocationAJService.GetMaterialItemData(o);

        getData.then(function (Response) {
            $scope.MaterialListJob = Response.data;
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    };




    $scope.updFlag = function (row, index) {
        
        var strlen = 0;
        if (row.ItemId == undefined) {
            $scope.errMsg = "Please Select Item.";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        $scope.currentInStock = row.InStoack;
        if (row.Make == undefined || row.Make == "") {
            row.InStoack = row.ItemInStock;
        }
        $scope.currentItemId = row.ItemId;
     
    }



    $scope.updItem = function (row, index) {
        
        var strlen = 0;

    
            row.ItemId = undefined;
            row.MakeId = undefined;
            row.Make = undefined;
            row.InStoack = undefined;
         
        

    }


    function GridAutoComplete() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];



        $(".txtPartNo").autocomplete({

            source: function (request, response) {
                
                var InputParam = {
                    //DepotName: request.term
                    ItemName: request.term,
                    DeportId: $scope.DepotId
                }
                $.ajax({
                    url: baseUrl + '/Store/IndentGenaration/GetItemMasterLookupWithDepot',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.ItemName,
                                ItemCode: item.ItemCode,
                                ItemId: item.ItemId,
                                ItemDesc: item.ItemDesc,
                                FinLedgerCode: item.FinLedgerCode,
                                InStock: item.InStock
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var cid = $(e.target)[0].id;
                var Indexval = cid.substring(7, cid.length);
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    
                    $scope.MaterialList[Indexval].ItemName = i.item.ItemName;

                    $scope.MaterialList[Indexval].ItemId = i.item.ItemId;
                
                    $scope.MaterialList[Indexval].Make = undefined;
                    $scope.MaterialList[Indexval].MakekeyId = undefined;
                    $scope.MaterialList[Indexval].InStoack = i.item.InStock;
                });
            },
            minLength: 3
        });




        $(".txtMake").autocomplete({

            source: function (request, response) {
                
                
                var InputParam = {
                    MakeDesc: request.term,
                    ItemId: $scope.currentItemId,
                    DepotId: $scope.DepotId
                }
                $.ajax({
                    url: baseUrl + '/Store/IndentGenaration/GetPartMakeWithInstock',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.MakeDesc,
                                Pkey: item.KeyId,
                                MakeDesc: item.MakeDesc,
                                InStock: item.InStoack
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                
                //var Indexval = e.target.parentNode.parentNode.id;
                var cid = $(e.target)[0].id;
                var Indexval = cid.substring(7, cid.length);
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.MaterialList[Indexval].Make = i.item.MakeDesc;
                    $scope.MaterialList[Indexval].MakeId = i.item.Pkey;
                    $scope.MaterialList[Indexval].InStoack = i.item.InStock;
                });
            },
            minLength: 1
        });
    }

    $scope.InitAutoComplete = function () {
        GridAutoComplete();
    }





    $scope.SaveMaterialAllocData = function () {
        //date validation crew register leave
        

        //take list of all emp from date to date, compare if emp is is equelk
        //for (var i = 0; i < $scope.CrewAllocationSublst.length; i++) {


            //var fDate = getDDMMYYYYHHMI($scope.CrewAllocationSublst[i].FromDateTime);
            //var tDate = getDDMMYYYYHHMI($scope.CrewAllocationSublst[i].ToDateTime);
            //if (fDate > tDate) {
            //    ErrorPopupMsg('ErrorDiv');
            //    // $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i] });
            //    // $scope.errMsg = " To Date should be greater than From Date";
            //    $scope.errMsg = "for " + $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i].EmployeeId })[0].EmployeeName + "- To Date should be greater than From Date";

            //    $scope.isError = true;
            //    return;
            //}
            //if ($scope.SCList != null) {
            //    for (var j = 0; j < $scope.SCList.length; j++) {
            //        if ($scope.SCList[j].EmpId == $scope.CrewAllocationSublst[i].EmployeeId) {
            //            var fDatej = getDDMMYYYYHHMI($scope.SCList[j].FromDate);
            //            var tDatej = getDDMMYYYYHHMI($scope.SCList[j].ToDate);

            //            if ((fDate > fDatej && fDate < tDatej) || (tDate > fDatej && tDate < tDatej)) {
            //                ErrorPopupMsg('ErrorDiv');
            //                $scope.errMsg = $filter('filter')($scope.EmployeeLookupData, { EmpId: $scope.CrewAllocationSublst[i].EmployeeId })[0].EmployeeName + " is on leave,Cannot allocate";
            //                $scope.isError = true;
            //                return false;
            //            }


            //        }
            //    }

        //}


   
        if ($scope.MaterialList.length != null || $scope.MaterialList.length != undefined) {
            for (i = 0; i < $scope.MaterialList.length; i++) {
                for (j = i + 1 ; j < $scope.MaterialList.length; j++) {
                    if ($scope.MaterialList[i].ItemId == ($scope.MaterialList[j].ItemId)) {
                        // got the duplicate element
                        if ($scope.MaterialList[i].ItemId != "") {
                            $scope.errMsg = "Item Name " + $scope.MaterialList[i].ItemName + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }



                }
            }


            for (i = 0 ; i < $scope.MaterialList.length; i++) {
                if ($scope.MaterialList[i].RequestQty <= 0 || $scope.MaterialList[i].RequestQty == undefined) {
                    // got the duplicate element

                    $scope.errMsg = "Please Enter Request Qty";
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    $scope.isError = true;
                    return;

                }

                if ($scope.MaterialList[i].ItemId == null || $scope.MaterialList[i].ItemId == undefined) {
                    // got the duplicate element

                    $scope.errMsg = "Please Enter Item";
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    $scope.isError = true;
                    return;

                }
            }
        }


            var inputdata = {
                MaterialDetails: $scope.MaterialList,
                 WisId: $scope.seletedJob.WisId,
                 DepotId: $scope.DepotId
            }
            
            var errorcheck = ""
            var UpdateWorkinst = JobAllocationAJService.UpdateMaterialDtls(inputdata);
            UpdateWorkinst.then(function (result) {
                $scope.ErrorList = (result.data);
                for (var j = 0; j < $scope.ErrorList.length; j++) {
                    if ($scope.ErrorList[j].ErrorMessage != null) {
                        errorcheck = "Error"
                        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                        $scope.errMsg = $scope.ErrorList[j].ErrorMessage;
                        $scope.isError = true;
                        return false;
                    }

                }
                if (errorcheck == "") {
                    $scope.GetMaterialJobDetails();


                    $scope.GetMaterialDetails();
                    //  creselectedwis(row.CrewId, row, indx);
                    $('#divMaterialAllocation').modal('hide');
                }

            });
        //}
    }

    $scope.DeleteMaterialRequest = function (row) {
        
        JobAllocationAJService.DeleteMaterialRequest(row).then(function (result) {
            if (result.data.ErrorMessage == "") {

                $scope.MaterialListJob.splice($scope.MaterialListJob.indexOf(row), 1);
                $scope.MaterialList.splice($scope.MaterialList.indexOf(row), 1);
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.errMsg = "Material Request Deleted";
            }
            else {
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                $scope.errMsg = "Could not delete Material Request";
                $scope.isError = true;
            }
        });
    }










    $scope.CheckRequestQty = function (row, index) {
        
        if(parseFloat(row.InStoack )<parseFloat(row.RequestQty))
        {
            row.RequestQty = 0;
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.errMsg = "Material Request Qty is Greater Than In Stock Qty.";
        }
      }

  
    $scope.ReturnUsedQty = function (row) {
        totalIssued = parseFloat(row.UsedQty) + parseFloat(row.ReturnQty);
        row.BalReturnQty = parseFloat(row.IssueQty) - (parseFloat(row.ReturnQty) + parseFloat(row.UsedQty))
        if (row.UsedQty < 0) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.errMsg = "Please enter positive Value";
            row.UsedQty = 0;
            return;
        }
        if (row.IssueQty < totalIssued) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            $scope.errMsg = "Used Qty + Return Qty not more then Issue Qty";
            row.UsedQty = 0;
            return;
        }        
    }


    $scope.SaveMaterialReturnData = function () {
        var inputdata = {
            MaterialDetails: $scope.MaterialList,
            WisId: $scope.seletedJob.WisId,
            DepotId: $scope.DepotId
        }        
        var errorcheck = ""
        var UpdateWorkinst = JobAllocationAJService.UpdateMaterialReturnDtls(inputdata);
        UpdateWorkinst.then(function (result) {
            $scope.ErrorList = (result.data);
            for (var j = 0; j < $scope.ErrorList.length; j++) {
                if ($scope.ErrorList[j].ErrorMessage != null) {
                    errorcheck = "Error"
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    $scope.errMsg = $scope.ErrorList[j].ErrorMessage;
                    $scope.isError = true;
                    return false;
                }
            }
            if (errorcheck == "") {
                $scope.GetMaterialJobDetails();
                $scope.GetMaterialDetails();
                $('#divMaterialReturn').modal('hide');
            }

        });
        
    }

    $scope.currentReadingChange = function (row) {
        var currentKmRun = row.CurrentOdoReading - row.LastOdoReading;
        row.KMRun = currentKmRun + row.LastKMRun;
    }

    $scope.UpdateVehicleDetails = function (selectedJob) {
        var InputParm = {
            ActualBeginDate:selectedJob.ActualBeginDate,
            CurrentOdoReading: selectedJob.CurrentOdoReading,
            WisId: selectedJob.WisId,
            DepotId: $scope.DepotId,
            KMRun: selectedJob.KMRun,
            WisStatus: 'E'
           
        }
        var JobAlocation = JobAllocationAJService.SaveWorkInstVehicleDtls(InputParm);
        JobAlocation.then(function (result) {
            if (result.data.ErrorMessage == "") {
                $scope.errMsg = "Vehicle details updated...........................!";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                GetJobAllocationList();
               // $scope.seletedJob = $scope.pndJobAllocationlst[$scope.RowIndex];
            }
            //groupToPages();
        });
    }

    $scope.JobCloseDate = function (selectedJob) {
        $scope.seletedJob = [];
        var InputParm = {
            ClosingDate: selectedJob.ClosingDate,
            WisId: selectedJob.WisId,
            DepotId: $scope.DepotId,            
            WisStatus: 'C'
        }
        var JobAlocation = JobAllocationAJService.SaveWorkInstCloseDtls(InputParm);
        JobAlocation.then(function (result) {
            if (result.data.ErrorMessage == "") {
                $scope.errMsg = "JobCard Closed...........................!";
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                GetJobAllocationList();
               // $scope.seletedJob = $scope.pndJobAllocationlst[$scope.RowIndex];
            }            
        });
    }

});