﻿app.service("JobAllocationAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetALLJobAllocation = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/GetJobAllocationList",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }

    this.SaveWorkInstAcceptUpdate = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/SaveWorkinstructionAccept",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }

    this.CrewDetailsListService = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/GetCrewDetails",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }
    this.getCrewAllocationList = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/GetCrewAllocation",
            data: JSON.stringify(inputValues),
            dataType: "json"
        });
        return response;
    }
    this.getworkinstruction = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/getworkinstruction",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }


    this.getCrewAllocationSUBList = function (EquipmentMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/getCrewAllocationSub",
            data: JSON.stringify(EquipmentMaster),
            dataType: "json"
        });
        return response;
    }


    this.EmployeeLookup = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/GetEmployeeListLookup",
            //data: JSON.stringify(),
            datatype: "json"
        });
        return response;
    }

    this.UpdateCrewDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/UpdateCrewDetails",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }

    this.GetAllVendorConfigs = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/VendorMaster/GetAllVendorForReapair",
            //data: JSON.stringify(pVendor),
            dataType: "json"
        });
        return response;
    }

    this.DeleteCrewdtls = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/DeleteCrewbyEmpID",
            data: JSON.stringify(inputValues),
            datatype: "json"
        });
        return response;
    }


    this.GetMaterialData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/LoadMaterialDetailsByScheduleId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.UpdateMaterialDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/UpdateMaterialDetails",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }



    this.DeleteMaterialRequest = function (pWisMaterialRequest) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/DeleteMaterialRequest",
            data: JSON.stringify(pWisMaterialRequest),
            dataType: "json"
        });
        return response;
    }


    this.GetMaterialItemData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/LoadMaterialDetailsByJobId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.UpdateMaterialReturnDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/UpdateMaterialReturn",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }

    this.SaveWorkInstVehicleDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/UpdateVehicledtls",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }

    this.SaveWorkInstCloseDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/UpdateCloseWorkinst",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }


    this.ServiceLookup = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JobAllocation/GetServiceListLookup",
            //data: JSON.stringify(),
            datatype: "json"
        });
        return response;
    }
    this.saveJobData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/SavaJobDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


});