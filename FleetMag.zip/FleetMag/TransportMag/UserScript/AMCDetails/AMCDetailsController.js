﻿app.controller("AMCGenCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, $localStorage, ErrorMsgDisplay, AmcGenAJService) {
   

});