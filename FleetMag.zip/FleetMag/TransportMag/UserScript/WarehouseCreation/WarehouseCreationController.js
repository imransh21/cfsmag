﻿app.controller("mvcWhCreationCtrl", function ($scope, $sessionStorage, $filter, $compile, WhCreationAJService, IndentGenAJService, KeyRefrenceCtrlAJService, VehicleAJService, HomeIndex) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.ShowLoader = false;
    $scope.isShownLease = true;

    var rects = [];
    var InW = "";
    var InH = "";
    var InC = "";
    var ctx = canvas.getContext("2d");
    var $canvas = $("#canvas");

    var canvasOffset = $canvas.offset();
    var offsetX = canvasOffset.left;
    var offsetY = canvasOffset.top;
    var scrollX = $canvas.scrollLeft();
    var scrollY = $canvas.scrollTop();
    var drag = false;

    // save info about each circle in an object
    var Rrects = [];
    var selectedRect = -1;
    // the html radio buttons indicating what action to do upon mousedown
    var $create = $("#rCreate")[0];
    var $select = $("#rSelect")[0];
    var $move = $("#rMove")[0];
    var $Clear = $("#rClear")[0];

    var btn = "";
    //$scope.YardReservationList = locale.YardReservation;
    var appendlst = "";
    WHLookupList();
    WarehouseTypeList();
    PolicyTypeList();
    GetWarehouseLeaseFrom();
    GetVecticalList();

    $scope.GetLeaseSelect = function () {
        if ($scope.OwnLease == 'L') {
            $scope.isShownLease = false;
        }
        else {
            $scope.isShownLease = true;

        }
    }

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage("/Home/Warehouse");
    }


    $scope.GetWhDetails = function () {
        inputParam = {
            BlockId: $scope.WarehouseId
        };
        rects = [];
        var GetData = WhCreationAJService.GetWDetails(inputParam);
        GetData.then(function (Response) {
            $scope.BlockList = Response.data;
            angular.forEach($scope.BlockList, function (value, key) {
                InputParam = {
                    cx: value.XCoor,
                    cy: value.YCoor,
                    width: value.Width,
                    height: value.Height,
                    color: value.ColorCode,
                    txt1: value.RackName,
                    txt2: value.RackId,
                    BlockType: value.BlockType
                }
                rects.push(InputParam);
            }
            )
            drawAll();
            drawtxt();
            GetRackList();
        });

    };
    function WHLookupList() {
        var GetData = WhCreationAJService.GetWHLookupList();
        GetData.then(function (Response) {
            $scope.WHLookupList = Response.data;
        });
    }

     function GetRackList()
    {
        $scope.RakeLookupList = [];
        inputParam = {
            BlockId: $scope.WarehouseId
        };
        var GetData = WhCreationAJService.GetRakeLookupList(inputParam);
        GetData.then(function (Response) {
            $scope.RakeLookupList = Response.data;
        });
    }

    function WarehouseTypeList() {
        var KeyReference = {
            HeadCode: 'WHType',
            GroupCode: 'WHType'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.WarehouseTypeList = [];
        GetData.then(function (Response) {
            var TempWarehouseTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempWarehouseTypeList.unshift(defaltvalue);
            $scope.WarehouseTypeList = TempWarehouseTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function PolicyTypeList() {
        var KeyReference = {
            HeadCode: 'Policy Type',
            GroupCode: 'Policy'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.PolicyTypeList = [];
        GetData.then(function (Response) {
            var TempPolicyTypeList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempPolicyTypeList.unshift(defaltvalue);
            $scope.PolicyTypeList = TempPolicyTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Policy Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVecticalList() {
        var KeyReference = {
            HeadCode: 'VECTICAL',
            GroupCode: 'WAREHOUSE'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.WarehouseTypeList = [];
        GetData.then(function (Response) {
            var TempVecticalList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVecticalList.unshift(defaltvalue);
            $scope.VecticalList = TempVecticalList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Vectical Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetWarehouseLeaseFrom() {
        var InputParam = {
            VendorName: "",
            VehicleLeaseStatus: 'W',
            LocationId: $sessionStorage.locationId
        }

        var GetData = VehicleAJService.GetVendorDtls(InputParam);
        $scope.VehicleLeaseList = [];
        GetData.then(function (Response) {
            var TempVehicleList = Response.data;
            var defaltvalue = {
                VendorId: "",
                VendorName: "Select"
            }
            TempVehicleList.unshift(defaltvalue);
            $scope.WarehouseLeaseList = TempVehicleList;
            $scope.LeaseFromWarehouse = "";

        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Lease From List " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    if ($scope.YardList != undefined) {
        if ($scope.YardList.length > 0) {
            //$scope.BlockId = $scope.YardList[0].YardBlocks[0].BlockId;
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
        }
    }

    $("#btnAdd").focus();





     function GetAllYards() {
         var uiEle = angular.element(document.querySelector('#LpYard'));
         $('#LpYard').html('');

         angular.forEach($scope.YardList, function (value, key) {
             //if (!jQuery.isEmptyObject(value.YardBlocks)) {
             appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\">" +
                                                     "" + value.TerminalCode +
                                                     "</a>" +
                                                     "<ul type=\"square\">";

             angular.forEach(value.YardBlocks, function (value, key) {
                    //$scope.uOYardList = value.YardBlocks;
                     appendlst = appendlst + "<li><span class=\"tree-icon1\"></span><a href=\"#\" class=\"Yrdblk\" ng-click=\"commonSource('" + value.BlockId + "')\">" + value.BlockCode + "</a></li>";
                     //$('#' + value.Url).attr('data-title', value.Title);
                 });
                 appendlst = appendlst + "</ul></li>";
            // }
         });


        //uiEle.remove();
         //var YardList = $compile(appendlst)($scope);
        // uiEle.append(YardList);
        appendlst = "";
    }

     function showFirst(BlockId) {
         clearData();
        var BlockMaster = {
            BlockId: BlockId
        };

        var getData = WhDefnAJService.getYardBlockById(BlockMaster);
        getData.then(function (pBlockMaster) {
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.isShown = true;
            $scope.isShownLease = true;

            if (pBlockMaster.data.ErrorMessage != null) {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
            $scope.BlockId = pBlockMaster.data.BlockId;
            $scope.LocationId = pBlockMaster.data.LocationId;
            $scope.DepotId = pBlockMaster.data.DepotId;
            $scope.BlockCode = pBlockMaster.data.BlockCode;
            $scope.RtToTmDistance = pBlockMaster.data.RtToTmDistance;
            $scope.YardLength = pBlockMaster.data.YardLength;
            $scope.YardWidth = pBlockMaster.data.YardWidth;
            $scope.NoOfStacks = pBlockMaster.data.NoOfStacks;
            $scope.PerWtCapacity = pBlockMaster.data.PerWtCapacity;
            $scope.SpecialReserve = pBlockMaster.data.SpecialReserve;
            $scope.MaxWtCapacity = pBlockMaster.data.MaxWtCapacity;
            $scope.Remarks = pBlockMaster.data.Remarks;
            $scope.PerTransTime = pBlockMaster.data.PerTransTime;
            $scope.ColumnList = pBlockMaster.data.BlockColumnMasterList;
            $scope.LaneList = pBlockMaster.data.BlockLaneMasterList;
            $scope.YardBlockLaneColumnList = pBlockMaster.data.YardBlockLaneColumnList;
            $scope.NoOfPlugReefer = pBlockMaster.data.NoOfPlugReefer;
            $scope.nooflanes = pBlockMaster.data.NoOfLanes;
            $scope.noofcolumns = pBlockMaster.data.NoOfColumns;
            $scope.COMMODITY = pBlockMaster.data.CommodityType;
            //$scope.WhType = pBlockMaster.data.WareHouseType;
            $scope.WareHouseTypeId = pBlockMaster.data.WarehouseTypeId;
            $scope.OwnLease = pBlockMaster.data.OwnLease;
            $scope.LeaseFromWarehouse = pBlockMaster.data.LeaseFrom;
            $scope.LeaseAgreementRefNo = pBlockMaster.data.LeaseAgreeRefNo;
            $scope.LeasePeriod = pBlockMaster.data.LeasePeriod;
            $scope.PolicyTypeId = pBlockMaster.data.PolicyTypeId;
            $scope.Insurer = pBlockMaster.data.Insurer;
            $scope.PolicyNumber = pBlockMaster.data.PolicyNumber;
            $scope.SumInsured = pBlockMaster.data.SumInsured;
            $scope.PolicyEffectFrom = pBlockMaster.data.PolicyEffectFrom;
            $scope.PolicyEffectTo = pBlockMaster.data.PolicyEffectTo;
            $scope.RackBinType = pBlockMaster.data.RackBinType;
            $scope.VecticalTypeId = pBlockMaster.data.VecticalTypeId;


        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Yard Defination";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (BlockId) {
        showFirst(BlockId);
    }

    function clearYardList() {
        $scope.YardList = [];
        GetAllYards();
    }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        angular.element('#myInput').focus();
        //for (var i = 0; i < 5; i++){
        //    AddLane();
        //    AdColumn();
        //}
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;

        if ($scope.BlockId == undefined || $scope.BlockId == 0 || $scope.BlockId == "") {
            clearData();

            var watchList = $scope.$watch('YardList', function () {
                for (var i = 0; i < $scope.YardList.length; i++) {
                    if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                        $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                        break;
                    }
                }

                showFirst($scope.BlockId);
                watchList();
            });
        }
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.BlockId = undefined;
        $scope.LocationId = undefined;
        $scope.DepotId = undefined;
        $scope.BlockCode = undefined;
        $scope.RtToTmDistance = undefined;
        $scope.YardLength = undefined;
        $scope.YardWidth = undefined;
        $scope.NoOfStacks = undefined;
        $scope.PerWtCapacity = undefined;
        $scope.SpecialReserve = undefined;
        $scope.MaxWtCapacity = undefined;
        $scope.Remarks = undefined;
        $scope.PerTransTime = undefined;
        $scope.NoOfPlugReefer = undefined;
        $scope.nooflanes = undefined;
        $scope.noofcolumns = undefined;
        $scope.LaneList = [];
        $scope.ColumnList = [];
        $scope.COMMODITY = undefined;
        $scope.WareHouseTypeId = undefined;
        $scope.OwnLease = undefined;
        $scope.LeaseFromWarehouse = undefined;
        $scope.LeaseAgreementRefNo = undefined;
        $scope.LeasePeriod = undefined;
        $scope.PolicyTypeId = undefined;
        $scope.Insurer = undefined;
        $scope.PolicyNumber = undefined;
        $scope.SumInsured = undefined;
        $scope.PolicyEffectFrom = undefined;
        $scope.PolicyEffectTo = undefined;
        $scope.RackBinType = undefined;
        $scope.VecticalTypeId = undefined;
    }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//

    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.DepotId == undefined || $scope.DepotId == "") {
            $scope.errMsg = "Depot is required";
            $scope.isError = true;
            $("#lstDepo").focus();
            return;
        }

        if ($scope.BlockCode == undefined || $scope.BlockCode == "") {

            $scope.errMsg = "Block Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtBlockCode").focus();
            return;




        }
        else {
            if ($scope.BlockCode.length > 2) {

                $scope.errMsg = "Block Code not More then two Charactors";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtBlockCode").focus();
                return;
            }
            else {
                if ($scope.BlockCode.length < 2) {

                    $scope.errMsg = "Block Code not Less then two Charactors";
                    $scope.isError = true;
                    ErrorPopupMsg('ErrorDiv');
                    $("#txtBlockCode").focus();
                    return;
                }
            }
        }


        //if ($scope.RtToTmDistance == undefined || $scope.RtToTmDistance == "") {
        //    $scope.errMsg = "Distance from RT is required";
        //    $scope.isError = true;
        //    $("#txtRtToTmDistance").focus();
        //    return;
        //} 

        if ($scope.NoOfStacks < 0) {
            $scope.errMsg = "Permitted No Of Stacks Negative not allowed.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardLength").focus();
            return;
        }
        if ($scope.YardLength == undefined || $scope.YardLength == "") {
            $scope.errMsg = "Block Length is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardLength").focus();
            return;
        }

        if ($scope.YardWidth == undefined || $scope.YardWidth == "") {
            $scope.errMsg = "Width is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardWidth").focus();
            return;
        }

        var arrLaneList = [];

        if ($scope.LaneList.length != 0) {
            for (var i = 0; i < $scope.LaneList.length; i++) {
                if ($scope.LaneList[i].LaneCode != undefined) {
                    var pLists = {
                        BlockId: $scope.BlockId,
                        LaneId: $scope.LaneList[i].LaneId,
                        LaneCode: $scope.LaneList[i].LaneCode
                    }
                    arrLaneList.push(pLists);
                }
            }
        }

        var arrColumnList = [];

        if ($scope.ColumnList.length != 0) {
            for (var i = 0; i < $scope.ColumnList.length; i++) {
                if ($scope.ColumnList[i].ColumnCode != undefined) {
                    var pPriSec;
                    if (i == 0) {
                        pPriSec = 'P';
                    } else if (i % 2 == 0) {
                        pPriSec = 'P';
                    } else {
                        pPriSec = 'S';
                    }
                    var pLists = {
                        BlockId: $scope.BlockId,
                        ColumnId: $scope.ColumnList[i].ColumnId,
                        ColumnCode: $scope.ColumnList[i].ColumnCode,
                        PriSec: pPriSec
                    }
                    arrColumnList.push(pLists);
                }
            }
        }

        var BlockMaster = {
            BlockId: $scope.BlockId,
            LocationId: $sessionStorage.locationId,
            DepotId: $scope.DepotId,
            BlockCode: $scope.BlockCode,
            RtToTmDistance: $scope.RtToTmDistance,
            YardLength: $scope.YardLength,
            YardWidth: $scope.YardWidth,
            NoOfStacks: $scope.NoOfStacks,
            PerWtCapacity: $scope.PerWtCapacity,
            SpecialReserve: $scope.SpecialReserve,
            MaxWtCapacity: $scope.MaxWtCapacity,
            Remarks: $scope.Remarks,
            PerTransTime: $scope.PerTransTime,
            NoOfPlugReefer: $scope.NoOfPlugReefer,
            NoofLanes: $scope.nooflanes,
            NoofColumns: $scope.noofcolumns,
            BlockLaneMasterList: arrLaneList,
            BlockColumnMasterList: arrColumnList,
            WareHouseTypeId: $scope.WareHouseTypeId,
            CommodityType: $scope.COMMODITY,
            OwnLease: $scope.OwnLease,
            LeaseFrom: $scope.LeaseFromWarehouse,
            LeaseAgreeRefNo: $scope.LeaseAgreementRefNo,
            LeasePeriod: $scope.LeasePeriod,
            PolicyTypeId: $scope.PolicyTypeId,
            Insurer: $scope.Insurer,
            PolicyNumber:$scope.PolicyNumber,
            SumInsured: $scope.SumInsured,
            PolicyEffectFrom:$scope.PolicyEffectFrom,
            PolicyEffectTo: $scope.PolicyEffectTo,
            RackBinType: $scope.RackBinType,
            VecticalTypeId: $scope.VecticalTypeId
        };

        $scope.ShowLoader = true;
        var saveData = WhDefnAJService.saveYardData(BlockMaster);
        saveData.then(function (pBlockMaster) {
            $scope.ShowLoader = false;
            if (pBlockMaster.data.ErrorMessage != null && pBlockMaster.data.ErrorMessage != "") {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.BlockId = pBlockMaster.data.BlockId;
                //$scope.TerminalList = [];
                clearYardList();
                YardListAll();
                $scope.isShownLease = true;
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Yard Defination";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        });
    }

    $scope.filter = function () {
        var filteredList = [];
        var filteredYardBlockList;
        if ($scope.SrchCtrl != "" && $scope.SrchCtrl != undefined) {
            if ($scope.YardList.length > 0) {
                for (var i = 0; i < $scope.YardList.length; i++) {
                    filteredYardBlockList = $filter('filter')($scope.YardList[i].YardBlocks, { BlockCode: $scope.SrchCtrl });

                    if (filteredYardBlockList.length != undefined && filteredYardBlockList.length != 0) {
                        //filteredList = $scope.YardList[i];

                        filteredList.push($scope.YardList[i]);
                    }
                }

                if (filteredList != undefined && filteredList.length != 0) {
                    //$scope.YardList.push(filteredList);
                    $scope.YardList = filteredList;
                }
            }

        }
        else {
            $scope.YardList = $scope.tempYardList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('YardList', function () {
        if ($scope.YardList != undefined) {
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
            showFirst($scope.BlockId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewLane = function () {
        var newItem = { LaneCode: "", LaneId: 0 }

        $scope.LaneList.push(newItem);
    }

    //====================================================End of new lane addition==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewColumn = function () {
        var newItem = { ColumnCode: "", ColumnId: 0 }

        $scope.ColumnList.push(newItem);
    }
    //====================================================End of new lane addition==============================================================//

    $scope.updYardStatus = function (cList, lList) {
        var YardBlockLaneColumnSts = {
            BlockId: $scope.BlockId,
            LaneId: lList.LaneId,
            ColumnId: cList.ColumnId
        };

        //Updation to db is pending. discussion required


        //var UpdData = WhDefnAJService.updateYardStatus(YardBlockLaneColumnSts);
        //UpdData.then(function (pYardBlockLaneColumnSts) {

        //if (pYardBlockLaneColumnSts.data.ErrorMessage != null && pYardBlockLaneColumnSts.data.ErrorMessage != "") {
        //    $scope.errMsg = pYardBlockLaneColumnSts.data.ErrorMessage;
        //        $scope.isError = true;
        //        return;
        //    }
        //    else {
        //        $scope.errMsg = "";
        //        $scope.isError = false;
        //    }
        //}, function () {
        //    $scope.errMsg = "Error in updating Yard Status";
        //    $scope.isError = true;
        //    return;
        //});
    }

    $scope.LaneDataChange = function () {
        if (($scope.nooflanes == undefined) || ($scope.nooflanes == 0)) {
            $scope.LaneList = [];
            return
        }
        $scope.LaneList = [];
        var AscChar = 65;
        for (i = 0; i < $scope.nooflanes; i++) {
            var InputParam = {
                LaneCode: String.fromCharCode(AscChar + i),
                LaneId: 0
            }
            $scope.LaneList.push(InputParam);
        }
    }

    $scope.ColumnDataChange = function () {
        if (($scope.noofcolumns == undefined) || ($scope.noofcolumns == 0)) {
            $scope.ColumnList = [];
            return
        }
        $scope.ColumnList = [];
        var ColSeq = 0
        for (i = 0; i < $scope.noofcolumns; i++) {
            var InputParam = {
                ColumnCode: padToFour(ColSeq + 1),
                ColumnId: 0
            }
            ColSeq = ColSeq + 1;
            $scope.ColumnList.push(InputParam);
        }
    }


    function padToFour(number) {
        if (number <= 999) { number = ("00" + number).slice(-2); }
        return number;
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    function CreateBlock(BlockType, BlockName, BlockId, InW, InH, InC)
    {
        inputParam = {
            BlockId: $scope.WarehouseId,
            RackId: BlockId,
            LocationId: 1,
            RackName: BlockName,
            XCoor: mouseX,
            YCoor: mouseY,
            Width: InW,
            Height: InH,
            ColorCode: InC
        };
        var GetData = WhCreationAJService.CreateBlock(inputParam);
        GetData.then(function (Response) {
            //$scope.RakeLookupList = Response.data;
        });

    }


    //function GetCommodity() {
    //    var getData = WhDefnAJService.CommodityList('');
    //    getData.then(function (result) {
    //        $scope.CmdtCode = $.parseJSON(result.data);
    //    });
    //}

    $(document).ready(function () {
        canvas = document.getElementById("canvas");
        ctx = canvas.getContext("2d");
        $canvas = $("#canvas");

        canvasOffset = $canvas.offset();
        offsetX = canvasOffset.left;
        offsetY = canvasOffset.top;
        scrollX = $canvas.scrollLeft();
        scrollY = $canvas.scrollTop();
        //ctx.lineWidth = 2;
        drag = false;

        // save info about each circle in an object
        rects = [];
        Rrects = [];
        selectedRect = -1;
        // the html radio buttons indicating what action to do upon mousedown
        $create = $("#rCreate")[0];
        $select = $("#rSelect")[0];
        $move = $("#rMove")[0];
        $Clear = $("#rClear")[0];

        InW = $("#CWidth").val();
        InH = $("#CHeight").val();
        InC = $("#Ccolor").val();
        btn = "";



        $("#canvas").mouseup(function (e) {
            e.preventDefault();
            var InW = $("#CWidth").val();
            var InH = $("#CHeight").val();
            var InC = $("#Ccolor").val();
            var RakeName = "";
            var RakeId = "";
            var BlockType = "";
            mouseX = parseInt(e.clientX - offsetX);
            mouseY = parseInt(e.clientY - offsetY);
            
            if ($create.checked && drag) {
                if (btn == "" || btn == undefined)
                {
                    alert("Select type to add");
                    return;
                }
                
                if ($("#WareHouseId").val() == undefined || $("#WareHouseId").val() == "?")
                {
                    alert("Select Warehouse");
                    return;
                }
                if (btn == "Rack") {
                    BlockType = "Rack";
                    RakeName = $("#RakeId").find(":selected").text();
                    if ($scope.RakeId == 0 || $scope.RakeId == undefined) {
                        alert("Select Rack");
                        return;
                    }
                    RakeId = $scope.RakeId;
                }
                if ($scope.CWidth == "" || $scope.CWidth == undefined || $scope.CHeight == "" || $scope.CHeight == undefined) {
                    alert("Enter Width/Height values");
                    return;
                }
                if (btn == "LA")
                {
                    BlockType = "LA";
                    RakeName = "LA";
                }
                if (btn == "PA")
                {
                    BlockType = "PA";
                    RakeName = "PA";
                }
                if (btn == "Deck")
                {
                    BlockType = "Deck";
                    RakeName = "Deck";
                }
                if (btn == "Office")
                {
                    BlockType = "Office";
                    RakeName = "Office";
                }
                    // create a new circle a the mouse position and select it
                InputParam = {
                    cx: mouseX,
                    cy: mouseY,
                    width: InW,
                    height: InH,
                    color: InC,
                    txt1: RakeName,
                    txt2: RakeId,
                    BlockType: RakeName
                }
                rects.push(InputParam);
                CreateBlock(btn, RakeName, RakeId, InW, InH, InC);
                //$scope.GetWhDetails();
                drawAll();
                drawtxt();
            }
            if ($move.checked == true)
            {
                var c = rects[selectedRect]
                updateBlock(c.txt1, c.txt2, mouseX, mouseY,c.BlockType);
            }
            drag = false;


        });

        $("#canvas").mousedown(function (e) {
            handleMouseDown(e);
            drawtxt();
            drag = true;
        });

        $("#canvas").mousemove(function (e) {
            e.preventDefault();
            mouseX = parseInt(e.clientX - offsetX);
            mouseY = parseInt(e.clientY - offsetY);

            if ($move.checked && selectedRect >= 0 && drag) {
                $(this).css({ 'cursor': 'move' });
                var c = rects[selectedRect];
                c.cx = mouseX;
                c.cy = mouseY;
                drawAll();
                drawtxt();
            }
            $(this).css({ 'cursor': 'default' });
//            $("#cord").html("pageX: " + mouseX + ", pageY: " + mouseY + ", Selected Shape: " + selectedRect + ", Color: " + InC);

        });

        //////Click on BTN///////////////////////////	
        $('#btnRack').click(function () {
            $("#Ccolor").val('#00ff00');
            btn = "Rack";
        });

        $('#btnLA').click(function () {
            $("#Ccolor").val('#0000ff');
            btn = "LA";
        });
        $('#btnPA').click(function () {
            $("#Ccolor").val('#00ffff');
            btn = "PA";
        });
        $('#btnDeck').click(function () {
            $("#Ccolor").val('#ffff00');
            btn = "Deck";
        });
        $('#btnOffice').click(function () {
            $("#Ccolor").val('#ffffff')
            btn = "Office";
        });

        $('#BtnClear').click(function () {
            clear();
        });


    });

    // draw all rects[]   
    function drawAll() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (var i = 0; i < rects.length; i++) {
            var c = rects[i];
            ctx.beginPath();

            ctx.rect(c.cx, c.cy, c.width, c.height);
            ctx.closePath();
            ctx.globalAlpha = 0.5;
            ctx.fillStyle = c.color;
            ctx.stroke();
            ctx.fill();            
            
            ctx.save();
            ctx.globalAlpha = 1;
            // if this is the selected circle, highlight it
            if (selectedRect == i) {
                ctx.strokeStyle = "red";                
                ctx.stroke();

/*                $(this).dblclick(function () {
                    $('#divRackDT').modal('show');
                    $('#divRackDT .panel-body').html("pageX: " + mouseX + ", pageY: " + mouseY + ",<br/> Selected Shape: " + selectedRect + ", <br/>Color: " + InC);
                });*/
            }

        }
    }

    function drawtxt() {
        for (var i = 0; i < rects.length; i++) {
            var c = rects[i];
            ctx.fillStyle = '#444444';
            ctx.font = 'italic small-caps 16px Arial ';
            ctx.fillText(c.txt1, c.cx + (parseFloat(c.width) / 2), c.cy + (parseFloat(c.height) / 2));
            //ctx.fillText(c.txt2, c.cx, c.cy + parseFloat(c.height));
        }
    }

    function handleMouseDown(e) {
        e.preventDefault();
        mouseX = parseInt(e.clientX - offsetX);
        mouseY = parseInt(e.clientY - offsetY);

        if ($select.checked) {
            selectedRect = -1;
            for (var i = 0; i < rects.length; i++) {
                var c = rects[i];
                var dx = mouseX - c.cx;
                var dy = mouseY - c.cy;
                var rr = c.width * c.height;
                //if (dx * dx + dy * dy < rr) {

                if (mouseX > c.cx && mouseX < c.cx + parseFloat(c.width) && mouseY > c.cy && mouseY < c.cy + parseFloat(c.height)) {
                    selectedRect = i;
                    //alert(dx);                    
                    //$('#divRackDT').modal('show')
                    //$('#divRackDT .panel-body').html(i)
                }
            }
        }
        drawAll();
    }



    function clear() {
        if ($select.checked && selectedRect >= 0) {
            removeBlock(selectedRect);
            rects.splice(selectedRect, 1)
            drawAll();
            drawtxt();
        }

    }


    function removeBlock(selectedRectid) {
        var c = rects[selectedRectid];
        var inputParam = {
            RackName: c.txt1,
            RackId: c.txt2,
            BlockType: c.BlockType
        }
        var GetData = WhCreationAJService.RemoveBlock(inputParam);
        GetData.then(function (Response) {
            
            $scope.RakeLookupList = Response.data;
        });

    }


    function updateBlock(BlockName, BlockId, InW, InH, BlockType) {
        inputParam = {
            BlockId: $scope.WarehouseId,
            RackId: BlockId,
            LocationId: 1,
            RackName: BlockName,
            XCoor: InW,
            YCoor: InH,
            BlockType: BlockType
        };
        var GetData = WhCreationAJService.UpdateBlock(inputParam);
        GetData.then(function (Response) {
            
            //$scope.RakeLookupList = Response.data;
        });

    }

});

