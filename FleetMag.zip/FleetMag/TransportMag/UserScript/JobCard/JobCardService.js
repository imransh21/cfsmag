﻿app.service("JobCardAJService", function ($http) {
    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetALLJobAllocation = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetJobAllocationList",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }

    this.SaveWorkInstAcceptUpdate = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/SaveWorkinstructionAccept",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }

    this.CrewDetailsListService = function (jobid) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetCrewDetails",
            data: JSON.stringify(jobid),
            datatype: "json"
        });
        return response;
    }
    this.getCrewAllocationList = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetCrewAllocation",
            data: JSON.stringify(inputValues),
            dataType: "json"
        });
        return response;
    }
    this.getworkinstruction = function (WorkInstructions) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/getworkinstruction",
            data: JSON.stringify(WorkInstructions),
            dataType: "json"
        });
        return response;
    }


    this.getCrewAllocationSUBList = function (EquipmentMaster) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/getCrewAllocationSub",
            data: JSON.stringify(EquipmentMaster),
            dataType: "json"
        });
        return response;
    }


    this.EmployeeLookup = function (p) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetEmployeeListLookup",
            data: JSON.stringify(p),
            datatype: "json"
        });
        return response;
    }

    this.UpdateCrewDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateCrewDetails",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }

    this.GetAllVendorConfigs = function (inputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Masters/VendorMaster/GetAllVendorForReapair",
            data: JSON.stringify(inputParam),
            dataType: "json"
        });
        return response;
    }

    this.DeleteCrewdtls = function (inputValues) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/DeleteCrewbyEmpID",
            data: JSON.stringify(inputValues),
            datatype: "json"
        });
        return response;
    }


    this.GetMaterialData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/LoadMaterialDetailsByScheduleId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.UpdateMaterialDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateMaterialDetails",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }



    this.DeleteMaterialRequest = function (pWisMaterialRequest) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/DeleteMaterialRequest",
            data: JSON.stringify(pWisMaterialRequest),
            dataType: "json"
        });
        return response;
    }


    this.GetMaterialItemData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/LoadMaterialDetailsByJobId",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.UpdateMaterialReturnDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateMaterialReturn",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }

    this.UpdateScrapReturnDtls = function (workinst) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateScrapReturn",
            data: JSON.stringify(workinst),
            datatype: "json"
        });
        return response;
    }

    this.SaveWorkInstVehicleDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateVehicledtls",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }

    this.SaveWorkInstCloseDtls = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateCloseWorkinst",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }


    this.ServiceLookup = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetServiceListLookup",
            //data: JSON.stringify(),
            datatype: "json"
        });
        return response;
    }


    this.SaveOutSideRepaireDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/UpdateOutSideRepairdtls",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }

    this.ScrapDetails = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Maintenance/JOBCard/GetScrapDetails",
            data: JSON.stringify(InputParam),
            datatype: "json"
        });
        return response;
    }

});