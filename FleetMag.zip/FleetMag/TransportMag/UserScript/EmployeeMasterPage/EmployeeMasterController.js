﻿app.controller("mvcEmpCtrl", function ($scope, $localStorage, $filter, $compile, $timeout, EmpAJService, YardAJService, RailLineAJService) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
   
    
    var appendlst = "";  
    GetEmpList();
    //GetSCList();
        
    BranchList();
    $("#btnAdd").focus();
   
    function BranchList() {
        $scope.LocationId = $localStorage.locationId;
        var GetData = YardAJService.GetAllTerminals();

        GetData.then(function (pTerminals) {
            $scope.BranchList = $.parseJSON(pTerminals.data);
            $scope.errMsg = "";
            $scope.isError = false;

        }, function (reason) {
            $scope.errMsg = "Error in getting Terminals " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    $('#txtCity').autocomplete({
        source: function (request, response) {

            var getUrl = window.location;
            var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
            $.ajax({
                url: baseUrl + '/EmployeeMaster/LoadAllCityAuto',
                data: "{ 'BranchId': " + $localStorage.locationId + ",'City':'" + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map($.parseJSON(data), function (item, key) {
                        return {
                            label: item.City,
                            CityId: item.EmpId
                             

                        }
                    }))
                },
                error: function (response) {
                    //alert(response.responseText);
                },
                failure: function (response) {
                    //alert(response.responseText);
                }
            });
        },
        select: function (e, i) {

            var $scope = angular.element(document.getElementById('divUser')).scope();
            $scope.CityId = i.item.CityId;
            $scope.City = i.item.label;


        },
        minLength: 1
    });

    $('#txtState').autocomplete({
        source: function (request, response) {

            $scope.StateId = undefined;

            var getUrl = window.location;
            var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
            $.ajax({
                url: baseUrl + '/EmployeeMaster/LoadAllStateAuto1',
                data: "{ 'BranchId': " + $localStorage.locationId + ",'State':'" + (request.term==undefined ? $scope.State : request.term) + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data != undefined && data != "" && data != "[]") {
                        if (typeof(response) == "function") {
                            response($.map($.parseJSON(data), function (item, key) {
                                return {
                                    label: item.State,
                                    StateId: item.EmpId

                                }
                            }));
                        }
                        else if ($.parseJSON(data).length > 0) {
                            $scope.StateId = $.parseJSON(data)[0].EmpId;
                        }
                    }
                    else {
                        $scope.StateId = undefined;
                    }
                },
                error: function (response) {
                    //alert(response.responseText);
                },
                failure: function (response) {
                    //alert(response.responseText);
                }
            });
        },
        select: function (e, i) {

            var $scope = angular.element(document.getElementById('divUser')).scope();
            $scope.StateId = i.item.StateId;
            $scope.State = i.item.label;


        },
        minLength: 1
    });
    function GetAllWarehouses(pLocationId) {
        var pWareHouse = {
            LocationId: pLocationId
        };

        var getData = RailLineAJService.GetAllWarehousesBlock(pWareHouse);

        getData.then(function (Response) {
            $scope.WarehouseList = $.parseJSON(Response.data);
        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse " + reason.data;
            $scope.isError = true;
            return;
        });
    };
    //====================================================Get Vendor List=====================================================================//
    function GetEmpList() {
        var pEmp = {
            BranchId: $localStorage.locationId
        };
        var GetData;
        if ($localStorage.adminUserStatus == "Y") {
            GetData = EmpAJService.GetAllEmployees(pEmp);
        }
        else {
            GetData = EmpAJService.GetAllEmpByBranch(pEmp);
        }
       
        GetData.then(function (pEmp) {
            $scope.EmpList = $.parseJSON(pEmp.data);
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempEmpList = $scope.EmpList;
           

        }, function (reason) {
            $scope.errMsg = "Error in getting Employee " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetSCList() {
       

        var GetData = EmpAJService.GetAllSC();

        GetData.then(function (pEmp) {
            $scope.SCList = $.parseJSON(pEmp.data);
            $scope.errMsg = "";
            $scope.isError = false;
           

        }, function (reason) {
            $scope.errMsg = "Error in getting SC List " + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllEmp() {
        var uiEle = angular.element(document.querySelector('#LpEmp'));
        $('#LpEmp').html('');
        angular.forEach($scope.EmpList, function (value, key) {
            if (!jQuery.isEmptyObject(value.EmpId)) {
                appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\" ng-click=\"commonSource('" + value.EmpId + "')\">" + value.EmployeeName + "</a></li>";
               
            }
        });       
        var Employee = $compile(appendlst)($scope);
        uiEle.append(Employee);
        appendlst = "";
    }

    function showFirst(EmpId)
    {
        var EmpMaster = {
            EmpId: EmpId
        };

        var getData = EmpAJService.getEmpById(EmpMaster);
        getData.then(function (pEmpMaster) {
            $scope.errMsg = "";
            $scope.isError = false;

            if (pEmpMaster.data.ErrorMessage != null) {
                $scope.errMsg = pEmpMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }
          
            $scope.EmpId = pEmpMaster.data.EmpId;
            $scope.EmpCode = pEmpMaster.data.EmpCode;
            $scope.EmployeeName = pEmpMaster.data.EmployeeName;
            $scope.BranchId = pEmpMaster.data.BranchId;
            $scope.Designation = pEmpMaster.data.Designation;
            $scope.ActiveStatus = pEmpMaster.data.ActiveStatus;
            $scope.PreferedArea = pEmpMaster.data.PreferedArea;
            $scope.Dob = pEmpMaster.data.Dob;
            $scope.CellNo = pEmpMaster.data.CellNo;
            $scope.EmgContNo = pEmpMaster.data.EmgContNo;
            $scope.Address = pEmpMaster.data.Address;
            $scope.City = pEmpMaster.data.City;
            $scope.State = pEmpMaster.data.State;
            $("#txtState").data('ui-autocomplete')._trigger('source', 'autocompletesource', {});
            $scope.Pin = pEmpMaster.data.Pin;
            $scope.DomPerDayRate = pEmpMaster.data.DomPerDayRate;
            $scope.OtRate = pEmpMaster.data.OtRate;
            $scope.EmployeeCard = pEmpMaster.data.EmployeeCard;
            $scope.IntPerDayRate = pEmpMaster.data.IntPerDayRate;
            $scope.Rating = pEmpMaster.data.Rating;
            GetAllWarehouses(pEmpMaster.data.BranchId);

           // $scope.SCList = pEmpMaster.data.SpecialCare;
            var arrSCList = [];
            if (pEmpMaster.data.SpecialCare != undefined && pEmpMaster.data.SpecialCare.length != 0) {
                for (var i = 0; i < pEmpMaster.data.SpecialCare.length; i++) {
                    //if (pEmpMaster.data.SpecialCare[i].EmpId != '' && pEmpMaster.data.SpecialCare[i].EmpId == $scope.EmpId) {
                    //    var pLists = {
                    //        ScId: pEmpMaster.data.SpecialCare[i].ScId,
                    //        Description: pEmpMaster.data.SpecialCare[i].Description,
                    //        Color: pEmpMaster.data.SpecialCare[i].Color,
                    //        Code: pEmpMaster.data.SpecialCare[i].Code,
                    //        EmpId: pEmpMaster.data.SpecialCare[i].EmpId,
                    //        EscId: pEmpMaster.data.SpecialCare[i].EscId,
                    //        Status: pEmpMaster.data.SpecialCare[i].Status
                    //    }
                    //}
                    //else {
                        var pLists = {
                            ScId: pEmpMaster.data.SpecialCare[i].ScId,
                            Description: pEmpMaster.data.SpecialCare[i].Description,
                            Color: pEmpMaster.data.SpecialCare[i].Color,
                            Code: pEmpMaster.data.SpecialCare[i].Code,
                            EmpId: pEmpMaster.data.EmpId,
                            EscId: pEmpMaster.data.SpecialCare[i].EscId,
                            Status: pEmpMaster.data.SpecialCare[i].Status
                        }                   
                       
                   // }
                    arrSCList.push(pLists);
                    }
            }
            $scope.SCList = arrSCList;  

        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Employee Data";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (EmpId) {
        showFirst(EmpId);
    }

    function clearEmpList() {
        $scope.EmpList = [];
        GetAllEmp();
   }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        GetSCList();
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
        $("#txtState").data('ui-autocomplete')._trigger('source', 'autocompletesource', {});
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;      
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.ExitDtls = function () {
        getIndexpage();

    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.EmpId = undefined;
        $scope.EmpCode = undefined;
        $scope.EmployeeName = undefined;
        $scope.BranchId = undefined;
        $scope.Designation = undefined;
        $scope.ActiveStatus = 'N';
        $scope.PreferedArea = undefined;
        $scope.Dob = undefined;
        $scope.CellNo = undefined;
        $scope.EmgContNo = undefined;
        $scope.Address = undefined;
        $scope.City = undefined;
        $scope.State = undefined;
        $scope.Pin = undefined;
        $scope.DomPerDayRate = undefined;
        $scope.OtRate = undefined;
        $scope.EmployeeCard = undefined;
        $scope.IntPerDayRate = undefined;
        $scope.Rating = undefined;
        $scope.SCList = [];
        }
    //====================================================End Clear form data=====================================================================//
    $scope.brachchange = function () {
        GetAllWarehouses($scope.LocationId);
    }
    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//
   
    $scope.SaveDtls = function () {
        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.EmpCode == undefined || $scope.EmpCode == "") {
            $scope.errMsg = "Employee Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtEmpCode").focus();
            return;
        }

        if ($scope.EmployeeName == undefined || $scope.EmployeeName == "") {
            $scope.errMsg = "Employee Name   is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtEmpName").focus();
            return;
        }

        if ($scope.Designation == undefined || $scope.Designation == "") {
            $scope.errMsg = " Designation is required.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtDesignation").focus();
            return;
        }
        if ($scope.State == undefined || $scope.State == "") {
            $scope.errMsg = " State is required.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtState").focus();
            return;
        }
        if ($scope.StateId == undefined || $scope.StateId == "") {
            $scope.errMsg = "Invalid State.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtState").val('');
            $("#txtState").focus();
            return;
        }
       
        var EmpMaster = {
            EmpId: $scope.EmpId,
            EmpCode: $scope.EmpCode,
            BranchId: $localStorage.locationId,
            EmployeeName: $scope.EmployeeName,
            Designation: $scope.Designation,
            ActiveStatus: $scope.ActiveStatus,
            PreferedArea: $scope.PreferedArea,
            Dob: $scope.Dob,
            CellNo: $scope.CellNo,
            EmgContNo: $scope.EmgContNo,
            Address: $scope.Address,
            City: $scope.City,
            State: $scope.State,
            Pin: $scope.Pin,
            DomPerDayRate: $scope.DomPerDayRate,
            OtRate: $scope.OtRate,
            EmployeeCard:$scope.EmployeeCard,
            IntPerDayRate: $scope.IntPerDayRate,
            Rating: $scope.Rating,
            SpecialCare:$filter('filter')($scope.SCList, { Flag: "U" })
            };

        var saveData = EmpAJService.saveEmpData(EmpMaster);
        saveData.then(function (pEmpMaster) {

            if (pEmpMaster.data.ErrorMessage != null && pEmpMaster.data.ErrorMessage != "") {
                $scope.errMsg = pEmpMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;
                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved";
                ErrorPopupMsg('ErrorDivG');
                $scope.EmpId = pEmpMaster.data.EmpId;               
                clearEmpList();
                GetEmpList();
                showFirst($scope.EmpId);
            }
        }, function () {
            clearFields();
            $scope.errMsg = "Error in saving Employee Data.";
            $scope.isError = true;
            return;
        });
    }
    
    $scope.filter = function () {
        var filteredList;
        
        if ($scope.SrchRecord != "" && $scope.SrchRecord != undefined) {
            
                if ($scope.EmpList.length!=0) {
                    filteredList = $filter('filter')($scope.EmpList, { EmployeeName: $scope.SrchRecord });

                    if (filteredList != undefined) {
                        $scope.EmpList = filteredList;
                    }                   
                }
        }
        else {
            $scope.EmpList = $scope.tempEmpList;
        }
    }

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('EmpList', function () {
        if ($scope.EmpList != undefined) {
            showFirst($scope.EmpList[0].EmpId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//
  
    $scope.updFlag = function (row) {     
            row.Flag = "U";       
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    $scope.OnStateTxtChange = function () {
      //  $scope.StateId = undefined;
    }

});

