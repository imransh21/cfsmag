﻿app.controller("mvcWhDefnCtrl", function ($scope, $sessionStorage, $filter, $compile, WhDefnAJService, IndentGenAJService, KeyRefrenceCtrlAJService, VehicleAJService, HomeIndex) {
    $scope.errMsg = "";
    $scope.isError = false;
    $scope.isShown = true;
    $scope.ShowLoader = false;
    $scope.isShownLease = true;
    $scope.isShownPoliceType = true;
    //$scope.YardReservationList = locale.YardReservation;
    var appendlst = "";
    DepoLookupList();
    WarehouseTypeList();
    PolicyTypeList();
    GetWarehouseLeaseFrom();
    YardListAll();
    GetVecticalList();
    StateLookupList();

    $scope.GetLeaseSelect = function () {
        if ($scope.OwnLease == 'L') {
            $scope.isShownLease = false;
        }
        else {
            $scope.isShownLease = true;

        }
    }


    $scope.PolicyTypeListChange = function () {

        if (($scope.PolicyTypeId != undefined || $scope.PolicyTypeId != null)) {
            $scope.isShownPoliceType = false;
        }
        else {
            $scope.isShownPoliceType = true;

        }
    }


    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function WarehouseTypeList() {
        var KeyReference = {
            HeadCode: 'WHType',
            GroupCode: 'WHType'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.WarehouseTypeList = [];
        GetData.then(function (Response) {
            var TempWarehouseTypeList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //   TempWarehouseTypeList.unshift(defaltvalue);
            $scope.WarehouseTypeList = TempWarehouseTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function PolicyTypeList() {
        var KeyReference = {
            HeadCode: 'Policy Type',
            GroupCode: 'Policy'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.PolicyTypeList = [];
        GetData.then(function (Response) {
            var TempPolicyTypeList = Response.data;
            //var defaltvalue = {
            //    Pkey: "",
            //    CodeValue: "Select"
            //}
            //TempPolicyTypeList.unshift(defaltvalue);
            $scope.PolicyTypeList = TempPolicyTypeList;
            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Policy Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };

    function GetVecticalList() {
        var KeyReference = {
            HeadCode: 'VERTICAL',
            GroupCode: 'WAREHOUSE'
        };

        var GetData = KeyRefrenceCtrlAJService.getMasterData(KeyReference);
        $scope.WarehouseTypeList = [];
        GetData.then(function (Response) {
            var TempVecticalList = Response.data;
            var defaltvalue = {
                Pkey: "",
                CodeValue: "Select"
            }
            TempVecticalList.unshift(defaltvalue);
            $scope.VecticalList = TempVecticalList;

            //$scope.WareHouseTypeId = "";
        }, function (reason) {
            $scope.errMsg = "Error in getting Vectical Type " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    function GetWarehouseLeaseFrom() {
        var InputParam = {
            VendorName: "",
            VehicleLeaseStatus: 'W',
            LocationId: $sessionStorage.locationId
        }

        var GetData = VehicleAJService.GetVendorDtls(InputParam);
        $scope.VehicleLeaseList = [];
        GetData.then(function (Response) {
            var TempVehicleList = Response.data;
            //var defaltvalue = {
            //    VendorId: "",
            //    VendorName: "Select"
            //}
            //TempVehicleList.unshift(defaltvalue);
            $scope.WarehouseLeaseList = TempVehicleList;
            $scope.LeaseFromWarehouse = "";

        }, function (reason) {
            $scope.errMsg = "Error in getting Warehouse Lease From List " + reason.data;
            $scope.isError = true;
            return;
        });
    };



    if ($scope.YardList != undefined) {
        if ($scope.YardList.length > 0) {
            //$scope.BlockId = $scope.YardList[0].YardBlocks[0].BlockId;
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
        }
    }

    $("#btnAdd").focus();



    //====================================================Get All Itvs=====================================================================//
    function YardListAll() {
        var GetData = WhDefnAJService.GetAllTerminalYards();

        GetData.then(function (pYards) {
            $scope.YardList = pYards.data;
            $scope.errMsg = "";
            $scope.isError = false;
            $scope.tempYardList = $scope.YardList;
            //GetAllYards();

        }, function (reason) {
            $scope.errMsg = "Error in getting Yard Defination" + reason.data;
            $scope.isError = true;
            return;
        });
    }

    function GetAllYards() {
        var uiEle = angular.element(document.querySelector('#LpYard'));
        $('#LpYard').html('');

        angular.forEach($scope.YardList, function (value, key) {
            //if (!jQuery.isEmptyObject(value.YardBlocks)) {
            appendlst = appendlst + "<li><span class=\"fa fa-file-o tree-icon\"></span><a href=\"#\">" +
                                                    "" + value.TerminalCode +
                                                    "</a>" +
                                                    "<ul type=\"square\">";

            angular.forEach(value.YardBlocks, function (value, key) {
                //$scope.uOYardList = value.YardBlocks;
                appendlst = appendlst + "<li><span class=\"tree-icon1\"></span><a href=\"#\" class=\"Yrdblk\" ng-click=\"commonSource('" + value.BlockId + "')\">" + value.BlockCode + "</a></li>";
                //$('#' + value.Url).attr('data-title', value.Title);
            });
            appendlst = appendlst + "</ul></li>";
            // }
        });


        //uiEle.remove();
        //var YardList = $compile(appendlst)($scope);
        // uiEle.append(YardList);
        appendlst = "";
    }

    function showFirst(BlockId) {

        clearData();
        var BlockMaster = {
            BlockId: BlockId
        };

        var getData = WhDefnAJService.getYardBlockById(BlockMaster);
        getData.then(function (pBlockMaster) {

            $scope.errMsg = "";
            $scope.isError = false;
            $scope.isShown = true;
            $scope.isShownLease = true;

            if (pBlockMaster.data.ErrorMessage != null) {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                return;
            }

            $scope.BlockId = pBlockMaster.data.BlockId;
            $scope.LocationId = pBlockMaster.data.LocationId;
            $scope.DepotId = pBlockMaster.data.DepotId;
            $scope.BlockCode = pBlockMaster.data.BlockCode;
            $scope.RtToTmDistance = pBlockMaster.data.RtToTmDistance;
            $scope.YardLength = pBlockMaster.data.YardLength;
            $scope.YardWidth = pBlockMaster.data.YardWidth;
            $scope.NoOfStacks = pBlockMaster.data.NoOfStacks;
            $scope.PerWtCapacity = pBlockMaster.data.PerWtCapacity;
            $scope.SpecialReserve = pBlockMaster.data.SpecialReserve;
            $scope.MaxWtCapacity = pBlockMaster.data.MaxWtCapacity;
            $scope.Remarks = pBlockMaster.data.Remarks;
            $scope.PerTransTime = pBlockMaster.data.PerTransTime;
            $scope.ColumnList = pBlockMaster.data.BlockColumnMasterList;
            $scope.LaneList = pBlockMaster.data.BlockLaneMasterList;
            $scope.YardBlockLaneColumnList = pBlockMaster.data.YardBlockLaneColumnList;
            $scope.NoOfPlugReefer = pBlockMaster.data.NoOfPlugReefer;
            $scope.nooflanes = pBlockMaster.data.NoOfLanes;
            $scope.noofcolumns = pBlockMaster.data.NoOfColumns;
            $scope.COMMODITY = pBlockMaster.data.CommodityType;
            //$scope.WhType = pBlockMaster.data.WareHouseType;
            $scope.WareHouseTypeId = pBlockMaster.data.WarehouseTypeId;
            $scope.OwnLease = pBlockMaster.data.OwnLease;
            $scope.LeaseFromWarehouse = pBlockMaster.data.LeaseFrom;
            $scope.LeaseAgreementRefNo = pBlockMaster.data.LeaseAgreeRefNo;
            $scope.LeasePeriod = pBlockMaster.data.LeasePeriod;
            $scope.PolicyTypeId = pBlockMaster.data.PolicyTypeId;
            $scope.Insurer = pBlockMaster.data.Insurer;
            $scope.PolicyNumber = pBlockMaster.data.PolicyNumber;
            $scope.SumInsured = pBlockMaster.data.SumInsured;
            $scope.PolicyEffectFrom = pBlockMaster.data.PolicyEffectFrom;
            $scope.PolicyEffectTo = pBlockMaster.data.PolicyEffectTo;
            $scope.RackBinType = pBlockMaster.data.RackBinType;
            $scope.VecticalTypeId = pBlockMaster.data.VecticalTypeId;
            $scope.WarehouseAddress = pBlockMaster.data.WarehouseAddress;
            $scope.ContactPerson = pBlockMaster.data.ContactPerson;
            $scope.WarehouseName = pBlockMaster.data.WarehouseName;
            $scope.StateId = pBlockMaster.data.StateId;

            $scope.ContactNo = pBlockMaster.data.ContactNo;


        }, function () {
            clearData();
            $scope.errMsg = "Error in fetching Yard Defination";
            $scope.isError = true;
            return;
        });
    }

    $scope.commonSource = function (BlockId) {

        showFirst(BlockId);
    }

    function clearYardList() {
        $scope.YardList = [];
        GetAllYards();
    }
    //====================================================End Get All Itvs=====================================================================//

    //====================================================Add Event=====================================================================//
    $scope.AddDtls = function () {
        clearData();
        $scope.isShown = false;
        angular.element('#myInput').focus();
        //for (var i = 0; i < 5; i++){
        //    AddLane();
        //    AdColumn();
        //}
    }
    //====================================================End Add Event=====================================================================//

    //====================================================Edit Event=====================================================================//
    $scope.EditDtls = function () {
        $scope.isShown = false;
        if ($scope.PolicyTypeId != "") {
            $scope.isShownPoliceType = false;
        }
    }
    //====================================================End Edit Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    $scope.clearDtls = function () {
        $scope.isShown = true;

        if ($scope.BlockId == undefined || $scope.BlockId == 0 || $scope.BlockId == "") {
            clearData();

            var watchList = $scope.$watch('YardList', function () {
                for (var i = 0; i < $scope.YardList.length; i++) {
                    if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                        $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                        break;
                    }
                }

                showFirst($scope.BlockId);
                watchList();
            });
        }
    }
    //====================================================End Cancel Event=====================================================================//

    //====================================================Cancel Event=====================================================================//
    //$scope.ExitDtls = function () {
    //    getIndexpage();
    //}

    $scope.ExitDtls = function () {
        HomeIndex.getIndexPage("/Home/Warehouse");
    }

    //====================================================End Cancel Event=====================================================================//

    //====================================================Clear form data=====================================================================//
    function clearData() {
        $scope.BlockId = undefined;
        $scope.LocationId = undefined;
        $scope.DepotId = undefined;
        $scope.BlockCode = undefined;
        $scope.RtToTmDistance = undefined;
        $scope.YardLength = undefined;
        $scope.YardWidth = undefined;
        $scope.NoOfStacks = undefined;
        $scope.PerWtCapacity = undefined;
        $scope.SpecialReserve = undefined;
        $scope.MaxWtCapacity = undefined;
        $scope.Remarks = undefined;
        $scope.PerTransTime = undefined;
        $scope.NoOfPlugReefer = undefined;
        $scope.nooflanes = undefined;
        $scope.noofcolumns = undefined;
        $scope.LaneList = [];
        $scope.ColumnList = [];
        $scope.COMMODITY = undefined;
        $scope.WareHouseTypeId = undefined;
        $scope.OwnLease = undefined;
        $scope.LeaseFromWarehouse = undefined;
        $scope.LeaseAgreementRefNo = undefined;
        $scope.LeasePeriod = undefined;
        $scope.PolicyTypeId = undefined;
        $scope.Insurer = undefined;
        $scope.PolicyNumber = undefined;
        $scope.SumInsured = undefined;
        $scope.PolicyEffectFrom = undefined;
        $scope.PolicyEffectTo = undefined;
        $scope.RackBinType = undefined;
        $scope.VecticalTypeId = undefined;
        $scope.WarehouseAddress = undefined;
        $scope.ContactPerson = undefined;
        $scope.ContactNo = undefined;
        $scope.WarehouseName = undefined;
        $scope.StateId = undefined;

    }
    //====================================================End Clear form data=====================================================================//

    //====================================================Redirect to IndexPage=====================================================================//
    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Index";

    }
    //====================================================End Redirect to IndexPage=====================================================================//

    $scope.SaveDtls = function () {

        $scope.errMsg = "";
        $scope.isError = false;

        if ($scope.DepotId == undefined || $scope.DepotId == "") {
            $scope.errMsg = "Depot is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstDepo").focus();
            return;
        }

        if ($scope.BlockCode == undefined || $scope.BlockCode == "") {

            $scope.errMsg = "WH Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtBlockCode").focus();
            return;
        }

        if ($scope.WareHouseTypeId == undefined || $scope.WareHouseTypeId == 0) {

            $scope.errMsg = "WH Type is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstWareHouseType").focus();
            return;
        }


        if ($scope.WarehouseName == undefined || $scope.WarehouseName == "") {

            $scope.errMsg = "WH Name is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtWarehouseName").focus();
            return;
        }

        if ($scope.WarehouseAddress == undefined || $scope.WarehouseAddress == "") {

            $scope.errMsg = "WH Address is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtWHAddress").focus();
            return;
        }


        if ($scope.StateId == undefined || $scope.StateId == 0) {

            $scope.errMsg = "State Code is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#lstState").focus();
            return;
        }


        if ($scope.ContactPerson == undefined || $scope.ContactPerson == "") {

            $scope.errMsg = "Contact Person is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtContactPerson").focus();
            return;
        }

        if ($scope.ContactNo == undefined || $scope.ContactNo == "") {

            $scope.errMsg = "Contact No is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtContactNo").focus();
            return;
        }


        if ($scope.Remarks == undefined || $scope.Remarks == "") {

            $scope.errMsg = "Remarks is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtRemarks").focus();
            return;
        }

        if ($scope.NoOfStacks == undefined || $scope.NoOfStacks == "") {

            $scope.errMsg = "No Of Stacks is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtNoOfStacks").focus();
            return;
        }
        if ($scope.PerWtCapacity == undefined || $scope.PerWtCapacity == "") {

            $scope.errMsg = "Permissible Capacity is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtPerWtCapacity").focus();
            return;
        }

        if ($scope.MaxWtCapacity == undefined || $scope.MaxWtCapacity == "") {

            $scope.errMsg = "Maximum Capacity is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtMaxWtCapacity").focus();
            return;
        }


        if ($scope.PolicyTypeId != 0 && $scope.PolicyTypeId != undefined) {
            if ($scope.Insurer == undefined || $scope.Insurer == "") {

                $scope.errMsg = "Insure is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtInsurer").focus();
                return;
            }
            if ($scope.PolicyNumber == undefined || $scope.PolicyNumber == "") {

                $scope.errMsg = "Policy No is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyNumber").focus();
                return;
            }
            if ($scope.PolicyEffectFrom == undefined || $scope.PolicyEffectFrom == "") {

                $scope.errMsg = "Policy Effect From is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyEffectFrom").focus();
                return;
            }

            if ($scope.PolicyEffectTo == undefined || $scope.PolicyEffectTo == "") {

                $scope.errMsg = "Policy Effect To is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtPolicyEffectTo").focus();
                return;
            }


            //if (new Date($scope.PolicyEffectTo) > new Date($scope.PolicyEffectFrom)) {
            //    
            if ($scope.PolicyEffectFrom != undefined && $scope.PolicyEffectTo != undefined) {
                var fDate = getDDMMYYYYHHMI($scope.PolicyEffectFrom);
                var tDate = getDDMMYYYYHHMI($scope.PolicyEffectTo);
                if (fDate > tDate) {
                    $scope.errMsg = "To Date should be greater than From Date";
                    $scope.isError = true;
                    ErrorPopupMsg('ErrorDiv');
                    $("#txtPolicyEffectFrom").focus();
                    return false;
                }
            }


            if ($scope.SumInsured == undefined || $scope.SumInsured == "" || $scope.SumInsured == "0") {

                $scope.errMsg = "Sum Insured is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtSumInsured").focus();
                return;
            }

        }

        if ($scope.OwnLease != undefined && $scope.OwnLease == "Lease") {
            if ($scope.LeaseFromWarehouse == undefined || $scope.LeaseFromWarehouse == "") {

                $scope.errMsg = "Lease From is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#lstLeaseFrom").focus();
                return;
            }
            if ($scope.LeaseAgreementRefNo == undefined || $scope.LeaseAgreementRefNo == "") {

                $scope.errMsg = "Lease Agreement RefNo is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtLeaseAgreementRefNo").focus();
                return;
            }
            if ($scope.LeasePeriod == undefined || $scope.LeasePeriod == "") {

                $scope.errMsg = "Lease Period is required";
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                $("#txtLeasePeriod").focus();
                return;
            }


        }

        //var fDate = getDDMMYYYYHHMI($scope.PolicyEffectFrom);
        //var tDate = getDDMMYYYYHHMI($scope.PolicyEffectTo);
        //if (fDate > tDate) {
        //     $scope.errMsg = " To Date should be greater than From Date";
        //    $scope.isError = true;
        //    return;
        //}


        //else {
        //    if ($scope.BlockCode.length > 2) {

        //        $scope.errMsg = "Block Code not More then two Charactors";
        //        $scope.isError = true;
        //        ErrorPopupMsg('ErrorDiv');
        //        $("#txtBlockCode").focus();
        //        return;
        //    }
        //    else {
        //        if ($scope.BlockCode.length < 2) {

        //            $scope.errMsg = "Block Code not Less then two Charactors";
        //            $scope.isError = true;
        //            ErrorPopupMsg('ErrorDiv');
        //            $("#txtBlockCode").focus();
        //            return;
        //        }
        //    }
        //}


        //if ($scope.RtToTmDistance == undefined || $scope.RtToTmDistance == "") {
        //    $scope.errMsg = "Distance from RT is required";
        //    $scope.isError = true;
        //    $("#txtRtToTmDistance").focus();
        //    return;
        //} 


        //if ( $scope.NoOfStacks == undefined) {
        //    $scope.errMsg = "Permitted No Of Stacks Negative is required.";
        //    $scope.isError = true;
        //    ErrorPopupMsg('ErrorDiv');
        //    $("#txtYardLength").focus();
        //    return;
        //}

        if ($scope.NoOfStacks < 0 || $scope.NoOfStacks == undefined) {
            // $scope.errMsg = "Permitted No Of Stacks Negative not allowed.";
            $scope.errMsg = "Permitted No Of Stacks Negative not allowed.";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardLength").focus();
            return;
        }
        if ($scope.YardLength == undefined || $scope.YardLength == "") {
            $scope.errMsg = "WH LENGTH is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardLength").focus();
            return;
        }

        if ($scope.YardWidth == undefined || $scope.YardWidth == "") {
            $scope.errMsg = "WH Width is required";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            $("#txtYardWidth").focus();
            return;
        }

        var arrLaneList = [];

        if ($scope.LaneList.length != 0) {
            for (var i = 0; i < $scope.LaneList.length; i++) {
                if ($scope.LaneList[i].LaneCode != undefined) {
                    var pLists = {
                        BlockId: $scope.BlockId,
                        LaneId: $scope.LaneList[i].LaneId,
                        LaneCode: $scope.LaneList[i].LaneCode
                    }
                    arrLaneList.push(pLists);
                }
            }
        }

        var arrColumnList = [];

        if ($scope.ColumnList.length != 0) {
            for (var i = 0; i < $scope.ColumnList.length; i++) {
                if ($scope.ColumnList[i].ColumnCode != undefined) {
                    var pPriSec;
                    if (i == 0) {
                        pPriSec = 'P';
                    } else if (i % 2 == 0) {
                        pPriSec = 'P';
                    } else {
                        pPriSec = 'S';
                    }
                    var pLists = {
                        BlockId: $scope.BlockId,
                        ColumnId: $scope.ColumnList[i].ColumnId,
                        ColumnCode: $scope.ColumnList[i].ColumnCode,
                        PriSec: pPriSec
                    }
                    arrColumnList.push(pLists);
                }
            }
        }

        var BlockMaster = {
            BlockId: $scope.BlockId,
            LocationId: $sessionStorage.locationId,
            DepotId: $scope.DepotId,
            BlockCode: $scope.BlockCode,
            RtToTmDistance: $scope.RtToTmDistance,
            YardLength: $scope.YardLength,
            YardWidth: $scope.YardWidth,
            NoOfStacks: $scope.NoOfStacks,
            PerWtCapacity: $scope.PerWtCapacity,
            SpecialReserve: $scope.SpecialReserve,
            MaxWtCapacity: $scope.MaxWtCapacity,
            Remarks: $scope.Remarks,
            PerTransTime: $scope.PerTransTime,
            NoOfPlugReefer: $scope.NoOfPlugReefer,
            NoofLanes: $scope.nooflanes,
            NoofColumns: $scope.noofcolumns,
            BlockLaneMasterList: arrLaneList,
            BlockColumnMasterList: arrColumnList,
            WareHouseTypeId: $scope.WareHouseTypeId,
            CommodityType: $scope.COMMODITY,
            OwnLease: $scope.OwnLease,
            LeaseFrom: $scope.LeaseFromWarehouse,
            LeaseAgreeRefNo: $scope.LeaseAgreementRefNo,
            LeasePeriod: $scope.LeasePeriod,
            PolicyTypeId: $scope.PolicyTypeId,
            Insurer: $scope.Insurer,
            PolicyNumber: $scope.PolicyNumber,
            SumInsured: $scope.SumInsured,
            PolicyEffectFrom: $scope.PolicyEffectFrom,
            PolicyEffectTo: $scope.PolicyEffectTo,
            RackBinType: $scope.RackBinType,
            VecticalTypeId: $scope.VecticalTypeId,
            WarehouseAddress: $scope.WarehouseAddress,
            ContactPerson: $scope.ContactPerson,
            ContactNo: $scope.ContactNo,
            WarehouseName: $scope.WarehouseName,
            StateId: $scope.StateId
        };

        $scope.ShowLoader = true;
        var saveData = WhDefnAJService.saveYardData(BlockMaster);
        saveData.then(function (pBlockMaster) {
            $scope.ShowLoader = false;
            if (pBlockMaster.data.ErrorMessage != null && pBlockMaster.data.ErrorMessage != "") {
                $scope.errMsg = pBlockMaster.data.ErrorMessage;
                $scope.isError = true;
                ErrorPopupMsg('ErrorDiv');
                return;
            }
            else {
                $scope.isShown = true;

                $scope.errMsg = "";
                $scope.isError = false;
                $scope.errMsg1 = "Data Saved Successfully";
                ErrorPopupMsg('ErrorDivG');
                $scope.BlockId = pBlockMaster.data.BlockId;
                //$scope.TerminalList = [];
                clearYardList();
                YardListAll();
                $scope.isShownLease = true;
                $scope.isShownPoliceType = true;
            }
        }, function () {
            //clearFields();
            $scope.errMsg = "Error in saving Yard Defination";
            $scope.isError = true;
            ErrorPopupMsg('ErrorDiv');
            return;
        });
    }


    $scope.filter = function () {
        var elem = document.getElementById('trview');
        //var elem = angular.element(document.querySelector('#LpTerminal'));
        for (var i = 0; i < elem.children.length; i++) {
            var name = elem.children[i].children[0].innerHTML;
            if (name.indexOf($scope.SrchCtrl) != -1 || $scope.SrchCtrl == "") {
                elem.children[i].style.display = "block";
            } else {
                elem.children[i].style.display = "none";
            }
        }
    }


    //$scope.filter = function () {
    //    
    //    var filteredList = [];
    //    var filteredYardBlockList;
    //    
    //    if ($scope.SrchCtrl != "" && $scope.SrchCtrl != undefined) {
    //        if ($scope.YardList.length > 0) {
    //            for (var i = 0; i < $scope.YardList.length; i++) {
    //                filteredYardBlockList = $filter('filter')($scope.YardList[i].YardBlocks, { BlockCode: $scope.SrchCtrl });

    //                if (filteredYardBlockList.length != undefined && filteredYardBlockList.length != 0) {
    //                    //filteredList = $scope.YardList[i];

    //                    filteredList.push($scope.YardList[i]);
    //                }
    //            }

    //            if (filteredList != undefined && filteredList.length != 0) {
    //                //$scope.YardList.push(filteredList);
    //                $scope.YardList = filteredList;
    //            }
    //        }

    //    }
    //    else {
    //        $scope.YardList = $scope.tempYardList;
    //    }
    //}

    //====================================================Watch for first page load=====================================================================//
    var watchList = $scope.$watch('YardList', function () {
        if ($scope.YardList != undefined) {
            for (var i = 0; i < $scope.YardList.length; i++) {
                if ($scope.YardList[i].YardBlocks.length != undefined && $scope.YardList[i].YardBlocks.length > 0) {
                    $scope.BlockId = $scope.YardList[i].YardBlocks[0].BlockId;
                    break;
                }
            }
            showFirst($scope.BlockId);
            watchList();
        }
    });
    //====================================================End of Watch for first page load==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewLane = function () {
        var newItem = { LaneCode: "", LaneId: 0 }

        $scope.LaneList.push(newItem);
    }

    //====================================================End of new lane addition==============================================================//

    //====================================================start of new lane addition==============================================================//
    $scope.AddNewColumn = function () {
        var newItem = { ColumnCode: "", ColumnId: 0 }

        $scope.ColumnList.push(newItem);
    }
    //====================================================End of new lane addition==============================================================//

    $scope.updYardStatus = function (cList, lList) {
        var YardBlockLaneColumnSts = {
            BlockId: $scope.BlockId,
            LaneId: lList.LaneId,
            ColumnId: cList.ColumnId
        };

        //Updation to db is pending. discussion required


        //var UpdData = WhDefnAJService.updateYardStatus(YardBlockLaneColumnSts);
        //UpdData.then(function (pYardBlockLaneColumnSts) {

        //if (pYardBlockLaneColumnSts.data.ErrorMessage != null && pYardBlockLaneColumnSts.data.ErrorMessage != "") {
        //    $scope.errMsg = pYardBlockLaneColumnSts.data.ErrorMessage;
        //        $scope.isError = true;
        //        return;
        //    }
        //    else {
        //        $scope.errMsg = "";
        //        $scope.isError = false;
        //    }
        //}, function () {
        //    $scope.errMsg = "Error in updating Yard Status";
        //    $scope.isError = true;
        //    return;
        //});
    }

    $scope.LaneDataChange = function () {
        debugger
        if (($scope.nooflanes == undefined) || ($scope.nooflanes == 0)) {
            $scope.LaneList = [];
            return
        }
        $scope.LaneList = [];
        var AscChar = 65;
        for (i = 0; i < $scope.nooflanes; i++) {
            var InputParam = {
                LaneCode: String.fromCharCode(AscChar + i),
                LaneId: 0
            }
            $scope.LaneList.push(InputParam);
        }
    }

    $scope.ColumnDataChange = function () {
        if (($scope.noofcolumns == undefined) || ($scope.noofcolumns == 0)) {
            $scope.ColumnList = [];
            return
        }
        $scope.ColumnList = [];
        var ColSeq = 0
        for (i = 0; i < $scope.noofcolumns; i++) {
            var InputParam = {
                ColumnCode: padToFour(ColSeq + 1),
                ColumnId: 0
            }
            ColSeq = ColSeq + 1;
            $scope.ColumnList.push(InputParam);
        }
    }


    function padToFour(number) {
        if (number <= 999) { number = ("00" + number).slice(-2); }
        return number;
    }

    function ErrorPopupMsg(ID) {
        $('#' + ID).fadeIn('slow').addClass('alertShowMsg');
        setTimeout(function () {
            $('#' + ID).fadeOut('slow').removeClass('alertShowMsg');
        }, 2000);

        $('#iconClose').click(function () {
            $('#' + ID).fadeOut('fast').removeClass('alertShowMsg');
        });
    }

    //function GetCommodity() {
    //    var getData = WhDefnAJService.CommodityList('');
    //    getData.then(function (result) {
    //        $scope.CmdtCode = $.parseJSON(result.data);
    //    });
    //}

    function StateLookupList() {
        var GetData = WhDefnAJService.GetStateLookupList();
        GetData.then(function (Response) {
            $scope.StateLookupList = Response.data;
        });
    }

    $scope.OnCapacityChange = function (pType) {

        if ($scope.PerWtCapacity >= 0 && $scope.MaxWtCapacity >= 0) {
            if (pType == 'Permissible') {
                if ($scope.PerWtCapacity > $scope.MaxWtCapacity) {
                    $scope.errMsg = "Permissible Capacity should bre less than Maximum Capacity.";
                    $scope.isError = true;

                    ErrorPopupMsg('ErrorDiv');
                    $scope.PerWtCapacity = 0;
                    setTimeout(function () {

                        $("#txtPermissibleCapacity").focus();
                    }, 1000);
                    return;
                }
            }
            if (pType == 'Maximum') {
                if ($scope.PerWtCapacity > $scope.MaxWtCapacity) {
                    $scope.errMsg = "Maximum Capacity should be greater than Permissible Capacity.";
                    $scope.isError = true;
                    ErrorPopupMsg('ErrorDiv');
                    $scope.MaxWtCapacity = 0;
                    setTimeout(function () {
                        $("#txtMaximumCapacity").focus();
                    }, 1000);
                    return;
                }
            }

        }
    }

    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setDate(objDateParts[0]);
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }
});

