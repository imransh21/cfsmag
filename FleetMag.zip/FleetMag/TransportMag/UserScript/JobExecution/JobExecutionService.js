﻿app.service("JobExecutionAJService", function ($http) {
    //if (!window.location.origin) { // Some browsers (mainly IE) does not have this property, so we need to build it manually...
    //    window.location.origin = window.location.protocol + '//' + window.location.hostname + (window.location.port ? (':' + window.location.port) : '');
    //}
    //var baseUrl = window.location.origin;

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.saveData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JOBExecution/SavaDetails",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.GetTruckData = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JOBExecution/GetTruckData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }

    this.GetALLJobExecution = function (iList) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JOBExecution/GetBookingJobLookup",
            data: JSON.stringify(iList),
            dataType: "json"
        });
        return response;
    }

    this.SaveJobExecuteAcceptUpdate = function (JobExecute) {
        var response = $http({
            method: "post",
            url: baseUrl + "/Transport/JOBExecution/SaveJobExecuteAccept",
            data: JSON.stringify(JobExecute),
            dataType: "json"
        });
        return response;
    }

})