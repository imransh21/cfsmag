﻿app.controller("cntrlJobExecution", function ($scope, $rootScope, $sessionStorage, $filter, ErrorMsgDisplay, $compile, $timeout, BookingAJService, JobExecutionAJService, IndentGenAJService) {
    $scope.isShown = true;
    $scope.isShown1 = true;
    $scope.isShown2 = true;
    $scope.isShownSearch = true;
    $scope.isShownAdd = true;
    $scope.isShownSave = false;
    $scope.isShownClear = false;
    $scope.isShownEdit = false;
    $scope.BookingJobTruckList = [];
    DepoLookupList();
    $scope.FilterJobStatus = 'P';
    Addrow();

    //$scope.addNewItem;

    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

              
    $scope.addNewItem = function () {
        Addrow();
    }

    $scope.ExitDtls = function () {
        
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Transportation";
    }

    $scope.DisplayDtls = function () {
        GetJobAllocationList();
    }

    function Addrow() {
        var InputParam = {
            Pkey: 0,
            JobId: 0,
            VehicleId: 0,
            TruckType: "",
            TruckTypeId: 0,
            FromDate: "",
            ToDate: "",
            NoOfContainer: "",
            Size: "",
            PickupLocation: "",
            DropupLocation: "",
            DriverName: "",
            DriverId: 0
        }
        $scope.BookingJobTruckList.push(InputParam);
    }

    function GridAutoComplete() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $(".txtVehicleNo").autocomplete({

            source: function (request, response) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                var InputParam = {
                    VehicleNo: request.term,
                    DepotId: $scope.DepotId,
                    LocationId: $sessionStorage.locationId

                }
                $.ajax({
                    url: baseUrl + '/Transport/VehicleMaster/GetVehicleDepotWiseLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                               
                                label: item.VehicleNo,
                                VehicleId: item.VehicleId,
                                TruckTypeId: item.TruckType,
                                TruckTypeName: item.TruckTypeName
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var Indexval = e.target.parentNode.parentNode.id;
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.BookingJobTruckList[Indexval].VehicleNo = i.item.label;
                    $scope.BookingJobTruckList[Indexval].VehicleId = i.item.VehicleId;
                    $scope.BookingJobTruckList[Indexval].TruckTypeId = i.item.TruckTypeId;
                    $scope.BookingJobTruckList[Indexval].TruckType = i.item.TruckTypeName;
                    $scope.BookingJobTruckList[Indexval].Size = $scope.seletedJob.Size;
                    
                });
            },
            minLength: 1
        });

    }

    $scope.InitAutoComplete = function () {
        GridAutoComplete();
    }




    function GetJobAllocationList() {

        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        var iList = {
            JobNo: $scope.FilterJobNo == "" ? undefined : $scope.FilterJobNo,
            DepotId: $scope.DepotId,
            JobStatus: $scope.FilterJobStatus == "" ? undefined : $scope.FilterJobStatus //          WisStatus: $scope.FilterJobStatus == undefined ? "P" : $scope.FilterJobStatus, // 
        };
        
        var JobExecution = JobExecutionAJService.GetALLJobExecution(iList);
        JobExecution.then(function (result) {
            $scope.isShown = true;
            
            $scope.pndJobAllocationlst = $.parseJSON($.parseJSON(result.data)).Table;
            if ($scope.RowIndex != undefined) {
                $scope.seletedJob = $scope.pndJobAllocationlst[$scope.RowIndex];
            }
            $scope.filteredItems = $filter('orderBy')($scope.pndJobAllocationlst, $scope.sortingOrder, $scope.reverse);
            //groupToPages();
        });
    }


    $scope.getClickJobDetails = function (row, indx) {
        
        $scope.seletedJob = row;
        $scope.RowIndex = indx;
        $('#targer' + indx).attr('data-target', "#Tr" + indx);
        $('#targer' + indx).toggleClass('fa-minus');
        SerachTruckDetails(row.JobId);
        //creselectedwis(row.CrewId, row, indx);
        $scope.isShown2 = false;

    }

    function SerachTruckDetails(JobId) {
        var InputParam = {
            JobId: JobId
        }
        
        var GetData = JobExecutionAJService.GetTruckData(InputParam);
        GetData.then(function (Response) {
            
            $scope.BookingJobTruckList = Response.data;
            if ($scope.BookingJobTruckList.length == 0) {
                Addrow();
            }
        });
    }


    $scope.AcceptJobDetails = function (selectedJob) {

        if (selectedJob.JobAcceptDate == "" || selectedJob.JobAcceptDate == undefined || selectedJob.JobAcceptDate == null) {
            $scope.errMsg = "Please Select JOB Accepted Date"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if (selectedJob.TripScheduleDate == "" || selectedJob.TripScheduleDate == undefined || selectedJob.TripScheduleDate == null) {
            $scope.errMsg = "Please Select Trip Schedule Date"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        var InputParam = {
            JobId: selectedJob.JobId,
            BookingId: selectedJob.BookingId,
            TripScheduleDate: selectedJob.TripScheduleDate,
            JobAcceptDate: selectedJob.JobAcceptDate,
            JobStatus: 'A'
        }
        var GetData = JobExecutionAJService.SaveJobExecuteAcceptUpdate(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {

                $scope.isShown2 = true;
                $scope.seletedJob.JobStatus = "Accepted";

                $scope.errMsg = 'Job Accepted'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });

    }


    $scope.RejectJobDetails = function (selectedJob) {

        if (selectedJob.JobAcceptDate != "" && selectedJob.JobAcceptDate != undefined && selectedJob.JobAcceptDate != null) {
            $scope.errMsg = "JOB Accepted Date is Updated"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if (selectedJob.TripScheduleDate != "" && selectedJob.TripScheduleDate != undefined && selectedJob.TripScheduleDate != null) {
            $scope.errMsg = "Trip Schedule Date is Updated"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        var InputParam = {
            JobId: selectedJob.JobId,
            BookingId: selectedJob.BookingId,
            TripScheduleDate: selectedJob.TripScheduleDate,
            JobAcceptDate: selectedJob.JobAcceptDate,
            JobStatus: 'R'
        }
        var GetData = JobExecutionAJService.SaveJobExecuteAcceptUpdate(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {

                $scope.isShown2 = true;
                $scope.seletedJob.JobStatus = "Rejected";
                $scope.errMsg = 'Job Rejected'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });

    }


       
    $scope.UpdateVehicleDetails = function (selectedJob) {
        
        var ErrorFound = false;
        var ItemCount = 0;
        var NoOfContCount = 0;
        
        if ($scope.BookingJobTruckList.length != null || $scope.BookingJobTruckList.length != undefined) {
            for (i = 0; i < $scope.BookingJobTruckList.length; i++) {



                if ($scope.BookingJobTruckList[i].VehicleNo != "" && $scope.BookingJobTruckList[i].VehicleNo != undefined && $scope.BookingJobTruckList[i].VehicleNo != null) {
                    if (ErrorFound == false) {
                        ItemCount = ItemCount + 1;

                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].FromDate == "" || $scope.BookingJobTruckList[i].FromDate == undefined || $scope.BookingJobTruckList[i].FromDate == null) {
                                $scope.errMsg = "Please Select From Date"
                                ErrorFound = true;
                            }
                        }

                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].ToDate == "" || $scope.BookingJobTruckList[i].ToDate == undefined || $scope.BookingJobTruckList[i].ToDate == null) {
                                $scope.errMsg = "Please Enter To Date"
                                ErrorFound = true;
                            }
                        }

                        var fDate = getDDMMYYYYHHMI($scope.BookingJobTruckList[i].FromDate);
                        var tDate = getDDMMYYYYHHMI($scope.BookingJobTruckList[i].ToDate);

                        if (fDate > tDate) {
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.errMsg = " To Date Date should be greater than From Date";
                            $scope.isError = true;
                            //  alert($scope.errMsg);
                            //  $("#txtEffectTo").focus();
                            return;
                        }


                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].NoOfContainer == "" || $scope.BookingJobTruckList[i].NoOfContainer == undefined || $scope.BookingJobTruckList[i].NoOfContainer == null) {
                                $scope.errMsg = "Please Select No Of Container"
                                ErrorFound = true;
                            }
                        }

                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].PickupLocation == "" || $scope.BookingJobTruckList[i].PickupLocation == undefined || $scope.BookingJobTruckList[i].PickupLocation == null) {
                                $scope.errMsg = "Please Select Pickup Location"
                                ErrorFound = true;
                            }
                        }

                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].DropupLocation == "" || $scope.BookingJobTruckList[i].DropupLocation == undefined || $scope.BookingJobTruckList[i].DropupLocation == null) {
                                $scope.errMsg = "Please Enter Dropup Location"
                                ErrorFound = true;
                            }
                        }

                        if (ErrorFound == false) {
                            if ($scope.BookingJobTruckList[i].DriverName == "" || $scope.BookingJobTruckList[i].DriverName == undefined || $scope.BookingJobTruckList[i].DriverName == null) {
                                $scope.errMsg = "Please Enter Driver Name"
                                ErrorFound = true;
                            }
                        }

                        NoOfContCount = parseInt(NoOfContCount) + parseInt($scope.BookingJobTruckList[i].NoOfContainer);


                    }
                }



                for (j = i + 1 ; j < $scope.BookingJobTruckList.length; j++) {
                    if ($scope.BookingJobTruckList[i].VehicleId == ($scope.BookingJobTruckList[j].VehicleId)) {
                        // got the duplicate element
                        if ($scope.BookingJobTruckList[i].VehicleId != "") {
                            $scope.errMsg = "Vehicle No " + $scope.BookingJobTruckList[i].VehicleNo + " is duplicate.";
                            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                            $scope.isError = true;
                            return;
                        }
                    }
                }


            }
        }


        

        if (ItemCount == 0) {
            $scope.errMsg = "No Truck to Save"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if (NoOfContCount != selectedJob.NoOfCont) {
            $scope.errMsg = "No Of Cont Mismatched"
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        
        var InputParam = {
            JobId: selectedJob.JobId,
            //BookingId: $scope.BookingId,
            //TripScheduleDate: $scope.TripScheduleDate,
            //JobAcceptDate: $scope.JobAcceptDate,
            BookingJobTruckDtlList: $scope.BookingJobTruckList
        }
        var GetData = JobExecutionAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage == "") {
                $scope.seletedJob.JobStatus = "Completed";
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
            else {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            }
        });

    }


    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        newObj.setDate(objDateParts[0]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }


    //$scope.AddDtls = function () {
    //    clearData();
    //    $scope.isShown1 = false;

    //    var getUrl = window.location;
    //    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    //    $("#txtJobNo").autocomplete({

    //        source: function (request, response) {
    //            var $scope = angular.element(document.getElementById('bigform')).scope();

    //            var InputParam = {
    //                JobNo: $("#txtJobNo").val()
    //            }
    //            $.ajax({
    //                url: baseUrl + '/Transport/JOBExecution/GetBookingJobLookup',
    //                data: JSON.stringify(InputParam),
    //                dataType: "json",
    //                type: "POST",
    //                contentType: "application/json; charset=utf-8",
    //                success: function (data) {
    //                    //response($.map(data, function (item, key) {
    //                    response($.map($.parseJSON(data).Table, function (item, key) {
    //                        return {
    //                            label: item.JobNo,
    //                            JobId: item.JobId,
    //                            JobDate: item.JobDate,
    //                            BookingNo: item.BookingNo,
    //                            BookingId: item.BookingId,
    //                            DepotId: item.DepotId,
    //                            BookingDate: item.BookingDate,
    //                            FromLocation: item.FromLocation,
    //                            ToLocation: item.ToLocation,
    //                            NoOfCont: item.NoOfCont,
    //                            Size: item.Size,
    //                            PickupFrom: item.PickupFrom,
    //                            DropTo: item.DropTo,
    //                            MovementType: item.MovementType,
    //                            AccountManager: item.AccountManager,
    //                            JobAcceptDate: item.JobAcceptDate,
    //                            TripScheduleDate: item.TripScheduleDate
    //                        }
    //                    }))
    //                },
    //                error: function (response) {
    //                    //alert(response.responseText);
    //                },
    //                failure: function (response) {
    //                    //alert(response.responseText);
    //                }
    //            });
    //        },
    //        select: function (e, i) {
    //            var $scope = angular.element(document.getElementById('bigform')).scope();
    //            $scope.$apply(function () {
    //                
    //                $scope.JobNo = i.item.label;
    //                $scope.JobId = i.item.JobId;
    //                $scope.JobDate = i.item.JobDate;
    //                $scope.BookingNo = i.item.BookingNo;
    //                $scope.BookingId= i.item.BookingId;
    //                $scope.DepotId= i.item.DepotId;
    //                $scope.BookingDate = i.item.BookingDate;
    //                $scope.FromLocation = i.item.FromLocation;
    //                $scope.ToLocation = i.item.ToLocation;
    //                $scope.NoOfCont = i.item.NoOfCont;
    //                $scope.Size = i.item.Size;
    //                $scope.PickupFrom = i.item.PickupFrom;
    //                $scope.DropTo = i.item.DropTo;
    //                $scope.MovementType = i.item.MovementType;
    //                $scope.AccountManager = i.item.AccountManager;
    //                $scope.JobAcceptDate = i.item.JobAcceptDate;
    //                $scope.TripScheduleDate = i.item.TripScheduleDate;
    //                //$scope.BookingJobTruckList = [];

    //                $scope.isShown1 = true;
    //                $scope.isShownAdd = false;
    //                $scope.isShownSave = true;
    //                $scope.isShownClear = true;
    //                $scope.isShownSearch = false;
    //                $scope.isShown2 = false;

    //            });
    //        },
    //        minLength: 1
    //    });
    //}

    //function clearData() {
    //    $scope.JobAcceptDate = undefined;
    //    $scope.TripScheduleDate = undefined;
    //    $scope.JobNo = undefined;
    //    $scope.JobId = undefined;
    //    $scope.JobDate = undefined;
    //    $scope.BookingNo = undefined;
    //    $scope.BookingId = undefined;
    //    $scope.DepotId = undefined;
    //    $scope.BookingDate = undefined;
    //    $scope.FromLocation = undefined;
    //    $scope.ToLocation = undefined;
    //    $scope.NoOfCont = undefined;
    //    $scope.Size = undefined;
    //    $scope.PickupFrom = undefined;
    //    $scope.DropTo = undefined;
    //    $scope.MovementType = undefined;
    //    $scope.AccountManager = undefined;
    //    $scope.JobAcceptDate = undefined;
    //    $scope.TripScheduleDate = undefined;
    //    $scope.BookingJobTruckList = [];
    //    Addrow();
    //}



    //$scope.CancelDtls = function () {
    //    clearData();
    //    $scope.isShown = true;
    //    $scope.isShown1 = true;
    //    $scope.isShown2 = true;
    //    $scope.isShownSearch = true;
    //    $scope.isShownAdd = true;
    //    $scope.isShownSave = false;
    //    $scope.isShownClear = false;
    //    $scope.isShownEdit = false;
    //}



    //$scope.SaveDtls = function () {


    //    if ($scope.JobAcceptDate == "" || $scope.JobAcceptDate == undefined || $scope.JobAcceptDate == null) {
    //        $scope.errMsg = "Please Select JOB Accepted Date"
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }

    //    if ($scope.TripScheduleDate == "" || $scope.TripScheduleDate == undefined || $scope.TripScheduleDate == null) {
    //        $scope.errMsg = "Please Select Trip Schedule Date"
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }


    //    var ErrorFound = false;
    //    var ItemCount = 0;
    //    var NoOfContCount = 0;
    //    angular.forEach($scope.BookingJobTruckList, function (value, key) {
    //        if (value.VehicleNo != "" && value.VehicleNo != undefined && value.VehicleNo != null) {
    //            if (ErrorFound == false) {
    //                ItemCount = ItemCount + 1;

    //                if (ErrorFound == false) {
    //                    if (value.FromDate == "" || value.FromDate == undefined || value.FromDate == null) {
    //                        $scope.errMsg = "Please Select From Date"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                if (ErrorFound == false) {
    //                    if (value.ToDate == "" || value.ToDate == undefined || value.ToDate == null) {
    //                        $scope.errMsg = "Please Enter To Date"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                if (ErrorFound == false) {
    //                    if (value.NoOfContainer == "" || value.NoOfContainer == undefined || value.NoOfContainer == null) {
    //                        $scope.errMsg = "Please Select No Of Container"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                if (ErrorFound == false) {
    //                    if (value.PickupLocation == "" || value.PickupLocation == undefined || value.PickupLocation == null) {
    //                        $scope.errMsg = "Please Select Pickup Location"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                if (ErrorFound == false) {
    //                    if (value.DropupLocation == "" || value.DropupLocation == undefined || value.DropupLocation == null) {
    //                        $scope.errMsg = "Please Enter Dropup Location"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                if (ErrorFound == false) {
    //                    if (value.DriverName == "" || value.DriverName == undefined || value.DriverName == null) {
    //                        $scope.errMsg = "Please Enter Driver Name"
    //                        ErrorFound = true;
    //                    }
    //                }

    //                NoOfContCount = parseInt(NoOfContCount) +  parseInt(value.NoOfContainer);


    //            }
    //        }
    //    });

    //    if ($scope.BookingJobTruckList.length != null || $scope.BookingJobTruckList.length != undefined) {
    //        for (i = 0; i < $scope.BookingJobTruckList.length; i++) {
    //            for (j = i + 1 ; j < $scope.BookingJobTruckList.length; j++) {
    //                if ($scope.BookingJobTruckList[i].VehicleId == ($scope.BookingJobTruckList[j].VehicleId)) {
    //                    // got the duplicate element
    //                    if ($scope.BookingJobTruckList[i].VehicleId != "") {
    //                        $scope.errMsg = "Vehicle No " + $scope.BookingJobTruckList[i].VehicleNo + " is duplicate.";
    //                        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //                        $scope.isError = true;
    //                        return;
    //                    }
    //                }
    //            }
    //        }
    //    }



    //    if (ItemCount == 0) {
    //        $scope.errMsg = "No Truck to Save"
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }

    //    if (NoOfContCount != $scope.NoOfCont) {
    //        $scope.errMsg = "No Of Cont Mismatched"
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }

    //    if (ErrorFound == true) {
    //        ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        return;
    //    }

    //    
    //    var InputParam = {
    //        JobId: $scope.JobId,
    //        BookingId: $scope.BookingId,
    //        TripScheduleDate: $scope.TripScheduleDate,
    //        JobAcceptDate: $scope.JobAcceptDate,
    //        BookingJobTruckDtlList: $scope.BookingJobTruckList
    //    }
    //    var GetData = JobExecutionAJService.saveData(InputParam);
    //    GetData.then(function (Response) {
    //        if (Response.data.ErrorMessage == "") {
    //            //$scope.BookingJobTruckList = Response.data.IndentDtlsList;
    //            $scope.isShown = true;
    //            $scope.isShown1 = true;
    //            $scope.isShown2 = true;
    //            $scope.isShownSearch = true;
    //            $scope.isShownAdd = true;
    //            $scope.isShownSave = false;
    //            $scope.isShownClear = false;
    //            $scope.isShownEdit = false;

    //            $scope.errMsg = 'Data Saved'
    //            ErrorMsgDisplay.ErrorMsg('ErrorDivG');
    //        }
    //        else {
    //            $scope.errMsg = Response.data.ErrorMessage;
    //            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
    //        }
    //    });

    //}




    //$scope.SearchDtls = function () {
    //    clearData();
    //    $scope.isShown1 = false;

    //    var getUrl = window.location;
    //    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    //    $("#txtJobNo").autocomplete({

    //        source: function (request, response) {
    //            var $scope = angular.element(document.getElementById('bigform')).scope();

    //            var InputParam = {
    //                JobNo: $("#txtJobNo").val()
    //            }
    //            $.ajax({
    //                url: baseUrl + '/Transport/JOBExecution/GetBookingJobSearchLookup',
    //                data: JSON.stringify(InputParam),
    //                dataType: "json",
    //                type: "POST",
    //                contentType: "application/json; charset=utf-8",
    //                success: function (data) {
    //                    //response($.map(data, function (item, key) {
    //                    response($.map($.parseJSON(data).Table, function (item, key) {
    //                        return {
    //                            label: item.JobNo,
    //                            JobId: item.JobId,
    //                            JobDate: item.JobDate,
    //                            BookingNo: item.BookingNo,
    //                            BookingId: item.BookingId,
    //                            DepotId: item.DepotId,
    //                            BookingDate: item.BookingDate,
    //                            FromLocation: item.FromLocation,
    //                            ToLocation: item.ToLocation,
    //                            NoOfCont: item.NoOfCont,
    //                            Size: item.Size,
    //                            PickupFrom: item.PickupFrom,
    //                            DropTo: item.DropTo,
    //                            MovementType: item.MovementType,
    //                            AccountManager: item.AccountManager,
    //                            JobAcceptDate: item.JobAcceptDate,
    //                            TripScheduleDate: item.TripScheduleDate
    //                        }
    //                    }))
    //                },
    //                error: function (response) {
    //                    //alert(response.responseText);
    //                },
    //                failure: function (response) {
    //                    //alert(response.responseText);
    //                }
    //            });
    //        },
    //        select: function (e, i) {
    //            var $scope = angular.element(document.getElementById('bigform')).scope();
    //            $scope.$apply(function () {
    //                
    //                $scope.JobNo = i.item.label;
    //                $scope.JobId = i.item.JobId;
    //                $scope.JobDate = i.item.JobDate;
    //                $scope.BookingNo = i.item.BookingNo;
    //                $scope.BookingId = i.item.BookingId;
    //                $scope.DepotId = i.item.DepotId;
    //                $scope.BookingDate = i.item.BookingDate;
    //                $scope.FromLocation = i.item.FromLocation;
    //                $scope.ToLocation = i.item.ToLocation;
    //                $scope.NoOfCont = i.item.NoOfCont;
    //                $scope.Size = i.item.Size;
    //                $scope.PickupFrom = i.item.PickupFrom;
    //                $scope.DropTo = i.item.DropTo;
    //                $scope.MovementType = i.item.MovementType;
    //                $scope.AccountManager = i.item.AccountManager;
    //                $scope.JobAcceptDate = i.item.JobAcceptDate;
    //                $scope.TripScheduleDate = i.item.TripScheduleDate;
    //                $scope.BookingJobTruckList = [];
    //                SerachTruckDetails()

    //                $scope.isShown = true;
    //                $scope.isShown1 = true;
    //                $scope.isShown2 = true;
    //                $scope.isShownSearch = true;
    //                $scope.isShownAdd = true;
    //                $scope.isShownSave = false;
    //                $scope.isShownClear = false;
    //                $scope.isShownEdit = false;

    //            });
    //        },
    //        minLength: 1
    //    });
    //}


});

