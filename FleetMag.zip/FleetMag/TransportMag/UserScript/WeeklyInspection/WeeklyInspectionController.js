﻿app.controller("WeeklyInspectionCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, WeeklyInspectionCtrlAJService, JobAllocationAJService, VehicleAJService, IndentGenAJService, ServiceSecheduleAJService, ErrorMsgDisplay) {
    
    $scope.isShownAdd = true;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownClear = false;
    $scope.isInWrdTrans = true;
    $scope.isShownVehicle = true;
    $scope.isShownDepot = true;
    $scope.isShownCheckType = true;
    $scope.isShown = true;
    $scope.isShownPattern = true;

    DailyWeeklyCheck();
    //DailyWeeklyListDtls($scope.Pkey1);
    DepoLookupList();
    ServiceTypeList();

    $("#JobCardDiv").hide();


    $scope.CloseJobCardDiv = function() {
        
        $.confirm({
            title: 'Close!',
            content: 'Do you wand to Close!',
            buttons: {
                confirm: function () {
                    $("#JobCardDiv").hide();
                },
                cancel: function () {
                    $("#JobCardDiv").show();
                }
            }
        });
        
    }

    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    function ServiceTypeList() {
        var GetData = ServiceSecheduleAJService.GetServSchedulelist();
        GetData.then(function (Response) {
            
            $scope.ServiceTypeList = Response.data;
        });
    }


    $scope.DepotFilterWeeklylistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            VehicleNo: $scope.FilterVehicleNo,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleAJService.GetVehicleMasterWeeklyListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.RequiredJobCardLst = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.DepotFilterMonthlylistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            VehicleNo: $scope.FilterVehicleNo,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleAJService.GetVehicleMasterMonthlyListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.RequiredJobCardLst = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }


    $scope.DepotFilterDailylistChange = function () {
        
        var InputParm = {
            DepotId: $scope.FilterDepotId,
            VehicleNo: $scope.FilterVehicleNo,
            LocationId: $sessionStorage.locationId
        }
        var GetData = VehicleAJService.GetVehicleMasterDailyListByDepot(InputParm);
        GetData.then(function (Response) {
            $scope.RequiredJobCardLst = $.parseJSON($.parseJSON(Response.data)).Table;
        });
    }

    $scope.CancelDtls = function () {
        ClearData();
        $scope.errMsg = "";
        $scope.isError = false;
        $scope.isShown = true;
    }

    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }

    function padToFour(number) {
        if (number <= 99) { number = ("00" + number).slice(-2); }
        return number;
    }

    function ClearData() {
        
        $scope.isShownAdd = true;
        $scope.isShownSave = false;
        $scope.isShownSearch = true;
        $scope.isShownClear = false;
        $scope.isInWrdTrans = true;
        $scope.isShownVehicle = true;
        $scope.isShownDepot = true;
        $scope.isShownCheckType = true;
        $scope.isShown = true;
        $scope.isShownPattern = true;
        
        $scope.InspId = undefined;
        $scope.VehicleId = undefined;
        $scope.VehicleNo = undefined;
        $scope.EquipmentType = undefined;
        $scope.TruckType1 = undefined;
        $scope.CodeValue = undefined;
        $scope.LastInspectionDate = undefined;
        $scope.LatestMeterReading = undefined;
        $scope.DailyWeeklycheckList = undefined;
        $scope.InspDate = undefined;
        $scope.LastMeterReading = undefined;
        $scope.InspTransNbr = undefined;
        $scope.InspDate = undefined;
        $scope.DepotId = undefined;
        DailyWeeklyCheck();
        ServiceTypeList();
        //$scope.Pkey = 102;
        //DailyWeeklyListDtls($scope.Pkey1);

        $scope.Pkey = $scope.Pkey1

        $scope.ExpBeginDate = undefined;
        $scope.ExpCompDate = undefined;
        $scope.ScheduleId = undefined;

        $scope.errMsg = undefined;

    }

    $scope.AddDtls = function () {
        ClearData();
        $scope.isShownAdd = false;
        $scope.isShownVehicle = false;
        $scope.isShownDepot = false;
        $scope.isShown = false;
        $scope.isShownPattern = false;
        $scope.isInWrdTrans = true;
        $scope.isShownSave = true;
        $scope.isShownPattern = false;
        $scope.isShownCheckType = false
        $scope.isShownClear = true;
        $scope.isShownSearch = false;

        $("#divQlist").modal('show');

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

        $("#txtVehicleNo").autocomplete({
            source: function (request, response) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                if ($scope.DepotId == undefined) {
                    alert("Please Select Depot");
                    //$scope.errMsg = "Please Select Depot";
                    //ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    //ErrorFound = true;
                    //return;
                }

                var InputParam = {
                    VehicleNo: $("#txtVehicleNo").val(),
                    DepotId: $scope.DepotId,
                    LocationId: $sessionStorage.locationId
                }
                
                $.ajax({
                    url: baseUrl + '/Transport/VehicleMaster/GetVehicleDepotWiseLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.VehicleNo,
                                VehicleId: item.VehicleId,
                                LastInspectionDate: item.LastInspectionDate
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    $scope.VehicleNo = i.item.label;
                    $scope.VehicleId = i.item.VehicleId;
                    $scope.LastInspectionDate = i.item.LastInspectionDate;
                    $scope.SearchVehicle();
                    $scope.isShownVehicle = true;
                    $scope.isShownDepot = true;
                });
            },
            minLength: 1
        });

        
        //var d = new Date();
        //$scope.InspDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
    }

    function SearchVehicleById() {
        
        var InputParam = {
            VehicleId: $scope.VehicleId,
            LocationId: $scope.LocationId
        }
        var VehicleData = VehicleAJService.GetVehicleDtlsById(InputParam);
        VehicleData.then(function (result) {
            
            $scope.VehicleId = result.data.VehicleId;
            $scope.LocationId = result.data.LocationId;
            $scope.VehicleNo = result.data.VehicleNo;
            $scope.TruckType1 = result.data.TruckTypeName;
            $scope.EquipmentType = result.data.EquipTypeName;
            $scope.LastMeterReading = result.data.LatestMeterReading;
        });
    }


    $scope.GetDataSearch = function (row) {

        ClearData();
        $scope.isShownAdd = false;
        $scope.isShown = false;
        $scope.isShownPattern = false;
        $scope.isInWrdTrans = true;
        $scope.isShownSave = true;
        $scope.isShownPattern = false;
        $scope.isShownCheckType = false
        $scope.isShownClear = true;
        $scope.isShownSearch = false
        $scope.isShownVehicle = true;
        $scope.isShownDepot = true;

        $scope.Pkey= $scope.Pkey1

        $scope.VehicleNo = row.VEHICLE_NO;
        $scope.VehicleId = row.VEHICLE_ID;
        $scope.DepotId = $scope.FilterDepotId;
        SearchVehicleById();
        FillCheckList();

        $("#divQlist").modal('hide');

    }

    function FillCheckList() {
        
        var InputParam = {
            Gkey: $scope.Pkey1,
            VehicleId: $scope.VehicleId
        }
        var GetData = WeeklyInspectionCtrlAJService.GetAllDailyWeelyListByVehicle(InputParam);
    GetData.then(function (Response) {
        $scope.DailyWeeklycheckList = Response.data;
    });
    }


    $scope.SearchVehicle = function () {
        SearchVehicleById();
        FillCheckList();
    }

      
    function DailyWeeklyCheck() {
        
        var GetData = WeeklyInspectionCtrlAJService.GetDailyWeeklyLookupList();
        GetData.then(function (Response) {
            $scope.DailyWeeklyList = Response.data;
            //setTimeout(function () {
            //    $scope.Pkey = 102;
            //}, 1000);
        });
    }

    //$scope.DailyWeeklylistChange = function (Pkey) {
    //    
    //    var InputParm = {
    //        Gkey: Pkey
    //    }

    //    var GetData = WeeklyInspectionCtrlAJService.GetAllDailyWeelyListById(InputParm);
    //      GetData.then(function (Response) {
    //        $scope.DailyWeeklycheckList = Response.data;
    //    });
        
    //}


    function DailyWeeklyListDtls(Pkey){
        
        var InputParm = {
            Gkey: Pkey
        }
        var GetData = WeeklyInspectionCtrlAJService.GetAllDailyWeelyListById(InputParm);
        GetData.then(function (Response) {
            $scope.DailyWeeklycheckList = Response.data;
        });
    }

    $scope.SaveJobDtls = function () {
        

        if ($scope.ExpBeginDate == undefined || $scope.ExpBeginDate == "") {
            $scope.errMsg = "Please Enter Expected Begin Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.ExpCompDate == undefined || $scope.ExpCompDate == "") {
            $scope.errMsg = "Please Enter Expected Comp Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }


        var fDate = getDDMMYYYYHHMI($scope.ExpBeginDate);
        var tDate = getDDMMYYYYHHMI($scope.ExpCompDate);
        var curdate = new Date();

        if (fDate < curdate) {
            $scope.errMsg = " Expected Begin Date should be greater than Current Date";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if (tDate < fDate) {
            $scope.errMsg = " Expected Comp Date should be greater than Expected Begin Date";
             ErrorMsgDisplay.ErrorMsg('ErrorDiv');
             ErrorFound = true;
             return;
        }
       

        if ($scope.ScheduleId == undefined || $scope.ScheduleId == "0") {
            $scope.errMsg = "Please Select Schedule Type";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.InspId == undefined || $scope.InspId == "0") {
            $scope.errMsg = "Inspection not Done";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }
        
             var InputParam = {
            InspId: $scope.InspId,
            ExpBeginDate: $scope.ExpBeginDate,
            ExpCompDate: $scope.ExpCompDate,
            ScheduleId: $scope.ScheduleId,
            LocationId: $sessionStorage.locationId
        }
        var getData = JobAllocationAJService.saveJobData(InputParam);
        getData.then(function (Response) {
            
            if (Response.data.ErrorMessage != "" && Response.data.ErrorMessage != null) {
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                ErrorFound = true;
                return;
            }
            else {
                $scope.WisId = Response.data.WisId;
                $scope.JobNo = Response.data.JobNo;
                $("#JobCardDiv").hide();
                $scope.isShownrr = true;
                $scope.isShownReceive = true;
                $scope.errMsg = 'Job No. ' + Response.data.JobNo + ' Opened.'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
            }
        });

    }

    $scope.SaveDtls = function () {
        

        if ($scope.VehicleId == undefined || $scope.VehicleId == "0") {
            $scope.errMsg = "Please Enter Vehicle No";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.LatestMeterReading == undefined || $scope.LatestMeterReading == "0") {
            $scope.errMsg = "Please Enter Latest Reading";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }
        
        if ($scope.LastMeterReading != undefined && $scope.LatestMeterReading > 0 && $scope.LastMeterReading > $scope.LatestMeterReading ) {
            $scope.errMsg = "Please Enter Latest Reading more than Last Reading";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.Pkey == undefined || $scope.Pkey == "0") {
            $scope.errMsg = "Please Select Check Type";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }

        if ($scope.DepotId == undefined || $scope.DepotId == "0") {
            $scope.errMsg = "Please Select Depot";
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            ErrorFound = true;
            return;
        }
   
        
        var ErrorFound = false;
        angular.forEach($scope.DailyWeeklycheckList, function (value, key) {
            if (ErrorFound == false) {
                
                if ((value.Remarks == undefined || value.Remarks == "") && (value.CheckStatus == "NOT OK")) {
                    $scope.errMsg = "Please Enter Remarks";
                    ErrorFound = true;
                    return;
                }
                if ((value.CheckStatus == undefined || value.CheckStatus == "") && (value.JobStatus == "Y")) {
                    $scope.errMsg = "Please Select Check Status";
                    ErrorFound = true;
                    return;
                }
            }
        })
           
        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        var d = new Date();
        $scope.InspDate = padToFour(d.getDate()) + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());

        var InputParam = {
            InspId : $scope.InspId,
            InspTransNbr : $scope.InspTransNbr,
            InspDate : $scope.InspDate,
            VehicleId : $scope.VehicleId,
            CheckTypeId : $scope.Pkey,
            LastReading : $scope.LastMeterReading,
            LastestReading: $scope.LatestMeterReading,
            DepotId: $scope.DepotId,
            DiffKm : $scope.LatestMeterReading - $scope.LastMeterReading,
            VehicleInspectionDtlsList: $scope.DailyWeeklycheckList,
            LocationId: $sessionStorage.locationId
        }
        var getData = WeeklyInspectionCtrlAJService.saveData(InputParam);
        getData.then(function (Response) {
            
            if (Response.data.ErrorMessage != "" && Response.data.ErrorMessage != null) {
                //alert(Response.data.ErrorMessage);
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                ErrorFound = true;
                return;

                //var d = new Date();
                //$scope.InwrdDate = padToFour(d.getDate()) + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());
            }
            else {
                $scope.InspTransNbr = Response.data.InspTransNbr;
                $scope.InspDate = Response.data.InspDate;
                $scope.InspId = Response.data.InspId;
                
                //ConfirmDialog('Do You Wand to Open Job Order');
               
                ListDataTest = $scope.DailyWeeklycheckList.filter(function (value) {
                    return value.CheckStatus == "NOT OK"
                });

                if (ListDataTest.length>0)
                {
                    $.confirm({
                        title: 'Job!',
                        content: 'Do you wand to Open Job Card!',
                        buttons: {
                            confirm: function () {
                                $("#JobCardDiv").show();
                            },
                            cancel: function () {
                                //$.alert('Canceled!');
                                $scope.isShownrr = true;
                                $scope.isShownReceive = true;
                                $scope.errMsg = 'Data Saved'
                                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                            }

                        }
                    });

                }
            else
            {
                $scope.isShownrr = true;
                $scope.isShownReceive = true;
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
             };

                
                //$scope.isShownrr = true;
                //$scope.isShownReceive = true;
                //$scope.errMsg = 'Data Saved'
                //ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                $scope.isShownAdd = true;
                $scope.isShownSearch = true;
                $scope.isShownExit = true;
                $scope.isShownSave = false;
                $scope.isShownExit = false;
                $scope.isShownClear = false;
                $scope.isShown = true;
                $scope.isShownPattern = true;
                $scope.isShownCheckType = true


            }
        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    $scope.SearchDtls = function () {
        ClearData();
        $scope.isInWrdTrans = false;
        $scope.isShownVehicle = false;
        $scope.isShownDepot = false;

        //$scope.isShownAdd = false;
        //$scope.isShownEdit = true;
        //$scope.isShownSave = false;
        //$scope.isShownSearch = false;
        //$scope.isShownExit = false;
        //$scope.isShownClear = true;
        //$scope.isShownDispaly = true;
        //$scope.isInWrdTrans = false;
        $scope.isShownrr = true;

        // $scope.isShown = true;
        // var d = new Date();
        /// $scope.InwrdDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes());

        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        

        $("#txtVehicleNo").autocomplete({

            source: function (request, response) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                if ($scope.DepotId == undefined) {
                    //alert("Please Select Depot");
                    $scope.errMsg = "Please Select Depot";
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                    return;
                }

                var InputParam = {
                    VehicleNo: $("#txtVehicleNo").val(),
                    DepotId: $scope.DepotId,
                    CheckTypeId: $scope.Pkey1,
                    LocationId: $sessionStorage.locationId
                }
                
                $.ajax({
                    url: baseUrl + '/Transport/VehicleMaster/GetVehicleDepotWiseSearchInspeLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.VehicleNo,
                                VehicleId: item.VehicleId,
                                LastInspectionDate: item.LastInspectionDate
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    
                    $scope.VehicleNo = i.item.label;
                    $scope.VehicleId = i.item.VehicleId;
                    $scope.LastInspectionDate = i.item.LastInspectionDate;
                    $scope.SearchVehicle();
                    $scope.isShownVehicle = true;
                    $scope.isShownDepot = true;
                });
            },
            minLength: 1
        });

        $("#txtInspTransNo").autocomplete({
            
            source: function (request, response) {
                
                var $scope = angular.element(document.getElementById('bigform')).scope();
                if ($scope.VehicleId == undefined) {
                    //alert("Please Enter Vehicle No");
                    $scope.errMsg = "Please Enter Vehicle No";
                    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                    ErrorFound = true;
                    return;
                }
                
                var InputParam = {
                    InspTransNbr: $("#txtInspTransNo").val(),
                    VehicleId: $scope.VehicleId,
                    CheckTypeId: $scope.Pkey1,
                    LocationId: $sessionStorage.locationId
                }
                $.ajax({
                    url: baseUrl + '/Maintenance/WeeklyInspection/GetVehicleInspectionLookup',
                    data: JSON.stringify(InputParam),
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        response($.map(data, function (item, key) {
                            return {
                                label: item.InspTransNbr,
                                InspId: item.InspId
                            }
                        }))
                    },
                    error: function (response) {
                        //alert(response.responseText);
                    },
                    failure: function (response) {
                        //alert(response.responseText);
                    }
                });
            },
            select: function (e, i) {
                
                var $scope = angular.element(document.getElementById('bigform')).scope();
                $scope.$apply(function () {
                    $scope.InspTransNbr = i.item.InspTransNbr;
                    $scope.InspId = i.item.InspId;
                    $sessionStorage.InspId = JSON.stringify(i.item.InspId);
                    DisplayData();
                    SearchVehicleById();
                    $scope.isInWrdTrans = true;
                });
            },
            minLength: 1
        });
               
    }


    function DisplayData() {
        
        var $scope = angular.element(document.getElementById('bigform')).scope();
        var InputParam = {
            InspId: $scope.InspId
        }
        var getData = WeeklyInspectionCtrlAJService.GetVehicleInspectionHdrByID(InputParam);
        getData.then(function (Response) {
            $scope.InspTransNbr = Response.data.InspTransNbr;
            $scope.InspId = Response.data.InspId;
            $scope.InspDate = Response.data.InspDate;
            $scope.LastMeterReading = Response.data.LastReading;
            $scope.LatestMeterReading = Response.data.LastestReading;
            $scope.Pkey = Response.data.CheckTypeId;
            $scope.DepotId = Response.data.DepotId;
            $scope.VehicleId = Response.data.VehicleId;

            $scope.DailyWeeklycheckList = Response.data.VehicleInspectionDtlsList;
            

        }, function (reason) {
            $scope.errMsg = "Error in getting locations " + reason.data;
            $scope.isError = true;
            return;
        });
    }


    function getDDMMYYYYHHMI(obj) {
        var objParts = obj.split(" ");
        var objDateParts = objParts[0].split("/");
        if (objParts[1] != null) {
            var objTimeParts = objParts[1].split(":");
        }

        var newObj = new Date();
        newObj.setMonth(Number(objDateParts[1]) - 1);
        newObj.setYear(objDateParts[2]);
        newObj.setDate(objDateParts[0]);
        if (objParts[1] != null) {
            newObj.setHours(objTimeParts[0]);
            newObj.setMinutes(objTimeParts[1]);
        }
        return newObj;
    }

    //function ConfirmDialog(message) {
    //    $('<div></div>').appendTo('body')
    //                    .html('<div><h6>' + message + '?</h6></div>')
    //                    .dialog({
    //                        modal: true, title: 'Job Order', zIndex: 10000, autoOpen: true,
    //                        width: 'auto', resizable: false,
    //                        buttons: {
                                
    //                            Yes: function () {
    //                                
    //                                // $(obj).removeAttr('onclick');                                
    //                                // $(obj).parents('.Parent').remove();

    //                                $('body').append('<h1>Confirm Dialog Result: <i>Yes</i></h1>');

    //                                $(this).dialog("close");
    //                            },
    //                            No: function () {
    //                                $('body').append('<h1>Confirm Dialog Result: <i>No</i></h1>');

    //                                $(this).dialog("close");
    //                            }
    //                        },
    //                        close: function (event, ui) {
    //                            $(this).remove();
    //                        }
    //                    });
    //};



    $scope.CheckAll = function (SelectAllData) {
        
        angular.forEach($scope.DailyWeeklycheckList, function (value, key) {
            if ($scope.SelectAllData == 'N') {
                value.JobStatus = "N";
            }
            else {
                if ($scope.SelectAllData == 'Y') {
                    value.JobStatus = "Y";
                }
            }
        })
    };

});