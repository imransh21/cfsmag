﻿app.service("WeeklyInspectionCtrlAJService", function ($http) {

    var getUrl = window.location;
    var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];

    this.GetDailyWeeklyLookupList = function () {
        var response = $http({
            method: "post",
            url: baseUrl + "/WeeklyInspection/GetDailyWeeklyCheck",
            dataType: "json"
        });
        return response;
    }



    this.GetAllDailyWeelyListById = function (Input) {
        var response = $http({
            method: "post",
            url: baseUrl + "/WeeklyInspection/GetAllDailyWeelyListById",
            data: JSON.stringify(Input),
            dataType: "json"
        });
        return response;
    }

    this.GetAllDailyWeelyListByVehicle = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/WeeklyInspection/GetAllDailyWeelyListByVehicle",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }


    this.saveData = function (Input) {
        var response = $http({
            method: "post",
            url: baseUrl + "/WeeklyInspection/SavaDetails",
            data: JSON.stringify(Input),
            dataType: "json"
        });
        return response;
    }


    this.GetVehicleInspectionHdrByID = function (InputParam) {
        var response = $http({
            method: "post",
            url: baseUrl + "/WeeklyInspection/GetRetrieveData",
            data: JSON.stringify(InputParam),
            dataType: "json"
        });
        return response;
    }
    
});