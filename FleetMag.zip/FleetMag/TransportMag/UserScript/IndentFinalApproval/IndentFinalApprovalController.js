﻿app.controller("IndentFinalAppvlCtrl", function ($scope, $state, $timeout, $sessionStorage, $filter, ErrorMsgDisplay, IndentFinalAppvlAJService, IndentGenAJService) {
    $scope.isShownAdd = true;
    $scope.isShownEdit = false;
    $scope.isShownSave = false;
    $scope.isShownSearch = true;
    $scope.isShownExit = true;
    $scope.isShownClear = false;
    $scope.isShown = true;
    $scope.isShownDispaly = false;
    $scope.isShownIndent = true;
    $scope.IsFinalApprove = 'N';
    $scope.IsReject = 'N';
    $scope.IsApprove = 'N';
    $scope.IsIndentchk = 'N';
    //GetAllIndentDetails();
    $scope.SelectAllData = 'N';
    $scope.SelectAllRejectData = 'N'
    var d = new Date();
    $scope.IndentDate = d.getDate() + "/" + padToFour(parseInt(d.getMonth()) + 1) + "/" + d.getFullYear() + " " + padToFour(d.getHours()) + ":" + padToFour(d.getMinutes())
    function padToFour(number) {
        if (number <= 99) { number = ("00" + number).slice(-2); }
        return number;
    }
    $scope.IndentDetailsList = [];

    DepoLookupList();
    $scope.DetailsEnabled = function (row, index) {


        if (row.IsIndentchk == 'Y') {
            //$('#exbtn' + index).removeAttr('disabled', 'disabled');
            
        } else {
            //$('#exbtn' + index).attr('disabled', 'disabled');
        }
    }

    $scope.SelectAllApproveRows = function (SelectAllData) {
        
        angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value, key) {
            if ($scope.IndentList[$scope.DtlCurrentIndex].SelectAllData == 'N') {
                value.IsApprove = 'N';
            }
            else {
                if ($scope.IndentList[$scope.DtlCurrentIndex].SelectAllData == 'Y') {
                    value.IsApprove = 'Y';
                    //id = "#SelectAllRejectData" + $scope.DtlCurrentIndex
                    //$(id).prop("checked", false);
                    $scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData = 'N';
                    angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value, key) {
                       
                            value.IsReject = 'N';
                        
                    });
                }
            }
        })
    };

    $scope.SelectAllRejectRows = function (SelectAllRejectData) {
        
        
        angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value, key) {
            if ($scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData == 'N') {
                value.IsReject = 'N';
            }
            else {
                if ($scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData == 'Y') {
                    value.IsReject = 'Y';
                    $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = 'N';
                    //id = "#SelectAllData" + $scope.DtlCurrentIndex
                    //$(id).prop("checked", false);

                    angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value, key) {

                        value.IsApprove = 'N';

                    });
                }
            }
        })
    };




    $scope.RejectChange = function (row) {
        

        if (row.IsReject == "Y") {
            row.IsApprove = "N";
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = "N";
           // $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = 'N';
            //id = "#SelectAllData" + $scope.DtlCurrentIndex
            //$(id).prop("checked", false);
        }
        else
        {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = "N";
        }


        IndentListDataTest = $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.filter(function (value) {
            return value.IsReject == "Y"
        });
        if ($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.length != IndentListDataTest.length) {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData = 'N';
        }
        else
        {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData = 'Y';
        }
    }


    $scope.ApproveChange = function (row) {
        
        if (row.IsApprove == "Y") {
            row.IsReject = "N";
            row.FinalRejectRemark = undefined;
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData = 'N'
            //id = "#SelectAllRejectData" + $scope.DtlCurrentIndex
            //$(id).prop("checked", false);
        }
        else
        {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllRejectData = 'N'

        }
        
        IndentListDataTest = $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.filter(function (value) {
            return value.IsApprove == "Y" 
        });
        if ($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.length != IndentListDataTest.length)
        {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = 'N';
        }
        else
        {
            $scope.IndentList[$scope.DtlCurrentIndex].SelectAllData = 'Y';
        }


    }



    $scope.ExitDtls = function () {
        getIndexpage();
    }

    function getIndexpage() {
        var getUrl = window.location;
        var baseUrl = getUrl.protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        window.location.href = baseUrl + "/Home/Store";
    }




    $scope.SaveDtls = function () {
        
     
        var ErrorFound = false;
        //angular.forEach($scope.IndentList, function (value, key) {
        //    if (ErrorFound == false) {
        //        if (value.IsIndentchk == "Y" && value.IsFinalApprove == "N") {

        //            $scope.errMsg = "Please Select Final Approve CheckBox For Indent No:- " + value.IndentNo

        //            ErrorFound = true;
        //            return;
        //        }
        //    } if (ErrorFound == false) {
        //        if (value.IsIndentchk == "N" && value.IsFinalApprove == "Y") {

        //            $scope.errMsg = "Please Select Indent CheckBox For Indent No:- " + value.IndentNo
        //            ErrorFound = true;
        //            return;
        //        }
        //    }
           
        //if (value.IsIndentchk == "Y" && value.IsFinalApprove == "Y") {

        IndentListData = $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.filter(function (value) {
            return value.IsApprove == "Y" || value.IsReject == "Y";
        });


        if (IndentListData.length <= 0) {
            $scope.errMsg = "Please Select Atleast One Item.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }

        angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value1, key) {
            
                    //if (ErrorFound == false) {
                    //    if (value1.IsApprove == "N" && value1.IsReject == "N") {

                    //        $scope.errMsg = "Please Select Approve/Reject Item For Indent No:- " + value.IndentNo
                    //        ErrorFound = true;
                    //        return;
                    //    }
                    //}
                    if (ErrorFound == false) {
                        if (value1.IsReject == "Y" && (value1.FinalRejectRemark == undefined || value1.FinalRejectRemark == "")) {

                            $scope.errMsg = "Please Enter Reject Remark For Indent No:- " + value1.PartName
                            ErrorFound = true;
                            return;
                        }
                    }
                
                });
        //}
        //});



        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
       

        var InputParam = {
            IndentDtlsList: $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList
        }
        var GetData = IndentFinalAppvlAJService.saveData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                //GetAllIndentDetails();

                $scope.GetAllIndentDetailsFilter();
            }
        });
    }





    $scope.SubmitDtls = function () {
        

        var ErrorFound = false;
        

        //IndentListData = $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList.filter(function (value) {
        //    return value.IsApprove == "Y" || value.IsReject == "Y";
        //});


        //if (IndentListData.length <= 0) {
        //    $scope.errMsg = "Please Select Atleast One Item.";

        //    ErrorMsgDisplay.ErrorMsg('ErrorDiv');
        //    return;
        //}

        angular.forEach($scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList, function (value1, key) {
            
            if (ErrorFound == false) {
                if (value1.IsApprove == "N" && value1.IsReject == "N") {

                    $scope.errMsg = "Please Select Approve/Reject Item For Item Name:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }
            }
            if (ErrorFound == false) {
                if (value1.IsReject == "Y" && (value1.FinalRejectRemark == undefined || value1.FinalRejectRemark == "")) {

                    $scope.errMsg = "Please Enter Reject Remark For Item Name:- " + value1.PartName
                    ErrorFound = true;
                    return;
                }
            }

        });
        //}
        //});

        if (ErrorFound == true) {
            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }


        var InputParam = {
            IndentRefId: $scope.IndentList[$scope.DtlCurrentIndex].IndentRefId,
            IndentDtlsList: $scope.IndentList[$scope.DtlCurrentIndex].IndentDtlsList
        }
        var GetData = IndentFinalAppvlAJService.SubmitData(InputParam);
        GetData.then(function (Response) {
            if (Response.data.ErrorMessage != null && Response.data.ErrorMessage != "") {
                //$scope.errMsg = pItemMasterAJService.data.ErrorMessage;
                //$scope.setclass = "popupBase alert alertShowMsg";
                //$scope.isError = true;
                $scope.errMsg = Response.data.ErrorMessage;
                ErrorMsgDisplay.ErrorMsg('ErrorDiv');
                return;
            }
            else {
                $scope.errMsg = 'Data Saved'
                ErrorMsgDisplay.ErrorMsg('ErrorDivG');
                //GetAllIndentDetails();
                $scope.GetAllIndentDetailsFilter();
            }
        });
    }



    $scope.DisplayData = function () {
        SerachIndentDetails();
    }

    function GetAllIndentDetails() {
        var InputParam = {
            IndentRefId: $scope.IndentRefId,
            DepotID: $scope.DepotID,
            fromDate: $scope.FromDate,
            Todate: $scope.Todate
        }
        var GetData = IndentFinalAppvlAJService.GetIndentData();
        GetData.then(function (Response) {
            
            //$scope.IndentNo = Response.data.IndentNo;
            //$scope.IndentDate = Response.data.IndentDate;
            //$scope.NatureOfIndent = Response.data.NatureOfIndent;
            //$scope.DepotCode = Response.data.DeportCd;
            //   $scope.ExpDelvDate = Response.data.ExpDelvDate;
            $scope.IndentList = Response.data;
            // $scope.IndentDetailsList = Response.data.IndentDtlsList;
            //$scope.isShownIndent = true;

        });
    }
    function DepoLookupList() {
        var GetData = IndentGenAJService.GetDepoLookupList();
        GetData.then(function (Response) {
            $scope.DepoLookupList = Response.data;
        });
    }

    $scope.GetAllIndentDetailsFilter = function () {
        

        if ($scope.DepotId == undefined || $scope.DepotId == '') {
            $scope.errMsg = "Please Select Depot.";

            ErrorMsgDisplay.ErrorMsg('ErrorDiv');
            return;
        }
        
        var InputParam = {
            IndentRefId: $scope.IndentRefId,
            DepotID: $scope.DepotId,
            fromDate: $scope.FromDate,
            Todate: $scope.Todate
        }
        var GetData = IndentFinalAppvlAJService.GetIndentData(InputParam);
        GetData.then(function (Response) {
            
            //$scope.IndentNo = Response.data.IndentNo;
            //$scope.IndentDate = Response.data.IndentDate;
            //$scope.NatureOfIndent = Response.data.NatureOfIndent;
            //$scope.DepotCode = Response.data.DeportCd;
            //   $scope.ExpDelvDate = Response.data.ExpDelvDate;
            $scope.IndentList = Response.data;
            // $scope.IndentDetailsList = Response.data.IndentDtlsList;
            //$scope.isShownIndent = true;

        });
    }



    $scope.CurrentIndex = function (row) {
        $scope.DtlCurrentIndex = row;
    }

    $scope.CurrentItemIndex = function (row) {
        $scope.ItemCurrentIndex = row;
    }

    $scope.CancelDtls = function () {
        $scope.GetAllIndentDetailsFilter();
    }


    $scope.ClearFilter = function () {
        $scope.IndentRefId=undefined;
        $scope.DepotId = undefined;
        $scope.FromDate= undefined;
        $scope.Todate = undefined;
        $scope.IndentNo = undefined;
        $scope.IndentRefId = undefined;
        $scope.IndentList = undefined;

   //     GetAllIndentDetails();
    }















});