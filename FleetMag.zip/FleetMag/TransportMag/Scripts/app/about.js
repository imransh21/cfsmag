﻿angular.module('main')
    .controller('AboutController', ['$scope', function ($scope) {

    }]);