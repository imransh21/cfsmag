﻿angular.module('main')
    .controller('MainController', ['$scope', function ($scope) {

    }]);