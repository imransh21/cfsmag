﻿angular.module('main')
    .controller('ContactController', ['$scope', function ($scope) {

    }]);