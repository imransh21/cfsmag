﻿
using System.Web;
using System.Web.Optimization;

namespace TransportMag
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/angular").Include(
                        "~/Scripts/angular.js",
                        "~/Scripts/angular-ng-grid.js",
                        "~/Scripts/angular-resource.js",
                        "~/Scripts/angular-route.js"));

            bundles.Add(new ScriptBundle("~/bundles/app").Include(
                        "~/Scripts/app/app.js",
                        "~/Scripts/app/services.js",
                        "~/Scripts/app/directives.js",
                        "~/Scripts/app/main.js",
                        "~/Scripts/app/contact.js",
                        "~/Scripts/app/about.js",
                        "~/Scripts/app/demo.js"
                        ));

            bundles.Add(new StyleBundle("~/bundles/UserScript").Include(
                "~/UserScript/Module.js",
                "~/UserScript/MainPage/MainController.js",
                "~/UserScript/MainPage/MainService.js",
                "~/UserScript/KeyReference/KeyRefrenceController.js",
                "~/UserScript/KeyReference/KeyRefrenceService.js",
                "~/UserScript/PatternConfiguration/PatternConfigurationController.js",
                "~/UserScript/PatternConfiguration/PatternConfigurationServices.js",
                "~/UserScript/TyreManagement/TyreManagementController.js",
                "~/UserScript/TyreManagement/TyreManagementService.js",
                "~/UserScript/VehicleMaster/VehicleController.js",
                "~/UserScript/VehicleMaster/VehicleService.js",
                "~/UserScript/UserMaster/UserMasterController.js",
                "~/UserScript/UserMaster/UserMasterService.js",
                "~/UserScript/Default/DefaultController.js",
                "~/UserScript/Default/DefaultService.js",
                "~/UserScript/RoleDefinition/Service.js",
                "~/UserScript/RoleDefinition/Controller.js",
                "~/UserScript/DepotMaster/DepotMasterController.js",
                "~/UserScript/DepotMaster/DepotMasterService.js",
                "~/UserScript/ItemsMaster/ItemsMasterController.js",
                "~/UserScript/ItemsMaster/ItemsMasterServices.js",
                "~/UserScript/IndentGeneration/IndentGenController.js",
                "~/UserScript/IndentGeneration/IndentGenService.js",
                "~/UserScript/IndentApproval/IndentApprovalController.js",
                "~/UserScript/IndentApproval/IndentApprovalService.js",
                "~/UserScript/IndentFinalApproval/IndentFinalApprovalController.js",
                "~/UserScript/IndentFinalApproval/IndentFinalApprovalService.js",
                "~/UserScript/VendorMaster/VendorMasterController.js",
                "~/UserScript/VendorMaster/VendorMasterService.js",
                "~/UserScript/POMapping/POMappingController.js",
                "~/UserScript/POMapping/POMappingService.js",
                "~/UserScript/QuotationReq/QuotationReqController.js",
                "~/UserScript/QuotationReq/QuotationReqService.js",
                "~/UserScript/GoodsReceiptGSecurity/GoodsReceiptGSecurityController.js",
                "~/UserScript/GoodsReceiptGSecurity/GoodsReceiptGSecurityServices.js",
                "~/UserScript/GoodsReceiptStore/GoodsReceiptStoreController.js",
                "~/UserScript/GoodsReceiptStore/GoodsReceiptStoreServices.js",
                "~/UserScript/GoodsReceiptGSecurityPrint/GoodsReceiptGSecurityPrintController.js",
                "~/UserScript/GoodsReceiptGSecurityPrint/GoodsReceiptGSecurityPrintServices.js",
                "~/UserScript/GoodsReceiptStorePrint/GoodsReceiptStorePrintController.js",
                "~/UserScript/GoodsReceiptStorePrint/GoodsReceiptStorePrintServices.js",
                "~/UserScript/GoodsReceiptStore/GoodsReceiptStoreServices.js",
                "~/UserScript/QuotationUploading/QuotationUploadingController.js",
                "~/UserScript/QuotationUploading/QuotationUploadingService.js",
                "~/UserScript/GoodsReceiptStore/GoodsReceiptStoreServices.js",
                "~/UserScript/PoGeneration/PoGenerationController.js",
                "~/UserScript/PoGeneration/PoGenerationServices.js",
                "~/UserScript/IndentGenarationPrint/IndentGenarationPrintController.js",
                "~/UserScript/IndentGenarationPrint/IndentGenarationPrintService.js",
                "~/UserScript/POApproval/POApprovalController.js",
                "~/UserScript/POApproval/POApprovalServices.js",
                "~/UserScript/DailyChecks/DailyChecksController.js",
                "~/UserScript/DailyChecks/DailyChecksService.js",
                "~/UserScript/POApproval/POApprovalServices.js",
                "~/UserScript/WeeklyInspection/WeeklyInspectionController.js",
                "~/UserScript/WeeklyInspection/WeeklyInspectionService.js",
                "~/UserScript/JobAllocation/JobAllocationController.js",
                "~/UserScript/JobAllocation/JobAllocationService.js",
                "~/UserScript/CrewMaster/CrewMasterController.js",
                "~/UserScript/CrewMaster/CrewMasterService.js",
                "~/UserScript/EmployeeMasterPage/EmployeeMasterController.js",
                "~/UserScript/EmployeeMasterPage/EmployeeMasterService.js",
                "~/UserScript/GoodsIssueJob/GoodsIssueJobController.js",
                "~/UserScript/GoodsIssueJob/GoodsIssueJobServices.js",
                 "~/UserScript/DriverMasterPage/DriverMasterController.js",
                "~/UserScript/DriverMasterPage/DriverMasterService.js",
                "~/UserScript/GoodsReturnJob/GoodsReturnJobController.js",
                "~/UserScript/GoodsReturnJob/GoodsReturnJobServices.js",
                "~/UserScript/DriverMasterPage/DriverMasterService.js",
                "~/UserScript/GoodsIssueJobPrint/GoodsIssueJobPrintController.js",
                "~/UserScript/GoodsIssueJobPrint/GoodsIssueJobPrintService.js",
                "~/UserScript/GoodsReturnJobPrint/GoodsReturnJobPrintController.js",
                "~/UserScript/GoodsReturnJobPrint/GoodsReturnJobPrintService.js",
                "~/UserScript/ServiceScheduleMaster/ServiceScheduleMasterController.js",
                "~/UserScript/ServiceScheduleMaster/ServiceScheduleMasterServices.js",
                "~/UserScript/JobCard/JobCardController.js",
                "~/UserScript/JobCard/JobCardService.js",
                "~/UserScript/ServiceScheduleMaster/ServiceScheduleMasterServices.js",
                "~/UserScript/JOBCardCreation/JOBCardCreationController.js",
                "~/UserScript/JOBCardCreation/JOBCardCreationServices.js",
                "~/UserScript/VehicleMaintReport/VehicleMaintReportController.js",
                "~/UserScript/VehicleMaintReport/VehicleMaintReportService.js",
                "~/UserScript/CustomerMaster/CustomerMasterController.js",
                "~/UserScript/CustomerMaster/CustomerMasterService.js",
                "~/UserScript/Booking/BookingController.js",
                "~/UserScript/Booking/BookingService.js",
                "~/UserScript/JobExecution/JobExecutionController.js",
                "~/UserScript/JobExecution/JobExecutionService.js",
                "~/UserScript/VehicleTracking/VehicleTrackingController.js",
                "~/UserScript/VehicleTracking/VehicleTrackingService.js",
                "~/UserScript/WarehouseDefination/WarehouseDefinationController.js",
                "~/UserScript/WarehouseDefination/WarehouseDefinationService.js",
                "~/UserScript/ProjectedWHPlanning/ProjectedWHPlanningController.js",
                "~/UserScript/ProjectedWHPlanning/ProjectedWHPlanningService.js",
                "~/UserScript/WarehouseView/WarehouseViewController.js",
                "~/UserScript/WarehouseView/WarehouseViewService.js",
                "~/UserScript/TariffHeadMaster/TariffHeadMasterController.js",
                "~/UserScript/TariffHeadMaster/TariffHeadMasterService.js",
                "~/UserScript/TaxTypesMaster/TaxTypesMasterController.js",
                "~/UserScript/TaxTypesMaster/TaxTypesMasterService.js",
                "~/UserScript/TaxGroupsMaster/TaxGroupsMasterController.js",
                "~/UserScript/TaxGroupsMaster/TaxGroupsMasterService.js",
                "~/UserScript/TaxHeadMatrix/TaxHeadMatrixController.js",
                "~/UserScript/TaxHeadMatrix/TaxHeadMatrixService.js",
                "~/UserScript/GoodsTransfer/GoodsTransferController.js",
                "~/UserScript/GoodsTransfer/GoodsTransferServices.js",
                "~/UserScript/GoodsReturnStore/GoodsReturnStoreController.js",
                "~/UserScript/GoodsReturnStore/GoodsReturnStoreServices.js",
                "~/UserScript/GoodsReturnGateSecurity/GoodsReturnGateSecurityController.js",
                "~/UserScript/GoodsReturnGateSecurity/GoodsReturnGateSecurityServices.js",
                "~/UserScript/Default/DefaultController1.js",
                "~/UserScript/PortalQuotationUploading/PortalQuotationUploadingController.js",
                "~/UserScript/PortalQuotationUploading/PortalQuotationUploadingService.js",
                "~/UserScript/PortalPOApproval/PortalPOApprovalController.js",
                "~/UserScript/PortalPOApproval/PortalPOApprovalServices.js",
                "~/UserScript/POPayment/POPaymentController.js",
                "~/UserScript/POPayment/POPaymentServices.js",
                "~/UserScript/EqipmentTransfer/EqipmentTransferController.js",
                "~/UserScript/EqipmentTransfer/EqipmentTransferServices.js",
                "~/UserScript/EqipmentTransferApproval/EqipmentTransferApprovalController.js",
                "~/UserScript/EqipmentTransferApproval/EqipmentTransferApprovalServices.js",
                "~/UserScript/EquipGateInDistPendency/EquipGateInDistPendencyController.js",
                "~/UserScript/EquipGateInDistPendency/EquipGateInDistPendencyServices.js",
                "~/UserScript/EqipmentTransferApproval/EqipmentTransferApprovalServices.js",
                 "~/UserScript/EquipmentGateOut/EquipmentGateOutController.js",
                "~/UserScript/EquipmentGateOut/EquipmentGateOutServices.js",
                "~/UserScript/JobCompletionStatus/JobCompletionStatusController.js",
                "~/UserScript/JobCompletionStatus/JobCompletionStatusServices.js",
                "~/UserScript/EquipmentGateOut/EquipmentGateOutServices.js",
                "~/UserScript/EquipGateInOrigin/EquipGateInOriginController.js",
                "~/UserScript/EquipGateInOrigin/EquipGateInOriginServices.js",
                "~/UserScript/JobCompletionStatus/JobCompletionStatusServices.js",
                "~/UserScript/EquipGateOutFromDist/EquipGateOutFromDistController.js",
                "~/UserScript/EquipGateOutFromDist/EquipGateOutFromDistServices.js",
                "~/UserScript/RackDefination/RackDefinationController.js",
               "~/UserScript/RackDefination/RackDefinationService.js",
               "~/UserScript/RackDefinationPrint/RackDefnController.js",
               "~/UserScript/RackDefinationPrint/RackDefnService.js",
               "~/UserScript/RackBinView/RackBinViewController.js",
               "~/UserScript/RackBinView/RackBinViewService.js",
               "~/UserScript/WarehouseCreation/WarehouseCreationController.js",
               "~/UserScript/WarehouseCreation/WarehouseCreationService.js",
               "~/UserScript/GeneralItemReq/GeneralItemReqController.js",
               "~/UserScript/GeneralItemReq/GeneralItemReqService.js",
               "~/UserScript/GeneralItemIssue/GeneralItemIssueController.js",
               "~/UserScript/GeneralItemIssue/GeneralItemIssueService.js",
               "~/UserScript/AMCDetails/AMCDetailsController.js",
               "~/UserScript/AMCDetails/AMCDetailsService.js",
               "~/UserScript/AMCIndentGeneration/AMCIndentGenController.js",
               "~/UserScript/AMCIndentGeneration/AMCIndentGenService.js",
               "~/UserScript/AMCReport/AMCReportController.js",
               "~/UserScript/AMCReport/AMCReportService.js",
               "~/UserScript/IndentGenrationApproval/IndentGenrationApprovalController.js",
               "~/UserScript/IndentGenrationApproval/IndentGenrationApprovalReport.js",
               "~/UserScript/MaterialRetrunToVendor/MaterialRetrunToVendorController.js",
               "~/UserScript/MaterialRetrunToVendor/MaterialRetrunToVendorService.js",
               "~/UserScript/MateraialReceivefromMaintainceDept/MaterialRevfromMaintnceDeptController.js",
                "~/UserScript/MateraialReceivefromMaintainceDept/MaterialRevfromMaintnceDept.js",
                "~/UserScript/ScrapMaterialReport/ScrapMaterialReportController.js",
                "~/UserScript/ScrapMaterialReport/ScrapMaterialReport.js",
                "~/UserScript/InvStockRpt/InvStockRptController.js",
                "~/UserScript/InvStockRpt/InvStockRptService.js"	
              ));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new StyleBundle("~/Content/bootstrap").Include(
                "~/Content/bootstrap.css",
                "~/Content/bootstrap-responsive.css"
                ));


            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css",
                "~/Content/ng-grid.css"));

            bundles.Add(new StyleBundle("~/Content/themes/base/css").Include(
                        "~/Content/themes/base/jquery.ui.core.css",
                        "~/Content/themes/base/jquery.ui.resizable.css",
                        "~/Content/themes/base/jquery.ui.selectable.css",
                        "~/Content/themes/base/jquery.ui.accordion.css",
                        "~/Content/themes/base/jquery.ui.autocomplete.css",
                        "~/Content/themes/base/jquery.ui.button.css",
                        "~/Content/themes/base/jquery.ui.dialog.css",
                        "~/Content/themes/base/jquery.ui.slider.css",
                        "~/Content/themes/base/jquery.ui.tabs.css",
                        "~/Content/themes/base/jquery.ui.datepicker.css",
                        "~/Content/themes/base/jquery.ui.progressbar.css",
                        "~/Content/themes/base/jquery.ui.theme.css"));



        }
    }
}