﻿using System.Web;
using System.Web.Mvc;

namespace TransportMag
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
           filters.Add(new TransportMag.Filters.CompressAttribute());
           filters.Add(new TransportMag.Filters.UserAuthenticationFilter());
            //filters.Add(new TransportMag.Filters.SkipMyGlobalActionFilterAttribute());
           

        }
    }
}